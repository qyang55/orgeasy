# Design System — "Natural Clay"

Light-first warm enterprise theme for Organisation Strategy Studio: natural white
/ clay / olive surfaces, hairline borders, an earthy clay accent, Space Grotesk
numerals over DM Sans body copy.

All values are defined once in `src/styles.css` (`:root` / `.dark`) and mapped
to Tailwind utilities via `@theme inline`. Composable class helpers live in
`src/lib/design-system.ts` (`ds`, `chip`, `tones`).

**Golden rule:** never hardcode colors in components — no `text-white`,
`bg-black`, hex values, or raw palette utilities (`bg-emerald-500/15`).
Use tokens. Intentional exceptions: text painted on user-chosen org-chart
swatches, and canvas / PPTX / PDF export renderers (jsPDF, pptxgenjs, canvas
2D) which need literal color values.

---

## 1. Color tokens

### Surfaces (backgrounds by elevation)

| Token | Utility | Use |
|---|---|---|
| `--surface-1` | `bg-surface-1` / `bg-background` | App canvas |
| `--surface-2` | `bg-surface-2` / `bg-card` | Cards, panels, inputs |
| `--surface-3` | `bg-surface-3` | Raised/inset wells, secondary fills |
| `--surface-hover` | `bg-surface-hover` | Hover state for interactive surfaces |
| `--popover` | `bg-popover` | Floating layers (menus, dialogs) |

### Borders & focus

| Token | Utility | Use |
|---|---|---|
| `--border` | `border-border` | Hairline dividers, card outlines (default) |
| `--border-strong` | `border-border-strong` | Outline buttons, emphasized outlines, hover |
| `--input` | `border-input` | Form control outlines |
| `--ring` | `ring-ring` | Focus rings (always `ring-2 ring-ring/50`) |
| `--overlay` | `bg-overlay` | Modal/drawer scrim |

### Accents

| Token | Utility | Use |
|---|---|---|
| `--primary` | `bg-primary` / `text-primary` | Primary actions (action clay) |
| `--brand` | `bg-brand` / `text-brand` | Identity highlights, active states (olive) |
| `--brand-subtle` | `bg-brand-subtle` | Tinted brand backgrounds |

### Status (solid + subtle tint pairs)

| Tone | Solid | Subtle bg | Foreground |
|---|---|---|---|
| Success | `--success` | `--success-subtle` | `--success-foreground` |
| Warning | `--warning` | `--warning-subtle` | `--warning-foreground` |
| Danger | `--destructive` | `--destructive-subtle` | `--destructive-foreground` |
| Info | `--info` | `--info-subtle` | `--info-foreground` |

Pattern for chips/banners: solid token for text + 25% border + subtle tint
background. The `chip(tone)` helper and `tones` map in
`src/lib/design-system.ts` implement this; `<Badge variant="success" …>`
covers it in the ui primitives.

### Charts & sidebar

`--chart-1..5` (`bg-chart-1`…) for dataviz series; `--sidebar-*` for the app
shell navigation. Marketing surfaces (welcome hero) use the `--aurora-*`
palette only.

---

## 2. Typography scale

Fonts: `font-display` = Space Grotesk (headings, numerals, KPIs) ·
`font-sans` = DM Sans (body, labels). Metrics always use `tabular-nums`.

| Utility | Size | Use |
|---|---|---|
| `text-2xs` | 11px | Chips, badges, eyebrow labels |
| `text-xs` | 12px | Captions, helper text, table meta |
| `text-sm` | 14px | Body copy, buttons, inputs |
| `text-base` | 16px | Emphasized body |
| `text-lg` / `text-xl` | 18/20px | Card titles, medium metrics |
| `text-2xl` / `text-3xl` | 24/30px | Page titles |
| `text-[34px]` | 34px | Primary KPI numerals (via `ds.kpi`) |

Helpers: `ds.eyebrow` (uppercase tracking label), `ds.sectionTitle`,
`ds.kpi`, `ds.metric`, `ds.caption`.

---

## 3. Spacing scale

Tailwind 4px grid, no custom spacing tokens.

- Card padding: `p-5` / `p-6`
- Bento / card grids: `gap-4`
- Section stacks: `space-y-6`
- Page gutters: `px-6 lg:px-8`
- Dense toolbars/table rows: `gap-2`, `px-3 py-1.5`

---

## 4. Card & panel styles

| Pattern | Implementation |
|---|---|
| Standard card | `<Card>` — `rounded-xl border-border bg-card shadow-raised` |
| Floating panel | `ds.floating` — popover surface + `shadow-panel` |
| Inset well | `ds.inset` — `bg-surface-3` inside a panel |

Elevation scale: `shadow-raised` (cards) → `shadow-panel` (floating panels,
canvas toolbars) → `shadow-overlay` (dialogs/sheets). Radii: base 10px —
`rounded-md` 8px (controls), `rounded-lg` 10px (wells), `rounded-xl` 14px
(cards/panels).

---

## 5. Buttons

`<Button>` variants (`src/components/ui/button.tsx`):

- `default` — violet primary action (`bg-primary`, `shadow-raised`)
- `brand` — brand-violet emphasis action
- `secondary` / `subtle` — surface fills (`surface-3`, hover `surface-hover`)
- `outline` — `border-border-strong` on `surface-2`
- `ghost` — transparent, `surface-hover` on hover
- `destructive` / `success` — status actions
- `link` — inline text action

Sizes: `sm` 32px · `default` 36px · `lg` 40px · `icon` 36×36.
Focus is always `ring-2 ring-ring/50`.

## 6. Inputs & controls

`<Input>`, `<Textarea>`, `<SelectTrigger>` share one recipe:
`h-9 rounded-md border-input bg-surface-2` → hover `border-border-strong` →
focus `ring-2 ring-ring/50`. Placeholders use `text-muted-foreground`;
disabled uses `opacity-50`. Toggles/checkboxes/sliders inherit the same
`--border` / `--ring` tokens via the ui primitives.

---

## Adoption checklist for new UI

1. Surfaces: `bg-card` / `bg-surface-*` — never `bg-white`/`bg-black`/hex.
2. Status: `chip(tone)` or `<Badge variant="success|warning|danger|info|brand">`.
3. Headings/numerals: `font-display` + `tabular-nums` for metrics.
4. Borders: `border-border` (default), `border-border-strong` (emphasis).
5. Focus: `ds.focusRing` on custom interactive elements.
6. Shadow: `shadow-raised` / `shadow-panel` / `shadow-overlay` only.
