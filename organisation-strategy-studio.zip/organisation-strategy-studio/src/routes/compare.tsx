import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  ArrowRight,
  Download,
  GitCompareArrows,
  Minus,
  Pin,
  PinOff,
  Plus,
  Search,
  Shuffle,
} from "lucide-react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { AgentHeavyView } from "@/components/orgeasy/AgentHeavyView";
import { useOrgEasy } from "@/lib/orgeasy/store";
import {
  buildDrilldown,
  compareScenarios,
  diffToCsv,
  drilldownToNotes,
  effHeadcount,
  loadPinnedScopes,
  savePinnedScopes,
  scopeId,
  type DrilldownScope,
} from "@/lib/orgeasy/diff";
import { currentStateFor, phasesFor, resolveBaseline } from "@/lib/orgeasy/phases";
import { formatMoney } from "@/lib/orgeasy/impact";
import { downloadBlob } from "@/lib/orgeasy/csv";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/compare")({
  head: () => ({
    meta: [
      { title: "Current vs Future Comparison — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Compare any two org scenarios role by role: added, removed and changed positions plus headcount, cost, layer and span-of-control deltas.",
      },
      { property: "og:title", content: "Current vs Future Comparison — Organisation Strategy Studio" },
      {
        property: "og:description",
        content: "Role-level difference report between current and future organisation states.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ComparePage,
});

function Delta({
  value,
  suffix = "",
  invert = false,
}: {
  value: number;
  suffix?: string;
  invert?: boolean;
}) {
  const good = invert ? value <= 0 : value >= 0;
  if (!value) return <span className="text-muted-foreground">no change</span>;
  return (
    <span className={cn("font-semibold", good ? "text-success" : "text-destructive")}>
      {value > 0 ? "+" : ""}
      {Math.round(value).toLocaleString()}
      {suffix}
    </span>
  );
}

function ComparePage() {
  const { workspace, scenario } = useOrgEasy();
  /** Always default to today's baseline (500 positions) vs the programme end state (450). */
  const baselineScenario = currentStateFor(workspace.scenarios, scenario);
  const phases = phasesFor(workspace.scenarios, baselineScenario);
  const endState = phases[phases.length - 1] ?? null;

  const [baseId, setBaseId] = useState<string>(
    () =>
      baselineScenario?.id ??
      resolveBaseline(workspace.scenarios, scenario)?.id ??
      workspace.scenarios.find((s) => s.id !== scenario?.id)?.id ??
      "",
  );
  const base = workspace.scenarios.find((s) => s.id === baseId) ?? null;
  const [targetId, setTargetId] = useState<string>(
    () =>
      (scenario && scenario.id !== (baselineScenario?.id ?? "") ? scenario.id : null) ??
      endState?.id ??
      scenario?.id ??
      "",
  );
  const target = workspace.scenarios.find((s) => s.id === targetId) ?? endState ?? scenario ?? null;

  const diff = useMemo(
    () => (base && target && base.id !== target.id ? compareScenarios(base, target) : null),
    [base, target],
  );

  const cur = diff?.currency ?? "USD";

  const [scope, setScope] = useState<DrilldownScope | null>(null);
  const [mode, setMode] = useState<"roles" | "agent">("roles");
  const [pins, setPins] = useState<DrilldownScope[]>(() => loadPinnedScopes());
  const drill = useMemo(
    () => (diff && scope ? buildDrilldown(diff, scope) : null),
    [diff, scope],
  );
  const isPinned = (s: DrilldownScope) => pins.some((p) => scopeId(p) === scopeId(s));
  const togglePin = (s: DrilldownScope) => {
    const next = isPinned(s)
      ? pins.filter((p) => scopeId(p) !== scopeId(s))
      : [...pins, s];
    setPins(next);
    savePinnedScopes(next);
    toast.success(
      isPinned(s) ? "Removed from export notes" : "Pinned — this drill-down joins the exports",
    );
  };

  return (
    <div className="pb-14">
      <PageHeader
        title="Current vs future comparison"
        description="A role-level difference report between two scenarios — what was added, removed, retitled, re-costed or re-lined."
        actions={
          <>
            <div className="flex rounded-md border border-border p-0.5">
              {(
                [
                  ["roles", "Role differences"],
                  ["agent", "Traditional vs agent-heavy"],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setMode(id)}
                  className={cn(
                    "rounded px-2.5 py-1.5 text-xs font-medium transition-colors",
                    mode === id
                      ? "bg-brand text-brand-foreground"
                      : "text-muted-foreground hover:bg-secondary",
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
            <Select value={baseId} onValueChange={setBaseId}>
              <SelectTrigger className="w-56">
                <SelectValue placeholder="Baseline scenario" />
              </SelectTrigger>
              <SelectContent>
                {workspace.scenarios.map((s) => (
                  <SelectItem key={s.id} value={s.id}>
                    Baseline: {s.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={targetId} onValueChange={setTargetId}>
              <SelectTrigger className="w-56">
                <SelectValue placeholder="Future scenario" />
              </SelectTrigger>
              <SelectContent>
                {workspace.scenarios.map((s) => (
                  <SelectItem key={s.id} value={s.id}>
                    Future: {s.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant="outline"
              disabled={!diff}
              onClick={() => {
                if (!diff) return;
                downloadBlob(
                  diffToCsv(diff),
                  `${diff.base.name}-vs-${diff.target.name}-changes.csv`.replace(
                    /[^a-z0-9.-]+/gi,
                    "-",
                  ),
                  "text/csv",
                );
                toast.success("Change log downloaded");
              }}
            >
              <Download className="mr-1.5 size-4" /> Change log
            </Button>
            <Button
              variant="outline"
              disabled={!diff}
              onClick={() => setScope({ kind: "total", key: "" })}
            >
              <Search className="mr-1.5 size-4" /> Drill down
            </Button>
          </>
        }
      />

      {!diff ? (
        <div className="mx-8 mt-8 rounded-xl border border-dashed border-border bg-card p-10 text-center">
          <GitCompareArrows className="mx-auto size-8 text-brand" />
          <p className="mt-3 font-medium">Pick two different scenarios</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Choose a baseline (usually Current State) and a future state to see the differences.
          </p>
        </div>
      ) : mode === "agent" ? (
        <AgentHeavyView base={base} target={target} />
      ) : (
        <div className="space-y-6 px-8 py-6">
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {[
              {
                label: "Positions",
                base: diff.headcount.base.toLocaleString(),
                target: diff.headcount.target.toLocaleString(),
                delta: <Delta value={diff.headcount.delta} />,
              },
              {
                label: "Annual people cost",
                base: formatMoney(diff.cost.base, cur),
                target: formatMoney(diff.cost.target, cur),
                delta: (
                  <span
                    className={cn(
                      "font-semibold",
                      diff.cost.delta <= 0 ? "text-success" : "text-destructive",
                    )}
                  >
                    {diff.cost.delta <= 0 ? "−" : "+"}
                    {formatMoney(Math.abs(diff.cost.delta), cur)}
                  </span>
                ),
              },
              {
                label: "Management layers",
                base: String(diff.layers.base),
                target: String(diff.layers.target),
                delta: <Delta value={diff.layers.target - diff.layers.base} invert />,
              },
              {
                label: "Avg. span of control",
                base: diff.span.base.toFixed(1),
                target: diff.span.target.toFixed(1),
                delta: <Delta value={Number((diff.span.target - diff.span.base).toFixed(1))} />,
              },
            ].map((row) => (
              <div
                key={row.label}
                className="rounded-xl border border-border bg-card p-5 shadow-panel"
              >
                <p className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">
                  {row.label}
                </p>
                <div className="mt-2.5 flex flex-wrap items-baseline gap-x-2 gap-y-1 text-xl font-semibold">
                  <span className="min-w-0 whitespace-nowrap text-muted-foreground">{row.base}</span>
                  <ArrowRight className="size-4 shrink-0 text-brand" />
                  <span className="min-w-0 whitespace-nowrap">{row.target}</span>
                </div>
                <p className="mt-1.5 text-[13px]">{row.delta}</p>
              </div>
            ))}
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            {[
              {
                label: "Roles added",
                value: diff.added.length,
                icon: Plus,
                tone: "text-success",
              },
              {
                label: "Roles removed",
                value: diff.removed.length,
                icon: Minus,
                tone: "text-destructive",
              },
              {
                label: "Roles changed",
                value: diff.changed.length,
                icon: Shuffle,
                tone: "text-info",
              },
            ].map((c) => (
              <div
                key={c.label}
                className="flex items-center gap-4 rounded-xl border border-border bg-card p-5 shadow-panel"
              >
                <span
                  className={cn("grid size-11 place-items-center rounded-lg bg-accent", c.tone)}
                >
                  <c.icon className="size-5" />
                </span>
                <div>
                  <p className="text-2xl font-semibold leading-none">{c.value}</p>
                  <p className="mt-1 text-[12.5px] text-muted-foreground">{c.label}</p>
                </div>
              </div>
            ))}
          </div>

          <Tabs defaultValue="roles" className="w-full">
            <TabsList>
              <TabsTrigger value="roles">Role changes</TabsTrigger>
              <TabsTrigger value="department">By department</TabsTrigger>
              <TabsTrigger value="country">By country</TabsTrigger>
            </TabsList>

            <TabsContent value="roles" className="mt-4 space-y-4">
              {diff.added.length ? (
                <section className="overflow-hidden rounded-xl border border-border bg-card shadow-panel">
                  <h2 className="border-b border-border px-5 py-3 text-sm font-semibold text-success">
                    Added in {diff.target.name}
                  </h2>
                  <ul className="divide-y divide-border">
                    {diff.added.map((e) => (
                      <li
                        key={e.id}
                        className="flex items-center justify-between gap-4 px-5 py-3 text-[13px]"
                      >
                        <span>
                          <span className="font-medium">{e.name || "Open Role"}</span> — {e.title}
                        </span>
                        <span className="text-muted-foreground">
                          {e.department || "—"} · {e.country} · {effHeadcount(e, "target")} FTE ·{" "}
                          {formatMoney(e.plannedCost, cur)}
                        </span>
                      </li>
                    ))}
                  </ul>
                </section>
              ) : null}

              {diff.removed.length ? (
                <section className="overflow-hidden rounded-xl border border-border bg-card shadow-panel">
                  <h2 className="border-b border-border px-5 py-3 text-sm font-semibold text-destructive">
                    Not present in {diff.target.name}
                  </h2>
                  <ul className="divide-y divide-border">
                    {diff.removed.map((e) => (
                      <li
                        key={e.id}
                        className="flex items-center justify-between gap-4 px-5 py-3 text-[13px]"
                      >
                        <span>
                          <span className="font-medium">{e.name || "Open Role"}</span> — {e.title}
                        </span>
                        <span className="text-muted-foreground">
                          {e.department || "—"} · {e.country} · {effHeadcount(e, "base")} FTE ·{" "}
                          {formatMoney(e.currentCost, cur)}
                        </span>
                      </li>
                    ))}
                  </ul>
                </section>
              ) : null}

              {diff.changed.length ? (
                <section className="overflow-hidden rounded-xl border border-border bg-card shadow-panel">
                  <h2 className="border-b border-border px-5 py-3 text-sm font-semibold text-info">
                    Changed roles
                  </h2>
                  <ul className="divide-y divide-border">
                    {diff.changed.map((c) => (
                      <li key={c.after.id} className="px-5 py-3.5">
                        <p className="text-[13px] font-medium">
                          {c.after.name || c.before.name || "Open Role"} — {c.after.title}
                        </p>
                        <ul className="mt-1.5 space-y-1">
                          {c.changes.map((ch) => (
                            <li
                              key={ch.field}
                              className="flex flex-wrap items-center gap-2 text-[12.5px]"
                            >
                              <span className="min-w-32 text-muted-foreground">{ch.label}</span>
                              <span className="rounded bg-muted px-1.5 py-0.5 text-muted-foreground line-through">
                                {ch.before}
                              </span>
                              <ArrowRight className="size-3 text-brand" />
                              <span className="rounded bg-accent px-1.5 py-0.5 font-medium text-brand">
                                {ch.after}
                              </span>
                            </li>
                          ))}
                        </ul>
                      </li>
                    ))}
                  </ul>
                </section>
              ) : null}

              {!diff.added.length && !diff.removed.length && !diff.changed.length ? (
                <p className="rounded-xl border border-dashed border-border bg-card p-8 text-center text-sm text-muted-foreground">
                  These two scenarios are structurally identical.
                </p>
              ) : null}
            </TabsContent>

            {(["department", "country"] as const).map((kind) => (
              <TabsContent key={kind} value={kind} className="mt-4">
                <div className="overflow-hidden rounded-xl border border-border bg-card shadow-panel">
                  <table className="w-full text-[13px]">
                    <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wide text-muted-foreground">
                      <tr>
                        <th className="px-5 py-2.5 font-semibold">
                          {kind === "department" ? "Department" : "Country"}
                        </th>
                        <th className="px-5 py-2.5 font-semibold">Positions</th>
                        <th className="px-5 py-2.5 font-semibold">Δ</th>
                        <th className="px-5 py-2.5 font-semibold">Cost</th>
                        <th className="px-5 py-2.5 font-semibold">Δ cost</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {(kind === "department" ? diff.byDepartment : diff.byCountry).map((g) => (
                        <tr
                          key={g.key}
                          tabIndex={0}
                          role="button"
                          onClick={() => setScope({ kind, key: g.key })}
                          onKeyDown={(e) => {
                            if (e.key === "Enter" || e.key === " ") setScope({ kind, key: g.key });
                          }}
                          className="cursor-pointer transition-colors hover:bg-accent/60 focus:bg-accent/60 focus:outline-none"
                        >
                          <td className="px-5 py-2.5 font-medium">
                            <span className="flex items-center gap-2">
                              {g.key}
                              {isPinned({ kind, key: g.key }) ? (
                                <Pin className="size-3.5 text-brand" />
                              ) : null}
                            </span>
                          </td>
                          <td className="px-5 py-2.5 text-muted-foreground">
                            {g.baseHeadcount} →{" "}
                            <span className="text-foreground">{g.targetHeadcount}</span>
                          </td>
                          <td className="px-5 py-2.5">
                            <Delta value={g.targetHeadcount - g.baseHeadcount} />
                          </td>
                          <td className="px-5 py-2.5 text-muted-foreground">
                            {formatMoney(g.baseCost, cur)} →{" "}
                            <span className="text-foreground">
                              {formatMoney(g.targetCost, cur)}
                            </span>
                          </td>
                          <td className="px-5 py-2.5">
                            <span
                              className={cn(
                                "font-semibold",
                                g.targetCost - g.baseCost <= 0
                                  ? "text-success"
                                  : "text-destructive",
                              )}
                            >
                              {g.targetCost - g.baseCost <= 0 ? "−" : "+"}
                              {formatMoney(Math.abs(g.targetCost - g.baseCost), cur)}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <p className="border-t border-border bg-muted/40 px-5 py-2 text-[12px] text-muted-foreground">
                    Select a row to see exactly which roles changed, and pin it to the export notes.
                  </p>
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      )}

      <Sheet open={!!drill} onOpenChange={(open) => !open && setScope(null)}>
        <SheetContent className="flex w-full flex-col gap-0 overflow-y-auto sm:max-w-xl">
          {drill ? (
            <>
              <SheetHeader className="text-left">
                <SheetTitle>{drill.label}</SheetTitle>
                <SheetDescription>
                  {drill.baseName} → {drill.targetName} · positions {drill.baseHeadcount} →{" "}
                  {drill.targetHeadcount} · cost {formatMoney(drill.baseCost, cur)} →{" "}
                  {formatMoney(drill.targetCost, cur)}
                </SheetDescription>
              </SheetHeader>

              <div className="mt-4 flex flex-wrap items-center gap-2">
                <Badge variant="secondary" className="text-success">
                  {drill.added.length} added
                </Badge>
                <Badge variant="secondary" className="text-destructive">
                  {drill.removed.length} removed
                </Badge>
                <Badge variant="secondary" className="text-info">
                  {drill.changed.length} changed
                </Badge>
                <Button
                  size="sm"
                  variant={isPinned(drill.scope) ? "secondary" : "default"}
                  className="ml-auto"
                  onClick={() => togglePin(drill.scope)}
                >
                  {isPinned(drill.scope) ? (
                    <>
                      <PinOff className="mr-1.5 size-4" /> Unpin from exports
                    </>
                  ) : (
                    <>
                      <Pin className="mr-1.5 size-4" /> Pin to export notes
                    </>
                  )}
                </Button>
              </div>

              <div className="mt-5 space-y-5 pb-8">
                {[
                  { title: "Added roles", tone: "text-success", list: drill.added, side: "target" as const },
                  {
                    title: "Removed roles",
                    tone: "text-destructive",
                    list: drill.removed,
                    side: "base" as const,
                  },
                ].map((block) =>
                  block.list.length ? (
                    <section key={block.title}>
                      <h3 className={cn("text-sm font-semibold", block.tone)}>{block.title}</h3>
                      <ul className="mt-2 divide-y divide-border rounded-lg border border-border">
                        {block.list.map((e) => (
                          <li key={e.id} className="px-3.5 py-2.5 text-[13px]">
                            <p className="font-medium">
                              {e.name || "Open role"} — {e.title}
                            </p>
                            <p className="text-[12px] text-muted-foreground">
                              {e.department || "—"} · {e.country} · {effHeadcount(e, block.side)} FTE
                              ·{" "}
                              {formatMoney(
                                block.side === "base" ? e.currentCost : e.plannedCost,
                                cur,
                              )}
                            </p>
                          </li>
                        ))}
                      </ul>
                    </section>
                  ) : null,
                )}

                {drill.changed.length ? (
                  <section>
                    <h3 className="text-sm font-semibold text-info">Changed roles</h3>
                    <ul className="mt-2 divide-y divide-border rounded-lg border border-border">
                      {drill.changed.map((c) => (
                        <li key={c.after.id} className="px-3.5 py-2.5 text-[13px]">
                          <p className="font-medium">
                            {c.after.name || c.before.name || "Open role"} — {c.after.title}
                          </p>
                          <ul className="mt-1 space-y-1">
                            {c.changes.map((ch) => (
                              <li key={ch.field} className="flex flex-wrap items-center gap-1.5 text-[12px]">
                                <span className="min-w-28 text-muted-foreground">{ch.label}</span>
                                <span className="rounded bg-muted px-1.5 py-0.5 text-muted-foreground line-through">
                                  {ch.before}
                                </span>
                                <ArrowRight className="size-3 text-brand" />
                                <span className="rounded bg-accent px-1.5 py-0.5 font-medium text-brand">
                                  {ch.after}
                                </span>
                              </li>
                            ))}
                          </ul>
                        </li>
                      ))}
                    </ul>
                  </section>
                ) : null}

                {!drill.added.length && !drill.removed.length && !drill.changed.length ? (
                  <p className="rounded-lg border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
                    No role-level changes in this slice.
                  </p>
                ) : null}

                <section>
                  <h3 className="text-sm font-semibold">Export note preview</h3>
                  <pre className="mt-2 max-h-56 overflow-auto whitespace-pre-wrap rounded-lg border border-border bg-muted/50 p-3 text-[11.5px] leading-relaxed text-muted-foreground">
                    {drilldownToNotes(drill).join("\n")}
                  </pre>
                  <p className="mt-1.5 text-[12px] text-muted-foreground">
                    Pinned drill-downs become appendix slides with speaker notes in the .pptx, and a
                    drill-down section in the PDF.
                  </p>
                </section>
              </div>
            </>
          ) : null}
        </SheetContent>
      </Sheet>
    </div>
  );
}
