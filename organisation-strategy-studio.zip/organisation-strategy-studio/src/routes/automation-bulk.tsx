import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import {
  Bot,
  CheckCircle2,
  Download,
  FileText,
  Layers,
  Loader2,
  Network,
  Sparkles,
  Trash2,
  Upload,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { AutomationScoreRing } from "@/components/orgeasy/AutomationScoreRing";
import { StatCard } from "@/components/orgeasy/StatCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { formatMoney } from "@/lib/orgeasy/impact";
import { cn } from "@/lib/utils";
import {
  BANDS,
  BAND_META,
  bandFromScore,
  computeTotals,
  emptyAnalysis,
  heuristicAnalyze,
  saveAnalysis,
  splitTasks,
  uid,
  weightedScore,
  type AutomatabilityBand,
  type RoleAutomationAnalysis,
  type TaskAssessment,
} from "@/lib/orgeasy/automation";
import {
  allTaskRows,
  bandDistribution,
  buildFutureState,
  departmentRollups,
  futureRoleTitle,
  portfolioTotals,
  recommendPhases,
} from "@/lib/orgeasy/automation-portfolio";
import { generatePortfolioDeck, portfolioCsv } from "@/lib/orgeasy/automation-portfolio-pptx";

export const Route = createFileRoute("/automation-bulk")({
  head: () => ({
    meta: [
      { title: "Bulk JD Automation Review — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Upload 20 or more job descriptions at once and get a portfolio automation dashboard, a proposed future-state org chart and a phased change roadmap.",
      },
      { property: "og:title", content: "Bulk JD Automation Review — Organisation Strategy Studio" },
      {
        property: "og:description",
        content:
          "Mass-analyse job descriptions to see returned hours, released capacity, future-state structure and recommended change phases.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: BulkAutomationPage,
});

type JobState = "queued" | "reading" | "analysing" | "done" | "error";

interface Job {
  id: string;
  filename: string;
  size: number;
  state: JobState;
  message?: string;
  analysis?: RoleAutomationAnalysis;
}

const MAX_FILES = 60;
const CONCURRENCY = 3;

async function toBase64(file: File) {
  const buffer = new Uint8Array(await file.arrayBuffer());
  let binary = "";
  for (let i = 0; i < buffer.length; i += 8192) {
    binary += String.fromCharCode(...buffer.subarray(i, i + 8192));
  }
  return btoa(binary);
}

function BulkAutomationPage() {
  const { scenario, createScenario, replaceEmployees, updateScenario } = useOrgEasy();
  const navigate = useNavigate();
  const currency = scenario?.currency ?? "USD";

  const [jobs, setJobs] = useState<Job[]>([]);
  const [hourlyCost, setHourlyCost] = useState(45);
  const [running, setRunning] = useState(false);
  const [exporting, setExporting] = useState(false);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const analyses = useMemo(
    () => jobs.map((j) => j.analysis).filter((a): a is RoleAutomationAnalysis => Boolean(a)),
    [jobs],
  );
  const totals = useMemo(() => portfolioTotals(analyses), [analyses]);
  const departments = useMemo(() => departmentRollups(analyses), [analyses]);
  const phases = useMemo(() => recommendPhases(analyses), [analyses]);
  const dist = useMemo(() => bandDistribution(analyses), [analyses]);
  const future = useMemo(() => buildFutureState(analyses), [analyses]);
  const topTasks = useMemo(() => allTaskRows(analyses).slice(0, 25), [analyses]);

  const done = jobs.filter((j) => j.state === "done" || j.state === "error").length;
  const patch = (id: string, next: Partial<Job>) =>
    setJobs((prev) => prev.map((j) => (j.id === id ? { ...j, ...next } : j)));

  const fileMap = useRef<Map<string, File>>(new Map());

  const addFiles = (files: File[]) => {
    const accepted = files.filter((f) => f.size <= 12 * 1024 * 1024);
    if (accepted.length < files.length) toast.warning("Some files were over 12 MB and skipped");
    for (const f of accepted) fileMap.current.set(f.name + f.size, f);
    setJobs((prev) => {
      const room = Math.max(0, MAX_FILES - prev.length);
      if (accepted.length > room) toast.warning(`Only ${MAX_FILES} files can be queued at once`);
      return [
        ...prev,
        ...accepted.slice(0, room).map<Job>((file) => ({
          id: uid(),
          filename: file.name,
          size: file.size,
          state: "queued",
        })),
      ];
    });
  };

  const processJob = async (job: Job) => {
    const file = fileMap.current.get(job.filename + job.size);
    if (!file) {
      patch(job.id, { state: "error", message: "File no longer available — re-add it." });
      return;
    }
    patch(job.id, { state: "reading" });
    let text = "";
    let roleTitle = "";
    let department = "";
    try {
      const res = await fetch("/api/jd-extract", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filename: file.name,
          mimeType: file.type,
          dataBase64: await toBase64(file),
        }),
      });
      if (!res.ok) throw new Error(await res.text());
      const data = (await res.json()) as { text: string; roleTitle?: string; department?: string };
      text = data.text;
      roleTitle = (data.roleTitle ?? "").trim();
      department = (data.department ?? "").trim();
    } catch (error) {
      patch(job.id, {
        state: "error",
        message: error instanceof Error ? error.message.slice(0, 120) : "Could not read the file",
      });
      return;
    }

    const title = roleTitle || file.name.replace(/\.[a-z0-9]+$/i, "").replace(/[_-]+/g, " ");
    const taskRows = splitTasks(text).map((task) => ({ task, hoursPerWeek: 0 }));
    const payload = {
      roleTitle: title,
      department,
      context: "",
      tools: "",
      jobDescription: text,
      tasks: taskRows,
    };
    const base = emptyAnalysis({
      scenarioId: scenario?.id ?? null,
      employeeId: null,
      roleTitle: title,
      department,
      hourlyCost: Number(hourlyCost) || 0,
      currency,
    });

    patch(job.id, { state: "analysing" });
    try {
      const res = await fetch("/api/automation-analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error(await res.text());
      const data = (await res.json()) as {
        overallScore: number;
        summary: string;
        nextActions: string[];
        tasks: Omit<TaskAssessment, "id">[];
      };
      const tasks: TaskAssessment[] = (data.tasks ?? []).map((t) => ({
        ...t,
        id: uid(),
        band: (BANDS.includes(t.band) ? t.band : bandFromScore(t.score)) as AutomatabilityBand,
        hoursPerWeek: Math.max(0, Number(t.hoursPerWeek) || 0),
        hoursSavedPerWeek: Math.max(0, Number(t.hoursSavedPerWeek) || 0),
      }));
      const analysis: RoleAutomationAnalysis = {
        ...base,
        source: "ai",
        summary: data.summary ?? "",
        nextActions: data.nextActions ?? [],
        tasks,
        overallScore: tasks.length ? weightedScore(tasks) : Math.round(data.overallScore ?? 0),
      };
      saveAnalysis(analysis);
      patch(job.id, { state: "done", analysis });
    } catch {
      const fallback = heuristicAnalyze(payload);
      const analysis = { ...base, ...fallback, source: "heuristic" as const };
      saveAnalysis(analysis);
      patch(job.id, {
        state: "done",
        analysis,
        message: "Rule-based estimate (AI unavailable)",
      });
    }
  };

  const runAll = async () => {
    const queue = jobs.filter((j) => j.state === "queued" || j.state === "error");
    if (!queue.length) {
      toast.error("Add some job descriptions first");
      return;
    }
    setRunning(true);
    let cursor = 0;
    const workers = Array.from({ length: Math.min(CONCURRENCY, queue.length) }, async () => {
      while (cursor < queue.length) {
        const job = queue[cursor++];
        if (job) await processJob(job);
      }
    });
    await Promise.all(workers);
    setRunning(false);
    toast.success("Portfolio analysis complete", {
      description: `${queue.length} job description${queue.length === 1 ? "" : "s"} processed.`,
    });
  };

  const createFutureScenario = () => {
    if (!future.employees.length) {
      toast.error("Analyse some job descriptions first");
      return;
    }
    const name = `Future State — Automation (${analyses.length} roles)`;
    createScenario(name, undefined, {
      kind: "future",
      currency,
      description:
        "Generated from the bulk job-description automation review. Statuses reflect automatability, not decisions about people.",
    });
    replaceEmployees(future.employees);
    updateScenario({ positions: {} });
    toast.success("Future-state scenario created", {
      description: "Opening the org chart so you can refine the structure.",
    });
    void navigate({ to: "/chart" });
  };

  const downloadCsv = () => {
    const blob = new Blob([portfolioCsv(analyses)], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "Strategy-Studio-Automation-Portfolio.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <PageHeader
        title="Bulk JD Automation Review"
        description="Drop 20+ job descriptions in one go. Every JD is read, split into tasks and scored, then rolled up into a portfolio dashboard, a proposed future-state structure and a phased change roadmap. Indicative planning inputs only — validate with role holders and take local legal advice."
        actions={
          analyses.length ? (
            <>
              <Button variant="outline" onClick={downloadCsv}>
                <FileText className="mr-1.5 size-4" /> CSV
              </Button>
              <Button
                variant="outline"
                disabled={exporting}
                onClick={() => {
                  setExporting(true);
                  generatePortfolioDeck(analyses)
                    .then(() => toast.success("Portfolio deck downloaded"))
                    .catch(() => toast.error("PowerPoint export failed"))
                    .finally(() => setExporting(false));
                }}
              >
                {exporting ? (
                  <Loader2 className="mr-1.5 size-4 animate-spin" />
                ) : (
                  <Download className="mr-1.5 size-4" />
                )}
                PowerPoint
              </Button>
              <Button onClick={createFutureScenario}>
                <Network className="mr-1.5 size-4" /> Build future-state chart
              </Button>
            </>
          ) : null
        }
      />

      <div className="grid gap-5 p-8 xl:grid-cols-[400px_minmax(0,1fr)]">
        {/* ------------------------------------------------------------ intake */}
        <div className="space-y-4">
          <section className="rounded-xl border border-border bg-card p-5 shadow-panel">
            <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-widest text-brand">
              <Layers className="size-3.5" /> Job descriptions
            </p>
            <input
              ref={inputRef}
              type="file"
              multiple
              accept=".pdf,.docx,.xlsx,.txt,.md,.csv"
              className="hidden"
              onChange={(e) => {
                addFiles(Array.from(e.target.files ?? []));
                if (inputRef.current) inputRef.current.value = "";
              }}
            />
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                addFiles(Array.from(e.dataTransfer.files ?? []));
              }}
              className="mt-3 flex w-full flex-col items-center gap-1 rounded-lg border border-dashed border-brand/40 bg-brand/5 px-4 py-6 text-center transition hover:border-brand hover:bg-brand/10"
            >
              <Upload className="size-5 text-brand" />
              <span className="text-[12.5px] font-semibold text-foreground">
                Drop up to {MAX_FILES} PDF, Word, Excel or text files
              </span>
              <span className="text-[11px] text-muted-foreground">
                No people data needed — job descriptions only
              </span>
            </button>

            <div className="mt-3">
              <Label className="text-[12px]">Average hourly cost ({currency})</Label>
              <Input
                className="mt-1"
                type="number"
                min={0}
                value={hourlyCost || ""}
                onChange={(e) => setHourlyCost(Number(e.target.value))}
              />
              <p className="mt-1 text-[11px] text-muted-foreground">
                Applied to every role in this batch to value the returned hours.
              </p>
            </div>

            <div className="mt-4 flex gap-2">
              <Button className="h-10 flex-1 font-semibold" onClick={runAll} disabled={running}>
                {running ? (
                  <Loader2 className="mr-2 size-4 animate-spin" />
                ) : (
                  <Bot className="mr-2 size-4" />
                )}
                {running ? `Analysing ${done}/${jobs.length}…` : "Analyse all"}
              </Button>
              {jobs.length ? (
                <Button
                  variant="outline"
                  className="h-10"
                  disabled={running}
                  onClick={() => setJobs([])}
                >
                  <Trash2 className="size-4" />
                </Button>
              ) : null}
            </div>

            {jobs.length ? (
              <>
                <Progress
                  className="mt-4"
                  value={jobs.length ? (done / jobs.length) * 100 : 0}
                />
                <ul className="mt-3 max-h-80 space-y-1.5 overflow-y-auto pr-1">
                  {jobs.map((job) => (
                    <li
                      key={job.id}
                      className="flex items-start gap-2 rounded-md border border-border/70 bg-background/60 px-2.5 py-2"
                    >
                      {job.state === "done" ? (
                        <CheckCircle2 className="mt-0.5 size-3.5 shrink-0 text-success" />
                      ) : job.state === "error" ? (
                        <XCircle className="mt-0.5 size-3.5 shrink-0 text-destructive" />
                      ) : job.state === "queued" ? (
                        <FileText className="mt-0.5 size-3.5 shrink-0 text-muted-foreground" />
                      ) : (
                        <Loader2 className="mt-0.5 size-3.5 shrink-0 animate-spin text-brand" />
                      )}
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[12px] font-medium">{job.filename}</p>
                        <p className="truncate text-[11px] text-muted-foreground">
                          {job.state === "done" && job.analysis
                            ? `${job.analysis.roleTitle} · ${job.analysis.overallScore}% automatable`
                            : job.state === "reading"
                              ? "Reading the document…"
                              : job.state === "analysing"
                                ? "Assessing tasks…"
                                : job.state === "error"
                                  ? (job.message ?? "Failed")
                                  : "Queued"}
                        </p>
                      </div>
                    </li>
                  ))}
                </ul>
              </>
            ) : null}
          </section>
        </div>

        {/* --------------------------------------------------------- dashboard */}
        <div className="min-w-0">
          {!analyses.length ? (
            <div className="rounded-xl border border-dashed border-border bg-card/50 p-12 text-center">
              <Sparkles className="mx-auto size-8 text-brand" />
              <p className="mt-3 text-lg font-semibold">Upload a batch of job descriptions</p>
              <p className="mx-auto mt-1.5 max-w-md text-sm text-muted-foreground">
                Once the batch is analysed you will see the portfolio dashboard, department rollups,
                the recommended change phases and a future-state structure you can push straight
                into the org chart.
              </p>
            </div>
          ) : (
            <Tabs defaultValue="overview">
              <TabsList>
                <TabsTrigger value="overview">Dashboard</TabsTrigger>
                <TabsTrigger value="departments">Departments ({departments.length})</TabsTrigger>
                <TabsTrigger value="phases">Change phases</TabsTrigger>
                <TabsTrigger value="future">Future state</TabsTrigger>
              </TabsList>

              {/* --------------------------------------------------- overview */}
              <TabsContent value="overview" className="mt-4 space-y-5">
                <section className="rounded-xl border border-border bg-card p-6 shadow-panel">
                  <div className="flex flex-col items-center gap-6 sm:flex-row sm:items-start">
                    <AutomationScoreRing score={totals.averageScore} />
                    <div className="min-w-0 flex-1">
                      <h2 className="text-xl font-semibold tracking-tight">
                        {totals.roles} roles · {totals.tasks} tasks assessed
                      </h2>
                      <p className="mt-2 text-[13.5px] leading-relaxed text-muted-foreground">
                        Across this portfolio about {totals.averageScore}% of the work looks
                        automatable or AI-assisted, returning {totals.hoursPerWeek} hours a week —
                        roughly {totals.fteEquivalent} FTE of capacity worth{" "}
                        {formatMoney(totals.annualSaving, totals.currency)} a year. Reinvest the
                        capacity before making any structural decision.
                      </p>
                    </div>
                  </div>
                </section>

                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                  <StatCard label="Hours / week" value={String(totals.hoursPerWeek)} sub="Returned to the team" tone="brand" />
                  <StatCard label="Hours / year" value={String(totals.hoursPerYear)} sub="46 working weeks" />
                  <StatCard label="Capacity" value={`${totals.fteEquivalent} FTE`} sub="Available to redeploy" tone="positive" />
                  <StatCard label="Indicative value" value={formatMoney(totals.annualSaving, totals.currency)} sub="Per year, before delivery cost" />
                </div>

                <section className="rounded-xl border border-border bg-card p-5 shadow-panel">
                  <p className="text-[11px] font-semibold uppercase tracking-widest text-brand">
                    Task mix
                  </p>
                  <div className="mt-3 flex h-3 overflow-hidden rounded-full">
                    {BANDS.map((band) => {
                      const pct = dist.total ? (dist.counts[band] / dist.total) * 100 : 0;
                      return pct > 0 ? (
                        <div
                          key={band}
                          className={BAND_META[band].barClass}
                          style={{ width: `${pct}%` }}
                        />
                      ) : null;
                    })}
                  </div>
                  <div className="mt-3 grid gap-2 sm:grid-cols-4">
                    {BANDS.map((band) => (
                      <div key={band} className="rounded-md border border-border/70 px-3 py-2">
                        <p className="text-[11px] text-muted-foreground">{BAND_META[band].label}</p>
                        <p className="text-lg font-semibold">
                          {dist.counts[band]}
                          <span className="ml-1 text-[11px] font-normal text-muted-foreground">
                            {dist.total ? Math.round((dist.counts[band] / dist.total) * 100) : 0}%
                          </span>
                        </p>
                      </div>
                    ))}
                  </div>
                </section>

                <section className="rounded-xl border border-border bg-card p-5 shadow-panel">
                  <p className="text-[11px] font-semibold uppercase tracking-widest text-brand">
                    Biggest single opportunities
                  </p>
                  <ul className="mt-3 divide-y divide-border/70">
                    {topTasks.map((row) => (
                      <li key={`${row.analysis.id}-${row.taskId}`} className="flex items-start gap-3 py-2.5">
                        <span
                          className={cn(
                            "mt-0.5 shrink-0 rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide",
                            BAND_META[row.band].badgeClass,
                          )}
                        >
                          {BAND_META[row.band].short}
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="text-[13px] font-medium">{row.task}</p>
                          <p className="text-[11.5px] text-muted-foreground">
                            {row.analysis.roleTitle}
                            {row.analysis.department ? ` · ${row.analysis.department}` : ""} ·{" "}
                            {row.approach}
                          </p>
                        </div>
                        <span className="shrink-0 text-[12px] font-semibold text-brand">
                          {row.hoursSavedPerWeek}h/wk
                        </span>
                      </li>
                    ))}
                  </ul>
                </section>
              </TabsContent>

              {/* ------------------------------------------------ departments */}
              <TabsContent value="departments" className="mt-4 space-y-4">
                {departments.map((group) => (
                  <section
                    key={group.department}
                    className="rounded-xl border border-border bg-card p-5 shadow-panel"
                  >
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <h3 className="text-[15px] font-semibold">{group.department}</h3>
                      <p className="text-[12px] text-muted-foreground">
                        {group.roles} roles · avg {group.averageScore}% · {group.hoursPerWeek}h/week ·{" "}
                        {group.fteEquivalent} FTE ·{" "}
                        {formatMoney(group.annualSaving, totals.currency)}/yr
                      </p>
                    </div>
                    <ul className="mt-3 divide-y divide-border/70">
                      {group.analyses.map((a) => {
                        const t = computeTotals(a);
                        return (
                          <li key={a.id} className="flex items-center gap-3 py-2">
                            <span className="w-11 shrink-0 text-[13px] font-semibold text-brand">
                              {a.overallScore}%
                            </span>
                            <div className="min-w-0 flex-1">
                              <p className="truncate text-[13px] font-medium">{a.roleTitle}</p>
                              <p className="truncate text-[11.5px] text-muted-foreground">
                                {a.tasks.length} tasks · {t.quickWins} quick wins · {t.humanTasks}{" "}
                                human-led
                              </p>
                            </div>
                            <span className="shrink-0 text-[12px] text-muted-foreground">
                              {t.hoursPerWeek}h/wk
                            </span>
                          </li>
                        );
                      })}
                    </ul>
                  </section>
                ))}
              </TabsContent>

              {/* ---------------------------------------------------- phases */}
              <TabsContent value="phases" className="mt-4 space-y-4">
                {phases.map((phase) => (
                  <section
                    key={phase.order}
                    className="rounded-xl border border-border bg-card p-5 shadow-panel"
                  >
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <h3 className="text-[15px] font-semibold">
                        Phase {phase.order} — {phase.name}
                      </h3>
                      <span className="rounded-full bg-brand/10 px-2 py-0.5 text-[10.5px] font-semibold uppercase tracking-wide text-brand">
                        {phase.window}
                      </span>
                    </div>
                    <p className="mt-2 text-[13px] text-muted-foreground">{phase.focus}</p>
                    <p className="mt-2 text-[12.5px] font-semibold text-brand">
                      {phase.hoursPerWeek}h/week ·{" "}
                      {formatMoney(phase.annualSaving, totals.currency)}/yr · {phase.items.length}{" "}
                      tasks · {phase.roles.length} roles
                    </p>
                    {phase.items.length ? (
                      <ul className="mt-3 space-y-1.5">
                        {phase.items.slice(0, 8).map((row) => (
                          <li
                            key={`${row.analysis.id}-${row.taskId}`}
                            className="text-[12.5px] text-foreground"
                          >
                            <span className="text-muted-foreground">•</span> {row.task}{" "}
                            <span className="text-muted-foreground">
                              ({row.analysis.roleTitle} · {row.approach})
                            </span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="mt-3 text-[12.5px] text-muted-foreground">
                        No tasks fell into this phase for the current batch.
                      </p>
                    )}
                    <ul className="mt-3 space-y-1 border-t border-border/70 pt-3">
                      {phase.actions.map((action) => (
                        <li key={action} className="text-[12px] italic text-muted-foreground">
                          → {action}
                        </li>
                      ))}
                    </ul>
                  </section>
                ))}
              </TabsContent>

              {/* ----------------------------------------------- future state */}
              <TabsContent value="future" className="mt-4 space-y-4">
                <section className="rounded-xl border border-border bg-card p-5 shadow-panel">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <h3 className="text-[15px] font-semibold">Proposed future-state structure</h3>
                      <p className="mt-1 text-[12.5px] text-muted-foreground">
                        {future.employees.length} nodes across {departments.length} departments.
                        Statuses describe automatability of the work, not decisions about people.
                      </p>
                    </div>
                    <Button onClick={createFutureScenario}>
                      <Network className="mr-1.5 size-4" /> Create scenario &amp; open chart
                    </Button>
                  </div>
                  <ul className="mt-4 space-y-1.5">
                    {future.notes.map((note) => (
                      <li key={note} className="text-[12.5px] text-muted-foreground">
                        • {note}
                      </li>
                    ))}
                  </ul>
                </section>

                {departments.map((group) => (
                  <section
                    key={group.department}
                    className="rounded-xl border border-border bg-card p-5 shadow-panel"
                  >
                    <h4 className="text-[13.5px] font-semibold">{group.department} Lead</h4>
                    <ul className="mt-2 space-y-1.5 border-l border-dashed border-border pl-4">
                      {group.analyses.map((a) => (
                        <li key={a.id} className="text-[12.5px]">
                          {futureRoleTitle(a)}{" "}
                          <span className="text-muted-foreground">— {a.overallScore}% automatable</span>
                        </li>
                      ))}
                    </ul>
                  </section>
                ))}
              </TabsContent>
            </Tabs>
          )}
        </div>
      </div>
    </div>
  );
}
