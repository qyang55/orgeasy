import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ArrowRightLeft, UserCheck, UserMinus, UserPlus, TrendingDown } from "lucide-react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { Disclaimer } from "@/components/orgeasy/Disclaimer";
import { StatCard } from "@/components/orgeasy/StatCard";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { resolveBaseline, phaseTitle } from "@/lib/orgeasy/phases";
import { SENIORITY_META } from "@/lib/orgeasy/hiring";
import {
  DEFAULT_REDEPLOY_ASSUMPTIONS,
  MATCH_BAND_META,
  analyseRedeployment,
  type RedeployAssumptions,
} from "@/lib/orgeasy/redeploy";

export const Route = createFileRoute("/redeployment")({
  head: () => ({
    meta: [
      { title: "Redeployment Matching — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Match displaced positions to the new roles the programme creates, by function, market and level — then see the residual external hires and managed exits.",
      },
      { property: "og:title", content: "Redeployment Matching — Organisation Strategy Studio" },
      {
        property: "og:description",
        content:
          "Internal supply versus new demand, with attrition assumptions, match confidence bands and unfilled gaps by function.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: RedeploymentPage,
});

function RedeploymentPage() {
  const { workspace, scenario } = useOrgEasy();
  const [assumptions, setAssumptions] = useState<RedeployAssumptions>(
    DEFAULT_REDEPLOY_ASSUMPTIONS,
  );
  const baseline = useMemo(
    () => resolveBaseline(workspace.scenarios, scenario),
    [workspace.scenarios, scenario],
  );
  const analysis = useMemo(
    () => analyseRedeployment(baseline, scenario, assumptions),
    [baseline, scenario, assumptions],
  );
  const set = <K extends keyof RedeployAssumptions>(key: K, value: RedeployAssumptions[K]) =>
    setAssumptions((a) => ({ ...a, [key]: value }));

  return (
    <div className="pb-12">
      <PageHeader
        title="Redeployment matching"
        description={
          baseline && scenario
            ? `Internal supply from ${phaseTitle(baseline)} matched against the new roles in ${phaseTitle(scenario)}.`
            : "Select a future-state phase with a baseline to match displaced people to new roles."
        }
      />

      <div className="space-y-6 px-8 py-6">
        <Disclaimer />

        <div className="grid grid-cols-2 gap-4 xl:grid-cols-5">
          <StatCard
            label="Displaced positions"
            value={analysis.displacedPositions.toLocaleString()}
            tone="negative"
            sub="Removed or reduced in the future state"
            icon={<UserMinus className="size-4" />}
          />
          <StatCard
            label="New positions to fill"
            value={analysis.vacancyPositions.toLocaleString()}
            tone="brand"
            sub="New roles plus headcount growth"
            icon={<UserPlus className="size-4" />}
          />
          <StatCard
            label="Redeployable internally"
            value={analysis.redeployedPositions.toLocaleString()}
            tone="positive"
            sub={`${analysis.coveragePct.toFixed(0)}% of new demand covered`}
            icon={<ArrowRightLeft className="size-4" />}
          />
          <StatCard
            label="External hires still needed"
            value={analysis.externalHires.toLocaleString()}
            sub="No credible internal match found"
            icon={<UserCheck className="size-4" />}
          />
          <StatCard
            label="Exits to manage"
            value={analysis.managedExits.toLocaleString()}
            tone="negative"
            sub={`After ${analysis.attritionAbsorbed} absorbed by natural attrition`}
            icon={<TrendingDown className="size-4" />}
          />
        </div>

        <section className="rounded-lg border border-border bg-card p-5 shadow-panel">
          <h2 className="text-sm font-semibold">Matching assumptions</h2>
          <div className="mt-4 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
            <div className="space-y-1.5">
              <Label className="text-[12px] font-semibold">Annual voluntary attrition (%)</Label>
              <Input
                type="number"
                className="h-9"
                min={0}
                max={40}
                value={assumptions.attritionPct}
                onChange={(e) => set("attritionPct", Math.min(Math.max(Number(e.target.value) || 0, 0), 40))}
              />
              <p className="text-[11px] text-muted-foreground">
                Natural leavers reduce the exits you have to manage.
              </p>
            </div>
            <div className="space-y-1.5">
              <Label className="text-[12px] font-semibold">Programme window (months)</Label>
              <Input
                type="number"
                className="h-9"
                min={1}
                max={36}
                value={assumptions.windowMonths}
                onChange={(e) => set("windowMonths", Math.min(Math.max(Number(e.target.value) || 1, 1), 36))}
              />
              <p className="text-[11px] text-muted-foreground">
                How long attrition can be relied on before exits must be actioned.
              </p>
            </div>
            <div className="space-y-1.5">
              <Label className="text-[12px] font-semibold">Minimum match score</Label>
              <Input
                type="number"
                className="h-9"
                min={20}
                max={90}
                value={assumptions.minScore}
                onChange={(e) => set("minScore", Math.min(Math.max(Number(e.target.value) || 20, 20), 90))}
              />
              <p className="text-[11px] text-muted-foreground">
                Raise it for a conservative plan, lower it to explore stretch moves.
              </p>
            </div>
            <div className="space-y-3">
              <label className="flex items-center justify-between gap-3 text-[12.5px]">
                <span className="font-medium">Allow cross-border moves</span>
                <Switch
                  checked={assumptions.crossBorder}
                  onCheckedChange={(v) => set("crossBorder", v)}
                />
              </label>
              <label className="flex items-center justify-between gap-3 text-[12.5px]">
                <span className="font-medium">Allow one-level reskilling</span>
                <Switch
                  checked={assumptions.allowReskill}
                  onCheckedChange={(v) => set("allowReskill", v)}
                />
              </label>
              <p className="text-[11px] text-muted-foreground">
                Relocation and reskilling widen the pool but add cost and lead time.
              </p>
            </div>
          </div>
          <div className="mt-5">
            <div className="flex items-baseline justify-between">
              <p className="text-[12.5px] font-medium">Internal coverage of new demand</p>
              <p className="text-[12.5px] font-semibold">{analysis.coveragePct.toFixed(0)}%</p>
            </div>
            <Progress value={analysis.coveragePct} className="mt-1.5 h-2" />
          </div>
        </section>

        <section className="rounded-lg border border-border bg-card shadow-panel">
          <div className="flex items-center justify-between border-b border-border px-5 py-3.5">
            <h2 className="text-sm font-semibold">Proposed internal moves</h2>
            <p className="text-xs text-muted-foreground">
              {analysis.matches.length} match{analysis.matches.length === 1 ? "" : "es"} ·{" "}
              {analysis.redeployedPositions} positions
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-secondary/60 text-[11px] uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-5 py-2.5 text-left font-semibold">Displaced role</th>
                  <th className="px-3 py-2.5 text-left font-semibold">Moves into</th>
                  <th className="px-3 py-2.5 text-right font-semibold">Positions</th>
                  <th className="px-3 py-2.5 text-left font-semibold">Confidence</th>
                  <th className="px-5 py-2.5 text-left font-semibold">Why it works</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {analysis.matches.slice(0, 60).map((m) => {
                  const meta = MATCH_BAND_META[m.band];
                  return (
                    <tr key={m.id}>
                      <td className="px-5 py-3">
                        <p className="font-medium">{m.sourceTitle}</p>
                        <p className="text-[11.5px] text-muted-foreground">
                          {m.sourceDepartment} · {m.sourceCountry} ·{" "}
                          {SENIORITY_META[m.sourceBand].label}
                        </p>
                      </td>
                      <td className="px-3 py-3">
                        <p className="font-medium">{m.vacancyTitle}</p>
                        <p className="text-[11.5px] text-muted-foreground">
                          {m.vacancyDepartment} · {m.vacancyCountry} ·{" "}
                          {SENIORITY_META[m.vacancyBand].label}
                        </p>
                      </td>
                      <td className="px-3 py-3 text-right font-semibold">{m.positions}</td>
                      <td className="px-3 py-3">
                        <span
                          className="rounded-full px-2 py-0.5 text-[11px] font-semibold"
                          style={{ backgroundColor: `#${meta.hex}1F`, color: `#${meta.hex}` }}
                          title={meta.note}
                        >
                          {meta.label} · {m.score}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-[12px] text-muted-foreground">
                        {m.reasons.join(" · ")}
                      </td>
                    </tr>
                  );
                })}
                {!analysis.matches.length ? (
                  <tr>
                    <td colSpan={5} className="px-5 py-8 text-center text-[13px] text-muted-foreground">
                      No internal matches at the current settings. Lower the minimum score, or allow
                      cross-border moves and reskilling.
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
        </section>

        <div className="grid gap-6 lg:grid-cols-2">
          <section className="rounded-lg border border-border bg-card shadow-panel">
            <div className="border-b border-border px-5 py-3.5">
              <h2 className="text-sm font-semibold">Gaps that go to market</h2>
              <p className="mt-0.5 text-xs text-muted-foreground">
                New positions with no internal match, by function.
              </p>
            </div>
            <ul className="divide-y divide-border">
              {analysis.gapsByDepartment.slice(0, 10).map((g) => (
                <li key={g.key} className="flex items-center gap-4 px-5 py-3">
                  <span className="min-w-0 flex-1 truncate text-[13px] font-medium">{g.key}</span>
                  <span className="text-[12px] text-success">{g.matched} internal</span>
                  <span className="text-[12px] text-destructive">{g.external} external</span>
                </li>
              ))}
              {!analysis.gapsByDepartment.length ? (
                <li className="px-5 py-6 text-center text-[13px] text-muted-foreground">
                  No new-role demand in this phase.
                </li>
              ) : null}
            </ul>
          </section>

          <section className="rounded-lg border border-border bg-card shadow-panel">
            <div className="border-b border-border px-5 py-3.5">
              <h2 className="text-sm font-semibold">People with no internal landing spot</h2>
              <p className="mt-0.5 text-xs text-muted-foreground">
                Plan consultation, outplacement and exit support for these groups first.
              </p>
            </div>
            <ul className="divide-y divide-border">
              {analysis.unmatchedDisplaced.slice(0, 10).map((d) => (
                <li key={`${d.id}-${d.title}`} className="flex items-center gap-4 px-5 py-3">
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[13px] font-medium">{d.title}</span>
                    <span className="block text-[11.5px] text-muted-foreground">
                      {d.department} · {d.country}
                    </span>
                  </span>
                  <span className="text-[13px] font-semibold text-destructive">{d.positions}</span>
                </li>
              ))}
              {!analysis.unmatchedDisplaced.length ? (
                <li className="px-5 py-6 text-center text-[13px] text-muted-foreground">
                  Every displaced position has a credible internal match.
                </li>
              ) : null}
            </ul>
          </section>
        </div>
      </div>
    </div>
  );
}
