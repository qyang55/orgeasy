import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { useOrgEasy, uid } from "@/lib/orgeasy/store";
import type { AdkarGroup, AdkarKey } from "@/lib/orgeasy/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/adkar")({
  head: () => ({
    meta: [
      { title: "ADKAR Change Readiness — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Score each stakeholder group on Awareness, Desire, Knowledge, Ability and Reinforcement to find the change barrier point.",
      },
      { property: "og:title", content: "ADKAR Change Readiness — Organisation Strategy Studio" },
      {
        property: "og:description",
        content: "Score stakeholder groups across the five ADKAR stages and find the barrier point.",
      },
    ],
  }),
  component: Adkar,
});

const STAGES: { key: AdkarKey; label: string; blurb: string; action: string }[] = [
  {
    key: "awareness",
    label: "Awareness",
    blurb: "Do they understand why the change is happening?",
    action: "Publish the business case and the cost of standing still. Repeat it in every forum.",
  },
  {
    key: "desire",
    label: "Desire",
    blurb: "Do they personally want to participate?",
    action: "Surface WIIFM per group, name the risks honestly, and give leaders visible ownership.",
  },
  {
    key: "knowledge",
    label: "Knowledge",
    blurb: "Do they know how to change?",
    action: "Run role-specific training and manager briefings before go-live, not after.",
  },
  {
    key: "ability",
    label: "Ability",
    blurb: "Can they demonstrate the new behaviours?",
    action: "Add coaching, shadowing and a safe practice period with real feedback loops.",
  },
  {
    key: "reinforcement",
    label: "Reinforcement",
    blurb: "What sustains the change?",
    action: "Tie recognition and measurement to the new structure at 30 / 60 / 90 days.",
  },
];

function scoreTone(score: number) {
  if (score <= 2) return "bg-destructive text-destructive-foreground";
  if (score === 3) return "bg-warning text-warning-foreground";
  return "bg-success text-success-foreground";
}

function Adkar() {
  const { scenario, upsertAdkarGroup, removeAdkarGroup } = useOrgEasy();
  const groups = scenario?.adkarGroups ?? [];
  const [name, setName] = useState("");

  const averages = STAGES.map((s) => ({
    ...s,
    avg: groups.length ? groups.reduce((a, g) => a + g.scores[s.key], 0) / groups.length : 0,
  }));
  const barrier = [...averages].sort((a, b) => a.avg - b.avg)[0];

  const addGroup = () => {
    const label = name.trim() || "New stakeholder group";
    const group: AdkarGroup = {
      id: uid(),
      name: label,
      scores: { awareness: 3, desire: 3, knowledge: 3, ability: 3, reinforcement: 3 },
      notes: "",
    };
    upsertAdkarGroup(group);
    setName("");
    toast.success(`Added "${label}"`);
  };

  return (
    <div className="pb-12">
      <PageHeader
        title="ADKAR change readiness"
        description="Score each group 1–5 per stage. The lowest average stage is the barrier point: work stops there until it is addressed."
        actions={
          <>
            <Input
              placeholder="Stakeholder group name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addGroup()}
              className="w-56"
            />
            <Button onClick={addGroup}>
              <Plus className="mr-1.5 size-4" /> Add group
            </Button>
          </>
        }
      />

      <div className="space-y-6 px-8 py-6">
        <div className="grid gap-4 md:grid-cols-3 xl:grid-cols-5">
          {averages.map((s) => (
            <div
              key={s.key}
              className={cn(
                "rounded-lg border bg-card p-4 shadow-panel",
                barrier?.key === s.key && groups.length ? "border-destructive" : "border-border",
              )}
            >
              <div className="flex items-baseline justify-between">
                <p className="text-[13px] font-semibold">{s.label}</p>
                <p className="text-xl font-semibold tabular-nums">{s.avg.toFixed(1)}</p>
              </div>
              <div className="mt-2 h-1.5 rounded-full bg-secondary">
                <div
                  className="h-1.5 rounded-full bg-brand"
                  style={{ width: `${(s.avg / 5) * 100}%` }}
                />
              </div>
              <p className="mt-2.5 text-[11.5px] leading-snug text-muted-foreground">{s.blurb}</p>
              {barrier?.key === s.key && groups.length ? (
                <p className="mt-2 rounded-md bg-destructive/10 px-2.5 py-2 text-[11.5px] font-medium leading-snug text-destructive">
                  Barrier point — {s.action}
                </p>
              ) : null}
            </div>
          ))}
        </div>

        <section className="overflow-x-auto rounded-lg border border-border bg-card shadow-panel">
          <h2 className="border-b border-border px-5 py-3.5 text-sm font-semibold">
            Group assessments
          </h2>
          {groups.length ? (
            <table className="w-full min-w-[900px] text-left text-[13px]">
              <thead className="bg-secondary text-[11px] uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="px-5 py-2.5 font-semibold">Group</th>
                  {STAGES.map((s) => (
                    <th key={s.key} className="px-3 py-2.5 font-semibold">
                      {s.label}
                    </th>
                  ))}
                  <th className="px-3 py-2.5 font-semibold">Notes</th>
                  <th />
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {groups.map((g) => (
                  <tr key={g.id} className="align-top">
                    <td className="px-5 py-3">
                      <Input
                        value={g.name}
                        onChange={(e) => upsertAdkarGroup({ ...g, name: e.target.value })}
                        className="h-8 w-40"
                      />
                    </td>
                    {STAGES.map((s) => (
                      <td key={s.key} className="px-3 py-3">
                        <div className="flex gap-1">
                          {[1, 2, 3, 4, 5].map((n) => (
                            <button
                              key={n}
                              onClick={() =>
                                upsertAdkarGroup({ ...g, scores: { ...g.scores, [s.key]: n } })
                              }
                              className={cn(
                                "size-6 rounded text-[11px] font-semibold transition-colors",
                                g.scores[s.key] === n
                                  ? scoreTone(n)
                                  : "bg-secondary text-muted-foreground hover:bg-accent",
                              )}
                            >
                              {n}
                            </button>
                          ))}
                        </div>
                      </td>
                    ))}
                    <td className="px-3 py-3">
                      <Textarea
                        rows={2}
                        placeholder="Evidence, blockers, owner"
                        value={g.notes}
                        onChange={(e) => upsertAdkarGroup({ ...g, notes: e.target.value })}
                        className="min-w-56 text-[12.5px]"
                      />
                    </td>
                    <td className="px-3 py-3">
                      <Button variant="ghost" size="icon" onClick={() => removeAdkarGroup(g.id)}>
                        <Trash2 className="size-4 text-destructive" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p className="px-5 py-10 text-center text-sm text-muted-foreground">
              No groups yet. Add executives, affected teams, managers and support functions to start.
            </p>
          )}
        </section>
      </div>
    </div>
  );
}