import { createFileRoute } from "@tanstack/react-router";
import { streamText } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider, getLovableAiGatewayRunId } from "@/lib/ai-gateway.server";

const BriefSchema = z.object({
  asset: z.string().min(1),
  audience: z.string().min(1),
  tone: z.string().min(1),
  language: z.string().min(1),
  length: z.string().min(1),
  channel: z.string().min(1),
  senderName: z.string().optional().default(""),
  senderTitle: z.string().optional().default(""),
  mustInclude: z.string().optional().default(""),
  guardrails: z.string().optional().default(""),
  facts: z.string().min(1),
  reference: z.string().optional().default(""),
  previousDraft: z.string().optional().default(""),
  revisionRequest: z.string().optional().default(""),
});

const SYSTEM = `You are an organisational development (OD) and change communication copilot for HR and OD leaders running restructuring programmes.

Write like a senior internal communications partner: plain, warm, direct, human. No corporate filler, no hype, no emoji, no exclamation marks.

Hard rules:
- Use ONLY the scenario facts supplied. Never invent headcount, cost, dates, names or country requirements. If a needed detail is missing, insert a clearly marked placeholder such as [date] or [HR partner].
- Never state severance amounts, notice periods or selection criteria as final. Refer people to HR and the local consultation process.
- Never imply a decision is final where employee consultation or works council information is still required.
- Never disclose individual employees' personal circumstances.
- Respect the dignity of impacted colleagues; no euphemisms that obscure what is happening.

Output format: clean Markdown, ready to paste. Start with the deliverable itself (subject line first when it is an email). No preamble about what you are about to do, no closing commentary.`;

export const Route = createFileRoute("/api/od-copilot")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let brief;
        try {
          brief = BriefSchema.parse(await request.json());
        } catch {
          return new Response("Invalid brief", { status: 400 });
        }

        const key = process.env["LOVABLE_API_KEY"];
        if (!key) return new Response("AI is not configured for this workspace.", { status: 500 });

        const prompt = [
          `Deliverable: ${brief.asset}`,
          `Primary audience: ${brief.audience}`,
          `Channel: ${brief.channel}`,
          `Tone: ${brief.tone}`,
          `Language: ${brief.language}`,
          `Length: ${brief.length}`,
          brief.senderName || brief.senderTitle
            ? `Signed by: ${brief.senderName || "[Leader name]"}${brief.senderTitle ? `, ${brief.senderTitle}` : ""}`
            : "",
          brief.mustInclude ? `Must include:\n${brief.mustInclude}` : "",
          brief.guardrails ? `Additional guardrails / things to avoid:\n${brief.guardrails}` : "",
          `\nScenario facts (authoritative — do not contradict):\n${brief.facts}`,
          brief.reference
            ? `\nHouse-style reference example (match structure and register, do not copy wording verbatim):\n${brief.reference.slice(0, 6000)}`
            : "",
          brief.previousDraft
            ? `\nPrevious draft to revise:\n${brief.previousDraft.slice(0, 8000)}`
            : "",
          brief.revisionRequest
            ? `\nRevision instruction (apply to the previous draft, keep everything else intact):\n${brief.revisionRequest}`
            : "",
        ]
          .filter(Boolean)
          .join("\n");

        const initialRunId = getLovableAiGatewayRunId(request);
        const gateway = createLovableAiGatewayProvider(key, initialRunId);

        try {
          const result = streamText({
            model: gateway("google/gemini-3.6-flash"),
            system: SYSTEM,
            prompt,
          });
          return result.toTextStreamResponse();
        } catch (error) {
          const message = error instanceof Error ? error.message : "AI request failed";
          console.error("od-copilot failed", message);
          return new Response(message, { status: 502 });
        }
      },
    },
  },
});