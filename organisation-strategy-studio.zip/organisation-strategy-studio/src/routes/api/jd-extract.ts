import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { getLovableAiGatewayRunId } from "@/lib/ai-gateway.server";

const InputSchema = z.object({
  filename: z.string().min(1),
  mimeType: z.string().default(""),
  dataBase64: z.string().min(16),
});

export const Route = createFileRoute("/api/jd-extract")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let input;
        try {
          input = InputSchema.parse(await request.json());
        } catch {
          return new Response("Invalid upload request", { status: 400 });
        }
        try {
          const { extractJobDescription } = await import("@/lib/orgeasy/jd-extract.server");
          const result = await extractJobDescription({
            ...input,
            runId: getLovableAiGatewayRunId(request),
          });
          return Response.json(result);
        } catch (error) {
          const message = error instanceof Error ? error.message : "Could not read that file";
          console.error("jd-extract failed", message);
          return new Response(message, { status: 422 });
        }
      },
    },
  },
});
