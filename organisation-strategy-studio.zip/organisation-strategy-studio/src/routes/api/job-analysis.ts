import { createFileRoute } from "@tanstack/react-router";
import { streamText, Output, NoObjectGeneratedError } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider, getLovableAiGatewayRunId } from "@/lib/ai-gateway.server";

/**
 * Organisation Strategy Studio Job Analysis Standard.
 * Returns ONLY the standard job-analysis JSON object, same shape every run.
 */
const InputSchema = z.object({
  roleTitle: z.string().optional().default(""),
  department: z.string().optional().default(""),
  level: z.string().optional().default(""),
  context: z.string().optional().default(""),
  tools: z.string().optional().default(""),
  jobDescription: z.string().optional().default(""),
  tasks: z
    .array(z.object({ task: z.string(), hoursPerWeek: z.number().nonnegative() }))
    .default([]),
});

const JobAnalysisSchema = z.object({
  role_title: z.string().catch(""),
  department: z.string().catch(""),
  level: z.string().catch("Individual Contributor"),
  key_responsibilities: z.array(z.string()).catch([]),
  core_tasks: z.array(
    z.object({
      task: z.string(),
      frequency: z.enum(["Daily", "Weekly", "Monthly", "Ad-hoc"]).catch("Weekly"),
      estimated_hours_per_week: z.number().catch(0),
      automation_potential: z.enum(["High", "Medium", "Low"]).catch("Medium"),
      automation_score: z.number().catch(50),
      rationale: z.string().catch(""),
    }),
  ).catch([]),
  overall_automation_score: z.number().catch(0),
  overall_automation_summary: z.string().catch(""),
  required_skills: z.object({
    hard_skills: z.array(z.string()).catch([]),
    soft_skills: z.array(z.string()).catch([]),
    tools_systems: z.array(z.string()).catch([]),
  }).catch({ hard_skills: [], soft_skills: [], tools_systems: [] }),
  headcount_impact_notes: z.string().catch(""),
  change_management_notes: z.string().catch(""),
  assumptions: z.array(z.string()).catch([]),
  recommended_next_actions: z.array(z.string()).catch([]),
});

export type JobAnalysis = z.infer<typeof JobAnalysisSchema>;

const SYSTEM = `You are the Job Analysis engine for Organisation Strategy Studio, an HR & organizational development platform covering org design, restructuring simulation, job automation analysis and automotive operating models.

Output ONLY a valid JSON object matching the required schema. No markdown, no explanation, no text before or after.

Consistency is mandatory: use the same scoring logic, language style and level of detail every run.

Content rules:
- key_responsibilities: 5 to 8 clear, actionable responsibilities.
- core_tasks: 6 to 12 tasks. "task" is a short verb-first phrase. frequency is exactly one of Daily / Weekly / Monthly / Ad-hoc. estimated_hours_per_week are realistic and sum to roughly 38 for a full-time role; if hours are supplied for a task, keep that exact number. rationale is one sentence in business language.
- automation_score rubric (apply every time):
  * 80-100 = High: highly repetitive, rule-based, data entry, reporting, scheduling or process-following work that current AI/RPA handles with minimal human oversight.
  * 50-79 = Medium: partial automation (drafting, analysis support, first-pass review) still needing human judgement or exception handling.
  * 0-49 = Low: deep domain expertise, complex stakeholder management, creative problem-solving or physical presence.
  automation_potential must match the band of automation_score.
- overall_automation_score: integer 0-100, the hours-weighted average of the task scores.
- overall_automation_summary: 2-3 sentences.
- headcount_impact_notes: how the role typically scales or can be optimised in a restructure.
- change_management_notes: ADKAR-relevant points for redesigning or automating the role.
- assumptions: every assumption you had to make where information was missing. If information is missing, assume the most reasonable typical automotive / manufacturing / corporate pattern and record it here.
- recommended_next_actions: 2 to 4 practical recommendations for Organisation Strategy Studio users.

Tone: professional, practical, optimistic. Automation frees people from repetitive work; never frame it as replacing people or justifying job cuts. Never name or speculate about individuals.`;

export const Route = createFileRoute("/api/job-analysis")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let input: z.infer<typeof InputSchema>;
        try {
          input = InputSchema.parse(await request.json());
        } catch {
          return new Response("Invalid job analysis request", { status: 400 });
        }

        const key = process.env["LOVABLE_API_KEY"];
        if (!key) return new Response("AI is not configured for this workspace.", { status: 500 });

        const prompt = [
          input.roleTitle ? `Role title: ${input.roleTitle}` : "",
          input.department ? `Department / function: ${input.department}` : "",
          input.level ? `Level: ${input.level}` : "",
          input.context ? `Context: ${input.context}` : "",
          input.tools ? `Tools and systems used today: ${input.tools}` : "",
          input.tasks.length
            ? `Known tasks (keep these and keep supplied hours exactly):\n${input.tasks
                .map(
                  (t) =>
                    `- ${t.task}${t.hoursPerWeek > 0 ? ` (${t.hoursPerWeek} hours per week)` : ""}`,
                )
                .join("\n")}`
            : "",
          input.jobDescription
            ? `Job description / responsibilities:\n${input.jobDescription.slice(0, 12000)}`
            : "",
        ]
          .filter(Boolean)
          .join("\n\n");

        if (!prompt.trim()) {
          return new Response("Provide a role title or job description to analyse.", {
            status: 400,
          });
        }

        const gateway = createLovableAiGatewayProvider(key, getLovableAiGatewayRunId(request));

        try {
          const result = streamText({
            model: gateway("google/gemini-3.6-flash"),
            system: SYSTEM,
            prompt,
            output: Output.object({ schema: JobAnalysisSchema }),
          });
          const output = await result.output;
          return Response.json(clamp(output, input));
        } catch (error) {
          if (NoObjectGeneratedError.isInstance(error)) {
            console.error("job-analysis schema miss", error.text?.slice(0, 400));
            return new Response("The analysis came back in an unexpected shape.", { status: 502 });
          }
          const message = error instanceof Error ? error.message : "AI request failed";
          console.error("job-analysis failed", message);
          return new Response(message, { status: 502 });
        }
      },
    },
  },
});

/** Keeps scores, bands and the weighted overall score internally consistent. */
function clamp(analysis: JobAnalysis, input: z.infer<typeof InputSchema>): JobAnalysis {
  const core_tasks = analysis.core_tasks.map((t) => {
    const score = Math.max(0, Math.min(100, Math.round(t.automation_score)));
    return {
      ...t,
      automation_score: score,
      automation_potential: (score >= 80 ? "High" : score >= 50 ? "Medium" : "Low") as
        | "High"
        | "Medium"
        | "Low",
      estimated_hours_per_week: Math.max(0, Math.round(t.estimated_hours_per_week * 10) / 10),
    };
  });
  const hours = core_tasks.reduce((s, t) => s + t.estimated_hours_per_week, 0);
  const overall = hours
    ? core_tasks.reduce((s, t) => s + t.automation_score * t.estimated_hours_per_week, 0) / hours
    : core_tasks.reduce((s, t) => s + t.automation_score, 0) / (core_tasks.length || 1);
  return {
    ...analysis,
    role_title: analysis.role_title || input.roleTitle || "Untitled role",
    department: analysis.department || input.department || "Not specified",
    level: analysis.level || input.level || "Individual Contributor",
    core_tasks,
    overall_automation_score: Math.max(0, Math.min(100, Math.round(overall))),
  };
}