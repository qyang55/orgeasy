import { createFileRoute } from "@tanstack/react-router";
import { streamText, Output, NoObjectGeneratedError } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider, getLovableAiGatewayRunId } from "@/lib/ai-gateway.server";

const InputSchema = z.object({
  roleTitle: z.string().min(1),
  department: z.string().optional().default(""),
  context: z.string().optional().default(""),
  tools: z.string().optional().default(""),
  jobDescription: z.string().optional().default(""),
  tasks: z
    .array(z.object({ task: z.string().min(1), hoursPerWeek: z.number().nonnegative() }))
    .default([]),
});

const ResultSchema = z.object({
  overallScore: z.number(),
  summary: z.string(),
  nextActions: z.array(z.string()),
  tasks: z.array(
    z.object({
      task: z.string(),
      band: z.enum(["full", "high", "partial", "human"]),
      score: z.number(),
      reason: z.string(),
      approach: z.string(),
      hoursPerWeek: z.number(),
      hoursSavedPerWeek: z.number(),
    }),
  ),
});

const SYSTEM = `You are an operations and workforce-design analyst helping HR and OD leaders find where automation and AI can give people their time back.

Your job: break a role into concrete tasks and judge how automatable each one is today with mainstream, proven technology (RPA, workflow tools, scripts/integrations, LLM assistants and agents, self-service, or simply removing the step through process redesign).

Scoring bands:
- "full" (score 85-100): rule-based, high volume, stable inputs; a system can run it end to end with exception handling.
- "high" (score 65-84): mostly automatable today; a person reviews or approves the output.
- "partial" (score 35-64): preparation, data gathering or drafting is automatable; the judgement, negotiation or decision stays human.
- "human" (score 0-34): depends on trust, leadership, ethics, ambiguity or accountability. Say so plainly and positively.

Rules:
- Be realistic and conservative. Do not claim automation that needs technology that is not commonly deployed.
- 6 to 12 tasks. Each task is a short verb-first phrase (max ~90 characters).
- If weekly hours are supplied for a task, keep that exact number in hoursPerWeek. If not supplied, estimate a sensible number for a full-time role and make all tasks sum to roughly 38 hours.
- hoursSavedPerWeek must be less than hoursPerWeek and consistent with the band (full ~90%, high ~65%, partial ~35%, human ~5%).
- "reason" is one short sentence explaining WHY, in business language.
- "approach" names the practical mechanism, e.g. "RPA on the invoice queue" or "AI agent drafting the weekly report".
- overallScore is the hours-weighted average automatability, 0-100, as an integer.
- nextActions: 3 to 4 concrete, decision-oriented next steps for a leader (pilot, validate, reinvest freed time, upskill).
- Tone: professional, optimistic, practical. This frees people from repetitive work; it is never framed as replacing people or justifying job cuts. Never name or speculate about individuals.`;

export const Route = createFileRoute("/api/automation-analyze")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let input;
        try {
          input = InputSchema.parse(await request.json());
        } catch {
          return new Response("Invalid analysis request", { status: 400 });
        }

        const key = process.env["LOVABLE_API_KEY"];
        if (!key) return new Response("AI is not configured for this workspace.", { status: 500 });

        const prompt = [
          `Role title: ${input.roleTitle}`,
          input.department ? `Department / function: ${input.department}` : "",
          input.context ? `Context: ${input.context}` : "",
          input.tools ? `Tools and systems used today: ${input.tools}` : "",
          input.tasks.length
            ? `Known tasks (keep these, keep the supplied hours exactly, add missing ones only if clearly implied):\n${input.tasks
                .map(
                  (t) =>
                    `- ${t.task}${t.hoursPerWeek > 0 ? ` (${t.hoursPerWeek} hours per week)` : ""}`,
                )
                .join("\n")}`
            : "",
          input.jobDescription
            ? `Job description / responsibilities:\n${input.jobDescription.slice(0, 8000)}`
            : "",
        ]
          .filter(Boolean)
          .join("\n\n");

        const initialRunId = getLovableAiGatewayRunId(request);
        const gateway = createLovableAiGatewayProvider(key, initialRunId);

        try {
          const result = streamText({
            model: gateway("google/gemini-3.6-flash"),
            system: SYSTEM,
            prompt,
            output: Output.object({ schema: ResultSchema }),
          });
          const output = await result.output;
          return Response.json(output);
        } catch (error) {
          if (NoObjectGeneratedError.isInstance(error)) {
            console.error("automation-analyze schema miss", error.text?.slice(0, 400));
            return new Response("The analysis came back in an unexpected shape.", { status: 502 });
          }
          const message = error instanceof Error ? error.message : "AI request failed";
          console.error("automation-analyze failed", message);
          return new Response(message, { status: 502 });
        }
      },
    },
  },
});