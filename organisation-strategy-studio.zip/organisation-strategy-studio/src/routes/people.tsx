import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  BookmarkPlus,
  Check,
  Download,
  FilterX,
  LayoutGrid,
  Plus,
  Star,
  Table2,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { EMPLOYMENT_TYPES, LEVER_META, STATUS_META, type Employee } from "@/lib/orgeasy/types";
import { SUPPORTED_COUNTRIES } from "@/lib/orgeasy/countries";
import { csvToEmployees, downloadBlob, employeesToCsv } from "@/lib/orgeasy/csv";
import { formatMoney } from "@/lib/orgeasy/impact";
import { fileToAvatarDataUrl } from "@/lib/orgeasy/photo";
import {
  countActiveFilters,
  describeFilters,
  loadPresets,
  sameFilters,
  savePresets,
  suggestPresetName,
  type FilterPreset,
  type PeopleFilterState,
} from "@/lib/orgeasy/filter-presets";
import { resolveBaseline } from "@/lib/orgeasy/phases";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { SCALE_LIMITS, formatCount, scaleTier, totalPositions } from "@/lib/orgeasy/scale";

export const Route = createFileRoute("/people")({
  head: () => ({
    meta: [
      { title: "People & Roles — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Maintain the role inventory: headcount, cost, country, manager and status, with CSV import and export.",
      },
      { property: "og:title", content: "People & Roles — Organisation Strategy Studio" },
      {
        property: "og:description",
        content: "Role inventory with headcount, cost, country and status, plus CSV import/export.",
      },
    ],
  }),
  component: People,
});

type ChangeKind = "new" | "removed" | "reduced" | "grown" | "moved" | "same";

const CHANGE_META: Record<ChangeKind, { label: string; className: string }> = {
  new: { label: "New role", className: "bg-brand/12 text-brand" },
  removed: { label: "Removed", className: "bg-destructive/12 text-destructive" },
  reduced: { label: "Reduced", className: "border border-warning/25 bg-warning-subtle text-warning" },
  grown: { label: "Grown", className: "border border-success/25 bg-success-subtle text-success" },
  moved: { label: "Reassigned", className: "border border-info/25 bg-info-subtle text-info" },
  same: { label: "Unchanged", className: "bg-secondary text-muted-foreground" },
};

const CHANGE_ORDER: ChangeKind[] = ["new", "removed", "reduced", "grown", "moved", "same"];

function People() {
  const { workspace, scenario, upsertEmployee, addEmployee, removeEmployee, replaceEmployees, snapshotScenario } =
    useOrgEasy();
  const [view, setView] = useState<"table" | "cards">("table");
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [departmentFilter, setDepartmentFilter] = useState("all");
  const [countryFilter, setCountryFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [managerFilter, setManagerFilter] = useState("all");
  const [openRolesOnly, setOpenRolesOnly] = useState(false);
  const [changeFilter, setChangeFilter] = useState<"all" | ChangeKind>("all");
  const [presets, setPresets] = useState<FilterPreset[]>(() => loadPresets());
  const [presetName, setPresetName] = useState("");
  const [saveOpen, setSaveOpen] = useState(false);
  const [editing, setEditing] = useState<Employee | null>(null);
  const [page, setPage] = useState(1);
  const fileRef = useRef<HTMLInputElement>(null);
  const photoRef = useRef<HTMLInputElement>(null);

  const employees = scenario?.employees ?? [];

  // Future-state awareness: compare each role against the scenario's baseline
  // (the previous phase or the current state) so the inventory reflects what
  // the transformation actually does to each role.
  const baseline = useMemo(
    () => resolveBaseline(workspace.scenarios, scenario ?? null),
    [workspace.scenarios, scenario],
  );

  const changeMap = useMemo(() => {
    const map = new Map<string, { kind: ChangeKind; from: number; to: number }>();
    if (!baseline || baseline.id === scenario?.id) return map;
    const base = new Map(baseline.employees.map((e) => [e.id, e]));
    for (const e of employees) {
      const prev = base.get(e.id);
      const from = prev?.plannedHeadcount ?? 0;
      const to = e.plannedHeadcount;
      let kind: ChangeKind = "same";
      if (!prev) kind = "new";
      else if (to === 0 && from > 0) kind = "removed";
      else if (to < from) kind = "reduced";
      else if (to > from) kind = "grown";
      else if (prev.managerId !== e.managerId) kind = "moved";
      map.set(e.id, { kind, from, to });
    }
    return map;
  }, [baseline, employees, scenario?.id]);

  const changeCounts = useMemo(() => {
    const counts: Record<ChangeKind, number> = {
      new: 0,
      removed: 0,
      reduced: 0,
      grown: 0,
      moved: 0,
      same: 0,
    };
    for (const c of changeMap.values()) counts[c.kind] += 1;
    return counts;
  }, [changeMap]);

  const byId = useMemo(() => new Map(employees.map((e) => [e.id, e])), [employees]);
  const managers = useMemo(
    () =>
      employees
        .slice(0, 2000)
        .map((e) => ({ id: e.id, label: `${e.name || "Open Role"} — ${e.title}` })),
    [employees],
  );

  const departments = useMemo(
    () => [...new Set(employees.map((e) => e.department).filter(Boolean))].sort(),
    [employees],
  );
  const countries = useMemo(
    () => [...new Set(employees.map((e) => e.country).filter(Boolean))].sort(),
    [employees],
  );
  const managerOptions = useMemo(() => {
    const managerIds = new Set(employees.map((e) => e.managerId).filter(Boolean) as string[]);
    return employees
      .filter((e) => managerIds.has(e.id))
      .slice(0, 2000)
      .map((e) => ({ id: e.id, label: e.name || e.title }));
  }, [employees]);

  const filtered = useMemo(
    () =>
      employees.filter((e) => {
        const q = query.trim().toLowerCase();
        const matchesQuery =
          !q ||
          [e.name, e.title, e.department, e.country, e.responsibilities].some((v) =>
            (v ?? "").toLowerCase().includes(q),
          );
        return (
          matchesQuery &&
          (statusFilter === "all" || e.status === statusFilter) &&
          (departmentFilter === "all" || e.department === departmentFilter) &&
          (countryFilter === "all" || e.country === countryFilter) &&
          (typeFilter === "all" || e.employmentType === typeFilter) &&
          (managerFilter === "all" ||
            (managerFilter === "none" ? !e.managerId : e.managerId === managerFilter)) &&
          (!openRolesOnly || !e.name.trim()) &&
          (changeFilter === "all" || (changeMap.get(e.id)?.kind ?? "same") === changeFilter)
        );
      }),
    [
      employees,
      query,
      statusFilter,
      departmentFilter,
      countryFilter,
      typeFilter,
      managerFilter,
      openRolesOnly,
      changeFilter,
      changeMap,
    ],
  );

  const currentFilters: PeopleFilterState = {
    query,
    status: statusFilter,
    department: departmentFilter,
    country: countryFilter,
    employmentType: typeFilter,
    manager: managerFilter,
    openRolesOnly,
  };
  const activeFilters = countActiveFilters(currentFilters);

  // Enterprise scale: render one page at a time so the table stays responsive
  // whether the scenario holds 500 or 500,000 rows.
  const pageSize = SCALE_LIMITS.tableRows;
  const pageCount = Math.max(1, Math.ceil(filtered.length / pageSize));
  const safePage = Math.min(Math.max(page, 1), pageCount);
  const paged = useMemo(
    () => filtered.slice((safePage - 1) * pageSize, safePage * pageSize),
    [filtered, safePage, pageSize],
  );
  const tier = scaleTier(employees.length);
  const positions = useMemo(() => totalPositions(employees), [employees]);
  useEffect(() => {
    setPage(1);
  }, [
    query,
    statusFilter,
    departmentFilter,
    countryFilter,
    typeFilter,
    managerFilter,
    openRolesOnly,
    changeFilter,
  ]);

  const applyFilters = (f: PeopleFilterState) => {
    setQuery(f.query);
    setStatusFilter(f.status);
    setDepartmentFilter(f.department);
    setCountryFilter(f.country);
    setTypeFilter(f.employmentType);
    setManagerFilter(f.manager);
    setOpenRolesOnly(f.openRolesOnly);
  };

  const activePresetId = presets.find((p) => sameFilters(p, currentFilters))?.id ?? null;

  const persistPresets = (next: FilterPreset[]) => {
    setPresets(next);
    savePresets(next);
  };

  const saveCurrentPreset = () => {
    const name = (presetName.trim() || suggestPresetName(currentFilters)).slice(0, 60);
    const existing = presets.find((p) => p.name.toLowerCase() === name.toLowerCase());
    const preset: FilterPreset = {
      ...currentFilters,
      id: existing?.id ?? `preset-${Date.now()}`,
      name,
    };
    persistPresets(
      existing ? presets.map((p) => (p.id === existing.id ? preset : p)) : [...presets, preset],
    );
    setPresetName("");
    setSaveOpen(false);
    toast.success(existing ? `Updated view “${name}”` : `Saved view “${name}”`);
  };

  const resetFilters = () => {
    setQuery("");
    setStatusFilter("all");
    setDepartmentFilter("all");
    setCountryFilter("all");
    setTypeFilter("all");
    setManagerFilter("all");
    setOpenRolesOnly(false);
  };

  const filteredHeadcount = filtered.reduce((a, e) => a + e.plannedHeadcount, 0);
  const filteredCost = filtered.reduce((a, e) => a + e.plannedCost * e.plannedHeadcount, 0);

  const cur = scenario?.currency ?? "USD";

  return (
    <div className="pb-12">
      <PageHeader
        title="People & roles"
        description="One row per role. Open roles need no name. Planned headcount and planned cost drive the impact simulation."
        actions={
          <>
            <input
              ref={fileRef}
              type="file"
              accept=".csv,text/csv"
              className="hidden"
              onChange={async (event) => {
                const file = event.target.files?.[0];
                if (!file) return;
                const { employees: parsed, errors } = csvToEmployees(await file.text());
                if (errors.length) toast.error(errors.join(" "));
                if (parsed.length) {
                  snapshotScenario({ reason: "pre-import", label: `Before ${file.name}` });
                  replaceEmployees(parsed);
                  toast.success(`Imported ${parsed.length} roles`);
                }
                event.target.value = "";
              }}
            />
            <Button variant="outline" onClick={() => fileRef.current?.click()}>
              <Upload className="mr-1.5 size-4" /> Import CSV
            </Button>
            <Button
              variant="outline"
              onClick={() =>
                downloadBlob(
                  employeesToCsv(employees),
                  `${scenario?.name ?? "roles"}.csv`,
                  "text/csv",
                )
              }
            >
              <Download className="mr-1.5 size-4" /> Export CSV
            </Button>
            <Button onClick={() => setEditing(addEmployee())}>
              <Plus className="mr-1.5 size-4" /> Add role
            </Button>
          </>
        }
      />

      <div className="space-y-4 px-8 py-6">
        <div className="flex flex-wrap items-center gap-2.5">
          <Input
            placeholder="Search name, title, department or country"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="max-w-xs bg-card"
          />
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40 bg-card">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              {Object.entries(STATUS_META).map(([key, meta]) => (
                <SelectItem key={key} value={key}>
                  {meta.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
            <SelectTrigger className="w-44 bg-card">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All departments</SelectItem>
              {departments.map((d) => (
                <SelectItem key={d} value={d}>
                  {d}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={countryFilter} onValueChange={setCountryFilter}>
            <SelectTrigger className="w-40 bg-card">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All countries</SelectItem>
              {countries.map((c) => (
                <SelectItem key={c} value={c}>
                  {c}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-36 bg-card">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All types</SelectItem>
              {EMPLOYMENT_TYPES.map((t) => (
                <SelectItem key={t} value={t}>
                  {t}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={managerFilter} onValueChange={setManagerFilter}>
            <SelectTrigger className="w-44 bg-card">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Any manager</SelectItem>
              <SelectItem value="none">No manager (top level)</SelectItem>
              {managerOptions.map((m) => (
                <SelectItem key={m.id} value={m.id}>
                  Reports to {m.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            variant={openRolesOnly ? "default" : "outline"}
            size="sm"
            className="h-9"
            onClick={() => setOpenRolesOnly((v) => !v)}
          >
            Open roles only
          </Button>
          {activeFilters ? (
            <Button variant="ghost" size="sm" className="h-9" onClick={resetFilters}>
              <FilterX className="mr-1.5 size-4" /> Clear ({activeFilters})
            </Button>
          ) : null}
          <div className="ml-auto flex overflow-hidden rounded-md border border-border bg-card">
            {(
              [
                { key: "table", icon: Table2, label: "Table" },
                { key: "cards", icon: LayoutGrid, label: "Cards" },
              ] as const
            ).map((v) => (
              <button
                key={v.key}
                onClick={() => setView(v.key)}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-2 text-[12.5px] font-medium",
                  view === v.key ? "bg-brand text-brand-foreground" : "text-muted-foreground",
                )}
              >
                <v.icon className="size-3.5" /> {v.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 rounded-lg border border-border bg-card px-3 py-2.5 shadow-panel">
          <span className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
            <Star className="size-3.5" /> Saved views
          </span>
          {presets.length ? (
            presets.map((p) => {
              const isActive = activePresetId === p.id;
              return (
                <span
                  key={p.id}
                  className={cn(
                    "group flex items-center rounded-full border text-[12px] transition-colors",
                    isActive
                      ? "border-brand bg-brand text-brand-foreground"
                      : "border-border bg-secondary text-foreground hover:border-brand/50",
                  )}
                >
                  <button
                    type="button"
                    className="flex items-center gap-1.5 py-1 pl-3 pr-1.5 font-medium"
                    title={describeFilters(p)}
                    onClick={() => {
                      applyFilters(p);
                      toast.success(`View “${p.name}” applied`);
                    }}
                  >
                    {isActive ? <Check className="size-3.5" /> : null}
                    {p.name}
                  </button>
                  <button
                    type="button"
                    aria-label={`Delete view ${p.name}`}
                    className="pr-2 pl-0.5 opacity-50 hover:opacity-100"
                    onClick={() => {
                      persistPresets(presets.filter((x) => x.id !== p.id));
                      toast.success(`Deleted view “${p.name}”`);
                    }}
                  >
                    <X className="size-3.5" />
                  </button>
                </span>
              );
            })
          ) : (
            <span className="text-[12.5px] text-muted-foreground">
              No saved views yet — filter by department or country, then save it for one-click reuse.
            </span>
          )}
          <Popover open={saveOpen} onOpenChange={setSaveOpen}>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="ml-auto h-8">
                <BookmarkPlus className="mr-1.5 size-4" /> Save current view
              </Button>
            </PopoverTrigger>
            <PopoverContent align="end" className="w-80 space-y-3">
              <div className="space-y-1">
                <Label className="text-[12px]">View name</Label>
                <Input
                  autoFocus
                  value={presetName}
                  placeholder={suggestPresetName(currentFilters)}
                  onChange={(e) => setPresetName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") saveCurrentPreset();
                  }}
                />
              </div>
              <p className="text-[12px] text-muted-foreground">
                Filters: {describeFilters(currentFilters)}
              </p>
              <Button size="sm" className="w-full" onClick={saveCurrentPreset}>
                Save view
              </Button>
            </PopoverContent>
          </Popover>
        </div>

        <p className="text-[12.5px] text-muted-foreground">
          Showing <span className="font-semibold text-foreground">{filtered.length}</span> of{" "}
          {formatCount(employees.length)} roles · {filteredHeadcount} planned positions ·{" "}
          {formatMoney(filteredCost, cur)} planned annual cost
          {tier !== "standard" ? (
            <span className="ml-1">
              · {formatCount(positions)} employees represented ({tier} scale — paged view)
            </span>
          ) : null}
        </p>

        {baseline && changeMap.size ? (
          <div className="rounded-lg border border-border bg-card p-4 shadow-panel">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <p className="text-[13px] font-semibold">
                Future-state view ·{" "}
                <span className="text-brand">
                  {scenario?.phaseLabel?.trim() || scenario?.name}
                </span>
              </p>
              <p className="text-[12px] text-muted-foreground">
                Compared with {baseline.phaseLabel?.trim() || baseline.name}
              </p>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <button
                onClick={() => setChangeFilter("all")}
                className={cn(
                  "rounded-md border px-2.5 py-1 text-[12px] font-medium transition-colors",
                  changeFilter === "all"
                    ? "border-brand bg-brand/10 text-brand"
                    : "border-border text-muted-foreground hover:border-brand/50",
                )}
              >
                All roles ({formatCount(employees.length)})
              </button>
              {CHANGE_ORDER.filter((k) => changeCounts[k] > 0).map((k) => (
                <button
                  key={k}
                  onClick={() => setChangeFilter(changeFilter === k ? "all" : k)}
                  className={cn(
                    "rounded-md border px-2.5 py-1 text-[12px] font-medium transition-colors",
                    changeFilter === k
                      ? "border-brand bg-brand/10 text-brand"
                      : "border-border text-muted-foreground hover:border-brand/50",
                  )}
                >
                  {CHANGE_META[k].label} ({formatCount(changeCounts[k])})
                </button>
              ))}
            </div>
          </div>
        ) : null}

        {view === "table" ? (
          <div className="overflow-x-auto rounded-lg border border-border bg-card shadow-panel">
            <table className="w-full min-w-[1180px] text-left text-[13px]">
              <thead className="bg-secondary text-[11px] uppercase tracking-wide text-muted-foreground">
                <tr>
                  {[
                    "Name / Open role",
                    "Job title",
                    "Department",
                    "Country",
                    "Type",
                    "Manager",
                    "HC now",
                    "HC plan",
                    "vs baseline",
                    "Cost now",
                    "Cost plan",
                    "Service",
                    "Status",
                    "",
                  ].map((h) => (
                    <th key={h} className="whitespace-nowrap px-3 py-2.5 font-semibold">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {paged.map((e) => {
                  const manager = e.managerId ? byId.get(e.managerId) : undefined;
                  const change = changeMap.get(e.id);
                  return (
                    <tr key={e.id} className="hover:bg-accent/40">
                      <td className="px-3 py-2.5">
                        <button
                          className="font-medium text-brand hover:underline"
                          onClick={() => setEditing(e)}
                        >
                          {e.name || "Open Role"}
                        </button>
                      </td>
                      <td className="px-3 py-2.5">{e.title}</td>
                      <td className="px-3 py-2.5">{e.department}</td>
                      <td className="px-3 py-2.5">{e.country}</td>
                      <td className="px-3 py-2.5 text-muted-foreground">{e.employmentType}</td>
                      <td className="px-3 py-2.5 text-muted-foreground">
                        {manager ? manager.name || manager.title : "—"}
                      </td>
                      <td className="px-3 py-2.5 tabular-nums">{e.currentHeadcount}</td>
                      <td className="px-3 py-2.5 tabular-nums font-medium">{e.plannedHeadcount}</td>
                      <td className="whitespace-nowrap px-3 py-2.5">
                        {change ? (
                          <span className="flex items-center gap-1.5">
                            <span
                              className={cn(
                                "rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide",
                                CHANGE_META[change.kind].className,
                              )}
                            >
                              {CHANGE_META[change.kind].label}
                            </span>
                            {change.kind !== "same" && change.kind !== "moved" ? (
                              <span className="tabular-nums text-[12px] text-muted-foreground">
                                {change.from} → {change.to}
                              </span>
                            ) : null}
                            {e.reductionLever ? (
                              <span className="text-[11px] text-muted-foreground">
                                {LEVER_META[e.reductionLever].label}
                              </span>
                            ) : null}
                          </span>
                        ) : (
                          <span className="text-muted-foreground">—</span>
                        )}
                      </td>
                      <td className="px-3 py-2.5 tabular-nums">
                        {formatMoney(e.currentCost, cur)}
                      </td>
                      <td className="px-3 py-2.5 tabular-nums">
                        {formatMoney(e.plannedCost, cur)}
                      </td>
                      <td className="px-3 py-2.5 text-muted-foreground">
                        {(e.serviceMonths / 12).toFixed(1)} yrs
                      </td>
                      <td className="px-3 py-2.5">
                        <span
                          className={cn(
                            "rounded px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide",
                            STATUS_META[e.status].className,
                          )}
                        >
                          {STATUS_META[e.status].label}
                        </span>
                      </td>
                      <td className="px-3 py-2.5">
                        <Button variant="ghost" size="icon" onClick={() => removeEmployee(e.id)}>
                          <Trash2 className="size-4 text-destructive" />
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {!filtered.length ? (
              <p className="px-4 py-10 text-center text-sm text-muted-foreground">
                No roles match these filters.
              </p>
            ) : null}
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
            {paged.map((e) => (
              <button
                key={e.id}
                onClick={() => setEditing(e)}
                className="rounded-lg border border-border bg-card p-4 text-left shadow-panel transition-colors hover:border-brand/60"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex min-w-0 items-center gap-2.5">
                    {e.photoUrl ? (
                      <img
                        src={e.photoUrl}
                        alt={e.name || e.title}
                        className="size-9 shrink-0 rounded-full object-cover ring-2 ring-brand/20"
                      />
                    ) : null}
                    <div className="min-w-0">
                      <p className="truncate text-[14px] font-semibold">{e.name || "Open Role"}</p>
                      <p className="truncate text-xs text-muted-foreground">{e.title}</p>
                    </div>
                  </div>
                  <span
                    className={cn(
                      "shrink-0 rounded px-2 py-0.5 text-[10px] font-semibold uppercase",
                      STATUS_META[e.status].className,
                    )}
                  >
                    {STATUS_META[e.status].label}
                  </span>
                </div>
                <p className="mt-3 line-clamp-2 text-xs text-muted-foreground">
                  {e.responsibilities || "No responsibilities captured."}
                </p>
                <dl className="mt-3 grid grid-cols-2 gap-2 text-[11.5px]">
                  <div>
                    <dt className="text-muted-foreground">Department</dt>
                    <dd className="font-medium">{e.department || "—"}</dd>
                  </div>
                  <div>
                    <dt className="text-muted-foreground">Country</dt>
                    <dd className="font-medium">{e.country}</dd>
                  </div>
                  <div>
                    <dt className="text-muted-foreground">Headcount</dt>
                    <dd className="font-medium tabular-nums">
                      {e.currentHeadcount} → {e.plannedHeadcount}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-muted-foreground">Annual cost</dt>
                    <dd className="font-medium tabular-nums">{formatMoney(e.plannedCost, cur)}</dd>
                  </div>
                </dl>
              </button>
            ))}
          </div>
        )}

        {pageCount > 1 ? (
          <div className="flex items-center justify-between gap-3 rounded-lg border border-border bg-card px-3 py-2 text-[12.5px]">
            <span className="text-muted-foreground">
              Rows {formatCount((safePage - 1) * pageSize + 1)}–
              {formatCount(Math.min(safePage * pageSize, filtered.length))} of{" "}
              {formatCount(filtered.length)}
            </span>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={safePage <= 1}
                onClick={() => setPage(safePage - 1)}
              >
                Previous
              </Button>
              <span className="tabular-nums text-muted-foreground">
                Page {safePage} / {formatCount(pageCount)}
              </span>
              <Button
                variant="outline"
                size="sm"
                disabled={safePage >= pageCount}
                onClick={() => setPage(safePage + 1)}
              >
                Next
              </Button>
            </div>
          </div>
        ) : null}
      </div>

      <Sheet open={!!editing} onOpenChange={(open) => !open && setEditing(null)}>
        <SheetContent className="w-full overflow-y-auto sm:max-w-lg">
          <SheetHeader>
            <SheetTitle>Edit role</SheetTitle>
          </SheetHeader>
          {editing ? (
            <div className="space-y-4 px-4 pb-8">
              <div className="flex items-center gap-3 rounded-xl border border-border bg-muted/30 p-3">
                {editing.photoUrl ? (
                  <img
                    src={editing.photoUrl}
                    alt={editing.name || editing.title}
                    className="size-14 shrink-0 rounded-full object-cover ring-2 ring-brand/30"
                  />
                ) : (
                  <span className="grid size-14 shrink-0 place-items-center rounded-full bg-brand/10 text-xs font-semibold text-brand">
                    Photo
                  </span>
                )}
                <div className="min-w-0 flex-1">
                  <p className="text-[13px] font-medium">Role photo</p>
                  <p className="text-[11.5px] text-muted-foreground">
                    Square headshots work best; images are cropped and resized automatically.
                  </p>
                </div>
                <input
                  ref={photoRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={async (ev) => {
                    const file = ev.target.files?.[0];
                    ev.target.value = "";
                    if (!file) return;
                    try {
                      const photoUrl = await fileToAvatarDataUrl(file);
                      setEditing((prev) => (prev ? { ...prev, photoUrl } : prev));
                    } catch (err) {
                      toast.error(err instanceof Error ? err.message : "Could not read that image");
                    }
                  }}
                />
                <div className="flex shrink-0 flex-col gap-1.5">
                  <Button size="sm" variant="outline" onClick={() => photoRef.current?.click()}>
                    {editing.photoUrl ? "Replace" : "Upload"}
                  </Button>
                  {editing.photoUrl ? (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setEditing({ ...editing, photoUrl: undefined })}
                    >
                      Remove
                    </Button>
                  ) : null}
                </div>
              </div>

              {(
                [
                  ["name", "Name (leave blank for an open role)", "text"],
                  ["title", "Job title", "text"],
                  ["department", "Department", "text"],
                ] as const
              ).map(([field, label]) => (
                <div key={field} className="space-y-1.5">
                  <Label>{label}</Label>
                  <Input
                    value={String(editing[field] ?? "")}
                    onChange={(ev) => setEditing({ ...editing, [field]: ev.target.value })}
                  />
                </div>
              ))}

              <div className="space-y-1.5">
                <Label>Country</Label>
                <Select
                  value={editing.country}
                  onValueChange={(v) => setEditing({ ...editing, country: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SUPPORTED_COUNTRIES.map((c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1.5">
                <Label>Job responsibilities</Label>
                <Textarea
                  rows={3}
                  value={editing.responsibilities}
                  onChange={(ev) => setEditing({ ...editing, responsibilities: ev.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Employment type</Label>
                  <Select
                    value={editing.employmentType}
                    onValueChange={(v) =>
                      setEditing({ ...editing, employmentType: v as Employee["employmentType"] })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {EMPLOYMENT_TYPES.map((t) => (
                        <SelectItem key={t} value={t}>
                          {t}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Status</Label>
                  <Select
                    value={editing.status}
                    onValueChange={(v) =>
                      setEditing({ ...editing, status: v as Employee["status"] })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(STATUS_META).map(([key, meta]) => (
                        <SelectItem key={key} value={key}>
                          {meta.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-1.5">
                <Label>Manager</Label>
                <Select
                  value={editing.managerId ?? "none"}
                  onValueChange={(v) =>
                    setEditing({ ...editing, managerId: v === "none" ? null : v })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No manager (top of chart)</SelectItem>
                    {managers
                      .filter((m) => m.id !== editing.id)
                      .map((m) => (
                        <SelectItem key={m.id} value={m.id}>
                          {m.label}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {(
                  [
                    ["currentHeadcount", "Current headcount"],
                    ["plannedHeadcount", "Planned headcount"],
                    ["currentCost", "Current annual cost"],
                    ["plannedCost", "Planned annual cost"],
                    ["serviceMonths", "Length of service (months)"],
                  ] as const
                ).map(([field, label]) => (
                  <div key={field} className="space-y-1.5">
                    <Label>{label}</Label>
                    <Input
                      type="number"
                      value={editing[field]}
                      onChange={(ev) =>
                        setEditing({ ...editing, [field]: Number(ev.target.value) || 0 })
                      }
                    />
                  </div>
                ))}
              </div>

              <div className="flex gap-2 pt-2">
                <Button
                  className="flex-1"
                  onClick={() => {
                    upsertEmployee({ ...editing, isOpenRole: !editing.name.trim() });
                    setEditing(null);
                    toast.success("Role saved");
                  }}
                >
                  Save role
                </Button>
                <Button variant="outline" onClick={() => setEditing(null)}>
                  Cancel
                </Button>
              </div>
            </div>
          ) : null}
        </SheetContent>
      </Sheet>
    </div>
  );
}
