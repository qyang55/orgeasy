import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import {
  Check,
  Copy,
  Download,
  FileText,
  Loader2,
  RefreshCw,
  Sparkle,
  Square,
  Wand2,
} from "lucide-react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { Disclaimer } from "@/components/orgeasy/Disclaimer";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { buildTemplates } from "@/lib/orgeasy/templates";
import {
  ASSET_PRESETS,
  LANGUAGES,
  LENGTHS,
  TONES,
  buildScenarioFacts,
} from "@/lib/orgeasy/copilot";
import { downloadBlob } from "@/lib/orgeasy/csv";
import { withNotices } from "@/lib/orgeasy/notices";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/communications")({
  head: () => ({
    meta: [
      { title: "OD Communication Copilot — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Draft leadership announcements, manager briefings, FAQs and consultation notes with AI, grounded in your restructuring scenario data.",
      },
      { property: "og:title", content: "OD Communication Copilot — Organisation Strategy Studio" },
      {
        property: "og:description",
        content:
          "An AI copilot that writes change communications from your live scenario numbers, plus a downloadable example library.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CommunicationCopilot,
});

function CommunicationCopilot() {
  const { scenario } = useOrgEasy();
  const examples = useMemo(() => buildTemplates(scenario), [scenario]);
  const facts = useMemo(() => buildScenarioFacts(scenario), [scenario]);

  const [presetId, setPresetId] = useState(ASSET_PRESETS[0]!.id);
  const preset = ASSET_PRESETS.find((p) => p.id === presetId) ?? ASSET_PRESETS[0]!;
  const [customAsset, setCustomAsset] = useState("");
  const [audience, setAudience] = useState(ASSET_PRESETS[0]!.audience);
  const [channel, setChannel] = useState(ASSET_PRESETS[0]!.channel);
  const [tone, setTone] = useState(TONES[0]!);
  const [length, setLength] = useState(LENGTHS[1]!);
  const [language, setLanguage] = useState(LANGUAGES[0]!);
  const [senderName, setSenderName] = useState("");
  const [senderTitle, setSenderTitle] = useState("");
  const [mustInclude, setMustInclude] = useState("");
  const [guardrails, setGuardrails] = useState("");
  const [useExampleStyle, setUseExampleStyle] = useState(true);

  const [draft, setDraft] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [revision, setRevision] = useState("");
  const [copied, setCopied] = useState(false);
  const abortRef = useRef<AbortController | null>(null);

  const [exampleId, setExampleId] = useState(examples[0]?.id ?? "");
  const activeExample = examples.find((t) => t.id === exampleId) ?? examples[0];

  function applyPreset(id: string) {
    setPresetId(id);
    const next = ASSET_PRESETS.find((p) => p.id === id);
    if (!next) return;
    if (next.audience) setAudience(next.audience);
    if (next.channel) setChannel(next.channel);
  }

  const assetLabel = presetId === "custom" ? customAsset.trim() : preset.asset;

  async function generate(mode: "new" | "revise") {
    if (!assetLabel) {
      toast.error("Describe the asset you need first");
      return;
    }
    if (mode === "revise" && !revision.trim()) {
      toast.error("Tell the copilot what to change");
      return;
    }

    const referenceTemplate = preset.referenceTemplateId
      ? examples.find((t) => t.id === preset.referenceTemplateId)
      : undefined;

    const controller = new AbortController();
    abortRef.current = controller;
    setStreaming(true);
    if (mode === "new") setDraft("");

    const previousDraft = mode === "revise" ? draft : "";

    try {
      const res = await fetch("/api/od-copilot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
          asset: assetLabel,
          audience: audience || "All employees",
          tone,
          language,
          length,
          channel: channel || "Email",
          senderName,
          senderTitle,
          mustInclude,
          guardrails,
          facts,
          reference: useExampleStyle && referenceTemplate ? referenceTemplate.body : "",
          previousDraft,
          revisionRequest: mode === "revise" ? revision : "",
        }),
      });

      if (!res.ok || !res.body) {
        const detail = await res.text().catch(() => "");
        if (res.status === 429) toast.error("AI rate limit reached — try again in a moment.");
        else if (res.status === 402)
          toast.error("AI credits exhausted. Add credits in workspace settings.");
        else toast.error(detail || "The copilot could not generate this draft.");
        return;
      }

      if (mode === "revise") setDraft("");
      const reader = res.body.pipeThrough(new TextDecoderStream()).getReader();
      let acc = "";
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        acc += value;
        setDraft(acc);
      }
      if (mode === "revise") setRevision("");
    } catch (error) {
      if ((error as Error).name !== "AbortError") {
        toast.error("The copilot connection dropped. Please try again.");
      }
    } finally {
      setStreaming(false);
      abortRef.current = null;
    }
  }

  const fileBase = `${scenario?.name ?? "scenario"}-${preset.id}`.replace(/[^\w-]+/g, "-");

  return (
    <div className="pb-12">
      <PageHeader
        title="OD communication copilot"
        description="Brief the copilot once and it writes change communications grounded in this scenario's headcount, cost and country data. Example packs stay available as a starting point."
        actions={
          <>
            <Button
              variant="outline"
              disabled={!draft}
              onClick={async () => {
                await navigator.clipboard.writeText(draft);
                setCopied(true);
                setTimeout(() => setCopied(false), 1600);
                toast.success("Draft copied");
              }}
            >
              {copied ? <Check className="mr-1.5 size-4" /> : <Copy className="mr-1.5 size-4" />}
              Copy draft
            </Button>
            <Button
              disabled={!draft}
              onClick={() =>
                downloadBlob(
                  withNotices(draft, "Important notices — AI-assisted draft"),
                  `${fileBase}.md`,
                  "text/markdown",
                )
              }
            >
              <Download className="mr-1.5 size-4" /> Download
            </Button>
          </>
        }
      />

      <div className="space-y-5 px-8 py-6">
        <Disclaimer />

        <Tabs defaultValue="copilot">
          <TabsList>
            <TabsTrigger value="copilot">
              <Wand2 className="mr-1.5 size-4" /> Copilot
            </TabsTrigger>
            <TabsTrigger value="examples">
              <FileText className="mr-1.5 size-4" /> Example library
            </TabsTrigger>
          </TabsList>

          <TabsContent value="copilot" className="mt-5">
            <div className="grid gap-6 xl:grid-cols-[380px_1fr]">
              <section className="space-y-5 rounded-lg border border-border bg-card p-5 shadow-panel">
                <div className="space-y-2">
                  <Label>What do you need?</Label>
                  <div className="grid gap-1.5">
                    {ASSET_PRESETS.map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => applyPreset(p.id)}
                        className={cn(
                          "rounded-md border px-3 py-2 text-left transition-colors",
                          presetId === p.id
                            ? "border-brand bg-accent"
                            : "border-border bg-background hover:border-brand/50",
                        )}
                      >
                        <p className="text-[13px] font-semibold">{p.label}</p>
                        <p className="text-[11.5px] text-muted-foreground">{p.hint}</p>
                      </button>
                    ))}
                  </div>
                </div>

                {presetId === "custom" ? (
                  <div className="space-y-1.5">
                    <Label htmlFor="custom-asset">Describe the asset</Label>
                    <Textarea
                      id="custom-asset"
                      rows={3}
                      value={customAsset}
                      onChange={(e) => setCustomAsset(e.target.value)}
                      placeholder="e.g. A LinkedIn post explaining the new operating model to candidates"
                    />
                  </div>
                ) : null}

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label htmlFor="audience">Audience</Label>
                    <Input
                      id="audience"
                      value={audience}
                      onChange={(e) => setAudience(e.target.value)}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="channel">Channel</Label>
                    <Input
                      id="channel"
                      value={channel}
                      onChange={(e) => setChannel(e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label>Tone</Label>
                    <Select value={tone} onValueChange={setTone}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {TONES.map((t) => (
                          <SelectItem key={t} value={t}>
                            {t}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Length</Label>
                    <Select value={length} onValueChange={setLength}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {LENGTHS.map((l) => (
                          <SelectItem key={l} value={l}>
                            {l}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <Label>Language</Label>
                  <Select value={language} onValueChange={setLanguage}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {LANGUAGES.map((l) => (
                        <SelectItem key={l} value={l}>
                          {l}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label htmlFor="sender">Signed by</Label>
                    <Input
                      id="sender"
                      value={senderName}
                      onChange={(e) => setSenderName(e.target.value)}
                      placeholder="Leader name"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="sender-title">Title</Label>
                    <Input
                      id="sender-title"
                      value={senderTitle}
                      onChange={(e) => setSenderTitle(e.target.value)}
                      placeholder="Chief People Officer"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="must">Must include</Label>
                  <Textarea
                    id="must"
                    rows={3}
                    value={mustInclude}
                    onChange={(e) => setMustInclude(e.target.value)}
                    placeholder="Consultation opens 12 Sept; support package covered by HR; reference the new customer operating model"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="guard">Avoid / guardrails</Label>
                  <Textarea
                    id="guard"
                    rows={2}
                    value={guardrails}
                    onChange={(e) => setGuardrails(e.target.value)}
                    placeholder="Do not mention site closures; avoid the word redundancy in APAC versions"
                  />
                </div>

                <label className="flex items-start gap-2 text-[12.5px] text-muted-foreground">
                  <input
                    type="checkbox"
                    className="mt-0.5 accent-[var(--brand)]"
                    checked={useExampleStyle}
                    onChange={(e) => setUseExampleStyle(e.target.checked)}
                  />
                  Match the structure of the matching Organisation Strategy Studio example template
                </label>

                <div className="flex gap-2">
                  <Button className="flex-1" disabled={streaming} onClick={() => generate("new")}>
                    {streaming ? (
                      <Loader2 className="mr-1.5 size-4 animate-spin" />
                    ) : (
                      <Sparkle className="mr-1.5 size-4" />
                    )}
                    {streaming ? "Drafting…" : "Draft with AI"}
                  </Button>
                  {streaming ? (
                    <Button variant="outline" onClick={() => abortRef.current?.abort()}>
                      <Square className="size-4" />
                    </Button>
                  ) : null}
                </div>
              </section>

              <section className="flex min-h-[520px] flex-col rounded-lg border border-border bg-card shadow-panel">
                <div className="flex items-center justify-between border-b border-border px-6 py-4">
                  <div>
                    <h2 className="text-lg font-semibold">
                      {assetLabel || "Your draft"}
                    </h2>
                    <p className="text-xs text-muted-foreground">
                      Grounded in {scenario?.name ?? "the active scenario"} · {audience || "audience"} · {language}
                    </p>
                  </div>
                </div>

                <div className="flex-1 overflow-auto px-6 py-5">
                  {draft ? (
                    <div className="prose prose-sm max-w-none text-[13.5px] leading-relaxed text-foreground prose-headings:text-foreground prose-strong:text-foreground">
                      <ReactMarkdown>{draft}</ReactMarkdown>
                    </div>
                  ) : streaming ? (
                    <p className="text-sm text-muted-foreground">Reading the scenario…</p>
                  ) : (
                    <div className="mx-auto max-w-md space-y-2 py-16 text-center">
                      <Wand2 className="mx-auto size-6 text-brand" />
                      <p className="text-sm font-semibold">Nothing drafted yet</p>
                      <p className="text-[12.5px] text-muted-foreground">
                        Pick an asset, set the tone and audience, then let the copilot write it from
                        your live headcount, cost and country data. You can refine it as many times
                        as you like.
                      </p>
                    </div>
                  )}
                </div>

                <div className="space-y-2 border-t border-border px-6 py-4">
                  <Label htmlFor="revise">Refine this draft</Label>
                  <div className="flex gap-2">
                    <Textarea
                      id="revise"
                      rows={2}
                      value={revision}
                      onChange={(e) => setRevision(e.target.value)}
                      placeholder="Make it shorter, add a line about the support package, soften the second paragraph"
                      disabled={!draft || streaming}
                    />
                    <Button
                      variant="outline"
                      disabled={!draft || streaming}
                      onClick={() => generate("revise")}
                    >
                      <RefreshCw className="mr-1.5 size-4" /> Refine
                    </Button>
                  </div>
                </div>
              </section>
            </div>
          </TabsContent>

          <TabsContent value="examples" className="mt-5">
            <div className="mb-4 flex items-center justify-between gap-4 rounded-lg border border-border bg-card px-5 py-4 shadow-panel">
              <p className="text-[12.5px] text-muted-foreground">
                Pre-written example packs, auto-filled with this scenario's numbers. Use them as a
                download-and-edit starting point, or as the house-style reference for the copilot.
              </p>
              <Button
                variant="outline"
                onClick={() =>
                  downloadBlob(
                    withNotices(
                      examples
                        .map((t) => `# ${t.title}\nAudience: ${t.audience}\n\n${t.body}`)
                        .join("\n\n---\n\n"),
                      "Important notices — communication examples",
                    ),
                    `${scenario?.name ?? "communications"}-examples.txt`,
                    "text/plain",
                  )
                }
              >
                <Download className="mr-1.5 size-4" /> Download all examples
              </Button>
            </div>

            <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
              <nav className="space-y-2">
                {examples.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setExampleId(t.id)}
                    className={cn(
                      "w-full rounded-lg border px-4 py-3 text-left shadow-panel transition-colors",
                      activeExample?.id === t.id
                        ? "border-brand bg-accent"
                        : "border-border bg-card hover:border-brand/50",
                    )}
                  >
                    <p className="text-[13.5px] font-semibold">{t.title}</p>
                    <p className="text-[11.5px] text-muted-foreground">{t.audience}</p>
                  </button>
                ))}
              </nav>

              {activeExample ? (
                <article className="rounded-lg border border-border bg-card shadow-panel">
                  <div className="flex items-start justify-between gap-4 border-b border-border px-6 py-4">
                    <div>
                      <h2 className="text-lg font-semibold">{activeExample.title}</h2>
                      <p className="text-xs text-muted-foreground">
                        Audience: {activeExample.audience}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={async () => {
                          await navigator.clipboard.writeText(activeExample.body);
                          toast.success("Example copied");
                        }}
                      >
                        <Copy className="mr-1.5 size-3.5" /> Copy
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          downloadBlob(
                            withNotices(
                              activeExample.body,
                              "Important notices — communication example",
                            ),
                            `${activeExample.id}-example.txt`,
                            "text/plain",
                          )
                        }
                      >
                        <Download className="mr-1.5 size-3.5" /> Download
                      </Button>
                    </div>
                  </div>
                  <pre className="whitespace-pre-wrap px-6 py-5 font-sans text-[13.5px] leading-relaxed text-foreground">
                    {activeExample.body}
                  </pre>
                </article>
              ) : null}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}