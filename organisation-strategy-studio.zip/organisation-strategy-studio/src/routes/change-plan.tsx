import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  CalendarClock,
  CheckCircle2,
  GaugeCircle,
  Pencil,
  RotateCcw,
  UserRound,
} from "lucide-react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { Disclaimer } from "@/components/orgeasy/Disclaimer";
import { StatCard } from "@/components/orgeasy/StatCard";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { listPhases, resolveBaseline } from "@/lib/orgeasy/phases";
import { formatMoney } from "@/lib/orgeasy/impact";
import {
  ADKAR_STAGES,
  SEVERITY_META,
  buildChangePlan,
  loadChangeEdits,
  mergedActions,
  planProgress,
  readinessBand,
  readinessScore,
  saveChangeEdits,
  type ChangePlanEdits,
} from "@/lib/orgeasy/change-plan";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/change-plan")({
  head: () => ({
    meta: [
      { title: "Change Plan — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Turn the structural change in any scenario into a practical ADKAR change plan with stakeholder impact severity, owners and due dates.",
      },
      { property: "og:title", content: "Change Plan — Organisation Strategy Studio" },
      {
        property: "og:description",
        content:
          "Stakeholder impact heat map plus Awareness, Desire, Knowledge, Ability and Reinforcement actions for the active scenario.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ChangePlanPage,
});

function ChangePlanPage() {
  const { workspace, scenario } = useOrgEasy();
  const [baselineId, setBaselineId] = useState("auto");
  const [edits, setEdits] = useState<ChangePlanEdits>({});
  const [editing, setEditing] = useState<string | null>(null);

  // When the active scenario IS the current state it has no delta to plan
  // against — automatically show the first future phase's plan instead.
  const firstFuture = useMemo(
    () => listPhases(workspace.scenarios)[0] ?? null,
    [workspace.scenarios],
  );
  const planScenario = useMemo(() => {
    if (!scenario) return scenario;
    const base = resolveBaseline(workspace.scenarios, scenario);
    if ((!base || base.id === scenario.id) && firstFuture && firstFuture.id !== scenario.id) {
      return firstFuture;
    }
    return scenario;
  }, [scenario, workspace.scenarios, firstFuture]);
  const autoSwitched = planScenario?.id !== scenario?.id;

  useEffect(() => {
    setEdits(loadChangeEdits(planScenario?.id));
    setEditing(null);
  }, [planScenario?.id]);

  const autoBaseline = resolveBaseline(workspace.scenarios, planScenario);
  const baseline =
    baselineId === "auto"
      ? autoBaseline
      : (workspace.scenarios.find((s) => s.id === baselineId) ?? null);

  const plan = useMemo(() => buildChangePlan(planScenario, baseline), [planScenario, baseline]);
  const actions = useMemo(() => mergedActions(plan, edits), [plan, edits]);
  const progress = planProgress(actions);
  const readiness = readinessScore(plan, actions);
  const band = readinessBand(readiness);
  const cur = plan.currency;

  const update = (id: string, patch: Partial<ChangePlanEdits[string]>) => {
    setEdits((prev) => {
      const next = { ...prev, [id]: { ...(prev[id] ?? {}), ...patch } };
      if (planScenario) saveChangeEdits(planScenario.id, next);
      return next;
    });
  };

  const reset = (id: string) => {
    setEdits((prev) => {
      const next = { ...prev };
      delete next[id];
      if (planScenario) saveChangeEdits(planScenario.id, next);
      return next;
    });
    toast.success("Reverted to the generated wording");
  };

  const maxScore = Math.max(1, ...plan.groups.map((g) => g.score));

  return (
    <div>
      <PageHeader
        title="Change Plan"
        description="Every scenario gets an ADKAR-based change plan generated from its own structural delta. Edit the wording, assign owners and set dates."
      />

      <div className="space-y-6 px-8 py-6">
        <Disclaimer />

        {autoSwitched && planScenario ? (
          <p className="rounded-lg border border-brand/30 bg-brand/10 px-4 py-2.5 text-[13px] text-foreground">
            The current state has no changes to plan — showing the generated plan for{" "}
            <span className="font-semibold">{planScenario.name}</span>. Switch the active scenario
            to any future phase to see its own plan.
          </p>
        ) : null}


        <div className="rounded-lg border border-border bg-card p-5 shadow-panel">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div className="max-w-3xl">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Impact summary
              </p>
              <p className="mt-1.5 text-sm text-foreground">{plan.headline}</p>
            </div>
            <div className="space-y-1.5">
              <Label>Compared against</Label>
              <Select value={baselineId} onValueChange={setBaselineId}>
                <SelectTrigger className="w-72">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="auto">
                    Automatic{autoBaseline ? ` — ${autoBaseline.name}` : " — none found"}
                  </SelectItem>
                  {workspace.scenarios
                    .filter((s) => s.id !== scenario?.id)
                    .map((s) => (
                      <SelectItem key={s.id} value={s.id}>
                        {s.name}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
          <StatCard
            label="Change readiness"
            value={`${readiness}%`}
            sub={`${band.label} · ${progress}% of actions complete`}
            tone={band.tone === "positive" ? "positive" : band.tone === "negative" ? "negative" : "brand"}
            icon={<GaugeCircle className="h-4 w-4" />}
          />
          <StatCard
            label="Positions affected"
            value={plan.impacted.toLocaleString()}
            sub={`of ${plan.totalPositions.toLocaleString()} in the baseline`}
          />
          <StatCard
            label="Exits & new roles"
            value={`${plan.exits} / ${plan.newRoles}`}
            sub="roles removed / roles created"
            tone="negative"
          />
          <StatCard
            label="Reassigned"
            value={plan.reassigned.toLocaleString()}
            sub={`${plan.spanChanges} manager span changes`}
          />
          <StatCard
            label="Annual cost movement"
            value={`${plan.costDelta <= 0 ? "−" : "+"}${formatMoney(Math.abs(plan.costDelta), cur)}`}
            tone={plan.costDelta <= 0 ? "positive" : "negative"}
            sub="people cost, annualised"
          />
        </div>

        <div className="rounded-lg border border-border bg-card p-5 shadow-panel">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold">Stakeholder impact heat map</h2>
              <p className="text-xs text-muted-foreground">
                Groups ordered by change impact severity — exits weigh heaviest, then moves, new
                roles and span changes.
              </p>
            </div>
            {plan.barrier ? (
              <Link
                to="/adkar"
                className="text-xs font-semibold text-primary underline-offset-4 hover:underline"
              >
                Barrier point: {plan.barrier} →
              </Link>
            ) : null}
          </div>

          {plan.groups.length ? (
            <div className="mt-4 space-y-2">
              {plan.groups.map((g) => (
                <div
                  key={g.id}
                  className="grid grid-cols-1 items-center gap-3 rounded-md border border-border bg-background p-3 md:grid-cols-[minmax(0,1fr)_140px_120px_110px]"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="truncate text-sm font-semibold">{g.name}</span>
                      <span
                        className={cn(
                          "rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide",
                          SEVERITY_META[g.severity].className,
                        )}
                      >
                        {SEVERITY_META[g.severity].label}
                      </span>
                    </div>
                    <p className="mt-0.5 truncate text-xs text-muted-foreground">
                      {g.drivers.join(" · ")}
                    </p>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${Math.max(6, (g.score / maxScore) * 100)}%`,
                        backgroundColor: `#${SEVERITY_META[g.severity].hex}`,
                      }}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {Math.round(g.touchRate * 100)}% of {g.positions} touched
                  </p>
                  <p
                    className={cn(
                      "text-right text-xs font-semibold",
                      g.headcountDelta < 0 ? "text-destructive" : "text-muted-foreground",
                    )}
                  >
                    {g.headcountDelta > 0 ? "+" : ""}
                    {g.headcountDelta} pos
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <p className="mt-4 text-sm text-muted-foreground">
              No comparison available yet. Pick a baseline scenario above, or create a future state
              to compare against.
            </p>
          )}
          <p className="mt-3 text-xs text-muted-foreground">
            {SEVERITY_META.critical.label}: {SEVERITY_META.critical.note} ·{" "}
            {SEVERITY_META.high.label}: {SEVERITY_META.high.note}
          </p>
        </div>

        {plan.actions.length ? (
          <div className="space-y-4">
            {ADKAR_STAGES.map((stage) => {
              const rows = actions.filter((a) => a.stage === stage.key);
              const done = rows.filter((a) => a.done).length;
              return (
                <div
                  key={stage.key}
                  className="rounded-lg border border-border bg-card shadow-panel"
                  style={{ borderTopColor: `#${stage.hex}`, borderTopWidth: 3 }}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-5 py-3.5">
                    <div>
                      <h3 className="text-sm font-semibold">
                        {stage.label} — {stage.focus}
                      </h3>
                      <p className="text-xs text-muted-foreground">{stage.question}</p>
                    </div>
                    <span className="text-xs font-semibold text-muted-foreground">
                      {done}/{rows.length} complete
                    </span>
                  </div>
                  <div className="divide-y divide-border">
                    {rows.map((a) => (
                      <div key={a.id} className="px-5 py-4">
                        <div className="flex items-start gap-3">
                          <Checkbox
                            checked={a.done}
                            onCheckedChange={(v) => update(a.id, { done: v === true })}
                            className="mt-1"
                          />
                          <div className="min-w-0 flex-1">
                            {editing === a.id ? (
                              <div className="space-y-2">
                                <Input
                                  value={a.title}
                                  onChange={(e) => update(a.id, { title: e.target.value })}
                                />
                                <Textarea
                                  value={a.detail}
                                  rows={4}
                                  onChange={(e) => update(a.id, { detail: e.target.value })}
                                />
                              </div>
                            ) : (
                              <>
                                <p
                                  className={cn(
                                    "text-sm font-semibold",
                                    a.done && "text-muted-foreground line-through",
                                  )}
                                >
                                  {a.title}
                                </p>
                                <p className="mt-1 text-sm text-muted-foreground">{a.detail}</p>
                              </>
                            )}
                            <div className="mt-3 flex flex-wrap items-center gap-2">
                              <div className="flex items-center gap-1.5">
                                <UserRound className="h-3.5 w-3.5 text-muted-foreground" />
                                <Input
                                  value={a.owner}
                                  placeholder={a.suggestedOwner}
                                  onChange={(e) => update(a.id, { owner: e.target.value })}
                                  className="h-8 w-52 text-xs"
                                />
                              </div>
                              <div className="flex items-center gap-1.5">
                                <CalendarClock className="h-3.5 w-3.5 text-muted-foreground" />
                                <Input
                                  type="date"
                                  value={a.due}
                                  onChange={(e) => update(a.id, { due: e.target.value })}
                                  className="h-8 w-40 text-xs"
                                />
                              </div>
                              <span className="text-[11px] text-muted-foreground">
                                Suggested: {a.suggestedOwner} · week {a.week}
                              </span>
                            </div>
                          </div>
                          <div className="flex shrink-0 gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              title={editing === a.id ? "Done editing" : "Edit wording"}
                              onClick={() => setEditing(editing === a.id ? null : a.id)}
                            >
                              {editing === a.id ? (
                                <CheckCircle2 className="h-4 w-4" />
                              ) : (
                                <Pencil className="h-4 w-4" />
                              )}
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              title="Reset to generated text"
                              onClick={() => reset(a.id)}
                            >
                              <RotateCcw className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        ) : null}

        <p className="text-xs text-muted-foreground">
          Change plan edits are stored in this browser only, and are included in the PowerPoint pack
          via the change impact and ADKAR roadmap slides on the{" "}
          <Link to="/exports" className="text-primary underline-offset-4 hover:underline">
            Programme exports
          </Link>{" "}
          page.
        </p>
      </div>
    </div>
  );
}