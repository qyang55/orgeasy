import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  ArrowRight,
  Check,
  ClipboardCopy,
  Printer,
  Users,
  TrendingDown,
  Wallet,
  AlertTriangle,
  Scale,
  Layers,
  Sparkles,
  ShieldAlert,
} from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { Disclaimer } from "@/components/orgeasy/Disclaimer";
import { Button } from "@/components/ui/button";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { computeImpact, formatMoney } from "@/lib/orgeasy/impact";
import { computeProgramme } from "@/lib/orgeasy/levers";
import { resolveBaseline } from "@/lib/orgeasy/phases";
import { buildChangePlan } from "@/lib/orgeasy/change-plan";
import { buildDecisionSummary, decisionSummaryText } from "@/lib/orgeasy/decision-summary";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/decision")({
  head: () => ({
    meta: [
      { title: "Decision Summary — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "One-page executive decision summary: what is changing, why, key numbers, trade-offs, top risks and the recommended next step.",
      },
      { property: "og:title", content: "Decision Summary — Organisation Strategy Studio" },
      {
        property: "og:description",
        content:
          "Leadership-ready summary of an organisation option: positions, annual saving, one-off cost, trade-offs and consultation risks.",
      },
      { property: "og:type", content: "website" },
    ],
  }),
  component: DecisionPage,
});

const TRADE_ICONS = {
  structure: Layers,
  cost: Wallet,
  capability: Sparkles,
  risk: ShieldAlert,
} as const;

const SEVERITY_STYLE = {
  high: "border-destructive/40 bg-destructive/5 text-destructive",
  medium: "border-warning/40 bg-warning/10 text-warning-foreground",
  low: "border-border bg-secondary text-muted-foreground",
} as const;

function DecisionPage() {
  const { workspace, scenario } = useOrgEasy();
  const [copied, setCopied] = useState(false);

  const summary = useMemo(() => {
    const programme = computeProgramme(workspace, scenario ?? null);
    const impact = computeImpact(scenario);
    const plan = buildChangePlan(scenario, resolveBaseline(workspace.scenarios, scenario));
    return buildDecisionSummary(scenario, programme, impact, plan);
  }, [workspace, scenario]);

  const n = summary.numbers;
  const cur = summary.currency;

  async function copySummary() {
    try {
      await navigator.clipboard.writeText(decisionSummaryText(summary));
      setCopied(true);
      toast.success("Decision summary copied — paste into your meeting note or email.");
      setTimeout(() => setCopied(false), 2500);
    } catch {
      toast.error("Copy failed. Use Print / PDF instead.");
    }
  }

  return (
    <div className="pb-12">
      <PageHeader
        title="Decision summary"
        description={`A one-page view of ${summary.scenarioName} for leadership discussion${summary.baselineName ? ` against ${summary.baselineName}` : ""}.`}
        actions={
          <div className="flex gap-2 print:hidden">
            <Button variant="outline" onClick={copySummary}>
              {copied ? <Check className="mr-1.5 size-4" /> : <ClipboardCopy className="mr-1.5 size-4" />}
              Copy as text
            </Button>
            <Button onClick={() => window.print()}>
              <Printer className="mr-1.5 size-4" /> Print / PDF
            </Button>
          </div>
        }
      />

      <div className="mx-auto max-w-5xl space-y-6 px-8 py-6 print:max-w-none print:px-0">
        {/* 3 — Key numbers first, so the room has the facts on screen */}
        <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <NumberCard
            label="Positions"
            value={`${n.baselinePositions.toLocaleString()} → ${n.futurePositions.toLocaleString()}`}
            sub={`${n.positionsRemoved.toLocaleString()} removed · ${n.rolesAdded.toLocaleString()} new roles`}
            icon={<Users className="size-4" />}
          />
          <NumberCard
            label="Change"
            value={`${(Math.abs(n.reductionPct) * 100).toFixed(1)}%`}
            sub={`Net ${(n.baselinePositions - n.futurePositions).toLocaleString()} positions`}
            tone="brand"
            icon={<TrendingDown className="size-4" />}
          />
          <NumberCard
            label="Annual saving"
            value={formatMoney(n.annualSaving, cur)}
            sub="Recurring people cost released"
            tone="positive"
            icon={<Wallet className="size-4" />}
          />
          <NumberCard
            label="One-off cost"
            value={formatMoney(n.oneOffCost, cur)}
            sub={`${formatMoney(n.oneOffLow, cur)} – ${formatMoney(n.oneOffHigh, cur)}${n.paybackMonths !== null ? ` · payback ~${n.paybackMonths.toFixed(1)} mo` : ""}`}
            tone="negative"
            icon={<Scale className="size-4" />}
          />
        </section>

        {/* 3b — One-off cost split by phase */}
        {summary.oneOffByPhase.length > 0 && (
          <Panel step="3" title="One-off cost by phase">
            <p className="text-[12.5px] leading-relaxed text-muted-foreground">
              Each phase is priced only for the exits it newly creates, so the phases add up to the
              total one-off cost of {formatMoney(n.oneOffCost, cur)}.
            </p>
            <div className="mt-3 overflow-hidden rounded-md border border-border">
              <table className="w-full text-[12.5px]">
                <thead className="bg-secondary/50 text-muted-foreground">
                  <tr>
                    <th className="px-3 py-2 text-left font-semibold">Phase</th>
                    <th className="px-3 py-2 text-right font-semibold">Exits</th>
                    <th className="px-3 py-2 text-right font-semibold">One-off cost</th>
                    <th className="px-3 py-2 text-right font-semibold">Range</th>
                    <th className="px-3 py-2 text-right font-semibold">Share</th>
                  </tr>
                </thead>
                <tbody>
                  {summary.oneOffByPhase.map((p) => (
                    <tr key={p.id} className="border-t border-border align-top">
                      <td className="px-3 py-2">
                        <span className="font-medium">{p.title}</span>
                        {p.countries.length > 0 && (
                          <span className="block text-[11.5px] text-muted-foreground">
                            Mainly {p.countries.join(", ")}
                          </span>
                        )}
                      </td>
                      <td className="px-3 py-2 text-right tabular-nums">{p.exits.toLocaleString()}</td>
                      <td className="px-3 py-2 text-right font-semibold tabular-nums">
                        {formatMoney(p.mid, cur)}
                      </td>
                      <td className="px-3 py-2 text-right tabular-nums text-muted-foreground">
                        {formatMoney(p.low, cur)} – {formatMoney(p.high, cur)}
                      </td>
                      <td className="px-3 py-2 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <div className="h-1.5 w-16 overflow-hidden rounded-full bg-secondary">
                            <div
                              className="h-full rounded-full bg-brand"
                              style={{ width: `${Math.round(p.share * 100)}%` }}
                            />
                          </div>
                          <span className="tabular-nums text-muted-foreground">
                            {Math.round(p.share * 100)}%
                          </span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="border-t border-border bg-secondary/40">
                  <tr>
                    <td className="px-3 py-2 font-semibold">Total programme</td>
                    <td className="px-3 py-2 text-right font-semibold tabular-nums">
                      {n.exits.toLocaleString()}
                    </td>
                    <td className="px-3 py-2 text-right font-semibold tabular-nums">
                      {formatMoney(n.oneOffCost, cur)}
                    </td>
                    <td className="px-3 py-2 text-right tabular-nums text-muted-foreground">
                      {formatMoney(n.oneOffLow, cur)} – {formatMoney(n.oneOffHigh, cur)}
                    </td>
                    <td className="px-3 py-2" />
                  </tr>
                </tfoot>
              </table>
            </div>
          </Panel>
        )}

        <div className="grid gap-6 lg:grid-cols-2">
          {/* 1 — What is changing */}
          <Panel step="1" title="What is changing">
            <ul className="space-y-2.5">
              {summary.whatIsChanging.map((t, i) => (
                <li key={i} className="flex gap-2.5 text-[13.5px] leading-relaxed">
                  <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-brand" />
                  <span>{t}</span>
                </li>
              ))}
            </ul>
          </Panel>

          {/* 2 — Why */}
          <Panel step="2" title="Why we are doing it">
            <ul className="space-y-2.5">
              {summary.drivers.map((t, i) => (
                <li key={i} className="flex gap-2.5 text-[13.5px] leading-relaxed">
                  <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-success" />
                  <span>{t}</span>
                </li>
              ))}
            </ul>
          </Panel>
        </div>

        {/* 4 — Trade-offs */}
        <Panel step="4" title="Main trade-offs">
          <div className="grid gap-4 md:grid-cols-2">
            {summary.tradeOffs.map((t) => {
              const Icon = TRADE_ICONS[t.id];
              return (
                <div key={t.id} className="rounded-md border border-border bg-secondary/40 p-4">
                  <p className="flex items-center gap-2 text-[13px] font-semibold">
                    <Icon className="size-4 text-brand" /> {t.label}
                  </p>
                  <p className="mt-1.5 text-[13px] font-medium">{t.headline}</p>
                  <p className="mt-2 text-[12.5px] leading-relaxed text-muted-foreground">
                    <span className="font-semibold text-success">What we gain: </span>
                    {t.gain}
                  </p>
                  <p className="mt-1 text-[12.5px] leading-relaxed text-muted-foreground">
                    <span className="font-semibold text-destructive">What we give up: </span>
                    {t.give}
                  </p>
                </div>
              );
            })}
          </div>
        </Panel>

        {/* 5 — Risks */}
        <Panel step="5" title="Top risks to watch">
          <ul className="space-y-2.5">
            {summary.risks.map((r) => (
              <li key={r.id} className={cn("rounded-md border px-4 py-3", SEVERITY_STYLE[r.severity])}>
                <p className="flex items-center gap-2 text-[13px] font-semibold">
                  <AlertTriangle className="size-4 shrink-0" /> {r.title}
                </p>
                <p className="mt-1 text-[12.5px] leading-relaxed text-muted-foreground">{r.detail}</p>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-[11.5px] text-muted-foreground">
            {n.exits.toLocaleString()} exits modelled across {n.countries} market
            {n.countries === 1 ? "" : "s"}. Country rules and overrides live on Country Guidance.
          </p>
        </Panel>

        {/* 6 — Next step */}
        <section className="rounded-lg border border-brand/40 bg-brand/5 p-5">
          <p className="text-[11px] font-semibold uppercase tracking-wider text-brand">
            6 · Recommended next step
          </p>
          <p className="mt-1.5 text-[15px] font-semibold">{summary.nextStep.title}</p>
          <p className="mt-1.5 max-w-3xl text-[13px] leading-relaxed text-muted-foreground">
            {summary.nextStep.detail}
          </p>
          <div className="mt-4 flex flex-wrap gap-2 print:hidden">
            <Button asChild variant="outline" size="sm">
              <Link to="/change-plan">
                Change plan <ArrowRight className="ml-1.5 size-3.5" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="sm">
              <Link to="/separation">Country guidance</Link>
            </Button>
            <Button asChild variant="outline" size="sm">
              <Link to="/exports">Generate PowerPoint</Link>
            </Button>
          </div>
        </section>

        <Disclaimer />
      </div>
    </div>
  );
}

function Panel({
  step,
  title,
  children,
}: {
  step: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-lg border border-border bg-card p-5 shadow-panel break-inside-avoid">
      <div className="flex items-center gap-2.5">
        <span className="grid size-6 shrink-0 place-items-center rounded-full bg-brand/10 text-[11px] font-semibold text-brand">
          {step}
        </span>
        <h2 className="text-sm font-semibold">{title}</h2>
      </div>
      <div className="mt-3.5">{children}</div>
    </section>
  );
}

function NumberCard({
  label,
  value,
  sub,
  tone = "default",
  icon,
}: {
  label: string;
  value: string;
  sub: string;
  tone?: "default" | "brand" | "positive" | "negative";
  icon?: React.ReactNode;
}) {
  const toneClass = {
    default: "text-foreground",
    brand: "text-brand",
    positive: "text-success",
    negative: "text-destructive",
  }[tone];
  return (
    <div className="rounded-lg border border-border bg-card p-4 shadow-panel break-inside-avoid">
      <div className="flex items-center justify-between">
        <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
          {label}
        </p>
        {icon ? <span className="text-muted-foreground">{icon}</span> : null}
      </div>
      <p className={cn("mt-2 text-[21px] font-semibold leading-tight tracking-tight", toneClass)}>
        {value}
      </p>
      <p className="mt-1.5 text-xs text-muted-foreground">{sub}</p>
    </div>
  );
}
