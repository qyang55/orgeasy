import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import {
  CheckCircle2,
  CircleAlert,
  Cloud,
  Database,
  FileUp,
  Link2,
  Plug,
  Upload,
} from "lucide-react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { isFixedDemoScenario } from "@/lib/orgeasy/seed";
import {
  HRIS_SYSTEMS,
  MAPPABLE_FIELDS,
  autoMap,
  detectSystem,
  extractToEmployees,
  getSystem,
  parseExtract,
  type FieldKey,
  type HrisId,
  type ParsedExtract,
} from "@/lib/orgeasy/hris";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/integrations")({
  head: () => ({
    meta: [
      { title: "HRIS Integrations — Workday, SAP, Oracle — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Import org data from Workday, SAP SuccessFactors, SAP HCM and Oracle Fusion HCM with automatic column mapping into Organisation Strategy Studio scenarios.",
      },
      { property: "og:title", content: "HRIS Integrations — Organisation Strategy Studio" },
      {
        property: "og:description",
        content: "Bring Workday, SAP, SuccessFactors and Oracle HCM data into your org scenarios.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Integrations,
});

function Integrations() {
  const { scenario, createScenario, replaceEmployees, workspace, snapshotScenario } = useOrgEasy();
  const [systemId, setSystemId] = useState<HrisId>("workday");
  const [raw, setRaw] = useState("");
  const [extract, setExtract] = useState<ParsedExtract | null>(null);
  const [mapping, setMapping] = useState<Record<FieldKey, string> | null>(null);
  const [asFuture, setAsFuture] = useState(false);
  const [intoNew, setIntoNew] = useState(true);
  const fileRef = useRef<HTMLInputElement>(null);
  const system = getSystem(systemId);

  const preview = useMemo(() => {
    if (!extract || !mapping) return null;
    return extractToEmployees({ ...extract, rows: extract.rows.slice(0, 5) }, mapping, {
      asFutureState: asFuture,
    });
  }, [extract, mapping, asFuture]);

  const ingest = (text: string) => {
    const parsed = parseExtract(text);
    if (!parsed.headers.length) {
      toast.error("Could not read any columns from that file.");
      return;
    }
    const detected = detectSystem(parsed.headers);
    setSystemId(detected.id);
    setExtract(parsed);
    setMapping(autoMap(parsed.headers, detected));
    toast.success(`${parsed.rows.length} rows read — detected ${detected.name} field names`);
  };

  const onFile = async (file: File) => {
    const text = await file.text();
    setRaw(text.slice(0, 4000));
    ingest(text);
  };

  const runImport = () => {
    if (!extract || !mapping) return;
    const result = extractToEmployees(extract, mapping, { asFutureState: asFuture });
    if (!result.employees.length) {
      toast.error("No importable rows found.");
      return;
    }
    const label = `${system.name} import — ${new Date().toLocaleDateString("en-GB")}`;
    // Never overwrite the fixed demo baseline — import into a new scenario.
    const toNew = intoNew || !scenario || isFixedDemoScenario(scenario.id);
    // Overwriting an existing scenario is reversible via its snapshot history.
    if (!toNew) snapshotScenario({ reason: "pre-import", label: `Before ${system.name} import` });
    if (toNew) createScenario(label);
    // createScenario activates the new scenario, so this writes into it.
    setTimeout(() => {
      replaceEmployees(result.employees);
      toast.success(
        `${result.employees.length} roles imported${toNew ? ` into “${label}”` : ""}`,
      );
      for (const w of result.warnings) toast.warning(w);
    }, 0);
  };

  return (
    <div className="pb-14">
      <PageHeader
        title="HRIS integrations"
        description="Bring your live org data in from Workday, SAP SuccessFactors, SAP HCM or Oracle Fusion HCM. Organisation Strategy Studio recognises each vendor's column names and maps them for you."
      />

      <div className="space-y-6 px-8 py-6">
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {HRIS_SYSTEMS.map((s) => (
            <button
              key={s.id}
              onClick={() => {
                setSystemId(s.id);
                if (extract) setMapping(autoMap(extract.headers, s));
              }}
              className={cn(
                "rounded-xl border bg-card p-5 text-left shadow-panel transition-all hover:-translate-y-0.5",
                systemId === s.id ? "border-brand ring-2 ring-brand/25" : "border-border",
              )}
            >
              <span className="grid size-10 place-items-center rounded-lg bg-accent text-brand">
                <Database className="size-5" />
              </span>
              <p className="mt-3 text-[14px] font-semibold">{s.name}</p>
              <p className="text-[11px] uppercase tracking-widest text-muted-foreground">
                {s.vendor}
              </p>
              <p className="mt-2 text-[12.5px] leading-relaxed text-muted-foreground">{s.blurb}</p>
            </button>
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-[1.35fr_1fr]">
          <section className="rounded-xl border border-border bg-card p-5 shadow-panel">
            <h2 className="flex items-center gap-2 text-sm font-semibold">
              <FileUp className="size-4 text-brand" /> Import a {system.name} extract
            </h2>
            <ol className="mt-3 space-y-1.5 text-[12.5px] leading-relaxed text-muted-foreground">
              {system.howTo.map((step, i) => (
                <li key={step}>
                  <span className="mr-1.5 font-semibold text-brand">{i + 1}.</span>
                  {step}
                </li>
              ))}
            </ol>

            <div className="mt-4 flex flex-wrap items-center gap-2">
              <input
                ref={fileRef}
                type="file"
                accept=".csv,text/csv,text/plain"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) void onFile(file);
                }}
              />
              <Button onClick={() => fileRef.current?.click()}>
                <Upload className="mr-1.5 size-4" /> Upload CSV
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setRaw(system.sample);
                  ingest(system.sample);
                }}
              >
                Load {system.vendor} sample
              </Button>
              <Button variant="ghost" disabled={!raw.trim()} onClick={() => ingest(raw)}>
                Parse pasted data
              </Button>
            </div>

            <div className="mt-4 space-y-1.5">
              <Label htmlFor="paste">Or paste the export here</Label>
              <Textarea
                id="paste"
                value={raw}
                onChange={(e) => setRaw(e.target.value)}
                rows={6}
                className="font-mono text-[12px]"
                placeholder="Employee ID,Worker,Business Title,Supervisory Organization,…"
              />
            </div>

            {extract && mapping ? (
              <div className="mt-5 border-t border-border pt-5">
                <p className="text-sm font-semibold">Field mapping</p>
                <p className="mt-1 text-[12.5px] text-muted-foreground">
                  {extract.rows.length} rows · {extract.headers.length} columns detected. Adjust
                  anything Organisation Strategy Studio guessed wrong.
                </p>
                <div className="mt-3 grid gap-3 sm:grid-cols-2">
                  {MAPPABLE_FIELDS.map((field) => (
                    <div key={field.key} className="space-y-1.5">
                      <Label className="flex items-center gap-1.5">
                        {field.label}
                        {field.required ? <span className="text-destructive">*</span> : null}
                        {mapping[field.key] ? (
                          <CheckCircle2 className="size-3.5 text-success" />
                        ) : (
                          <CircleAlert className="size-3.5 text-muted-foreground" />
                        )}
                      </Label>
                      <Select
                        value={mapping[field.key] || "__none"}
                        onValueChange={(v) =>
                          setMapping((m) => ({ ...m!, [field.key]: v === "__none" ? "" : v }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="__none">Not mapped</SelectItem>
                          {extract.headers.map((h) => (
                            <SelectItem key={h} value={h}>
                              {h}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  ))}
                </div>

                <div className="mt-5 flex flex-wrap items-center gap-6">
                  <div className="flex items-center gap-2.5">
                    <Switch id="new" checked={intoNew} onCheckedChange={setIntoNew} />
                    <Label htmlFor="new" className="cursor-pointer">
                      Create a new scenario
                    </Label>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <Switch id="future" checked={asFuture} onCheckedChange={setAsFuture} />
                    <Label htmlFor="future" className="cursor-pointer">
                      Mark imported roles as planned (future state)
                    </Label>
                  </div>
                </div>

                {preview?.employees.length ? (
                  <div className="mt-4 overflow-hidden rounded-lg border border-border">
                    <table className="w-full text-[12.5px]">
                      <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wide text-muted-foreground">
                        <tr>
                          <th className="px-3 py-2">Name</th>
                          <th className="px-3 py-2">Title</th>
                          <th className="px-3 py-2">Dept</th>
                          <th className="px-3 py-2">Country</th>
                          <th className="px-3 py-2">Cost</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {preview.employees.map((e) => (
                          <tr key={e.id}>
                            <td className="px-3 py-2">{e.name || "Open Role"}</td>
                            <td className="px-3 py-2">{e.title}</td>
                            <td className="px-3 py-2">{e.department || "—"}</td>
                            <td className="px-3 py-2">{e.country}</td>
                            <td className="px-3 py-2">
                              {(e.plannedCost || e.currentCost).toLocaleString()}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : null}

                <Button className="mt-4" disabled={!mapping.title} onClick={runImport}>
                  <Plug className="mr-1.5 size-4" /> Import {extract.rows.length} rows
                </Button>
                {!mapping.title ? (
                  <p className="mt-2 text-[12px] text-destructive">
                    Map a job title column before importing.
                  </p>
                ) : null}
              </div>
            ) : null}
          </section>

          <aside className="space-y-4">
            <section className="rounded-xl border border-border bg-card p-5 shadow-panel">
              <h2 className="flex items-center gap-2 text-sm font-semibold">
                <Cloud className="size-4 text-brand" /> Live API connection
              </h2>
              <p className="mt-2 text-[12.5px] leading-relaxed text-muted-foreground">
                A scheduled, credentialed sync with {system.name} runs server-side, so it needs the
                workspace backend enabled and these credentials stored securely:
              </p>
              <ul className="mt-3 space-y-1.5">
                {system.credentials.map((c) => (
                  <li key={c} className="flex items-start gap-2 text-[12.5px]">
                    <Link2 className="mt-0.5 size-3.5 shrink-0 text-brand" />
                    <span>{c}</span>
                  </li>
                ))}
              </ul>
              <p className="mt-3 rounded-lg bg-accent/60 p-3 text-[12px] leading-relaxed text-accent-foreground">
                This workspace currently runs fully in your browser, so file-based import above is
                the live path. Ask to “enable the backend and connect {system.vendor}” when you are
                ready for scheduled syncs.
              </p>
            </section>

            <section className="rounded-xl border border-border bg-card p-5 shadow-panel">
              <h2 className="text-sm font-semibold">Where imports land</h2>
              <p className="mt-2 text-[12.5px] leading-relaxed text-muted-foreground">
                Imported roles become a full scenario you can restructure on the chart, cost in the
                impact simulator, and compare against any other scenario.
              </p>
              <p className="mt-3 text-[12.5px] text-muted-foreground">
                Workspace scenarios: <span className="font-medium text-foreground">{workspace.scenarios.length}</span>
                {scenario ? (
                  <>
                    {" "}· active: <span className="font-medium text-foreground">{scenario.name}</span>
                  </>
                ) : null}
              </p>
            </section>
          </aside>
        </div>
      </div>
    </div>
  );
}
