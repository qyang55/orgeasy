import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { Disclaimer } from "@/components/orgeasy/Disclaimer";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { COUNTRY_GUIDANCE, illustrativeSeverance } from "@/lib/orgeasy/countries";
import { formatMoney } from "@/lib/orgeasy/impact";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { AlertTriangle, Scale, Search, X, HelpCircle, ChevronDown } from "lucide-react";

export const Route = createFileRoute("/separation")({
  head: () => ({
    meta: [
      { title: "Country Guidance — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "High-level, illustrative Country Guidance for each country, including notice, severance heuristics and consultation notes.",
      },
      { property: "og:title", content: "Country Guidance — Organisation Strategy Studio" },
      {
        property: "og:description",
        content: "Illustrative country-by-country separation awareness — never legal advice.",
      },
    ],
  }),
  component: Separation,
});

const REGIONS = Array.from(new Set(COUNTRY_GUIDANCE.map((g) => g.region))).sort();

function Separation() {
  const { scenario } = useOrgEasy();
  const [query, setQuery] = useState("");
  const [region, setRegion] = useState<string>("All");
  const [helpOpen, setHelpOpen] = useState(true);
  const cur = scenario?.currency ?? "USD";

  const affected = useMemo(() => {
    const removed = (scenario?.employees ?? []).filter((e) => e.status === "to-be-removed");
    const map = new Map<string, { count: number; cost: number }>();
    for (const e of removed) {
      const hc = Math.max(e.currentHeadcount, 1);
      const prev = map.get(e.country) ?? { count: 0, cost: 0 };
      map.set(e.country, {
        count: prev.count + hc,
        cost: prev.cost + illustrativeSeverance(e.currentCost, e.serviceMonths, e.country).total * hc,
      });
    }
    return map;
  }, [scenario]);

  const list = COUNTRY_GUIDANCE.filter((g) => {
    const q = query.trim().toLowerCase();
    const matchesQuery = !q || g.country.toLowerCase().includes(q) || g.region.toLowerCase().includes(q);
    const matchesRegion = region === "All" || g.region === region;
    return matchesQuery && matchesRegion;
  }).sort((a, b) => (affected.get(b.country)?.count ?? 0) - (affected.get(a.country)?.count ?? 0));

  return (
    <div className="pb-12">
      <PageHeader
        title="Country Guidance"
        description="General awareness for planning conversations across 22 countries. Countries with roles marked To Be Removed are surfaced first."
      />

      <div className="space-y-5 px-8 py-6">
        <Disclaimer />

        <div className="rounded-lg border border-border bg-card p-4 shadow-panel">
          <button
            onClick={() => setHelpOpen((v) => !v)}
            className="flex w-full items-center justify-between gap-2 text-left"
            aria-expanded={helpOpen}
          >
            <div className="flex items-center gap-2">
              <HelpCircle className="size-4 text-brand" />
              <span className="text-sm font-semibold">What does Country Guidance cover?</span>
            </div>
            <ChevronDown
              className={cn("size-4 text-muted-foreground transition-transform", helpOpen && "rotate-180")}
            />
          </button>
          {helpOpen && (
            <div className="mt-3 space-y-3 border-t border-border pt-3 text-sm text-muted-foreground">
              <p>
                This section provides high-level planning awareness for people-change programmes across 22 countries.
                It is designed to help HR and transformation teams spot early risks, not to replace legal counsel.
              </p>
              <ul className="grid gap-2 sm:grid-cols-2">
                <li className="flex gap-2">
                  <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-brand" />
                  <span>
                    <strong className="text-foreground">Severance heuristic</strong> — typical weeks of pay per year
                    of service used for rough cost modelling.
                  </span>
                </li>
                <li className="flex gap-2">
                  <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-brand" />
                  <span>
                    <strong className="text-foreground">Notice period</strong> — indicative statutory or contractual
                    minimum notice employers should factor into timelines.
                  </span>
                </li>
                <li className="flex gap-2">
                  <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-brand" />
                  <span>
                    <strong className="text-foreground">Consultation &amp; representative rules</strong> — works-council,
                    union or employee-representation triggers to consider before change.
                  </span>
                </li>
                <li className="flex gap-2">
                  <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-brand" />
                  <span>
                    <strong className="text-foreground">Illustrative cost</strong> — estimated severance exposure for
                    roles currently marked To Be Removed in your active scenario.
                  </span>
                </li>
              </ul>
              <p className="rounded-md bg-destructive/10 px-3 py-2 text-xs font-medium text-destructive">
                This is not legal advice. Always validate country-specific requirements with qualified local counsel
                before making employment decisions.
              </p>
            </div>
          )}
        </div>

        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative max-w-xs flex-1">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search country or region"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="bg-card pl-9"
              />
              {query ? (
                <button
                  onClick={() => setQuery("")}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  aria-label="Clear search"
                >
                  <X className="size-3.5" />
                </button>
              ) : null}
            </div>
            <p className="text-xs text-muted-foreground">
              {list.length} countries · {affected.size} with proposed removals in this scenario
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-medium text-muted-foreground">Filter by region:</span>
            <button
              onClick={() => setRegion("All")}
              className={cn(
                "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                region === "All"
                  ? "border-brand bg-brand/10 text-brand"
                  : "border-border bg-card text-muted-foreground hover:bg-muted hover:text-foreground",
              )}
            >
              All
            </button>
            {REGIONS.map((r) => (
              <button
                key={r}
                onClick={() => setRegion(r)}
                className={cn(
                  "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                  region === r
                    ? "border-brand bg-brand/10 text-brand"
                    : "border-border bg-card text-muted-foreground hover:bg-muted hover:text-foreground",
                )}
              >
                {r}
              </button>
            ))}
            {(query || region !== "All") && (
              <Button variant="ghost" size="sm" onClick={() => { setQuery(""); setRegion("All"); }} className="h-6 px-2 text-xs">
                <X className="mr-1 size-3" /> Clear filters
              </Button>
            )}
          </div>
        </div>

        {list.length === 0 ? (
          <div className="rounded-lg border border-dashed border-border bg-card py-12 text-center">
            <p className="text-sm font-medium text-foreground">No countries match your filters</p>
            <p className="mt-1 text-xs text-muted-foreground">
              Try a different search term or region, or{" "}
              <button
                onClick={() => { setQuery(""); setRegion("All"); }}
                className="text-brand underline-offset-2 hover:underline"
              >
                clear all filters
              </button>
              .
            </p>
          </div>
        ) : (
          <div className="grid gap-4 lg:grid-cols-2 2xl:grid-cols-3">
            {list.map((g) => {
              const hit = affected.get(g.country);
              return (
                <article
                  key={g.country}
                  className={cn(
                    "rounded-lg border bg-card p-5 shadow-panel",
                    hit ? "border-destructive/40" : "border-border",
                  )}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h2 className="text-[15px] font-semibold">{g.country}</h2>
                      <p className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">
                        {g.region}
                      </p>
                    </div>
                    {hit ? (
                      <span className="inline-flex items-center gap-1 rounded bg-destructive/15 px-2 py-0.5 text-[10px] font-semibold uppercase text-destructive">
                        <AlertTriangle className="size-3" /> {hit.count} in scope
                      </span>
                    ) : null}
                  </div>

                  <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                    <div className="rounded-md bg-secondary px-2 py-2">
                      <p className="text-[15px] font-semibold tabular-nums">
                        {g.severanceWeeksPerYear}
                      </p>
                      <p className="text-[10px] text-muted-foreground">weeks / year</p>
                    </div>
                    <div className="rounded-md bg-secondary px-2 py-2">
                      <p className="text-[15px] font-semibold tabular-nums">{g.noticeWeeks}</p>
                      <p className="text-[10px] text-muted-foreground">weeks notice</p>
                    </div>
                    <div className="rounded-md bg-secondary px-2 py-2">
                      <p className="text-[15px] font-semibold tabular-nums">
                        {hit ? formatMoney(hit.cost, cur) : "—"}
                      </p>
                      <p className="text-[10px] text-muted-foreground">illustrative cost</p>
                    </div>
                  </div>

                  <p className="mt-3 flex gap-1.5 text-[11.5px] leading-relaxed text-muted-foreground">
                    <Scale className="mt-0.5 size-3.5 shrink-0" />
                    {g.capNote}
                  </p>

                  <ul className="mt-3 space-y-1.5">
                    {g.considerations.map((c) => (
                      <li key={c} className="flex gap-2 text-[12.5px] leading-snug">
                        <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-brand" />
                        {c}
                      </li>
                    ))}
                  </ul>
                </article>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}