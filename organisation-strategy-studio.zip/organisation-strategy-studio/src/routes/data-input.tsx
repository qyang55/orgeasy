import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Car, Download, Network, Plug, Table2, Upload, Users } from "lucide-react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { Button } from "@/components/ui/button";
import { downloadBlob, employeesToCsv } from "@/lib/orgeasy/csv";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { toast } from "sonner";

export const Route = createFileRoute("/data-input")({
  head: () => ({
    meta: [
      { title: "Data input — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Four ways to load organisation design data: HRIS import, CSV upload, industry pack generation and manual chart building.",
      },
      { property: "og:title", content: "Data input — Organisation Strategy Studio" },
      {
        property: "og:description",
        content: "HRIS connectors, CSV upload, generated industry baselines or manual design.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DataInput,
});

const WAYS = [
  {
    to: "/integrations",
    icon: Plug,
    step: "Option 1",
    title: "HRIS import",
    blurb:
      "Pull an extract from Workday, SAP SuccessFactors or Oracle. Vendor field mapping is handled for you — positions, managers, countries, salaries and employment type.",
    best: "Best when the org already lives in an HR system.",
    cta: "Open HRIS data sources",
  },
  {
    to: "/people",
    icon: Table2,
    step: "Option 2",
    title: "Spreadsheet / CSV upload",
    blurb:
      "One row per role. Download the template below, fill it in from any spreadsheet, then use Import CSV on Positions & headcount.",
    best: "Best for a one-off extract, a pilot function or a consultant file.",
    cta: "Go to Positions & headcount",
  },
  {
    to: "/packs",
    icon: Car,
    step: "Option 3",
    title: "Generate an industry baseline",
    blurb:
      "Industry packs build a realistic organisation for your sector and enterprise size — layers, spans, functions, countries and cost — ready to adjust.",
    best: "Best when you need to model before real data is available.",
    cta: "Open industry packs",
  },
  {
    to: "/chart",
    icon: Network,
    step: "Option 4",
    title: "Build it manually",
    blurb:
      "Design directly on the canvas: add boxes, drag to reparent, set scope, unit type and cost, and add photos. Every edit feeds the impact model.",
    best: "Best for leadership layers and top-of-house redesign.",
    cta: "Open chart designer",
  },
] as const;


function DataInput() {
  const { scenario } = useOrgEasy();

  return (
    <div className="pb-12">
      <PageHeader
        title="Data input"
        description="Four ways to get organisation data into the studio. Mix them freely — imports and manual edits sit in the same scenario."
        actions={
          <Button
            variant="outline"
            onClick={() => {
              downloadBlob(employeesToCsv([]), "org-data-template.csv", "text/csv");
              toast.success("CSV template downloaded");
            }}
          >
            <Download className="mr-1.5 size-4" /> CSV template
          </Button>
        }
      />

      <div className="space-y-6 px-8 py-6">
        <section className="rounded-xl border border-border bg-card p-5 shadow-panel">
          <h2 className="flex items-center gap-2 text-[14px] font-semibold">
            <Plug className="size-4 text-brand" /> Importing from an HR system?
          </h2>
          <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">
            HRIS extracts are handled in one place: HRIS data sources. Upload or paste your Workday,
            SAP SuccessFactors, SAP HCM or Oracle Fusion HCM export there — vendor column names are
            detected, the field mapping is editable, and the roles land in a new scenario so the
            fixed demo baseline stays untouched.
          </p>
          <Button asChild size="sm" className="mt-4">
            <Link to="/integrations">
              Open HRIS data sources <ArrowRight className="ml-1.5 size-4" />
            </Link>
          </Button>
        </section>

        <div className="grid gap-4 lg:grid-cols-2">
          {WAYS.map((w, i) => (
            <Link
              key={w.to}
              to={w.to}
              className="group animate-in fade-in slide-in-from-bottom-2 rounded-xl border border-border bg-card p-5 shadow-panel transition-all hover:-translate-y-0.5 hover:border-brand/60 hover:shadow-lg"
              style={{ animationDelay: `${i * 70}ms`, animationDuration: "420ms" }}
            >
              <div className="flex items-start gap-3">
                <span className="rounded-lg bg-brand/10 p-2.5 text-brand">
                  <w.icon className="size-5" />
                </span>
                <div className="min-w-0">
                  <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    {w.step}
                  </p>
                  <h2 className="text-[15px] font-semibold">{w.title}</h2>
                </div>
              </div>
              <p className="mt-3 text-[13px] leading-relaxed text-muted-foreground">{w.blurb}</p>
              <p className="mt-2 text-[12.5px] font-medium text-foreground/80">{w.best}</p>
              <span className="mt-4 inline-flex items-center gap-1.5 text-[13px] font-semibold text-brand">
                {w.cta}
                <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
              </span>
            </Link>
          ))}
        </div>

        <div className="rounded-xl border border-border bg-card p-5 shadow-panel">
          <h3 className="flex items-center gap-2 text-[14px] font-semibold">
            <Upload className="size-4 text-brand" /> How the CSV template works
          </h3>
          <p className="mt-2 text-[13px] text-muted-foreground">
            Required columns: <code>title</code>, <code>department</code>, <code>country</code>,{" "}
            <code>currentHeadcount</code>, <code>plannedHeadcount</code>, <code>currentCost</code>,{" "}
            <code>plannedCost</code>. Leave <code>name</code> blank for open roles. Use{" "}
            <code>managerId</code> to point a role at its manager&apos;s <code>id</code> — that is
            what builds the hierarchy. Import replaces the roles in the active scenario
            {scenario ? ` (“${scenario.name}”)` : ""}, so clone a scenario first if you want to keep
            the current one.
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button asChild size="sm" variant="outline">
              <Link to="/people">
                <Users className="mr-1.5 size-4" /> Import on Positions &amp; headcount
              </Link>
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() =>
                downloadBlob(
                  employeesToCsv(scenario?.employees ?? []),
                  `${scenario?.name ?? "roles"}.csv`,
                  "text/csv",
                )
              }
            >
              <Download className="mr-1.5 size-4" /> Export current scenario as CSV
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
