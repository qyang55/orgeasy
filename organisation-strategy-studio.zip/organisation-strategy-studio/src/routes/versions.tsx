import { useCallback, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { RotateCcw, Save, Trash2, ShieldCheck } from "lucide-react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { ScenarioSnapshots } from "@/components/orgeasy/ScenarioSnapshots";

import { StatCard } from "@/components/orgeasy/StatCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useOrgEasy } from "@/lib/orgeasy/store";
import {
  VERSION_LIMITS,
  deleteVersion,
  loadVersions,
  summarise,
  type WorkspaceVersion,
} from "@/lib/orgeasy/versions";
import { toast } from "sonner";

export const Route = createFileRoute("/versions")({
  head: () => ({
    meta: [
      { title: "Version History — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Restore a previous industry pack, cost model or hiring pipeline. Automatic and manual restore points of the whole workspace, with one-click rollback.",
      },
      { property: "og:title", content: "Version History — Organisation Strategy Studio" },
      {
        property: "og:description",
        content:
          "Point-in-time snapshots of scenarios, positions, costs and agents so any mistake can be rolled back.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: VersionsPage,
});

const REASON_META: Record<WorkspaceVersion["reason"], { label: string; hex: string }> = {
  manual: { label: "Saved by you", hex: "2563EB" },
  auto: { label: "Auto restore point", hex: "0F9D8F" },
  "pre-restore": { label: "Before a restore", hex: "B45309" },
};

function money(value: number, currency: string) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    maximumFractionDigits: 0,
  }).format(value);
}

function when(iso: string) {
  const d = new Date(iso);
  return Number.isFinite(d.getTime()) ? d.toLocaleString() : "unknown";
}

function VersionsPage() {
  const { workspace, saveVersion, restoreVersion } = useOrgEasy();
  const [versions, setVersions] = useState<WorkspaceVersion[]>(() => loadVersions());
  const [label, setLabel] = useState("");
  const refresh = useCallback(() => setVersions(loadVersions()), []);
  const live = summarise(workspace);

  const onSave = () => {
    saveVersion(label.trim() || undefined);
    setLabel("");
    // The store writes synchronously, so the list is current immediately.
    refresh();
    toast.success("Restore point saved");
  };

  const onRestore = (version: WorkspaceVersion) => {
    const ok = restoreVersion(version.id);
    refresh();
    if (ok) {
      toast.success(`Restored “${version.label}”`, {
        description: "Your previous state was saved as “Before a restore”.",
      });
    } else {
      toast.error("That version is no longer available.");
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Version history"
        description="Every restore point captures the whole workspace — scenarios, positions, cost model, agents and hiring inputs — so you can roll back a bad pack generation or edit."
      />

      <div className="grid gap-4 md:grid-cols-3">
        <StatCard label="Restore points" value={String(versions.length)} sub={`Newest ${VERSION_LIMITS.maxVersions} kept`} />
        <StatCard label="Live scenario" value={live.label} sub={`${live.scenarioCount} scenarios in workspace`} />
        <StatCard
          label="Live positions"
          value={live.plannedPositions.toLocaleString()}
          sub={money(live.annualCost, live.currency)}
        />
      </div>

      <section className="rounded-xl border bg-card p-5">
        <div className="flex flex-wrap items-end gap-3">
          <div className="min-w-[240px] flex-1">
            <label className="text-[11.5px] font-semibold uppercase tracking-wide text-muted-foreground">
              Save the current workspace
            </label>
            <Input
              className="mt-1.5"
              value={label}
              placeholder="Optional name, e.g. “Automotive pack before 10% cut”"
              onChange={(e) => setLabel(e.target.value)}
            />
          </div>
          <Button className="gap-2" onClick={onSave}>
            <Save className="size-4" /> Save restore point
          </Button>
        </div>
        <p className="mt-3 flex items-start gap-2 text-[12px] leading-relaxed text-muted-foreground">
          <ShieldCheck className="mt-0.5 size-3.5 shrink-0" />
          Restore points stay in this browser only — never uploaded. Automatic points are captured at
          most every {Math.round(VERSION_LIMITS.autoIntervalMs / 60000)} minute(s) of activity, and
          very large imports are skipped to protect browser storage.
        </p>
      </section>

      <section className="overflow-hidden rounded-xl border bg-card">
        <header className="flex items-center justify-between border-b px-5 py-3">
          <h2 className="text-[13.5px] font-semibold">Restore points</h2>
          {versions.length ? (
            <Button variant="ghost" size="sm" onClick={refresh}>
              Refresh
            </Button>
          ) : null}
        </header>
        {versions.length === 0 ? (
          <p className="px-5 py-8 text-center text-[13px] text-muted-foreground">
            No restore points yet. Save one before you generate a pack or rework the cost model.
          </p>
        ) : (
          <ul className="divide-y">
            {versions.map((v) => {
              const meta = REASON_META[v.reason];
              return (
                <li key={v.id} className="flex flex-wrap items-start justify-between gap-3 px-5 py-4">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className="rounded-full px-2 py-0.5 text-[10.5px] font-semibold uppercase tracking-wide"
                        style={{ backgroundColor: `#${meta.hex}1F`, color: `#${meta.hex}` }}
                      >
                        {meta.label}
                      </span>
                      <p className="truncate text-[13.5px] font-semibold">{v.label}</p>
                    </div>
                    <p className="mt-1.5 text-[12.5px] text-muted-foreground">
                      {when(v.createdAt)} · {v.scenarioCount} scenarios · {v.roleCount.toLocaleString()} roles ·{" "}
                      {v.plannedPositions.toLocaleString()} positions · {money(v.annualCost, v.currency)}
                      {v.origin ? ` · from ${v.origin}` : ""}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button size="sm" className="gap-2" onClick={() => onRestore(v)}>
                      <RotateCcw className="size-3.5" /> Restore
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        deleteVersion(v.id);
                        refresh();
                        toast.success("Restore point deleted");
                      }}
                    >
                      <Trash2 className="size-3.5" />
                    </Button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      <ScenarioSnapshots />

    </div>
  );
}