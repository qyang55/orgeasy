import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  useRouterState,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { OrgEasyProvider } from "@/lib/orgeasy/store";
import { AppShell } from "@/components/orgeasy/AppShell";
import { Toaster } from "@/components/ui/sonner";
import { CookieConsentBanner } from "@/components/orgeasy/ConsentControls";
import { GuidedDemoBar } from "@/components/orgeasy/GuidedDemoBar";
import { DemoNudge } from "@/components/orgeasy/DemoNudge";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Organisation Strategy Studio — Design. Simulation. Transform." },
      {
        name: "description",
        content:
          "Build current and future org charts, simulate headcount and budget impact, and export a leadership-ready PowerPoint.",
      },
      { property: "og:title", content: "Organisation Strategy Studio — Design. Simulation. Transform." },
      {
        property: "og:description",
        content:
          "Model restructuring scenarios, review Country Guidance, apply ADKAR, and export to PPTX.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      { rel: "icon", href: "/favicon.png", type: "image/png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      {
        rel: "preconnect",
        href: "https://fonts.gstatic.com",
        crossOrigin: "anonymous",
      },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=DM+Sans:opsz,wght@9..40,400..700&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function useStaleChunkRecovery() {
  useEffect(() => {
    const KEY = "orgeasy:chunk-reloaded";

    const recover = () => {
      // A stale module URL (after a dep re-bundle) can never resolve without a
      // fresh document load. Reload once, guarding against a reload loop.
      if (sessionStorage.getItem(KEY)) return;
      sessionStorage.setItem(KEY, "1");
      window.location.reload();
    };

    const isStaleChunk = (message: string) =>
      /Importing a module script failed|Failed to fetch dynamically imported module|error loading dynamically imported module/i.test(
        message,
      );

    const onPreloadError = () => recover();
    const onError = (event: ErrorEvent) => {
      if (isStaleChunk(String(event.message ?? ""))) recover();
    };
    const onRejection = (event: PromiseRejectionEvent) => {
      const reason = event.reason;
      const message =
        typeof reason === "string" ? reason : String(reason?.message ?? "");
      if (isStaleChunk(message)) recover();
    };

    window.addEventListener("vite:preloadError", onPreloadError);
    window.addEventListener("error", onError);
    window.addEventListener("unhandledrejection", onRejection);

    // Successful load: clear the guard so a future stale chunk can recover too.
    const clear = window.setTimeout(() => sessionStorage.removeItem(KEY), 4000);

    return () => {
      window.removeEventListener("vite:preloadError", onPreloadError);
      window.removeEventListener("error", onError);
      window.removeEventListener("unhandledrejection", onRejection);
      window.clearTimeout(clear);
    };
  }, []);
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  useStaleChunkRecovery();
  // The popped-out canvas window stays chrome-free: no consent banner, guided
  // demo bar, or conversion nudges — just the modelling surface.
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isPopout = pathname === "/canvas-popout";

  return (
    <QueryClientProvider client={queryClient}>
      <OrgEasyProvider>
        <AppShell>
          {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
          <Outlet />
        </AppShell>
        {!isPopout && (
          <>
            <CookieConsentBanner />
            <GuidedDemoBar />
            <DemoNudge />
          </>
        )}
        <Toaster richColors position="top-right" />
      </OrgEasyProvider>
    </QueryClientProvider>
  );
}
