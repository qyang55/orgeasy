import { createFileRoute } from "@tanstack/react-router";
import { AlertTriangle, Layers3, Users, Copy, Flame } from "lucide-react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { Disclaimer } from "@/components/orgeasy/Disclaimer";
import { StatCard } from "@/components/orgeasy/StatCard";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { formatMoney } from "@/lib/orgeasy/impact";
import { analyseSpans, SPAN_BENCHMARK } from "@/lib/orgeasy/span";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/span")({
  head: () => ({
    meta: [
      { title: "Span & Layers Analysis — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Benchmark spans of control and management layers, spot expensive pockets on a cost heat map, and detect duplicate or overlapping roles.",
      },
      { property: "og:title", content: "Span & Layers Analysis — Organisation Strategy Studio" },
      {
        property: "og:description",
        content: "Span of control benchmarks, cost heat map and duplicate role detection.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SpanPage,
});

const VERDICT_CLASS = {
  narrow: "bg-destructive/15 text-destructive",
  ideal: "bg-success/15 text-success",
  acceptable: "bg-secondary text-secondary-foreground",
  wide: "bg-warning/20 text-warning-foreground",
} as const;

/** Green (efficient) → red (expensive) heat colour. */
function heatStyle(intensity: number) {
  const hue = 145 - 145 * Math.min(Math.max(intensity, 0), 1);
  return {
    backgroundColor: `hsl(${hue} 72% 46% / ${0.16 + intensity * 0.62})`,
    borderColor: `hsl(${hue} 60% 40% / 0.45)`,
  };
}

function SpanPage() {
  const { scenario } = useOrgEasy();
  const a = analyseSpans(scenario);
  const cur = scenario?.currency ?? "USD";
  const layerNumbers = a.layers.map((l) => l.layer);

  return (
    <div className="pb-12">
      <PageHeader
        title="Span & layers analysis"
        description="Benchmark spans of control, expose surplus layers, see where cost concentrates, and find overlapping roles before you finalise the structure."
      />

      <div className="space-y-6 px-8 py-6">
        <Disclaimer />

        <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
          <StatCard
            label="Management layers"
            value={String(a.maxLayer)}
            tone={a.maxLayer > SPAN_BENCHMARK.maxLayers ? "negative" : "positive"}
            sub={`Benchmark ≤ ${SPAN_BENCHMARK.maxLayers} layers`}
            icon={<Layers3 className="size-4" />}
          />
          <StatCard
            label="Average span of control"
            value={a.avgSpan ? a.avgSpan.toFixed(1) : "—"}
            tone={
              a.avgSpan >= SPAN_BENCHMARK.idealSpanMin && a.avgSpan <= SPAN_BENCHMARK.idealSpanMax
                ? "positive"
                : "negative"
            }
            sub={`Benchmark ${SPAN_BENCHMARK.idealSpanMin}–${SPAN_BENCHMARK.idealSpanMax} reports`}
            icon={<Users className="size-4" />}
          />
          <StatCard
            label="Manager : IC ratio"
            value={a.managerRatio ? `1:${a.managerRatio.toFixed(1)}` : "—"}
            sub={`${a.managerCount} managers · ${a.icCount} individual contributors`}
          />
          <StatCard
            label="Overlap exposure"
            value={formatMoney(a.duplicateCost, cur)}
            tone={a.duplicateCost > 0 ? "negative" : "positive"}
            sub={`${a.duplicates.length} potential duplicate clusters`}
            icon={<Copy className="size-4" />}
          />
        </div>

        {a.flags.length ? (
          <section className="rounded-lg border border-border bg-card p-5 shadow-panel">
            <h2 className="flex items-center gap-2 text-sm font-semibold">
              <AlertTriangle className="size-4 text-warning" /> Structural findings
            </h2>
            <ul className="mt-3 space-y-2">
              {a.flags.map((f) => (
                <li
                  key={f.id}
                  className="flex items-start gap-3 rounded-md border border-border bg-secondary/50 px-3.5 py-2.5"
                >
                  <span
                    className={cn(
                      "mt-0.5 rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide",
                      f.severity === "high"
                        ? "bg-destructive/15 text-destructive"
                        : f.severity === "medium"
                          ? "bg-warning/20 text-warning-foreground"
                          : "bg-secondary text-muted-foreground",
                    )}
                  >
                    {f.severity}
                  </span>
                  <span className="min-w-0">
                    <span className="block text-[13px] font-semibold">{f.title}</span>
                    <span className="block text-xs text-muted-foreground">{f.detail}</span>
                  </span>
                </li>
              ))}
            </ul>
          </section>
        ) : (
          <section className="rounded-lg border border-border bg-card p-5 text-sm text-muted-foreground shadow-panel">
            No layer, span or duplication issues detected against the benchmark.
          </section>
        )}

        <section className="rounded-lg border border-border bg-card shadow-panel">
          <div className="border-b border-border px-5 py-3.5">
            <h2 className="text-sm font-semibold">Layers vs benchmark</h2>
            <p className="mt-0.5 text-xs text-muted-foreground">
              Ideal span is {SPAN_BENCHMARK.idealSpanMin}–{SPAN_BENCHMARK.idealSpanMax} direct
              reports per manager, with no more than {SPAN_BENCHMARK.maxLayers} layers end to end.
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-[13px]">
              <thead className="bg-secondary/60 text-left text-[11px] uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-5 py-2 font-semibold">Layer</th>
                  <th className="px-5 py-2 font-semibold">Roles</th>
                  <th className="px-5 py-2 font-semibold">Positions</th>
                  <th className="px-5 py-2 font-semibold">Managers</th>
                  <th className="px-5 py-2 font-semibold">Avg span</th>
                  <th className="px-5 py-2 font-semibold">Annual cost</th>
                  <th className="px-5 py-2 font-semibold">Benchmark</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {a.layers.map((l) => (
                  <tr key={l.layer}>
                    <td className="px-5 py-2.5 font-semibold">L{l.layer}</td>
                    <td className="px-5 py-2.5">{l.people}</td>
                    <td className="px-5 py-2.5">{l.positions}</td>
                    <td className="px-5 py-2.5">{l.managers}</td>
                    <td className="px-5 py-2.5">{l.avgSpan ? l.avgSpan.toFixed(1) : "—"}</td>
                    <td className="px-5 py-2.5">{formatMoney(l.cost, cur)}</td>
                    <td className="px-5 py-2.5">
                      <span
                        className={cn(
                          "rounded px-2 py-0.5 text-[11px] font-semibold",
                          l.verdict === "ok"
                            ? "bg-success/15 text-success"
                            : l.verdict === "thin"
                              ? "bg-warning/20 text-warning-foreground"
                              : "bg-destructive/15 text-destructive",
                        )}
                      >
                        {l.verdict === "ok"
                          ? "On benchmark"
                          : l.verdict === "thin"
                            ? "Thin layer"
                            : "Beyond benchmark"}
                      </span>
                    </td>
                  </tr>
                ))}
                {!a.layers.length ? (
                  <tr>
                    <td colSpan={7} className="px-5 py-6 text-center text-muted-foreground">
                      Add roles to the scenario to analyse layers.
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
        </section>

        <section className="rounded-lg border border-border bg-card p-5 shadow-panel">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="flex items-center gap-2 text-sm font-semibold">
                <Flame className="size-4 text-destructive" /> Cost heat map
              </h2>
              <p className="mt-0.5 text-xs text-muted-foreground">
                Cost per position by department and layer. Red = expensive, green = efficient.
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <span>Efficient</span>
              <span
                className="h-2.5 w-32 rounded-full"
                style={{
                  backgroundImage:
                    "linear-gradient(90deg, hsl(145 72% 46% / .75), hsl(70 72% 46% / .75), hsl(0 72% 46% / .85))",
                }}
              />
              <span>Expensive</span>
            </div>
          </div>

          {a.departments.length ? (
            <div className="mt-4 overflow-x-auto">
              <table className="w-full border-separate border-spacing-1 text-[12.5px]">
                <thead>
                  <tr>
                    <th className="px-2 text-left text-[11px] uppercase tracking-wider text-muted-foreground">
                      Department
                    </th>
                    {layerNumbers.map((n) => (
                      <th
                        key={n}
                        className="px-2 text-center text-[11px] uppercase tracking-wider text-muted-foreground"
                      >
                        L{n}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {a.departments.map((dept) => (
                    <tr key={dept}>
                      <td className="max-w-[220px] truncate px-2 py-1 font-medium">{dept}</td>
                      {layerNumbers.map((n) => {
                        const cell = a.heat.find((c) => c.department === dept && c.layer === n);
                        if (!cell)
                          return (
                            <td key={n} className="px-2 py-1">
                              <div className="rounded-md border border-dashed border-border/60 px-2 py-2 text-center text-[11px] text-muted-foreground">
                                —
                              </div>
                            </td>
                          );
                        return (
                          <td key={n} className="px-2 py-1">
                            <div
                              className="rounded-md border px-2 py-1.5 text-center"
                              style={heatStyle(cell.intensity)}
                              title={`${dept} · L${n} — ${cell.positions} positions · ${formatMoney(cell.cost, cur)} total`}
                            >
                              <span className="block font-semibold text-foreground">
                                {formatMoney(cell.costPerPosition, cur)}
                              </span>
                              <span className="block text-[10.5px] text-foreground/70">
                                {cell.positions} pos
                              </span>
                            </div>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="mt-4 text-sm text-muted-foreground">
              No cost data yet — add costs on People &amp; Roles to build the heat map.
            </p>
          )}
        </section>

        <div className="grid gap-6 xl:grid-cols-2">
          <section className="rounded-lg border border-border bg-card shadow-panel">
            <div className="border-b border-border px-5 py-3.5">
              <h2 className="text-sm font-semibold">Span of control by manager</h2>
              <p className="mt-0.5 text-xs text-muted-foreground">
                Narrow spans point at surplus layers; wide spans at overload.
              </p>
            </div>
            <ul className="max-h-[420px] divide-y divide-border overflow-y-auto">
              {a.rows
                .filter((r) => r.directReports > 0)
                .map((r) => (
                  <li key={r.id} className="flex items-center gap-3 px-5 py-2.5">
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[13px] font-semibold">{r.name}</span>
                      <span className="block truncate text-xs text-muted-foreground">
                        {r.title} · {r.department} · L{r.layer}
                      </span>
                    </span>
                    <span className="shrink-0 text-right text-xs text-muted-foreground">
                      {r.directReports} direct · {r.totalReports} total
                    </span>
                    <span
                      className={cn(
                        "shrink-0 rounded px-2 py-0.5 text-[11px] font-semibold capitalize",
                        VERDICT_CLASS[r.verdict],
                      )}
                    >
                      {r.verdict}
                    </span>
                  </li>
                ))}
              {!a.managerCount ? (
                <li className="px-5 py-6 text-center text-sm text-muted-foreground">
                  No reporting lines defined yet.
                </li>
              ) : null}
            </ul>
          </section>

          <section className="rounded-lg border border-border bg-card shadow-panel">
            <div className="border-b border-border px-5 py-3.5">
              <h2 className="text-sm font-semibold">Duplicate &amp; overlapping roles</h2>
              <p className="mt-0.5 text-xs text-muted-foreground">
                Clusters matched on role title and responsibility wording.
              </p>
            </div>
            <ul className="max-h-[420px] divide-y divide-border overflow-y-auto">
              {a.duplicates.map((d) => (
                <li key={d.id} className="px-5 py-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate text-[13px] font-semibold">{d.label}</p>
                      <p className="text-xs text-muted-foreground">{d.reason}</p>
                    </div>
                    <div className="shrink-0 text-right">
                      <p className="text-[13px] font-semibold text-destructive">
                        {formatMoney(d.cost, cur)}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {Math.round(d.similarity * 100)}% match
                      </p>
                    </div>
                  </div>
                  <ul className="mt-2 space-y-1">
                    {d.members.map((m) => (
                      <li
                        key={m.id}
                        className="flex items-center justify-between gap-3 rounded-md bg-secondary/60 px-2.5 py-1.5 text-xs"
                      >
                        <span className="truncate">
                          {m.name || "Open role"} — {m.title || "—"}
                        </span>
                        <span className="shrink-0 text-muted-foreground">
                          {m.department || "Unassigned"} · {m.country || "—"}
                        </span>
                      </li>
                    ))}
                  </ul>
                </li>
              ))}
              {!a.duplicates.length ? (
                <li className="px-5 py-6 text-center text-sm text-muted-foreground">
                  No overlapping roles detected in this scenario.
                </li>
              ) : null}
            </ul>
          </section>
        </div>
      </div>
    </div>
  );
}
