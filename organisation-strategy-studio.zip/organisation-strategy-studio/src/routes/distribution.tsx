import { useMemo } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { BarChart3, Layers3, GitCompareArrows, Users } from "lucide-react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { StatCard } from "@/components/orgeasy/StatCard";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { resolveBaseline } from "@/lib/orgeasy/phases";
import { buildDistribution, buildFlowModel, type FlowModel } from "@/lib/orgeasy/distribution";
import { formatMoney } from "@/lib/orgeasy/impact";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/distribution")({
  head: () => ({
    meta: [
      { title: "Workforce Distributions & Flow — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Span histograms, the org pyramid, cost per layer and a current-to-future flow diagram showing where every position goes.",
      },
      {
        property: "og:title",
        content: "Workforce Distributions & Flow — Organisation Strategy Studio",
      },
      {
        property: "og:description",
        content:
          "See the shape of the organisation: span distribution, layer pyramid, cost concentration and position-level flow into the future state.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DistributionPage,
});

const TONE_CLASS = {
  good: "bg-success",
  watch: "bg-warning",
  bad: "bg-destructive",
  neutral: "bg-brand",
} as const;

function BarRow({
  label,
  value,
  max,
  caption,
  tone = "neutral",
}: {
  label: string;
  value: number;
  max: number;
  caption: string;
  tone?: keyof typeof TONE_CLASS;
}) {
  return (
    <div className="grid grid-cols-[11rem_1fr_5.5rem] items-center gap-3">
      <p className="truncate text-[12.5px] font-medium">{label}</p>
      <div className="h-3 w-full overflow-hidden rounded-full bg-secondary">
        <div
          className={cn("h-full rounded-full transition-all", TONE_CLASS[tone])}
          style={{ width: `${max ? (value / max) * 100 : 0}%` }}
        />
      </div>
      <p className="text-right text-[12px] text-muted-foreground">{caption}</p>
    </div>
  );
}

/** Lightweight Sankey: two stacked columns joined by proportional ribbons. */
function FlowDiagram({ model }: { model: FlowModel }) {
  const width = 940;
  const height = 460;
  const colWidth = 16;
  const gap = 8;
  const left = model.nodes.filter((n) => n.side === "left");
  const right = model.nodes.filter((n) => n.side === "right");
  const scale = (side: typeof left) => {
    const total = side.reduce((s, n) => s + n.value, 0);
    const usable = height - gap * Math.max(side.length - 1, 0);
    return total ? usable / total : 0;
  };
  const layout = (side: typeof left) => {
    const k = scale(side);
    let y = 0;
    return new Map(
      side.map((n) => {
        const h = Math.max(n.value * k, 2);
        const box = { y, h, node: n };
        y += h + gap;
        return [n.id, box];
      }),
    );
  };
  const leftBoxes = layout(left);
  const rightBoxes = layout(right);
  const cursorL = new Map<string, number>();
  const cursorR = new Map<string, number>();
  const kL = scale(left);
  const kR = scale(right);

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="w-full" role="img" aria-label="Position flow from the baseline into the future state">
      {model.links.map((link) => {
        const l = leftBoxes.get(link.source);
        const r = rightBoxes.get(link.target);
        if (!l || !r) return null;
        const hL = Math.max(link.value * kL, 1);
        const hR = Math.max(link.value * kR, 1);
        const y0 = l.y + (cursorL.get(link.source) ?? 0);
        const y1 = r.y + (cursorR.get(link.target) ?? 0);
        cursorL.set(link.source, (cursorL.get(link.source) ?? 0) + hL);
        cursorR.set(link.target, (cursorR.get(link.target) ?? 0) + hR);
        const x0 = 210 + colWidth;
        const x1 = width - 250 - colWidth;
        const mid = (x0 + x1) / 2;
        const path = `M${x0},${y0} C${mid},${y0} ${mid},${y1} ${x1},${y1} L${x1},${y1 + hR} C${mid},${y1 + hR} ${mid},${y0 + hL} ${x0},${y0 + hL} Z`;
        return (
          <path key={`${link.source}-${link.target}`} d={path} fill={`#${r.node.hex}`} opacity={0.28} />
        );
      })}
      {[...leftBoxes.values()].map(({ node, y, h }) => (
        <g key={node.id}>
          <rect x={210} y={y} width={colWidth} height={h} rx={3} fill={`#${node.hex}`} />
          <text x={200} y={y + h / 2 + 4} textAnchor="end" className="fill-foreground" fontSize="12">
            {node.label}
          </text>
          <text x={200} y={y + h / 2 + 18} textAnchor="end" className="fill-muted-foreground" fontSize="10.5">
            {node.value.toLocaleString()} positions
          </text>
        </g>
      ))}
      {[...rightBoxes.values()].map(({ node, y, h }) => (
        <g key={node.id}>
          <rect x={width - 250 - colWidth} y={y} width={colWidth} height={h} rx={3} fill={`#${node.hex}`} />
          <text x={width - 240} y={y + h / 2 + 4} className="fill-foreground" fontSize="12">
            {node.label}
          </text>
          <text x={width - 240} y={y + h / 2 + 18} className="fill-muted-foreground" fontSize="10.5">
            {node.value.toLocaleString()} positions
          </text>
        </g>
      ))}
    </svg>
  );
}

function DistributionPage() {
  const { workspace, scenario } = useOrgEasy();
  const baseline = useMemo(
    () => resolveBaseline(workspace.scenarios, scenario),
    [workspace.scenarios, scenario],
  );
  const dist = useMemo(() => buildDistribution(scenario), [scenario]);
  const flow = useMemo(() => buildFlowModel(baseline, scenario), [baseline, scenario]);
  const cur = scenario?.currency ?? "USD";

  const maxSpan = Math.max(1, ...dist.spanBuckets.map((b) => b.count));
  const maxLayer = Math.max(1, ...dist.pyramid.map((p) => p.positions));
  const maxCost = Math.max(1, ...dist.costBuckets.map((b) => b.count));
  const maxDept = Math.max(1, ...dist.byDepartment.map((d) => d.positions));

  return (
    <div className="pb-12">
      <PageHeader
        title="Workforce distributions & flow"
        description="Averages hide the problem. These distributions show the actual shape of the organisation — where spans collapse, where cost concentrates, and where every baseline position lands in the future state."
      />

      <div className="space-y-6 px-8 py-6">
        <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
          <StatCard
            label="Positions in scope"
            value={dist.totalPositions.toLocaleString()}
            sub={`${dist.pyramid.length} layers · ${dist.byDepartment.length} functions`}
            icon={<Users className="size-4" />}
          />
          <StatCard
            label="Median span"
            value={dist.medianSpan ? String(dist.medianSpan) : "—"}
            tone={dist.medianSpan >= 5 && dist.medianSpan <= 9 ? "positive" : "negative"}
            sub="Benchmark 5–9 direct reports"
            icon={<Layers3 className="size-4" />}
          />
          <StatCard
            label="Manager share"
            value={`${(dist.managerShare * 100).toFixed(1)}%`}
            tone={dist.managerShare > 0.2 ? "negative" : "positive"}
            sub="Roles with at least one direct report"
            icon={<BarChart3 className="size-4" />}
          />
          <StatCard
            label="Cost in top 3 layers"
            value={`${(dist.topHeavyIndex * 100).toFixed(0)}%`}
            tone={dist.topHeavyIndex > 0.35 ? "negative" : "positive"}
            sub={`of ${formatMoney(dist.totalCost, cur)} total people cost`}
          />
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <section className="rounded-lg border border-border bg-card p-5 shadow-panel">
            <h2 className="text-sm font-semibold">Span of control distribution</h2>
            <p className="mt-1 text-[12.5px] text-muted-foreground">
              How many managers sit in each span band. Weight on the 1–2 band is the delayering
              opportunity; weight on 15+ signals unmapped or overloaded reporting.
            </p>
            <div className="mt-4 space-y-2.5">
              {dist.spanBuckets.map((b) => (
                <BarRow
                  key={b.label}
                  label={b.label}
                  value={b.count}
                  max={maxSpan}
                  tone={b.tone}
                  caption={`${b.count} roles`}
                />
              ))}
            </div>
          </section>

          <section className="rounded-lg border border-border bg-card p-5 shadow-panel">
            <h2 className="text-sm font-semibold">Organisation pyramid</h2>
            <p className="mt-1 text-[12.5px] text-muted-foreground">
              Positions and cost per layer. A healthy pyramid widens steadily; a bulge in the middle
              layers is where duplicate management sits.
            </p>
            <div className="mt-4 space-y-2.5">
              {dist.pyramid.map((p) => (
                <BarRow
                  key={p.layer}
                  label={`Layer ${p.layer}`}
                  value={p.positions}
                  max={maxLayer}
                  tone={p.layer > 6 ? "bad" : p.avgSpan > 0 && p.avgSpan < 3 ? "watch" : "neutral"}
                  caption={`${p.positions} · ${formatMoney(p.cost, cur)}`}
                />
              ))}
              {!dist.pyramid.length ? (
                <p className="text-[12.5px] text-muted-foreground">No hierarchy data yet.</p>
              ) : null}
            </div>
          </section>

          <section className="rounded-lg border border-border bg-card p-5 shadow-panel">
            <h2 className="text-sm font-semibold">Cost per position distribution</h2>
            <p className="mt-1 text-[12.5px] text-muted-foreground">
              Where the cost per role clusters. A long right tail means savings concentrate in a
              small number of expensive positions.
            </p>
            <div className="mt-4 space-y-2.5">
              {dist.costBuckets.map((b) => (
                <BarRow
                  key={b.label}
                  label={b.label}
                  value={b.count}
                  max={maxCost}
                  tone={b.tone}
                  caption={`${b.count} roles`}
                />
              ))}
              {!dist.costBuckets.length ? (
                <p className="text-[12.5px] text-muted-foreground">
                  No cost data on this scenario yet.
                </p>
              ) : null}
            </div>
          </section>

          <section className="rounded-lg border border-border bg-card p-5 shadow-panel">
            <h2 className="text-sm font-semibold">Positions and management by function</h2>
            <p className="mt-1 text-[12.5px] text-muted-foreground">
              Managers as a share of each function — the fastest read on where structure is heavier
              than the work requires.
            </p>
            <div className="mt-4 space-y-2.5">
              {dist.byDepartment.slice(0, 10).map((d) => (
                <BarRow
                  key={d.key}
                  label={d.key}
                  value={d.positions}
                  max={maxDept}
                  tone={d.positions && d.managers / d.positions > 0.25 ? "watch" : "neutral"}
                  caption={`${d.managers} mgr / ${d.positions}`}
                />
              ))}
            </div>
          </section>
        </div>

        <section className="rounded-lg border border-border bg-card p-5 shadow-panel">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <h2 className="flex items-center gap-2 text-sm font-semibold">
                <GitCompareArrows className="size-4 text-brand" /> Where every position goes
              </h2>
              <p className="mt-1 text-[12.5px] text-muted-foreground">
                {flow.total
                  ? `${flow.baseName} → ${flow.targetName}. Functions on the left, outcome on the right, ribbon width in positions.`
                  : "Select a future-state phase with a baseline to see the position flow."}
              </p>
            </div>
            {flow.total ? (
              <div className="flex flex-wrap gap-4 text-[12px]">
                <span className="text-success">Retained {flow.retained}</span>
                <span className="text-warning-foreground">Reassigned {flow.reassigned}</span>
                <span className="text-destructive">Removed {flow.reduced}</span>
                <span className="text-info">New {flow.created}</span>
              </div>
            ) : null}
          </div>
          {flow.total ? (
            <div className="mt-5 overflow-x-auto">
              <div className="min-w-[880px]">
                <FlowDiagram model={flow} />
              </div>
            </div>
          ) : null}
        </section>
      </div>
    </div>
  );
}
