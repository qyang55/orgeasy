import { createFileRoute, redirect } from "@tanstack/react-router";

// Legacy/typo safety net: some bookmarks and preview sessions point at /index.
// The real home route is "/", which forwards to /welcome.
export const Route = createFileRoute("/index/")({
  head: () => ({
    meta: [
      { title: "Organisation Strategy Studio" },
      { name: "robots", content: "noindex" },
    ],
  }),
  beforeLoad: () => {
    throw redirect({ to: "/" });
  },
});
