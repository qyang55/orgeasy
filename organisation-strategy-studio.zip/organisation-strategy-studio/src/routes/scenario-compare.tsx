import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Columns3, Copy, Printer, ArrowRight, Trophy, Info } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { currentStateFor, isCurrentState, phaseTitle } from "@/lib/orgeasy/phases";
import {
  COMPARE_GROUPS,
  buildCompareColumn,
  compareToText,
  formatMetric,
  type CompareColumn,
  type CompareMetric,
} from "@/lib/orgeasy/scenario-compare";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/scenario-compare")({
  head: () => ({
    meta: [
      { title: "Side-by-side Scenario Comparison — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Compare the current state against up to two future organisation options side by side: positions, annual cost, one-off separation cost, layers, spans and the levers behind each option.",
      },
      {
        property: "og:title",
        content: "Side-by-side Scenario Comparison — Organisation Strategy Studio",
      },
      {
        property: "og:description",
        content:
          "Put two future organisation options next to today's baseline and see where the trade-offs sit.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ScenarioComparePage,
});

const NONE = "__none";

function DeltaChip({
  delta,
  metric,
  currency,
}: {
  delta: number;
  metric: CompareMetric;
  currency: string;
}) {
  if (!Math.round(delta * (metric.format === "decimal" || metric.format === "pct" ? 100 : 1))) {
    return <span className="text-[11px] text-muted-foreground">same as baseline</span>;
  }
  const better =
    metric.goal === "none" ? null : metric.goal === "lower" ? delta < 0 : delta > 0;
  return (
    <span
      className={cn(
        "text-[11px] font-semibold",
        better === null
          ? "text-muted-foreground"
          : better
            ? "text-success"
            : "text-destructive",
      )}
    >
      {delta > 0 ? "+" : "−"}
      {formatMetric(Math.abs(delta), metric.format, currency)} vs baseline
    </span>
  );
}

function ScenarioComparePage() {
  const { workspace, scenario } = useOrgEasy();
  const scenarios = workspace.scenarios;
  const baselineDefault = currentStateFor(scenarios, scenario);
  const currents = scenarios.filter(isCurrentState);
  const futures = scenarios.filter((s) => !isCurrentState(s));

  const [baseId, setBaseId] = useState(
    () => baselineDefault?.id ?? currents[0]?.id ?? scenarios[0]?.id ?? "",
  );
  const firstPick =
    scenario && !isCurrentState(scenario) ? scenario.id : (futures[0]?.id ?? NONE);
  const [leftId, setLeftId] = useState(() => firstPick);
  const [rightId, setRightId] = useState(
    () => futures.find((s) => s.id !== firstPick)?.id ?? NONE,
  );

  const picked = useMemo(() => {
    const ids = [baseId, leftId, rightId].filter((id) => id && id !== NONE);
    const seen = new Set<string>();
    return ids
      .filter((id) => (seen.has(id) ? false : (seen.add(id), true)))
      .map((id) => scenarios.find((s) => s.id === id))
      .filter((s): s is NonNullable<typeof s> => Boolean(s));
  }, [baseId, leftId, rightId, scenarios]);

  const columns = useMemo<CompareColumn[]>(
    () => picked.map((s) => buildCompareColumn(s)),
    [picked],
  );
  const baseline = columns.find((c) => c.id === baseId) ?? null;
  const currency = columns[0]?.currency ?? "USD";
  const futureColumns = columns.filter((c) => c.id !== baseId);

  /** With two future options on screen, mark the stronger value per metric. */
  const bestOf = (metric: CompareMetric) => {
    if (metric.goal === "none" || futureColumns.length < 2) return null;
    const scored = futureColumns.map((c) => ({ id: c.id, v: metric.value(c) }));
    const target =
      metric.goal === "lower"
        ? Math.min(...scored.map((s) => s.v))
        : Math.max(...scored.map((s) => s.v));
    const winners = scored.filter((s) => s.v === target);
    return winners.length === 1 ? winners[0]!.id : null;
  };

  const gridCols =
    columns.length === 3
      ? "grid-cols-[minmax(190px,1.15fr)_repeat(3,minmax(150px,1fr))]"
      : columns.length === 2
        ? "grid-cols-[minmax(190px,1.15fr)_repeat(2,minmax(150px,1fr))]"
        : "grid-cols-[minmax(190px,1.15fr)_minmax(150px,1fr)]";

  const availableFor = (slot: "left" | "right") =>
    futures.filter((s) => s.id !== (slot === "left" ? rightId : leftId));

  return (
    <div className="pb-14">
      <PageHeader
        title="Side-by-side scenario comparison"
        description="Put the current state next to up to two future organisation options and read the trade-offs in one table — size, cost, transition cost, shape and the levers behind each option."
        actions={
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => {
                void navigator.clipboard
                  .writeText(compareToText(columns))
                  .then(() => toast.success("Comparison copied for your meeting notes"))
                  .catch(() => toast.error("Could not copy — select and copy the table instead"));
              }}
            >
              <Copy className="mr-1.5 size-4" /> Copy as text
            </Button>
            <Button variant="outline" onClick={() => window.print()}>
              <Printer className="mr-1.5 size-4" /> Print / PDF
            </Button>
            <Button asChild>
              <Link to="/compare">
                Role-level diff <ArrowRight className="ml-1.5 size-4" />
              </Link>
            </Button>
          </div>
        }
      />

      <div className="space-y-6 px-6 pt-5">
        {/* Selectors */}
        <div className="rounded-lg border bg-card p-4">
          <p className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            <Columns3 className="size-3.5" /> Choose what to compare
          </p>
          <div className="mt-3 grid gap-3 md:grid-cols-3">
            <div>
              <p className="mb-1.5 text-[12px] font-medium text-muted-foreground">
                Baseline — current state
              </p>
              <Select value={baseId} onValueChange={setBaseId}>
                <SelectTrigger aria-label="Baseline scenario">
                  <SelectValue placeholder="Select current state" />
                </SelectTrigger>
                <SelectContent>
                  {(currents.length ? currents : scenarios).map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      {phaseTitle(s)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {(
              [
                ["left", leftId, setLeftId, "Future option A"],
                ["right", rightId, setRightId, "Future option B"],
              ] as const
            ).map(([slot, value, setValue, label]) => (
              <div key={slot}>
                <p className="mb-1.5 text-[12px] font-medium text-muted-foreground">{label}</p>
                <Select value={value} onValueChange={setValue}>
                  <SelectTrigger aria-label={label}>
                    <SelectValue placeholder="Not selected" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={NONE}>Not selected</SelectItem>
                    {availableFor(slot).map((s) => (
                      <SelectItem key={s.id} value={s.id}>
                        {phaseTitle(s)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ))}
          </div>
          <p className="mt-3 flex items-start gap-1.5 text-[12px] text-muted-foreground">
            <Info className="mt-0.5 size-3.5 shrink-0" />
            Comparing here does not change your phase sequence or the active scenario — every
            individual scenario view stays exactly as it is.
          </p>
        </div>

        {!baseline ? (
          <div className="rounded-lg border border-dashed p-10 text-center text-[13px] text-muted-foreground">
            Add a current state scenario to start comparing.
          </div>
        ) : futureColumns.length === 0 ? (
          <div className="rounded-lg border border-dashed p-10 text-center text-[13px] text-muted-foreground">
            Select at least one future option above to see the comparison.
          </div>
        ) : (
          <>
            {/* Headline cards */}
            <div className={cn("grid gap-3", columns.length === 3 ? "md:grid-cols-3" : "md:grid-cols-2")}>
              {columns.map((c) => {
                const posDelta = c.positions - baseline.positions;
                const costDelta = c.annualCost - baseline.annualCost;
                return (
                  <div
                    key={c.id}
                    className={cn(
                      "rounded-lg border bg-card p-4",
                      c.isCurrent ? "border-border" : "border-brand/40 bg-brand/[0.04]",
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <Badge variant={c.isCurrent ? "secondary" : "default"} className="text-[10px]">
                        {c.isCurrent ? "Baseline" : "Future option"}
                      </Badge>
                      {c.id === scenario?.id ? (
                        <Badge variant="outline" className="text-[10px]">
                          Active
                        </Badge>
                      ) : null}
                    </div>
                    <p className="mt-2 text-[15px] font-semibold leading-snug">{c.title}</p>
                    <p className="mt-2 text-2xl font-semibold tabular-nums">
                      {c.positions.toLocaleString()}
                      <span className="ml-1.5 text-[12px] font-normal text-muted-foreground">
                        positions
                      </span>
                    </p>
                    {c.isCurrent ? (
                      <p className="mt-1 text-[12px] text-muted-foreground">
                        Today's organisation — everything else is measured against this.
                      </p>
                    ) : (
                      <div className="mt-1 space-y-0.5 text-[12px]">
                        <p className={cn("font-semibold", posDelta <= 0 ? "text-brand" : "text-warning-foreground")}>
                          {posDelta > 0 ? "+" : ""}
                          {posDelta.toLocaleString()} positions (
                          {baseline.positions
                            ? `${((Math.abs(posDelta) / baseline.positions) * 100).toFixed(1)}%`
                            : "—"}
                          )
                        </p>
                        <p className={cn(costDelta <= 0 ? "text-success" : "text-destructive")}>
                          {costDelta <= 0 ? "Saves " : "Adds "}
                          {formatMetric(Math.abs(costDelta), "money", currency)} a year
                        </p>
                        <p className="text-muted-foreground">
                          One-off cost {formatMetric(c.separationMid, "money", currency)} (mid case)
                        </p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Metric table */}
            <div className="overflow-hidden rounded-lg border bg-card">
              <div className={cn("grid border-b bg-muted/40", gridCols)}>
                <div className="px-4 py-2.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                  Metric
                </div>
                {columns.map((c) => (
                  <div
                    key={c.id}
                    className="border-l px-4 py-2.5 text-[12px] font-semibold leading-tight"
                  >
                    {c.title}
                    {c.isCurrent ? (
                      <span className="block text-[10px] font-normal uppercase tracking-wider text-muted-foreground">
                        baseline
                      </span>
                    ) : null}
                  </div>
                ))}
              </div>

              {COMPARE_GROUPS.map((group) => (
                <div key={group.title}>
                  <div className="border-b bg-muted/20 px-4 py-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                    {group.title}
                  </div>
                  {group.metrics.map((metric) => {
                    const winner = bestOf(metric);
                    return (
                      <div key={metric.key} className={cn("grid border-b last:border-b-0", gridCols)}>
                        <div className="px-4 py-3">
                          <p className="text-[13px] font-medium">{metric.label}</p>
                          {metric.hint ? (
                            <p className="text-[11px] text-muted-foreground">{metric.hint}</p>
                          ) : null}
                        </div>
                        {columns.map((c) => {
                          const na = metric.futureOnly && c.isCurrent;
                          const value = metric.value(c);
                          return (
                            <div
                              key={c.id}
                              className={cn(
                                "border-l px-4 py-3",
                                winner === c.id && "bg-success/5",
                              )}
                            >
                              {na ? (
                                <p className="text-[13px] text-muted-foreground">—</p>
                              ) : (
                                <>
                                  <p className="flex items-center gap-1.5 text-[14px] font-semibold tabular-nums">
                                    {formatMetric(value, metric.format, currency)}
                                    {winner === c.id ? (
                                      <Trophy
                                        className="size-3.5 text-success"
                                        aria-label="Stronger of the two options"
                                      />
                                    ) : null}
                                  </p>
                                  {c.isCurrent ? (
                                    <span className="text-[11px] text-muted-foreground">
                                      baseline
                                    </span>
                                  ) : metric.futureOnly ? (
                                    <span className="text-[11px] text-muted-foreground">
                                      no baseline equivalent
                                    </span>
                                  ) : (
                                    <DeltaChip
                                      delta={value - metric.value(baseline)}
                                      metric={metric}
                                      currency={currency}
                                    />
                                  )}
                                </>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    );
                  })}
                </div>
              ))}

              {/* Levers row */}
              <div className="border-b bg-muted/20 px-4 py-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                Main levers used
              </div>
              <div className={cn("grid", gridCols)}>
                <div className="px-4 py-3">
                  <p className="text-[13px] font-medium">Where the change comes from</p>
                  <p className="text-[11px] text-muted-foreground">Positions per lever</p>
                </div>
                {columns.map((c) => (
                  <div key={c.id} className="border-l px-4 py-3">
                    {c.levers.length === 0 ? (
                      <p className="text-[12px] text-muted-foreground">
                        {c.isCurrent ? "—" : "No levers applied yet"}
                      </p>
                    ) : (
                      <div className="space-y-1.5">
                        {c.levers.map((l) => (
                          <div key={l.lever} className="flex items-center gap-1.5">
                            <span
                              className="size-2 shrink-0 rounded-full"
                              style={{ backgroundColor: `#${l.hex}` }}
                            />
                            <span className="text-[12px]">{l.label}</span>
                            <span className="ml-auto text-[12px] font-semibold tabular-nums">
                              {l.positions.toLocaleString()}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <p className="text-[12px] text-muted-foreground">
              Illustrative planning figures only. Separation costs use mid-case country assumptions
              and are not legal advice — confirm notice, severance and consultation duties with
              qualified local counsel before acting.
            </p>
          </>
        )}
      </div>
    </div>
  );
}
