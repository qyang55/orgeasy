import { createFileRoute } from "@tanstack/react-router";
import { Landing } from "@/components/orgeasy/Landing";

export const Route = createFileRoute("/welcome")({
  head: () => ({
    meta: [
      { title: "Organisation Strategy Studio — Org design, simulation & transformation" },
      {
        name: "description",
        content:
          "Model, simulate and transform your organisation: living org charts, headcount and cost impact across 22 countries, phased transformation planning and board-ready PowerPoint exports.",
      },
      {
        property: "og:title",
        content: "Organisation Strategy Studio — Org design, simulation & transformation",
      },
      {
        property: "og:description",
        content:
          "Simulate restructuring, headcount, cost and risk scenarios in minutes — and walk into leadership meetings with board-ready answers.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: WelcomePage,
});

function WelcomePage() {
  return <Landing />;
}
