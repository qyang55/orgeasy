import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Organisation Strategy Studio — Org design, simulation & transformation" },
      {
        name: "description",
        content:
          "Model, simulate and transform your organisation: living org charts, headcount and cost impact across 22 countries, phased transformation planning and board-ready PowerPoint exports.",
      },
      {
        property: "og:title",
        content: "Organisation Strategy Studio — Org design, simulation & transformation",
      },
      {
        property: "og:description",
        content:
          "Simulate restructuring, headcount, cost and risk scenarios in minutes — and walk into leadership meetings with board-ready answers.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  beforeLoad: () => {
    throw redirect({ to: "/welcome" });
  },
});
