import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import orgeasyLogo from "@/assets/orgeasy-logo.png";
import { useStudioChrome } from "@/lib/orgeasy/studio-chrome";
import { analyseSpans, SPAN_BENCHMARK } from "@/lib/orgeasy/span";
import {
  OrgChartCanvas,
  CARD_DENSITY_PRESETS,
  CARD_FIELD_LABELS,
  DEFAULT_CARD_FIELDS,
  type CardDensity,
  type CardFields,
} from "@/components/orgeasy/OrgChartCanvas";
import { ChartImportDialog } from "@/components/orgeasy/ChartImportDialog";
import { POP_OUT_HANDOFF_KEY, emptyEmployee, useOrgEasy } from "@/lib/orgeasy/store";
import { useChartHistory } from "@/lib/orgeasy/chart-history";
import { LAYOUT_OPTIONS, type LayoutKind } from "@/lib/orgeasy/layout";
import {
  ORG_UNIT_KINDS,
  ROLE_SCOPES,
  ROLE_TYPES,
  ROLE_TYPE_META,
  REDUCTION_LEVERS,
  LEVER_META,
  SCOPE_META,
  STATUS_META,
  UNIT_META,
  type Employee,
  type EmployeeStatus,
  type OrgUnitKind,
  type ReductionLever,
  type RoleScope,
  type RoleType,
} from "@/lib/orgeasy/types";
import { HYBRID_AGENT_SHARE, roleTypeOf, useAgentMonthlyCost, agentAnnualCost } from "@/lib/orgeasy/agents";
import { computeCostModel, roleCost, roleCostLines, useCostAssumptions } from "@/lib/orgeasy/cost-model";
import {
  CHART_THEMES,
  COLOR_BY_OPTIONS,
  getTheme,
  type ColorBy,
} from "@/lib/orgeasy/themes";
import { fileToAvatarDataUrl } from "@/lib/orgeasy/photo";
import {
  applyLayout,
  captureLayout,
  clearLayoutSnapshot,
  countMatches,
  loadLayoutSnapshot,
  saveLayoutSnapshot,
  DEFAULT_APPLY_OPTIONS,
  type ApplyLayoutOptions,
  type LayoutSnapshot,
} from "@/lib/orgeasy/layout-clipboard";
import {
  buildLegend,
  drawLegend,
  loadLegendConfig,
  saveLegendConfig,
  DEFAULT_LEGEND,
  type LegendConfig,
} from "@/lib/orgeasy/legend";
import { SCALE_LIMITS, capHierarchy, formatCount } from "@/lib/orgeasy/scale";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { formatMoney } from "@/lib/orgeasy/impact";
import {
  compareScenarios,
  diffClassMap,
  DIFF_CLASS_META,
  type DiffClass,
} from "@/lib/orgeasy/diff";
import {
  isCurrentState,
  laterPhases,
  listPhases,
  nextPhaseOrder,
  phaseTitle,
  resolveBaseline,
  scenarioLabel,
} from "@/lib/orgeasy/phases";
import { cn } from "@/lib/utils";
import { usePersistedFlag } from "@/lib/orgeasy/ui-prefs";
import {
  Activity,
  ArrowLeft,
  Bot,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  ClipboardCopy,
  ClipboardPaste,
  Columns2,
  GitCompare,
  ImageDown,
  ImagePlus,
  LayoutGrid,
  List,
  SlidersHorizontal,
  Eye,
  Expand,
  Maximize2,
  Minimize2,
  Palette,
  Redo2,
  RotateCcw,
  Trash2,

  PictureInPicture2,
  Undo2,
  UserPlus,
  CircleDollarSign,
  GitFork,
  Layers3,
  Network,
  Search,
  Users,
} from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/chart")({
  validateSearch: (search: Record<string, unknown>): { layout?: LayoutKind } =>
    typeof search['layout'] === "string" ? { layout: search['layout'] as LayoutKind } : {},
  head: () => ({
    meta: [
      { title: "Org Chart Designer — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Design current and future org structures with drag-and-drop reporting lines, six layouts and side-by-side comparison.",
      },
      { property: "og:title", content: "Org Chart Designer — Organisation Strategy Studio" },
      {
        property: "og:description",
        content: "Drag-and-drop org chart designer with six layouts and scenario comparison.",
      },
    ],
  }),
  component: ChartRoute,
});

function ChartRoute() {
  const search = Route.useSearch();
  return <ChartPage search={search} />;
}

/** A manual chart edit waiting for the user to choose where it applies. */
type StructuralChange = {
  /** Short undo/redo label. */
  verb: string;
  /** Human description shown in the confirmation dialog. */
  summary: string;
  /** Removals ask whether later phases should change too. */
  askScope: boolean;
  apply: (employees: Employee[]) => Employee[];
  /** Runs after the change lands (e.g. move the selection). */
  after?: () => void;
};

export function ChartPage({
  search,
  popout = false,
}: {
  search: { layout?: LayoutKind | undefined };
  popout?: boolean;
}) {
  const {
    workspace,
    scenario,
    setActiveScenario,
    setPosition,
    setNodeSize,
    upsertEmployee,
    replaceEmployees,
    updateScenario,
    resetChartData,
    resetChartLayout,
    createScenarioWithEmployees,
    mutateScenarioEmployees,
  } = useOrgEasy();
  const navigate = useNavigate();

  const [layout, setLayout] = useState<LayoutKind>(
    LAYOUT_OPTIONS.some((o) => o.value === search.layout) ? search.layout! : "vertical",
  );
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [compareId, setCompareId] = useState<string>("none");
  const [roleTypeFilter, setRoleTypeFilter] = useState<"all" | RoleType>("all");
  const [deptFilter, setDeptFilter] = useState("all");
  const [locationFilter, setLocationFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState<"all" | "vacant" | EmployeeStatus>("all");
  const [levelFilter, setLevelFilter] = useState<"all" | "1" | "2" | "3" | "4">("all");
  const [minSpan, setMinSpan] = useState(0);
  const [groupBy, setGroupBy] = useState<"none" | "department" | "country">("none");
  const [cardFields, setCardFields] = useState<CardFields>(DEFAULT_CARD_FIELDS);
  // The density segmented control is derived from the fields: hand-tuning a
  // checkbox turns the preset into a "custom" mix.
  const cardDensity = useMemo<CardDensity | "custom">(() => {
    const match = (Object.keys(CARD_DENSITY_PRESETS) as CardDensity[]).find((level) =>
      (Object.keys(CARD_DENSITY_PRESETS[level].fields) as (keyof CardFields)[]).every(
        (f) => CARD_DENSITY_PRESETS[level].fields[f] === cardFields[f],
      ),
    );
    return match ?? "custom";
  }, [cardFields]);
  const agentMonthly = useAgentMonthlyCost();
  const [themeId, setThemeId] = useState("clay");
  const [colorBy, setColorBy] = useState<ColorBy>("status");
  const [diffMode, setDiffMode] = useState(false);
  const [legendConfig, setLegendConfig] = useState<LegendConfig>(DEFAULT_LEGEND);
  const [panelOpen, setPanelOpen] = usePersistedFlag("chart.panelOpen", true);
  const [detailsOpen, setDetailsOpen] = usePersistedFlag("chart.detailsOpen", true);
  const [identityOpen, setIdentityOpen] = usePersistedFlag("chart.identityOpen", true);
  const [structureOpen, setStructureOpen] = usePersistedFlag("chart.structureOpen", true);
  const [costOpen, setCostOpen] = usePersistedFlag("chart.costOpen", true);
  const [dottedOpen, setDottedOpen] = usePersistedFlag("chart.dottedOpen", true);
  const [responsibilitiesOpen, setResponsibilitiesOpen] = usePersistedFlag(
    "chart.responsibilitiesOpen",
    true,
  );
  const [legendOpen, setLegendOpen] = usePersistedFlag("chart.legendOpen", true);
  /** Reset actions are destructive, so they go through a confirmation dialog. */
  const [pendingReset, setPendingReset] = useState<"data" | "data-links" | "layout" | null>(null);
  const [resetMenuOpen, setResetMenuOpen] = useState(false);
  /** Structural edit waiting for a “which phase?” decision. */
  const [pendingChange, setPendingChange] = useState<StructuralChange | null>(null);
  const [changeScopeLater, setChangeScopeLater] = useState(false);
  const [targetPhaseId, setTargetPhaseId] = useState<string>("new");

  const askReset = (kind: "data" | "data-links" | "layout") => {
    setResetMenuOpen(false);
    setPendingReset(kind);
  };

  const [fullScreen, setFullScreen] = useState(false);
  // Studio top-bar integration: actions and the live metrics strip portal into
  // the shell chrome; search is controlled from the top bar in shell mode.
  const chrome = useStudioChrome();
  const [searchQuery, setSearchQuery] = useState("");


  useEffect(() => {
    if (!fullScreen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setFullScreen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [fullScreen]);
  const [railHintOpen, setRailHintOpen] = useState(false);
  const [layoutClip, setLayoutClip] = useState<LayoutSnapshot | null>(null);
  const [applyOptions, setApplyOptions] = useState<ApplyLayoutOptions>(DEFAULT_APPLY_OPTIONS);
  const photoRef = useRef<HTMLInputElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const history = useChartHistory();
  // Undo/redo entries re-read state at replay time, so keep a live reference.
  const scenarioRef = useRef(scenario);
  scenarioRef.current = scenario;

  const openPopoutCanvas = () => {
    const url = `${window.location.origin}/canvas-popout?layout=${layout}`;
    const popup = window.open("", "oss-canvas-popout", "popup=yes,width=1680,height=1000");
    if (!popup) {
      toast.error("Pop-out canvas was blocked", {
        description: "Allow pop-ups for this site, then try again.",
      });
      return;
    }
    try {
      popup.sessionStorage.setItem(POP_OUT_HANDOFF_KEY, JSON.stringify(workspace));
    } catch {
      /* The broadcast sync channel will still hydrate the pop-out. */
    }
    popup.location.href = url;
    popup.focus();
  };

  useEffect(() => {
    const saved = localStorage.getItem("orgeasy.chart.theme");
    const savedBy = localStorage.getItem("orgeasy.chart.colorBy");
    // The old dark default is retired: migrate saved prefs to the light clay theme.
    if (saved) setThemeId(saved === "obsidian" ? "clay" : saved);
    if (savedBy) setColorBy(savedBy as ColorBy);
    setLegendConfig(loadLegendConfig());
  }, []);
  useEffect(() => {
    setLayoutClip(loadLayoutSnapshot());
  }, []);
  useEffect(() => {
    localStorage.setItem("orgeasy.chart.theme", themeId);
    localStorage.setItem("orgeasy.chart.colorBy", colorBy);
  }, [themeId, colorBy]);
  useEffect(() => {
    saveLegendConfig(legendConfig);
  }, [legendConfig]);

  const RAIL_HINT_KEY = "orgeasy.chart.railHintSeen";
  /** Collapses the panel, showing a one-time hint the first time it happens this session. */
  const collapsePanel = () => {
    setPanelOpen(false);
    try {
      if (!sessionStorage.getItem(RAIL_HINT_KEY)) {
        sessionStorage.setItem(RAIL_HINT_KEY, "1");
        setRailHintOpen(true);
      }
    } catch {
      /* storage unavailable — skip the hint */
    }
  };
  useEffect(() => {
    if (!railHintOpen) return;
    const t = window.setTimeout(() => setRailHintOpen(false), 8000);
    return () => window.clearTimeout(t);
  }, [railHintOpen]);

  const compareScenario = workspace.scenarios.find((s) => s.id === compareId) ?? null;
  /** Sequential future-state phases a manual edit can be routed into. */
  const futurePhases = useMemo(() => listPhases(workspace.scenarios), [workspace.scenarios]);

  /**
   * Filters the canvas by delivery model, department, location, status, level
   * and span of control, re-rooting any orphaned cards. In group view the
   * chosen attribute is copied into `department` so the grouped layout can
   * arrange the same people by department or location instead of hierarchy.
   */
  const applyChartFilters = (s: typeof scenario) => {
    if (!s) return s;
    const levels = new Map<string, number>();
    const byId = new Map(s.employees.map((e) => [e.id, e]));
    const levelOf = (id: string, guard = new Set<string>()): number => {
      if (levels.has(id)) return levels.get(id)!;
      if (guard.has(id)) return 0;
      guard.add(id);
      const mid = byId.get(id)?.managerId ?? null;
      const level = mid ? levelOf(mid, guard) + 1 : 0;
      levels.set(id, level);
      return level;
    };
    const spans = new Map<string, number>();
    for (const e of s.employees)
      if (e.managerId) spans.set(e.managerId, (spans.get(e.managerId) ?? 0) + 1);

    const kept = s.employees.filter((e) => {
      if (roleTypeFilter !== "all" && roleTypeOf(e) !== roleTypeFilter) return false;
      if (deptFilter !== "all" && (e.department || "Unassigned") !== deptFilter) return false;
      if (locationFilter !== "all" && (e.country || "Unassigned") !== locationFilter) return false;
      if (statusFilter === "vacant" && !(e.isOpenRole || !e.name)) return false;
      if (statusFilter !== "all" && statusFilter !== "vacant" && e.status !== statusFilter)
        return false;
      if (levelFilter !== "all" && levelOf(e.id) > Number(levelFilter)) return false;
      if (minSpan > 0 && (spans.get(e.id) ?? 0) < minSpan) return false;
      return true;
    });
    const keptIds = new Set(kept.map((e) => e.id));
    const employees = kept.map((e) => ({
      ...e,
      department: groupBy === "country" ? e.country || "Unassigned" : e.department,
      managerId: e.managerId && keptIds.has(e.managerId) ? e.managerId : null,
      dottedManagerIds: (e.dottedManagerIds ?? []).filter((id) => keptIds.has(id)),
    }));
    return { ...s, employees };
  };

  /** Group view swaps the hierarchy layout for grouped columns. */
  const effectiveLayout: LayoutKind = groupBy === "none" ? layout : "department";

  const canvasScenario = useMemo(
    () => {
      const filteredScenario = applyChartFilters(scenario);
      if (!filteredScenario) return filteredScenario;
      const capped = capHierarchy(filteredScenario.employees);
      return capped.truncated
        ? { ...filteredScenario, employees: capped.employees }
        : filteredScenario;
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [scenario, roleTypeFilter, deptFilter, locationFilter, statusFilter, levelFilter, minSpan, groupBy],
  );
  /** How many cards the canvas had to leave out at enterprise scale. */
  const canvasTruncated = useMemo(
    () =>
      Math.max((applyChartFilters(scenario)?.employees.length ?? 0) - SCALE_LIMITS.canvasNodes, 0),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [scenario, roleTypeFilter, deptFilter, locationFilter, statusFilter, levelFilter, minSpan, groupBy],
  );
  const canvasCompareScenario = useMemo(
    () => {
      const filteredScenario = applyChartFilters(compareScenario);
      if (!filteredScenario) return filteredScenario;
      const capped = capHierarchy(filteredScenario.employees);
      return capped.truncated
        ? { ...filteredScenario, employees: capped.employees }
        : filteredScenario;
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [compareScenario, roleTypeFilter, deptFilter, locationFilter, statusFilter, levelFilter, minSpan, groupBy],
  );
  const departments = useMemo(
    () =>
      [...new Set((scenario?.employees ?? []).map((e) => e.department || "Unassigned"))].sort((a, b) =>
        a.localeCompare(b),
      ),
    [scenario],
  );
  const locations = useMemo(
    () =>
      [...new Set((scenario?.employees ?? []).map((e) => e.country || "Unassigned"))].sort((a, b) =>
        a.localeCompare(b),
      ),
    [scenario],
  );
  const activeFilterCount =
    (roleTypeFilter !== "all" ? 1 : 0) +
    (deptFilter !== "all" ? 1 : 0) +
    (locationFilter !== "all" ? 1 : 0) +
    (statusFilter !== "all" ? 1 : 0) +
    (levelFilter !== "all" ? 1 : 0) +
    (minSpan > 0 ? 1 : 0);
  const theme = getTheme(themeId);
  /**
   * Visual diff: compares the active scenario against the chosen comparison
   * scenario, or its own phase baseline when nothing is picked.
   */
  const diffBaseline = useMemo(
    () => compareScenario ?? resolveBaseline(workspace.scenarios, scenario ?? null),
    [compareScenario, workspace.scenarios, scenario],
  );
  const diffClasses = useMemo(() => {
    if (!diffMode || !scenario || !diffBaseline || diffBaseline.id === scenario.id)
      return new Map<string, DiffClass>();
    return diffClassMap(compareScenarios(diffBaseline, scenario));
  }, [diffMode, scenario, diffBaseline]);
  const diffCounts = useMemo(() => {
    const counts: Record<DiffClass, number> = {
      added: 0,
      removed: 0,
      moved: 0,
      changed: 0,
      unchanged: 0,
    };
    for (const e of scenario?.employees ?? []) {
      const cls = diffClasses.get(e.id) ?? (e.status === "to-be-removed" ? "removed" : "unchanged");
      counts[cls] += 1;
    }
    return counts;
  }, [scenario, diffClasses]);
  const diffActive = diffMode && Boolean(diffBaseline) && diffBaseline?.id !== scenario?.id;
  const legendSections = useMemo(
    () => buildLegend(scenario, legendConfig, theme, colorBy),
    [scenario, legendConfig, theme, colorBy],
  );
  const selected = useMemo(
    () => scenario?.employees.find((e) => e.id === selectedId) ?? null,
    [scenario, selectedId],
  );
  const costRates = useCostAssumptions();
  const selectedCost = useMemo(
    () =>
      selected
        ? roleCost(selected, "planned", costRates, agentMonthly)
        : roleCost(
            {
              id: "",
              name: "",
              isOpenRole: true,
              title: "",
              department: "",
              country: "",
              responsibilities: "",
              currentHeadcount: 0,
              plannedHeadcount: 0,
              employmentType: "Full-time",
              managerId: null,
              status: "current",
              currentCost: 0,
              plannedCost: 0,
              serviceMonths: 0,
            },
            "planned",
            costRates,
            agentMonthly,
          ),
    [selected, costRates, agentMonthly],
  );

  /** Applies a roster change to any scenario, with one-step undo/redo. */
  const applyToScenario = (
    scenarioId: string,
    label: string,
    apply: (employees: Employee[]) => Employee[],
  ) => {
    const target = workspace.scenarios.find((s) => s.id === scenarioId);
    if (!target) return false;
    const before = target.employees;
    const after = apply(before);
    mutateScenarioEmployees(scenarioId, () => after);
    history.push({
      label,
      redo: () => mutateScenarioEmployees(scenarioId, () => after),
      undo: () => mutateScenarioEmployees(scenarioId, () => before),
    });
    return true;
  };

  /**
   * Manual chart edits never touch the current state — that is the baseline
   * every phase is compared against. Edits made there are routed into a future
   * phase (existing or newly created); edits in a future phase either apply
   * straight away or, for removals, ask how far down the phase plan they go.
   */
  const requestStructuralChange = (change: StructuralChange): "applied" | "pending" => {
    const current = scenarioRef.current;
    if (!current) return "pending";
    if (isCurrentState(current) || change.askScope) {
      setTargetPhaseId(futurePhases[0]?.id ?? "new");
      setChangeScopeLater(false);
      setPendingChange(change);
      return "pending";
    }
    applyToScenario(current.id, change.verb, change.apply);
    change.after?.();
    return "applied";
  };

  /** Adds a new open role straight onto the canvas, undoable in one step. */
  const addRole = (managerId: string | null) => {
    const current = scenarioRef.current;
    if (!current) return;
    const manager = managerId ? current.employees.find((e) => e.id === managerId) : null;
    const role: Employee = {
      ...emptyEmployee(),
      managerId: manager?.id ?? null,
      department: manager?.department ?? "",
      country: manager?.country ?? "United States",
      title: manager ? "New role" : "New top-level role",
    };
    const result = requestStructuralChange({
      verb: "new role",
      summary: manager
        ? `Add a new open role under “${manager.title}”.`
        : "Add a new top-level role.",
      askScope: false,
      apply: (emps) => [...emps, role],
      after: () => setSelectedId(role.id),
    });
    if (result !== "applied") return;
    toast.success(
      manager ? `New role added under ${manager.title}` : "New top-level role added",
      { description: "Rename it and set headcount in the Selected role panel." },
    );
  };

  /** Removes a role; its direct reports move up to its manager. */
  const deleteRole = (id: string) => {
    const current = scenarioRef.current;
    const role = current?.employees.find((e) => e.id === id);
    if (!current || !role) return;
    const kids = current.employees.filter((e) => e.managerId === id).length;
    const parentTitle = role.managerId
      ? (current.employees.find((e) => e.id === role.managerId)?.title ?? "the top of the chart")
      : "the top of the chart";
    requestStructuralChange({
      verb: "role removal",
      summary:
        `Remove “${role.title}”.` +
        (kids
          ? ` Its ${kids} direct report${kids === 1 ? "" : "s"} move up to ${parentTitle}.`
          : ""),
      askScope: true,
      apply: (emps) => {
        const target = emps.find((e) => e.id === id);
        if (!target) return emps;
        return emps
          .filter((e) => e.id !== id)
          .map((e) => (e.managerId === id ? { ...e, managerId: target.managerId ?? null } : e))
          .map((e) =>
            (e.dottedManagerIds ?? []).includes(id)
              ? { ...e, dottedManagerIds: e.dottedManagerIds!.filter((m) => m !== id) }
              : e,
          );
      },
      after: () => {
        if (selectedId === id) setSelectedId(role.managerId ?? null);
      },
    });
  };

  const resizeNode = (id: string, size: { w: number; h: number } | null) => {
    const before = scenarioRef.current?.nodeSizes?.[id] ?? null;
    const same =
      (before === null && size === null) ||
      (before && size && before.w === size.w && before.h === size.h);
    if (same) return;
    setNodeSize(id, size);
    history.push({
      label: size ? "card resize" : "card size reset",
      redo: () => setNodeSize(id, size),
      undo: () => setNodeSize(id, before),
    });
  };

  /** Saves a title / person name typed straight onto a card. */
  const renameRole = (id: string, patch: { title?: string; name?: string }) => {
    const role = scenarioRef.current?.employees.find((e) => e.id === id);
    if (!role) return;
    requestStructuralChange({
      verb: patch.title !== undefined ? "role title change" : "person change",
      summary:
        patch.title !== undefined
          ? `Rename “${role.title}” to “${patch.title}”.`
          : `Update the person in “${role.title}”.`,
      askScope: false,
      apply: (emps) =>
        emps.map((e) =>
          e.id === id
            ? {
                ...e,
                ...(patch.title !== undefined ? { title: patch.title } : {}),
                ...(patch.name !== undefined
                  ? { name: patch.name, isOpenRole: patch.name.trim().length === 0 }
                  : {}),
              }
            : e,
        ),
    });
  };

  const reparent = (childId: string, managerId: string | null) => {
    const current = scenarioRef.current;
    const child = current?.employees.find((e) => e.id === childId);
    if (!current || !child || child.managerId === managerId) return;
    let cursor = managerId;
    while (cursor) {
      if (cursor === childId) {
        toast.error("That would create a circular reporting line");
        return;
      }
      cursor = current.employees.find((e) => e.id === cursor)?.managerId ?? null;
    }
    const managerTitle = managerId
      ? (current.employees.find((e) => e.id === managerId)?.title ?? "another role")
      : "the top of the chart";
    const result = requestStructuralChange({
      verb: "reporting line change",
      summary: `Move “${child.title}” to report to ${managerTitle}.`,
      askScope: false,
      apply: (emps) => emps.map((e) => (e.id === childId ? { ...e, managerId } : e)),
    });
    if (result === "applied") toast.success("Reporting line updated");
  };

  const runUndo = () => {
    const label = history.undo();
    if (label) toast.success(`Undid ${label}`);
  };

  /** Stores the active scenario's card sizes, positions and reporting lines. */
  const copyLayout = () => {
    if (!scenario) return;
    const snapshot = captureLayout(scenario);
    saveLayoutSnapshot(snapshot);
    setLayoutClip(snapshot);
    toast.success(`Layout copied from “${scenario.name}” (${snapshot.entries.length} roles)`);
  };

  /** Re-applies a copied layout onto the active scenario, undoable in one step. */
  const pasteLayout = () => {
    const current = scenarioRef.current;
    if (!current || !layoutClip) return;
    if (!applyOptions.sizes && !applyOptions.positions && !applyOptions.managers) {
      toast.error("Pick at least one thing to apply");
      return;
    }
    const before = {
      employees: current.employees,
      positions: current.positions ?? {},
      nodeSizes: current.nodeSizes ?? {},
    };
    const result = applyLayout(current, layoutClip, applyOptions);
    if (!result.matched) {
      toast.error("No matching roles found in this scenario");
      return;
    }
    const write = (state: {
      employees: typeof before.employees;
      positions: typeof before.positions;
      nodeSizes: typeof before.nodeSizes;
    }) => {
      replaceEmployees(state.employees);
      updateScenario({ positions: state.positions, nodeSizes: state.nodeSizes });
    };
    write(result);
    history.push({
      label: "layout apply",
      redo: () => write(result),
      undo: () => write(before),
    });
    toast.success(
      `Layout applied to ${result.matched} of ${result.total} roles` +
        (applyOptions.managers ? ` · ${result.managerChanges} reporting lines updated` : "") +
        (result.skipped ? ` · ${result.skipped} skipped (would loop)` : ""),
    );
  };

  const runRedo = () => {
    const label = history.redo();
    if (label) toast.success(`Redid ${label}`);
  };

  // A fresh scenario has its own resize/reparent history.
  useEffect(() => {
    history.reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scenario?.id]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (!(event.metaKey || event.ctrlKey) || event.key.toLowerCase() !== "z") {
        if (!((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "y")) return;
      }
      const target = event.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.isContentEditable)
      )
        return;
      event.preventDefault();
      if (event.key.toLowerCase() === "y" || event.shiftKey) runRedo();
      else runUndo();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const toggleDotted = (childId: string, managerId: string) => {
    const current = scenarioRef.current;
    const child = current?.employees.find((e) => e.id === childId);
    if (!current || !child || childId === managerId) return;
    if (child.managerId === managerId) {
      toast.error("That role already reports solid line to this manager");
      return;
    }
    const existing = (child.dottedManagerIds ?? []).includes(managerId);
    const result = requestStructuralChange({
      verb: "dotted line change",
      summary: existing
        ? `Remove the dotted (secondary) reporting line from “${child.title}”.`
        : `Add a dotted (secondary) reporting line for “${child.title}”.`,
      askScope: false,
      apply: (emps) =>
        emps.map((e) =>
          e.id === childId
            ? {
                ...e,
                dottedManagerIds: existing
                  ? (e.dottedManagerIds ?? []).filter((m) => m !== managerId)
                  : [...(e.dottedManagerIds ?? []), managerId],
              }
            : e,
        ),
    });
    if (result === "applied")
      toast.success(existing ? "Dotted line removed" : "Dotted-line reporting added");
  };

  /** Restyles or removes a connector the user clicked on the canvas. */
  const changeLine = (childId: string, managerId: string, action: "solid" | "dotted" | "remove") => {
    const current = scenarioRef.current;
    const child = current?.employees.find((e) => e.id === childId);
    if (!current || !child) return;
    const managerTitle =
      current.employees.find((e) => e.id === managerId)?.title ?? "that manager";
    const isDotted = (child.dottedManagerIds ?? []).includes(managerId);
    let summary: string;
    let apply: (employees: Employee[]) => Employee[];
    if (action === "solid") {
      summary = `“${child.title}” now reports solid line to “${managerTitle}”.`;
      apply = (emps) =>
        emps.map((e) =>
          e.id === childId
            ? {
                ...e,
                managerId,
                dottedManagerIds: (e.dottedManagerIds ?? []).filter((m) => m !== managerId),
              }
            : e,
        );
    } else if (action === "dotted") {
      summary = `“${child.title}” → “${managerTitle}” is now a dotted line.`;
      apply = (emps) =>
        emps.map((e) => {
          if (e.id !== childId || e.managerId !== managerId) return e;
          // Keep a primary line: promote an existing dotted manager when one
          // exists, otherwise the role becomes top-level with a dotted link.
          const promote = (e.dottedManagerIds ?? []).find((m) => m !== managerId) ?? null;
          const dotted = new Set(e.dottedManagerIds ?? []);
          dotted.add(managerId);
          if (promote) dotted.delete(promote);
          return { ...e, managerId: promote, dottedManagerIds: [...dotted] };
        });
    } else {
      summary = isDotted
        ? `Removed the dotted line “${managerTitle}” → “${child.title}”.`
        : `Removed the reporting line into “${child.title}” — it is now top-level.`;
      apply = (emps) =>
        emps.map((e) =>
          e.id === childId
            ? isDotted
              ? { ...e, dottedManagerIds: (e.dottedManagerIds ?? []).filter((m) => m !== managerId) }
              : { ...e, managerId: null }
            : e,
        );
    }
    const result = requestStructuralChange({
      verb: "reporting line change",
      summary,
      askScope: false,
      apply,
    });
    if (result === "applied") toast.success(summary);
  };

  /** Applies the pending structural edit to the chosen phase(s). */
  const confirmStructuralChange = () => {
    const change = pendingChange;
    const current = scenarioRef.current;
    if (!change || !current) return;
    setPendingChange(null);
    if (isCurrentState(current)) {
      if (targetPhaseId === "new") {
        const order = nextPhaseOrder(workspace.scenarios);
        const after = change.apply(current.employees);
        createScenarioWithEmployees(`Future State — Phase ${order}`, after, {
          kind: "future",
          phaseOrder: order,
          phaseLabel: `Phase ${order}`,
          baselineId: current.id,
        });
        change.after?.();
        toast.success(`Applied in a new future phase (Phase ${order})`, {
          description: "The current state baseline was left untouched.",
        });
        return;
      }
      const target = workspace.scenarios.find((s) => s.id === targetPhaseId);
      if (!target) return;
      const later =
        change.askScope && changeScopeLater ? laterPhases(workspace.scenarios, target.id) : [];
      for (const s of [target, ...later]) applyToScenario(s.id, change.verb, change.apply);
      setActiveScenario(target.id);
      change.after?.();
      toast.success(
        `Applied to ${phaseTitle(target)}${later.length ? ` and ${later.length} later phase${later.length === 1 ? "" : "s"}` : ""}`,
        { description: "The current state baseline was left untouched." },
      );
      return;
    }
    const later =
      change.askScope && changeScopeLater ? laterPhases(workspace.scenarios, current.id) : [];
    for (const s of [current, ...later]) applyToScenario(s.id, change.verb, change.apply);
    change.after?.();
    toast.success(
      later.length
        ? `Applied to this phase and ${later.length} later phase${later.length === 1 ? "" : "s"}`
        : change.summary,
    );
  };

  const exportPng = async () => {
    const el = wrapRef.current?.querySelector<HTMLElement>(".react-flow__viewport");
    if (!el) return;
    const { toPng } = await import("html-to-image");
    const darkTheme = themeId === "midnight" || themeId === "obsidian";
    const dataUrl = await toPng(el, {
      backgroundColor:
        themeId === "midnight" ? "#0B1120" : themeId === "obsidian" ? "#081A1A" : "#ffffff",
      pixelRatio: 2,
    });
    const withLegend = legendSections.length
      ? await composeLegendOnImage(dataUrl, legendSections, themeId)
      : dataUrl;
    const a = document.createElement("a");
    a.href = withLegend;
    a.download = `${scenario?.name ?? "org-chart"}.png`;
    a.click();
    toast.success("Chart image downloaded");
  };

  /** Stamps the legend band above the exported chart image. */
  async function composeLegendOnImage(
    dataUrl: string,
    sections: ReturnType<typeof buildLegend>,
    themeId: string,
  ) {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = reject;
      image.src = dataUrl;
    });
    const s = Math.max(1, Math.min(3, img.width / 1400));
    const legendWidth = Math.min(img.width / s - 40, Math.max(520, (img.width / s) * 0.6));
    const probe = document.createElement("canvas").getContext("2d");
    if (!probe) return dataUrl;
    const legendHeight = drawLegend(probe, sections, { x: 0, y: 0, maxWidth: legendWidth });
    const bandHeight = Math.round((legendHeight + 32) * s);

    const canvas = document.createElement("canvas");
    canvas.width = img.width;
    canvas.height = img.height + bandHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return dataUrl;
    const bg =
      themeId === "midnight" ? "#0B1120" : themeId === "obsidian" ? "#081A1A" : "#ffffff";
    const dark = themeId === "midnight" || themeId === "obsidian";
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.scale(s, s);
    drawLegend(ctx, sections, {
      x: 20,
      y: 12,
      maxWidth: legendWidth,
      textColor: dark ? (themeId === "obsidian" ? "#E7F0F0" : "#E9EFF9") : "#0f172a",
      mutedColor: dark ? (themeId === "obsidian" ? "#9BBDBD" : "#93A4BD") : "#64748b",
      surface: dark ? (themeId === "obsidian" ? "#0F2626" : "#131D30") : "#F8FAFC",
      border: dark ? (themeId === "obsidian" ? "#3A5F5F" : "#3f5170") : "#CBD5E1",
    });
    ctx.restore();
    ctx.drawImage(img, 0, bandHeight);
    return canvas.toDataURL("image/png");
  }

  const uploadPhoto = async (file: File | undefined) => {
    if (!file || !selected) return;
    try {
      const photoUrl = await fileToAvatarDataUrl(file);
      upsertEmployee({ ...selected, photoUrl });
      toast.success("Photo added");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not read that image");
    }
  };

  function CollapsibleSection({
    title,
    open,
    onToggle,
    children,
    id,
  }: {
    title: string;
    open: boolean;
    onToggle: () => void;
    children: React.ReactNode;
    id?: string;
  }) {
    return (
      <div className="overflow-hidden rounded-lg border border-border">
        <button
          type="button"
          onClick={onToggle}
          className="flex w-full items-center justify-between gap-2 bg-secondary/40 px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-widest text-muted-foreground transition-colors hover:bg-secondary/70"
          aria-expanded={open}
          aria-controls={id}
        >
          <span>{title}</span>
          {open ? <ChevronUp className="size-3.5" /> : <ChevronDown className="size-3.5" />}
        </button>
        <div
          id={id}
          className={cn(
            "overflow-hidden transition-all duration-200",
            open ? "max-h-[800px] opacity-100" : "max-h-0 opacity-0",
          )}
        >
          <div className="space-y-3 p-3">{children}</div>
        </div>
      </div>
    );
  }

  /** Adds a new AI-agent role straight onto the canvas, undoable in one step. */
  const addAgentRole = (managerId: string | null) => {
    const current = scenarioRef.current;
    if (!current) return;
    const manager = managerId ? current.employees.find((e) => e.id === managerId) : null;
    const role: Employee = {
      ...emptyEmployee(),
      managerId: manager?.id ?? null,
      department: manager?.department ?? "",
      country: manager?.country ?? "United States",
      title: manager ? "New AI agent" : "New top-level AI agent",
      roleType: "agent",
    };
    const result = requestStructuralChange({
      verb: "new AI agent",
      summary: manager
        ? `Add a new AI-agent role under “${manager.title}”.`
        : "Add a new top-level AI-agent role.",
      askScope: false,
      apply: (emps) => [...emps, role],
      after: () => setSelectedId(role.id),
    });
    if (result !== "applied") return;
    toast.success(manager ? `AI agent added under ${manager.title}` : "Top-level AI agent added", {
      description: "Set its monthly running cost in the Selected role panel.",
    });
  };

  // Live model metrics for the studio top bar (the pop-out window keeps the
  // on-canvas strip instead).
  const liveModel = useMemo(() => {
    if (popout || !scenario) return null;
    const active = scenario.employees.filter((e) => e.status !== "to-be-removed");
    if (!active.length) return null;
    const spans = analyseSpans(scenario);
    const cost = computeCostModel(scenario.employees);
    let fte = 0;
    let agentFte = 0;
    let dotted = 0;
    for (const e of active) {
      const f = Math.max(e.plannedHeadcount || e.currentHeadcount || 0, 0);
      fte += f;
      const t = roleTypeOf(e);
      agentFte += t === "agent" ? f : t === "hybrid" ? f * HYBRID_AGENT_SHARE : 0;
      dotted += (e.dottedManagerIds ?? []).length;
    }
    return {
      roles: active.length,
      fte,
      layers: spans.maxLayer,
      avgSpan: spans.avgSpan,
      wide: spans.wide.length,
      cost: cost.planned.total,
      agentShare: fte ? agentFte / fte : 0,
      dotted,
    };
  }, [scenario, popout]);

  /** Metrics strip portaled into the studio top bar. */
  const liveStrip = liveModel ? (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
      <span className="flex items-center gap-1.5 text-[9.5px] font-bold uppercase tracking-[0.14em] text-brand">
        <span className="relative flex size-1.5">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand opacity-60" />
          <span className="relative inline-flex size-1.5 rounded-full bg-brand" />
        </span>
        Live model
      </span>
      <span className="flex items-center gap-1.5" title="Active roles in this scenario">
        <Users className="size-3.5 text-muted-foreground" />
        <span className="text-[12.5px] font-semibold tabular-nums">
          {liveModel.roles.toLocaleString()}
        </span>
        <span className="text-[9px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
          Roles
        </span>
      </span>
      <span className="flex items-center gap-1.5" title="Planned full-time equivalents">
        <Activity className="size-3.5 text-muted-foreground" />
        <span className="text-[12.5px] font-semibold tabular-nums">
          {liveModel.fte.toLocaleString()}
        </span>
        <span className="text-[9px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
          FTE
        </span>
      </span>
      <span
        className="flex items-center gap-1.5"
        title={`Organisation depth — benchmark up to ${SPAN_BENCHMARK.maxLayers} layers`}
      >
        <Layers3
          className={cn(
            "size-3.5",
            liveModel.layers > SPAN_BENCHMARK.maxLayers ? "text-warning" : "text-muted-foreground",
          )}
        />
        <span className="text-[12.5px] font-semibold tabular-nums">{liveModel.layers}</span>
        <span className="text-[9px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
          Layers
        </span>
      </span>
      <span
        className="flex items-center gap-1.5"
        title={
          liveModel.wide
            ? `${liveModel.wide} manager${liveModel.wide === 1 ? "" : "s"} over ${SPAN_BENCHMARK.wideSpan} direct reports`
            : "Average direct reports per manager"
        }
      >
        <GitFork
          className={cn("size-3.5", liveModel.wide ? "text-warning" : "text-muted-foreground")}
        />
        <span className="text-[12.5px] font-semibold tabular-nums">
          {liveModel.avgSpan.toFixed(1)}
        </span>
        <span className="text-[9px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
          Avg span{liveModel.wide ? ` · ${liveModel.wide} wide` : ""}
        </span>
      </span>
      <span className="flex items-center gap-1.5" title="Total planned annual cost">
        <CircleDollarSign className="size-3.5 text-muted-foreground" />
        <span className="text-[12.5px] font-semibold tabular-nums">
          {liveModel.cost >= 1e9
            ? `$${(liveModel.cost / 1e9).toFixed(2)}B`
            : liveModel.cost >= 1e6
              ? `$${(liveModel.cost / 1e6).toFixed(1)}M`
              : `$${Math.round(liveModel.cost / 1e3)}K`}
        </span>
        <span className="text-[9px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
          / yr
        </span>
      </span>
      <span
        className="flex items-center gap-1.5"
        title="Share of planned capacity delivered by AI agents"
      >
        <Bot className="size-3.5 text-muted-foreground" />
        <span className="text-[12.5px] font-semibold tabular-nums">
          {Math.round(liveModel.agentShare * 100)}%
        </span>
        <span className="text-[9px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
          AI agent
        </span>
      </span>
      <span className="flex items-center gap-1.5" title="Dotted secondary reporting lines (matrix)">
        <Network className="size-3.5 text-muted-foreground" />
        <span className="text-[12.5px] font-semibold tabular-nums">{liveModel.dotted}</span>
        <span className="text-[9px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
          Matrix
        </span>
      </span>
    </div>
  ) : null;

  /**
   * Primary design controls. In the studio shell they portal into the top
   * bar; in the popped-out window they render inline in the pop-out header.
   */
  const designActions = (
    <>
      {!popout ? (
        <div className="relative">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(ev) => setSearchQuery(ev.target.value)}
            placeholder="Find a role or person"
            aria-label="Find a role or person on the chart"
            className="h-8 w-48 pl-8 text-[12.5px]"
          />
        </div>
      ) : null}
      <TooltipProvider delayDuration={200}>
        <div className="flex items-center gap-1 rounded-md border border-border bg-card p-0.5">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="size-8"
                disabled={!history.canUndo}
                onClick={runUndo}
                aria-label="Undo last chart change"
              >
                <Undo2 className="size-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              {history.canUndo
                ? `Undo ${history.nextUndoLabel} (Ctrl+Z)`
                : "Nothing to undo"}
            </TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="size-8"
                disabled={!history.canRedo}
                onClick={runRedo}
                aria-label="Redo chart change"
              >
                <Redo2 className="size-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              {history.canRedo
                ? `Redo ${history.nextRedoLabel} (Ctrl+Shift+Z)`
                : "Nothing to redo"}
            </TooltipContent>
          </Tooltip>
        </div>
      </TooltipProvider>
      <Button size="sm" onClick={() => addRole(null)}>
        <UserPlus className="mr-1.5 size-3.5" /> Add role
      </Button>
      <Button size="sm" variant="outline" onClick={() => addAgentRole(null)}>
        <Bot className="mr-1.5 size-3.5" /> Add AI agent
      </Button>
      <div className="mx-0.5 h-6 w-px bg-border" />
      <Select value={compareId} onValueChange={setCompareId}>
        <SelectTrigger className="h-8 w-40 text-[12.5px]">
          <SelectValue placeholder="Compare with…" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="none">Single view</SelectItem>
          {workspace.scenarios
            .filter((s) => s.id !== scenario?.id)
            .map((s) => (
              <SelectItem key={s.id} value={s.id}>
                Compare: {s.name}
              </SelectItem>
            ))}
        </SelectContent>
      </Select>
      <Button
        size="sm"
        variant={diffMode ? "default" : "outline"}
        onClick={() => setDiffMode((v) => !v)}
        title={
          diffBaseline
            ? `Colour cards by change vs “${diffBaseline.name}”`
            : "No baseline scenario found to compare against"
        }
      >
        <GitCompare className="mr-1.5 size-3.5" /> Visual diff
      </Button>
      <Popover>
        <PopoverTrigger asChild>
          <Button size="sm" variant={activeFilterCount ? "default" : "outline"}>
            <SlidersHorizontal className="mr-1.5 size-3.5" /> Filters
            {activeFilterCount ? (
              <span className="ml-1.5 rounded-full bg-background/25 px-1.5 text-[11px] font-bold">
                {activeFilterCount}
              </span>
            ) : null}
          </Button>
        </PopoverTrigger>
        <PopoverContent align="end" className="w-80 space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-[13px] font-semibold">Filter the chart</p>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 text-[12px]"
              onClick={() => {
                setRoleTypeFilter("all");
                setDeptFilter("all");
                setLocationFilter("all");
                setStatusFilter("all");
                setLevelFilter("all");
                setMinSpan(0);
              }}
            >
              Clear all
            </Button>
          </div>
          <div className="space-y-1.5">
            <Label className="text-[12px]">Department</Label>
            <Select value={deptFilter} onValueChange={setDeptFilter}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All departments</SelectItem>
                {departments.map((d) => (
                  <SelectItem key={d} value={d}>
                    {d}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-[12px]">Location</Label>
            <Select value={locationFilter} onValueChange={setLocationFilter}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All locations</SelectItem>
                {locations.map((l) => (
                  <SelectItem key={l} value={l}>
                    {l}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1.5">
              <Label className="text-[12px]">Status</Label>
              <Select
                value={statusFilter}
                onValueChange={(v) => setStatusFilter(v as typeof statusFilter)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any status</SelectItem>
                  <SelectItem value="vacant">Vacant / open roles</SelectItem>
                  <SelectItem value="current">Current</SelectItem>
                  <SelectItem value="planned">Planned</SelectItem>
                  <SelectItem value="moved">Moved</SelectItem>
                  <SelectItem value="to-be-removed">To be removed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-[12px]">Depth</Label>
              <Select
                value={levelFilter}
                onValueChange={(v) => setLevelFilter(v as typeof levelFilter)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All layers</SelectItem>
                  <SelectItem value="1">Top 2 layers</SelectItem>
                  <SelectItem value="2">Top 3 layers</SelectItem>
                  <SelectItem value="3">Top 4 layers</SelectItem>
                  <SelectItem value="4">Top 5 layers</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-[12px]">
              Minimum span of control {minSpan ? `(${minSpan}+ direct reports)` : "(off)"}
            </Label>
            <Input
              type="number"
              min={0}
              max={30}
              value={minSpan}
              onChange={(ev) => setMinSpan(Math.max(0, Number(ev.target.value) || 0))}
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-[12px]">Delivery model</Label>
            <Select
              value={roleTypeFilter}
              onValueChange={(v) => setRoleTypeFilter(v as "all" | RoleType)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All role types</SelectItem>
                {ROLE_TYPES.map((t) => (
                  <SelectItem key={t} value={t}>
                    Only {ROLE_TYPE_META[t].label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </PopoverContent>
      </Popover>
      <div className="mx-0.5 h-6 w-px bg-border" />
      {!popout ? <ChartImportDialog /> : null}
      <Button variant="outline" size="sm" onClick={exportPng}>
        <ImageDown className="mr-1.5 size-4" /> PNG
      </Button>
      {!popout ? (
        <>
          <Button
            variant="outline"
            size="sm"
            onClick={openPopoutCanvas}
          >
            <PictureInPicture2 className="mr-1.5 size-4" /> Pop out canvas
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="size-8"
            aria-label="Full screen"
            title="Full screen"
            onClick={() => setFullScreen(true)}
          >
            <Maximize2 className="size-4" />
          </Button>
        </>
      ) : null}
    </>
  );

  /**
   * View & overlay controls. In the studio shell they sit in a compact row
   * directly above the canvas; in the pop-out they join the header toolbar.
   */
  const overlayControls = (
    <>
      <span className="mr-0.5 text-[9.5px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
        View
      </span>
      <Select value={layout} onValueChange={(v) => setLayout(v as LayoutKind)}>
        <SelectTrigger className="h-8 w-40 text-[12.5px]">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {LAYOUT_OPTIONS.map((o) => (
            <SelectItem key={o.value} value={o.value}>
              {o.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Select value={themeId} onValueChange={setThemeId}>
        <SelectTrigger className="h-8 w-44 text-[12.5px]">
          <Palette className="mr-1 size-3.5 text-brand" />
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {CHART_THEMES.map((t) => (
            <SelectItem key={t.id} value={t.id}>
              <span className="flex items-center gap-2">
                <span className="flex">
                  {t.swatches.slice(0, 4).map((c) => (
                    <span
                      key={c}
                      className="-ml-0.5 size-2.5 rounded-full ring-1 ring-background first:ml-0"
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </span>
                {t.label}
              </span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Select value={colorBy} onValueChange={(v) => setColorBy(v as ColorBy)}>
        <SelectTrigger className="h-8 w-44 text-[12.5px]" disabled={diffActive}>
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {(["Category", "Measure"] as const).map((group) => (
            <div key={group}>
              <p className="px-2 py-1.5 text-[10.5px] font-semibold uppercase tracking-wider text-muted-foreground">
                {group === "Category" ? "Categories" : "Measures (heat ramp)"}
              </p>
              {COLOR_BY_OPTIONS.filter((o) => o.group === group).map((o) => (
                <SelectItem key={o.value} value={o.value}>
                  {o.label}
                </SelectItem>
              ))}
            </div>
          ))}
        </SelectContent>
      </Select>
      <Select value={groupBy} onValueChange={(v) => setGroupBy(v as typeof groupBy)}>
        <SelectTrigger className="h-8 w-40 text-[12.5px]">
          <LayoutGrid className="mr-1 size-3.5 text-brand" />
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="none">Hierarchy view</SelectItem>
          <SelectItem value="department">Group by department</SelectItem>
          <SelectItem value="country">Group by location</SelectItem>
        </SelectContent>
      </Select>
      <Popover>
        <PopoverTrigger asChild>
          <Button size="sm" variant="outline">
            <Eye className="mr-1.5 size-3.5 text-brand" /> Card fields
          </Button>
        </PopoverTrigger>
        <PopoverContent align="end" className="w-72 space-y-2.5">
          <p className="text-[13px] font-semibold">Show on each card</p>
          <p className="text-[12px] leading-relaxed text-muted-foreground">
            Vacant roles always show a dashed outline. High spans of control (9+) are flagged
            in amber.
          </p>
          {CARD_FIELD_LABELS.map(([key, label]) => (
            <label key={key} className="flex cursor-pointer items-center gap-2.5 text-[13px]">
              <Checkbox
                checked={cardFields[key]}
                onCheckedChange={(v) =>
                  setCardFields((prev) => ({ ...prev, [key]: Boolean(v) }))
                }
              />
              {label}
            </label>
          ))}
        </PopoverContent>
      </Popover>
      <Popover>
        <PopoverTrigger asChild>
          <Button size="sm" variant="outline">
            <List className="mr-1.5 size-3.5 text-brand" /> Legend
          </Button>
        </PopoverTrigger>
        <PopoverContent align="end" className="w-72 space-y-3">
          <p className="text-[13px] font-semibold">Legend</p>
          <p className="text-[12px] leading-relaxed text-muted-foreground">
            Shown on the canvas and stamped into exported PNG, PowerPoint and PDF.
          </p>
          {(
            [
              ["show", "Show legend"],
              ["status", "Status"],
              ["employmentType", "Employment type"],
              ["openRole", "Open role vs named"],
              ["roleScope", "Role scope (global / regional / local)"],
              ["unitKind", "CoE & GBS centres"],
              ["dottedLine", "Solid vs dotted reporting lines"],
            ] as [keyof LegendConfig, string][]
          ).map(([key, label]) => (
            <label
              key={key}
              className="flex cursor-pointer items-center gap-2.5 text-[13px]"
            >
              <Checkbox
                checked={legendConfig[key]}
                disabled={key !== "show" && !legendConfig.show}
                onCheckedChange={(v) =>
                  setLegendConfig((prev) => ({ ...prev, [key]: Boolean(v) }))
                }
              />
              <span className={key === "show" ? "font-medium" : ""}>{label}</span>
            </label>
          ))}
        </PopoverContent>
      </Popover>
      <Popover>
        <PopoverTrigger asChild>
          <Button size="sm" variant="outline">
            <ClipboardCopy className="mr-1.5 size-3.5 text-brand" /> Layout
          </Button>
        </PopoverTrigger>
        <PopoverContent align="end" className="w-80 space-y-3">
          <p className="text-[13px] font-semibold">Reuse layout across scenarios</p>
          <p className="text-[12px] leading-relaxed text-muted-foreground">
            Copy the card sizes, canvas positions and manager structure from this
            scenario, then apply them to another. Roles are matched by name and title.
          </p>
          <Button className="w-full" onClick={copyLayout} disabled={!scenario}>
            <ClipboardCopy className="mr-1.5 size-4" /> Copy layout from this scenario
          </Button>
          <div className="space-y-2 rounded-lg border border-border bg-muted/40 p-2.5">
            {layoutClip ? (
              <>
                <p className="text-[12px] font-medium">
                  Copied: {layoutClip.scenarioName}
                </p>
                <p className="text-[11px] text-muted-foreground">
                  {layoutClip.entries.length} roles ·{" "}
                  {new Date(layoutClip.copiedAt).toLocaleString()}
                  {scenario
                    ? ` · ${countMatches(scenario, layoutClip)} match here`
                    : ""}
                </p>
                {(
                  [
                    ["sizes", "Card sizes"],
                    ["positions", "Canvas positions"],
                    ["managers", "Manager structure (solid & dotted)"],
                  ] as [keyof ApplyLayoutOptions, string][]
                ).map(([key, label]) => (
                  <label
                    key={key}
                    className="flex cursor-pointer items-center gap-2.5 text-[13px]"
                  >
                    <Checkbox
                      checked={applyOptions[key]}
                      onCheckedChange={(v) =>
                        setApplyOptions((prev) => ({ ...prev, [key]: Boolean(v) }))
                      }
                    />
                    {label}
                  </label>
                ))}
                <div className="flex gap-2 pt-1">
                  <Button
                    className="flex-1"
                    variant="secondary"
                    onClick={pasteLayout}
                    disabled={layoutClip.scenarioId === scenario?.id}
                  >
                    <ClipboardPaste className="mr-1.5 size-4" /> Apply layout
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label="Clear copied layout"
                    onClick={() => {
                      clearLayoutSnapshot();
                      setLayoutClip(null);
                    }}
                  >
                    <Trash2 className="size-4" />
                  </Button>
                </div>
                {layoutClip.scenarioId === scenario?.id ? (
                  <p className="text-[11px] text-muted-foreground">
                    Switch to another scenario to apply this layout.
                  </p>
                ) : null}
              </>
            ) : (
              <p className="text-[12px] text-muted-foreground">
                Nothing copied yet. Copy a layout, switch scenario, then apply it.
              </p>
            )}
          </div>
        </PopoverContent>
      </Popover>
      <Popover open={resetMenuOpen} onOpenChange={setResetMenuOpen}>
        <PopoverTrigger asChild>
          <Button size="sm" variant="outline">
            <RotateCcw className="mr-1.5 size-3.5" /> Reset
          </Button>
        </PopoverTrigger>
        <PopoverContent align="end" className="w-80">
          <div className="space-y-3">
            <div>
              <p className="text-[12px] font-medium">Reset this scenario</p>
              <p className="text-[11px] text-muted-foreground">
                Choose exactly what goes back to its original state — data and layout are
                reset separately.
              </p>
            </div>
            <div className="space-y-2 rounded-lg border border-border p-2.5">
              <p className="text-[12px] font-medium">Org chart data only</p>
              <p className="text-[11px] text-muted-foreground">
                Restores original roles, names, headcount and costs. Keeps your node positions,
                card sizes and manually drawn reporting lines.
              </p>
              <Button
                size="sm"
                variant="secondary"
                className="w-full"
                onClick={() => askReset("data")}
              >
                Reset data, keep layout &amp; lines
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="w-full"
                onClick={() => askReset("data-links")}
              >
                Reset data &amp; reporting lines
              </Button>
            </div>
            <div className="space-y-2 rounded-lg border border-border p-2.5">
              <p className="text-[12px] font-medium">Layout only</p>
              <p className="text-[11px] text-muted-foreground">
                Clears saved node positions and card sizes so auto-layout takes over. Your
                roles and structure stay exactly as they are.
              </p>
              <Button
                size="sm"
                variant="secondary"
                className="w-full"
                onClick={() => askReset("layout")}
              >
                Reset positions &amp; card sizes
              </Button>
            </div>
          </div>
        </PopoverContent>
      </Popover>
    </>
  );

  return (
    <div
      className={cn(
        "flex flex-col",
        fullScreen
          ? "fixed inset-0 z-50 h-screen bg-background"
          : popout
            ? "h-screen"
            : "h-full min-h-0",
      )}
    >
      {!popout && chrome.actionsEl ? createPortal(designActions, chrome.actionsEl) : null}
      {!popout && chrome.metricsEl && liveStrip ? createPortal(liveStrip, chrome.metricsEl) : null}
      {popout && !fullScreen ? (
      <header className="shrink-0 border-b border-border bg-background">
        <div className="flex items-center gap-3 border-b border-border/60 px-4 py-2">
          <Link to="/dashboard" className="flex min-w-0 items-center gap-2.5">
            <img
              src={orgeasyLogo}
              alt="Organisation Strategy Studio logo"
              width={32}
              height={32}
              className="size-8 shrink-0 rounded-lg"
            />
            <div className="min-w-0">
              <p className="truncate font-display text-[13px] font-semibold leading-tight tracking-tight">
                Organisation Strategy Studio
              </p>
              <p className="text-[9px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
                Org chart designer
              </p>
            </div>
          </Link>
          <div className="mx-1 h-6 w-px bg-border" />
          <Select value={scenario?.id ?? ""} onValueChange={setActiveScenario}>
            <SelectTrigger className="h-9 w-64 max-w-[40vw]">
              <SelectValue placeholder="Select scenario" />
            </SelectTrigger>
            <SelectContent>
              {workspace.scenarios.map((s) => (
                <SelectItem key={s.id} value={s.id}>
                  {scenarioLabel(s)} · {s.employees.length} roles
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="ml-auto flex items-center gap-2">
            <ChartImportDialog />
            {popout ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  // Popped-out window: hand back to the main app by focusing
                  // the opener and closing. Fall back to in-window navigation
                  // when there is no opener (e.g. opened from a bookmark).
                  if (window.opener && !window.opener.closed) {
                    window.opener.focus();
                    window.close();
                  } else {
                    void navigate({ to: "/chart" });
                  }
                }}
              >
                <ArrowLeft className="mr-1.5 size-4" /> Back to main app
              </Button>
            ) : (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={openPopoutCanvas}
                >
                  <PictureInPicture2 className="mr-1.5 size-4" /> Pop out canvas
                </Button>
                <Button asChild variant="outline" size="sm">
                  <Link to="/dashboard">
                    <ArrowLeft className="mr-1.5 size-4" /> Back to studio
                  </Link>
                </Button>
              </>
            )}
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2 px-4 py-2">
          {designActions}
          {overlayControls}
        </div>
      </header>
      ) : null}

      {!popout && !fullScreen ? (
        <div className="flex shrink-0 flex-wrap items-center gap-1.5 border-b border-border/60 bg-background px-3 py-1.5">
          {overlayControls}
        </div>
      ) : null}

      <AlertDialog
        open={pendingReset !== null}
        onOpenChange={(open) => {
          if (!open) setPendingReset(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {pendingReset === "layout"
                ? "Reset positions & card sizes?"
                : pendingReset === "data-links"
                  ? "Reset org chart data & reporting lines?"
                  : "Reset org chart data?"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {pendingReset === "layout" ? (
                <>
                  This clears every saved node position and card size in{" "}
                  <strong>{scenario?.name ?? "this scenario"}</strong> so auto-layout takes over. Your
                  roles, headcount and reporting structure stay exactly as they are. This cannot be
                  undone.
                </>
              ) : pendingReset === "data-links" ? (
                <>
                  This restores the original roles, names, headcount and costs in{" "}
                  <strong>{scenario?.name ?? "this scenario"}</strong> and discards every manual or
                  dotted reporting line you have drawn. Node positions are kept. A snapshot is saved
                  first, so you can revert from Version history.
                </>
              ) : (
                <>
                  This restores the original roles, names, headcount and costs in{" "}
                  <strong>{scenario?.name ?? "this scenario"}</strong>, discarding your edits. Node
                  positions, card sizes and manual reporting lines are kept. A snapshot is saved
                  first, so you can revert from Version history.
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep my changes</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                const kind = pendingReset;
                setPendingReset(null);
                if (kind === "layout") {
                  resetChartLayout();
                  toast.success("Canvas layout reset — org chart data untouched");
                  return;
                }
                const keepLinks = kind === "data";
                const ok = resetChartData({ keepLayout: true, keepLinks });
                toast[ok ? "success" : "error"](
                  ok
                    ? keepLinks
                      ? "Org chart data reset — positions and manual lines kept"
                      : "Org chart data and reporting lines reset — positions kept"
                    : "This scenario has no original dataset to restore",
                );
              }}
            >
              {pendingReset === "layout" ? "Reset layout" : "Reset data"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog
        open={pendingChange !== null}
        onOpenChange={(open) => {
          if (!open) setPendingChange(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {scenario && isCurrentState(scenario)
                ? "Keep the current state intact"
                : "Apply this change"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {pendingChange?.summary}
              {scenario && isCurrentState(scenario)
                ? " The current state is the baseline every phase is compared against, so manual edits are made in a future phase instead — the original structure stays untouched."
                : ""}
            </AlertDialogDescription>
          </AlertDialogHeader>
          {scenario && isCurrentState(scenario) ? (
            <div className="space-y-1.5">
              <Label className="text-[12px]">Apply in</Label>
              <Select value={targetPhaseId} onValueChange={setTargetPhaseId}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {futurePhases.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {phaseTitle(p)} — {p.name}
                    </SelectItem>
                  ))}
                  <SelectItem value="new">Create a new phase</SelectItem>
                </SelectContent>
              </Select>
            </div>
          ) : null}
          {pendingChange?.askScope &&
          (scenario && isCurrentState(scenario)
            ? targetPhaseId !== "new" &&
              laterPhases(workspace.scenarios, targetPhaseId).length > 0
            : laterPhases(workspace.scenarios, scenario?.id ?? "").length > 0) ? (
            <label className="flex cursor-pointer items-center gap-2.5 text-[13px]">
              <Checkbox
                checked={changeScopeLater}
                onCheckedChange={(v) => setChangeScopeLater(Boolean(v))}
              />
              Also apply to all later phases (
              {scenario && isCurrentState(scenario)
                ? laterPhases(workspace.scenarios, targetPhaseId).length
                : laterPhases(workspace.scenarios, scenario?.id ?? "").length}
              )
            </label>
          ) : null}
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmStructuralChange}>
              Apply change
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <div className="flex min-h-0 flex-1">
        <div ref={wrapRef} className="relative min-w-0 flex-1 border-r border-border">
          {canvasScenario ? (
            <OrgChartCanvas
              scenario={canvasScenario}
              layout={effectiveLayout}
              cardFields={cardFields}
              density={cardDensity}
              onDensityChange={(level) =>
                setCardFields({ ...CARD_DENSITY_PRESETS[level].fields })
              }
              selectedId={selectedId}
              onSelect={setSelectedId}
              onReparent={reparent}
              onDottedLink={toggleDotted}
              onLineChange={changeLine}
              onMove={setPosition}
              onResizeNode={(id, size) => resizeNode(id, size)}
              themeId={themeId}
              colorBy={colorBy}
              diffMode={diffActive}
              diffClasses={diffClasses}
              onAddChild={(managerId) => addRole(managerId)}
              onAddRoot={() => addRole(null)}
              onDeleteRole={deleteRole}
              onRename={renameRole}
              hideMetrics={!popout}
              searchValue={popout ? undefined : searchQuery}
              onSearchValueChange={popout ? undefined : setSearchQuery}
            />
          ) : null}
          {popout || fullScreen ? (
          <TooltipProvider delayDuration={200}>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="icon"
                  className="absolute right-4 top-3 z-20 size-9 rounded-lg border-border bg-card/95 shadow-panel backdrop-blur"
                  aria-label={fullScreen ? "Exit full screen" : "Full screen"}
                  onClick={() => setFullScreen((v) => !v)}
                >
                  {fullScreen ? (
                    <Minimize2 className="size-4" />
                  ) : (
                    <Maximize2 className="size-4" />
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent side="left">
                {fullScreen ? "Exit full screen (Esc)" : "Full screen"}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          ) : null}
          {canvasTruncated > 0 ? (
            <p className="pointer-events-none absolute right-4 top-3 z-10 max-w-xs rounded-md border border-border bg-card/95 px-2.5 py-1.5 text-[11.5px] text-muted-foreground shadow-panel backdrop-blur">
              Large organisation: showing the top {formatCount(SCALE_LIMITS.canvasNodes)} roles from
              the top of the house. {formatCount(canvasTruncated)} more are hidden — use filters or
              the People &amp; roles table to work deeper in the structure.
            </p>
          ) : null}
          {diffActive ? (
            <div className="pointer-events-none absolute bottom-4 left-4 z-10 space-y-1.5 rounded-xl border border-border bg-card/95 px-3.5 py-2.5 shadow-panel backdrop-blur">
              <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                Visual diff vs {diffBaseline?.name}
              </p>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                {(["added", "removed", "moved", "changed", "unchanged"] as DiffClass[]).map((k) => (
                  <span key={k} className="flex items-center gap-1.5 text-[11px]">
                    <span
                      className="size-2.5 rounded-full"
                      style={{ backgroundColor: `#${DIFF_CLASS_META[k].hex}` }}
                    />
                    {DIFF_CLASS_META[k].label}
                    <span className="font-semibold">{diffCounts[k]}</span>
                  </span>
                ))}
              </div>
            </div>
          ) : null}
          {legendSections.length ? (
            <div
              className={cn(
                "absolute left-4 top-16 z-10 rounded-xl border border-border bg-card/95 shadow-panel backdrop-blur transition-all",
                legendOpen ? "max-w-[74%] px-3.5 py-2.5" : "px-2 py-2",
              )}
            >
              <button
                type="button"
                onClick={() => setLegendOpen((v) => !v)}
                className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground"
                aria-expanded={legendOpen}
                aria-label={legendOpen ? "Hide colour legend" : "Show colour legend"}
              >
                <Palette className="size-3.5 text-brand" />
                <span className={cn("transition-opacity", legendOpen ? "opacity-100" : "opacity-0")}>
                  Colour coding
                </span>
                {legendOpen ? <ChevronUp className="size-3" /> : <ChevronDown className="size-3" />}
              </button>
              <div
                className={cn(
                  "overflow-hidden transition-all duration-200",
                  legendOpen ? "mt-2 max-h-[400px] opacity-100" : "max-h-0 opacity-0",
                )}
              >
                <div className="space-y-2">
                  {legendSections.map((section) => (
                    <div key={section.title} className="flex flex-wrap items-center gap-x-3 gap-y-1">
                      <span className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                        {section.title}
                      </span>
                      {section.items.map((item) => (
                        <span
                          key={item.label}
                          className="flex items-center gap-1.5 text-[11px] text-foreground"
                        >
                          <span
                            className="size-2.5 rounded-full"
                            style={
                              item.hollow
                                ? { border: `2px solid ${item.color}` }
                                : { backgroundColor: item.color }
                            }
                          />
                          {item.label}
                        </span>
                      ))}
                    </div>
                  ))}
                  {colorBy !== "status" ? (
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                      <span className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                        {COLOR_BY_OPTIONS.find((o) => o.value === colorBy)?.label} · {theme.label}
                      </span>
                      {theme.swatches.map((c) => (
                        <span
                          key={c}
                          className="size-2.5 rounded-full"
                          style={{ backgroundColor: c }}
                        />
                      ))}
                    </div>
                  ) : null}
                </div>
              </div>
            </div>
          ) : null}

        </div>

        {canvasCompareScenario && compareScenario ? (
          <div className="relative min-w-0 flex-1">
            <p className="absolute left-4 top-3 z-10 inline-flex items-center gap-1.5 rounded-md border border-border bg-card px-2.5 py-1 text-[11.5px] font-semibold shadow-panel">
              <Columns2 className="size-3.5 text-brand" />
              {compareScenario.name}
            </p>
            <OrgChartCanvas
              scenario={canvasCompareScenario}
              layout={effectiveLayout}
              cardFields={cardFields}
              selectedId={null}
              onSelect={() => {}}
              showViewTools={false}
              themeId={themeId}
              colorBy={colorBy}
            />
          </div>
        ) : (
          <aside
            className={cn(
              "relative shrink-0 overflow-hidden border-l border-border bg-card transition-[width] duration-300 ease-in-out motion-reduce:transition-none",
              panelOpen ? "w-80" : "w-12",
            )}
          >
            <div
              className={cn(
                "absolute inset-x-0 top-0 flex flex-col items-center gap-2 py-3 transition-opacity duration-200",
                panelOpen ? "pointer-events-none opacity-0" : "opacity-100 delay-150",
              )}
            >
              <Popover open={railHintOpen} onOpenChange={setRailHintOpen}>
                <TooltipProvider delayDuration={200}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <PopoverTrigger asChild>
                        <button
                          type="button"
                          aria-label="Expand selected role panel"
                          onClick={() => {
                            setRailHintOpen(false);
                            setPanelOpen(true);
                          }}
                          className="flex flex-col items-center gap-2 rounded-md px-1 py-2 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
                        >
                          <ChevronLeft className="size-4" />
                          <span className="mt-1 whitespace-nowrap text-[10px] font-semibold uppercase tracking-widest [writing-mode:vertical-rl]">
                            Selected role
                          </span>
                        </button>
                      </PopoverTrigger>
                    </TooltipTrigger>
                    <TooltipContent side="left" className="max-w-56">
                      <p className="text-[12px] font-semibold">Selected role panel</p>
                      <p className="mt-1 text-[11.5px] leading-relaxed text-muted-foreground">
                        Expand to inspect the role you click on the canvas — status, department,
                        headcount and cost deltas, photo and responsibilities.
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                <PopoverContent side="left" align="start" className="w-72 space-y-2">
                  <p className="text-[11px] font-semibold uppercase tracking-widest text-brand">
                    Panel tucked away
                  </p>
                  <p className="text-[13px] font-semibold leading-snug">
                    The Selected role rail lives here
                  </p>
                  <p className="text-[12px] leading-relaxed text-muted-foreground">
                    Click a card on the canvas any time, then use this rail to reopen the panel and
                    review status, department, headcount and cost deltas, photo and
                    responsibilities.
                  </p>
                  <Button
                    size="sm"
                    variant="outline"
                    className="w-full"
                    onClick={() => setRailHintOpen(false)}
                  >
                    Got it
                  </Button>
                </PopoverContent>
              </Popover>
            </div>
            <div
              className={cn(
                "h-full w-80 overflow-y-auto p-5 transition-opacity duration-200",
                panelOpen ? "opacity-100 delay-150" : "pointer-events-none opacity-0",
              )}
              aria-hidden={!panelOpen}
            >
            <div className="mb-3 flex items-center justify-between gap-2">
              <p className="text-[11px] font-semibold uppercase tracking-widest text-brand">
                Selected role
              </p>
              <Button
                size="icon"
                variant="ghost"
                className="size-7"
                aria-label="Collapse selected role panel"
                title="Collapse selected role panel"
                aria-expanded={panelOpen}
                onClick={collapsePanel}
              >
                <ChevronRight className="size-4 transition-transform duration-300" />
              </Button>
            </div>
            {selected ? (
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  {selected.photoUrl ? (
                    <img
                      src={selected.photoUrl}
                      alt={selected.name || selected.title}
                      className="size-14 shrink-0 rounded-full object-cover ring-2 ring-brand/30"
                    />
                  ) : null}
                  <div className="min-w-0">
                    <h2 className="text-lg font-semibold leading-tight">
                      {selected.name || "Open Role"}
                    </h2>
                    <p className="text-sm text-muted-foreground">{selected.title}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <input
                    ref={photoRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(ev) => {
                      void uploadPhoto(ev.target.files?.[0]);
                      ev.target.value = "";
                    }}
                  />
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1"
                    onClick={() => photoRef.current?.click()}
                  >
                    <ImagePlus className="mr-1.5 size-3.5" />
                    {selected.photoUrl ? "Replace photo" : "Add photo"}
                  </Button>
                  {selected.photoUrl ? (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        upsertEmployee({ ...selected, photoUrl: undefined });
                        toast.success("Photo removed");
                      }}
                    >
                      <Trash2 className="size-3.5" />
                    </Button>
                  ) : null}
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="secondary"
                    className="flex-1"
                    onClick={() => addRole(selected.id)}
                  >
                    <UserPlus className="mr-1.5 size-3.5" /> Add report
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 text-destructive hover:text-destructive"
                    onClick={() => deleteRole(selected.id)}
                  >
                    <Trash2 className="mr-1.5 size-3.5" /> Remove role
                  </Button>
                </div>
                <span
                  className={cn(
                    "inline-block rounded px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide",
                    STATUS_META[selected.status].className,
                  )}
                >
                  {STATUS_META[selected.status].label}
                </span>
                <CollapsibleSection
                  title="Status & role type"
                  id="role-status-section"
                  open={identityOpen}
                  onToggle={() => setIdentityOpen((v) => !v)}
                >
                  <div>
                    <Label className="text-[12px]">Role type</Label>
                    <Select
                      value={roleTypeOf(selected)}
                      onValueChange={(v) =>
                        upsertEmployee({ ...selected, roleType: v as RoleType })
                      }
                    >
                      <SelectTrigger className="mt-1 h-9">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {ROLE_TYPES.map((t) => (
                          <SelectItem key={t} value={t}>
                            {ROLE_TYPE_META[t].label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">
                      {ROLE_TYPE_META[roleTypeOf(selected)].description}
                    </p>
                  </div>
                  <div>
                    <Label className="text-[12px]">Transformation lever</Label>
                    <Select
                      value={selected.reductionLever ?? "headcount"}
                      onValueChange={(v) =>
                        upsertEmployee({ ...selected, reductionLever: v as ReductionLever })
                      }
                    >
                      <SelectTrigger className="mt-1 h-9">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {REDUCTION_LEVERS.map((l) => (
                          <SelectItem key={l} value={l}>
                            {LEVER_META[l].label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </CollapsibleSection>
                <CollapsibleSection
                  title="Structure & scope"
                  id="role-structure-section"
                  open={structureOpen}
                  onToggle={() => setStructureOpen((v) => !v)}
                >
                  <div>
                    <Label className="text-[12px]">Line manager</Label>
                    <Select
                      value={selected.managerId ?? "none"}
                      onValueChange={(v) => reparent(selected.id, v === "none" ? null : v)}
                    >
                      <SelectTrigger className="mt-1 h-9">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No manager (top of chart)</SelectItem>
                        {(scenario?.employees ?? [])
                          .filter((e) => e.id !== selected.id)
                          .map((e) => (
                            <SelectItem key={e.id} value={e.id}>
                              {(e.name || "Open Role") + " — " + e.title}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-[12px]">Delivery model</Label>
                    <Select
                      value={selected.unitKind ?? "line"}
                      onValueChange={(v) =>
                        upsertEmployee({ ...selected, unitKind: v as OrgUnitKind })
                      }
                    >
                      <SelectTrigger className="mt-1 h-9">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {ORG_UNIT_KINDS.map((k) => (
                          <SelectItem key={k} value={k}>
                            {UNIT_META[k].label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-[12px]">Role scope</Label>
                    <Select
                      value={selected.roleScope ?? "unset"}
                      onValueChange={(v) =>
                        upsertEmployee({ ...selected, roleScope: v as RoleScope })
                      }
                    >
                      <SelectTrigger className="mt-1 h-9">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {ROLE_SCOPES.map((k) => (
                          <SelectItem key={k} value={k}>
                            {SCOPE_META[k].label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </CollapsibleSection>
                <CollapsibleSection
                  title="Cost model"
                  id="role-cost-section"
                  open={costOpen}
                  onToggle={() => setCostOpen((v) => !v)}
                >
                  {roleTypeOf(selected) !== "human" ? (
                    <div>
                      <Label className="text-[12px]">Agent running cost (per month)</Label>
                      <Input
                        className="mt-1 h-9"
                        type="number"
                        min={0}
                        placeholder={String(agentMonthly)}
                        value={selected.agentMonthlyCost ?? ""}
                        onChange={(ev) =>
                          upsertEmployee({
                            ...selected,
                            agentMonthlyCost:
                              ev.target.value === "" ? undefined : Number(ev.target.value),
                          })
                        }
                      />
                      <p className="mt-1 text-[11px] text-muted-foreground">
                        Annual running cost:{" "}
                        {formatMoney(agentAnnualCost(selected, agentMonthly), scenario?.currency)}
                        {selected.agentMonthlyCost == null
                          ? ` · using the workspace default of ${formatMoney(agentMonthly, scenario?.currency)}/month`
                          : ""}
                      </p>
                    </div>
                  ) : null}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label className="text-[12px]">Benefits %</Label>
                      <Input
                        className="mt-1 h-9"
                        type="number"
                        min={0}
                        max={100}
                        placeholder={String(costRates.benefitsPct)}
                        value={selected.benefitsPct ?? ""}
                        onChange={(ev) =>
                          upsertEmployee({
                            ...selected,
                            benefitsPct:
                              ev.target.value === "" ? undefined : Number(ev.target.value),
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label className="text-[12px]">Bonus %</Label>
                      <Input
                        className="mt-1 h-9"
                        type="number"
                        min={0}
                        max={100}
                        placeholder={String(costRates.variablePayPct)}
                        value={selected.variablePayPct ?? ""}
                        onChange={(ev) =>
                          upsertEmployee({
                            ...selected,
                            variablePayPct:
                              ev.target.value === "" ? undefined : Number(ev.target.value),
                          })
                        }
                      />
                    </div>
                  </div>
                  <ul className="space-y-0.5 text-[11px] text-muted-foreground">
                    {roleCostLines(selectedCost).map((line) => (
                      <li key={line.label} className="flex justify-between gap-3">
                        <span>
                          {line.label}
                          <span className="ml-1 uppercase tracking-wide opacity-70">
                            ({line.kind})
                          </span>
                        </span>
                        <span className="tabular-nums">
                          {formatMoney(line.value, scenario?.currency)}
                        </span>
                      </li>
                    ))}
                    <li className="flex justify-between gap-3 border-t border-border pt-1 font-semibold text-foreground">
                      <span>Total (fixed + variable)</span>
                      <span className="tabular-nums">
                        {formatMoney(selectedCost.total, scenario?.currency)}
                      </span>
                    </li>
                  </ul>
                  <p className="text-[11px] text-muted-foreground">
                    Fixed {formatMoney(selectedCost.fixed, scenario?.currency)} · variable{" "}
                    {formatMoney(selectedCost.variable, scenario?.currency)} ·{" "}
                    {formatMoney(selectedCost.totalPerPosition, scenario?.currency)} per position
                  </p>
                </CollapsibleSection>
                <CollapsibleSection
                  title="Employment & headcount"
                  id="role-details-section"
                  open={detailsOpen}
                  onToggle={() => setDetailsOpen((v) => !v)}
                >
                  <dl className="space-y-2.5 text-[13px]">
                    {[
                      ["Department", selected.department || "—"],
                      ["Country", selected.country],
                      ["Employment type", selected.employmentType],
                      ["Delivery model", UNIT_META[selected.unitKind ?? "line"].label],
                      ["Role scope", SCOPE_META[selected.roleScope ?? "unset"].label],
                      ["Role type", ROLE_TYPE_META[roleTypeOf(selected)].label],
                      ["Transformation lever", LEVER_META[selected.reductionLever ?? "headcount"].label],
                      ["Dotted lines", String((selected.dottedManagerIds ?? []).length)],
                      ["Headcount", `${selected.currentHeadcount} → ${selected.plannedHeadcount}`],
                      [
                        "Annual cost",
                        `${formatMoney(selected.currentCost, scenario?.currency)} → ${formatMoney(selected.plannedCost, scenario?.currency)}`,
                      ],
                      ["Length of service", `${(selected.serviceMonths / 12).toFixed(1)} years`],
                    ].map(([label, value]) => (
                      <div key={label} className="flex justify-between gap-3 border-b border-border pb-2 last:border-0 last:pb-0">
                        <dt className="text-muted-foreground">{label}</dt>
                        <dd className="text-right font-medium">{value}</dd>
                      </div>
                    ))}
                  </dl>
                </CollapsibleSection>
                <CollapsibleSection
                  title="Dotted-line reporting"
                  id="role-dotted-section"
                  open={dottedOpen}
                  onToggle={() => setDottedOpen((v) => !v)}
                >
                  <p className="text-[11px] text-muted-foreground">
                    Matrix or functional relationships, drawn as dotted connectors.
                  </p>
                  <div className="max-h-40 space-y-1 overflow-y-auto rounded-md border border-border p-2">
                    {(scenario?.employees ?? [])
                      .filter((e) => e.id !== selected.id && e.id !== selected.managerId)
                      .map((e) => (
                        <label
                          key={e.id}
                          className="flex cursor-pointer items-center gap-2 text-[12px]"
                        >
                          <Checkbox
                            checked={(selected.dottedManagerIds ?? []).includes(e.id)}
                            onCheckedChange={() => toggleDotted(selected.id, e.id)}
                          />
                          <span className="truncate">
                            {e.name || "Open Role"}{" "}
                            <span className="text-muted-foreground">— {e.title}</span>
                          </span>
                        </label>
                      ))}
                  </div>
                </CollapsibleSection>
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    resizeNode(selected.id, null);
                    toast.success("Card size reset to the layout default");
                  }}
                >
                  <Maximize2 className="mr-1.5 size-3.5" /> Reset card size
                </Button>
                {selected.responsibilities ? (
                  <CollapsibleSection
                    title="Responsibilities"
                    id="role-responsibilities-section"
                    open={responsibilitiesOpen}
                    onToggle={() => setResponsibilitiesOpen((v) => !v)}
                  >
                    <p className="text-[13px] leading-relaxed text-foreground">
                      {selected.responsibilities}
                    </p>
                  </CollapsibleSection>
                ) : null}
              </div>
            ) : (
              <div className="text-sm text-muted-foreground">
                <p className="font-medium text-foreground">Nothing selected</p>
                <p className="mt-1.5">
                  Click a card to inspect and edit the role. Drag a card onto another to move it
                  under a new line manager, hold Shift while dropping to add a dotted line, and drag
                  a card corner to resize it.
                </p>
              </div>
            )}

            </div>
          </aside>
        )}
      </div>
    </div>
  );
}