import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { StatCard } from "@/components/orgeasy/StatCard";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { computeImpact, formatMoney } from "@/lib/orgeasy/impact";
import { useAgentMonthlyCost, setAgentMonthlyDefault } from "@/lib/orgeasy/agents";
import { useCostAssumptions } from "@/lib/orgeasy/cost-model";
import { CostModelPanel } from "@/components/orgeasy/CostModelPanel";
import { Input } from "@/components/ui/input";
import { AlertTriangle, Bot, Receipt } from "lucide-react";
import { Disclaimer } from "@/components/orgeasy/Disclaimer";
import { CountryCostRules, RiskBadge } from "@/components/orgeasy/CountryCostRules";
import { effectiveRules } from "@/lib/orgeasy/country-costs";
import { STATUS_META, type Employee, type Scenario } from "@/lib/orgeasy/types";
import { currentStateFor, phasesFor, phaseTitle } from "@/lib/orgeasy/phases";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/impact")({
  head: () => ({
    meta: [
      { title: "Restructuring Impact Simulation — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Simulate headcount and budget impact by department and country, with new, removed and reassigned role detail.",
      },
      { property: "og:title", content: "Restructuring Impact Simulation — Organisation Strategy Studio" },
      {
        property: "og:description",
        content: "Headcount and budget deltas by department and country for any scenario.",
      },
    ],
  }),
  component: Impact,
});

function Bar({ current, planned }: { current: number; planned: number }) {
  const max = Math.max(current, planned, 1);
  return (
    <div className="space-y-1">
      <div className="h-2 rounded-full bg-secondary">
        <div
          className="h-2 rounded-full bg-muted-foreground/60"
          style={{ width: `${(current / max) * 100}%` }}
        />
      </div>
      <div className="h-2 rounded-full bg-secondary">
        <div className="h-2 rounded-full bg-brand" style={{ width: `${(planned / max) * 100}%` }} />
      </div>
    </div>
  );
}

function Impact() {
  const { workspace, scenario } = useOrgEasy();
  const baseline = currentStateFor(workspace.scenarios, scenario);
  const phases = phasesFor(workspace.scenarios, baseline);
  const [scope, setScope] = useState<string>(() => (phases.length ? "programme" : "active"));

  const target = useMemo(() => {
    if (scope === "active") return scenario ?? null;
    if (scope === "programme") return phases[phases.length - 1] ?? scenario ?? null;
    return phases.find((p) => p.id === scope) ?? scenario ?? null;
  }, [scope, phases, scenario]);

  /** Baseline (today) vs the selected end state, so 500 → 450 is always visible. */
  const view = useMemo<Scenario | null>(() => {
    if (!baseline || !target || target.id === baseline.id) return target;
    const byId = new Map(baseline.employees.map((e) => [e.id, e]));
    const merged: Employee[] = target.employees.map((e) => {
      const b = byId.get(e.id);
      return {
        ...e,
        currentHeadcount: b?.currentHeadcount ?? 0,
        currentCost: b?.currentCost ?? e.currentCost,
      };
    });
    const seen = new Set(target.employees.map((e) => e.id));
    for (const b of baseline.employees) {
      if (!seen.has(b.id))
        merged.push({ ...b, plannedHeadcount: 0, status: "to-be-removed" });
    }
    return { ...target, employees: merged };
  }, [baseline, target]);

  const agentMonthly = useAgentMonthlyCost();
  const assumptions = useCostAssumptions();
  const rules = useMemo(() => effectiveRules(scenario), [scenario]);
  const impact = computeImpact(view, agentMonthly, rules, assumptions);
  const cur = view?.currency ?? "USD";
  const pct = impact.currentCost ? (impact.costDelta / impact.currentCost) * 100 : 0;
  const sep = impact.separation;

  return (
    <div className="pb-12">
      <PageHeader
        title="Impact simulation"
        description="Current values describe today's baseline organisation; planned values describe the selected end state of the reduction programme."
      />

      <div className="space-y-6 px-8 py-6">
        <Disclaimer />

        <div className="flex flex-wrap items-center gap-2 rounded-lg border border-border bg-card px-4 py-3 shadow-panel">
          <span className="mr-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
            Compare baseline against
          </span>
          {[
            ...(phases.length
              ? [{ id: "programme", label: "Full programme (end state)" }]
              : []),
            ...phases.map((p) => ({ id: p.id, label: phaseTitle(p) })),
            { id: "active", label: `Active scenario${scenario ? `: ${scenario.name}` : ""}` },
          ].map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => setScope(opt.id)}
              className={cn(
                "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                scope === opt.id
                  ? "border-brand bg-brand text-brand-foreground"
                  : "border-border text-muted-foreground hover:bg-secondary",
              )}
            >
              {opt.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-4 xl:grid-cols-5">
          <StatCard
            label="Headcount"
            value={`${impact.currentHeadcount} → ${impact.plannedHeadcount}`}
            sub={`${impact.headcountDelta >= 0 ? "+" : ""}${impact.headcountDelta} positions${
              impact.currentHeadcount
                ? ` (${((impact.headcountDelta / impact.currentHeadcount) * 100).toFixed(1)}%)`
                : ""
            }`}
            tone={impact.headcountDelta < 0 ? "negative" : "brand"}
          />
          <StatCard
            label="Human people cost"
            value={formatMoney(impact.plannedHumanCost, cur)}
            sub={`from ${formatMoney(impact.currentCost, cur)} · ${impact.plannedHumanHeadcount} people`}
          />
          <StatCard
            label="Agent running cost"
            value={formatMoney(impact.plannedAgentCost, cur)}
            sub={`${impact.agentPositions} agent · ${impact.hybridPositions} hybrid roles`}
            icon={<Bot className="size-4" />}
          />
          <StatCard
            label={impact.costDelta <= 0 ? "Annual saving" : "Annual increase"}
            value={formatMoney(Math.abs(impact.costDelta), cur)}
            tone={impact.costDelta <= 0 ? "positive" : "negative"}
            sub={`${pct >= 0 ? "+" : ""}${pct.toFixed(1)}% vs today · total ${formatMoney(impact.plannedCost, cur)}`}
          />
          <StatCard
            label="One-off separation cost"
            value={formatMoney(sep.mid, cur)}
            tone="negative"
            sub={`${formatMoney(sep.low, cur)} – ${formatMoney(sep.high, cur)} · ${sep.exits} exits`}
            icon={<Receipt className="size-4" />}
          />
        </div>

        {sep.highRiskCountries.length ? (
          <div className="rounded-lg border border-destructive/40 bg-destructive/5 px-5 py-4">
            <p className="flex items-center gap-2 text-[13px] font-semibold text-destructive">
              <AlertTriangle className="size-4" /> High consultation risk in{" "}
              {sep.highRiskCountries.length} market
              {sep.highRiskCountries.length === 1 ? "" : "s"}
            </p>
            <ul className="mt-2 space-y-1.5">
              {sep.highRiskCountries.map((c) => (
                <li key={c.country} className="text-[12px] text-muted-foreground">
                  <span className="font-medium text-foreground">{c.country}</span> · {c.exits} exits
                  · {formatMoney(c.mid, cur)} — {c.rule.riskNote}
                </li>
              ))}
            </ul>
          </div>
        ) : null}

        <div className="flex flex-wrap items-end justify-between gap-4 rounded-lg border border-border bg-card px-5 py-4 shadow-panel">
          <div>
            <p className="text-[13px] font-semibold">Agent running cost assumption</p>
            <p className="mt-0.5 text-[11.5px] text-muted-foreground">
              Default monthly cost per deployed agent (licences, tokens, orchestration and
              oversight). Individual roles can override this in the chart designer.
            </p>
          </div>
          <div className="flex items-end gap-3">
            <label className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
              {cur} / month
              <Input
                className="mt-1 h-9 w-32"
                type="number"
                min={0}
                value={agentMonthly}
                onChange={(e) => setAgentMonthlyDefault(Number(e.target.value))}
              />
            </label>
            <div className="text-right">
              <p className="text-[11px] uppercase tracking-wide text-muted-foreground">
                Illustrative separation cost (mid-point)
              </p>
              <p className="text-sm font-semibold text-destructive tabular-nums">
                {formatMoney(sep.mid, cur)}
              </p>
            </div>
          </div>
        </div>

        <CostModelPanel model={impact.costModel} currency={cur} />

        <section className="rounded-lg border border-border bg-card shadow-panel">
          <div className="border-b border-border px-5 py-3.5">
            <h2 className="text-sm font-semibold">Separation cost build-up by country</h2>
            <p className="mt-0.5 text-[11.5px] text-muted-foreground">
              Notice and severance are priced from pay; legal fees, outplacement and administration
              are per-exit country costs; tribunal risk is the expected value of claims (claim rate ×
              defence cost + award months of pay); collective procedure cost is charged once per
              market when the consultation threshold is met. Illustrative only — confirm with local
              counsel.
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-[12.5px]">
              <thead className="bg-secondary text-[11px] uppercase tracking-wide text-muted-foreground">
                <tr>
                  {[
                    "Country",
                    "Exits",
                    "Notice",
                    "Severance",
                    "Legal fees",
                    "Outplacement",
                    "Admin",
                    "Tribunal risk",
                    "Collective procedure",
                    "Total (range)",
                  ].map((h) => (
                    <th key={h} className="px-4 py-2.5 font-semibold">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {sep.byCountry.map((c) => (
                  <tr key={c.country}>
                    <td className="px-4 py-2.5">
                      <p className="font-medium">{c.country}</p>
                      <p className="text-[11px] text-muted-foreground">{c.region}</p>
                    </td>
                    <td className="px-4 py-2.5 tabular-nums">{c.exits}</td>
                    <td className="px-4 py-2.5 tabular-nums">{formatMoney(c.noticeCost, cur)}</td>
                    <td className="px-4 py-2.5 tabular-nums">{formatMoney(c.severanceCost, cur)}</td>
                    <td className="px-4 py-2.5 tabular-nums">{formatMoney(c.legalFees, cur)}</td>
                    <td className="px-4 py-2.5 tabular-nums">{formatMoney(c.outplacement, cur)}</td>
                    <td className="px-4 py-2.5 tabular-nums">{formatMoney(c.adminCost, cur)}</td>
                    <td className="px-4 py-2.5 tabular-nums">
                      {formatMoney(c.tribunalRisk, cur)}
                      <p className="text-[11px] text-muted-foreground">
                        {c.rule.claimRatePct}% claim rate · {c.expectedClaims.toFixed(1)} claims
                      </p>
                    </td>
                    <td className="px-4 py-2.5 tabular-nums">
                      {c.collectiveTriggered ? (
                        <>
                          {formatMoney(c.collectiveCost, cur)}
                          <p className="text-[11px] text-destructive">
                            triggered at {c.rule.collectiveThreshold}+ exits
                          </p>
                        </>
                      ) : (
                        <span className="text-muted-foreground">
                          not triggered ({c.rule.collectiveThreshold}+ exits)
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-2.5 tabular-nums font-semibold">
                      {formatMoney(c.mid, cur)}
                      <p className="text-[11px] font-normal text-muted-foreground">
                        {formatMoney(c.low, cur)} – {formatMoney(c.high, cur)}
                      </p>
                    </td>
                  </tr>
                ))}
                {!sep.byCountry.length ? (
                  <tr>
                    <td colSpan={10} className="px-4 py-6 text-center text-muted-foreground">
                      No exits modelled in this scenario yet.
                    </td>
                  </tr>
                ) : (
                  <tr className="bg-secondary/60 font-semibold">
                    <td className="px-4 py-2.5">All markets</td>
                    <td className="px-4 py-2.5 tabular-nums">{sep.exits}</td>
                    <td className="px-4 py-2.5" colSpan={2} />
                    <td className="px-4 py-2.5 tabular-nums">{formatMoney(sep.legalFees, cur)}</td>
                    <td className="px-4 py-2.5" colSpan={2} />
                    <td className="px-4 py-2.5 tabular-nums">{formatMoney(sep.tribunalRisk, cur)}</td>
                    <td className="px-4 py-2.5 tabular-nums">
                      {formatMoney(sep.collectiveCost, cur)}
                    </td>
                    <td className="px-4 py-2.5 tabular-nums">{formatMoney(sep.mid, cur)}</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        <section className="rounded-lg border border-border bg-card shadow-panel">
          <div className="flex items-center justify-between border-b border-border px-5 py-3.5">
            <h2 className="text-sm font-semibold">By department</h2>
            <div className="flex gap-4 text-[11px] text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-4 rounded-full bg-muted-foreground/60" /> Current
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-4 rounded-full bg-brand" /> Planned
              </span>
            </div>
          </div>
          <table className="w-full text-left text-[13px]">
            <thead className="bg-secondary text-[11px] uppercase tracking-wide text-muted-foreground">
              <tr>
                {["Department", "Headcount", "Change", "Cost now", "Human cost", "Agent cost", "Cost change"].map(
                  (h) => (
                    <th key={h} className="px-5 py-2.5 font-semibold">
                      {h}
                    </th>
                  ),
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {impact.byDepartment.map((d) => {
                const hcDelta = d.plannedHeadcount - d.currentHeadcount;
                const costDelta = d.plannedCost - d.currentCost;
                return (
                  <tr key={d.department}>
                    <td className="px-5 py-3 font-medium">{d.department}</td>
                    <td className="w-48 px-5 py-3">
                      <p className="mb-1 tabular-nums text-muted-foreground">
                        {d.currentHeadcount} → <span className="text-foreground">{d.plannedHeadcount}</span>
                      </p>
                      <Bar current={d.currentHeadcount} planned={d.plannedHeadcount} />
                    </td>
                    <td
                      className={cn(
                        "px-5 py-3 tabular-nums font-medium",
                        hcDelta < 0 ? "text-destructive" : hcDelta > 0 ? "text-success" : "",
                      )}
                    >
                      {hcDelta > 0 ? "+" : ""}
                      {hcDelta}
                    </td>
                    <td className="px-5 py-3 tabular-nums">{formatMoney(d.currentCost, cur)}</td>
                    <td className="px-5 py-3 tabular-nums">{formatMoney(d.plannedHumanCost, cur)}</td>
                    <td className="px-5 py-3 tabular-nums text-info">
                      {d.plannedAgentCost ? formatMoney(d.plannedAgentCost, cur) : "—"}
                    </td>
                    <td
                      className={cn(
                        "px-5 py-3 tabular-nums font-medium",
                        costDelta <= 0 ? "text-success" : "text-destructive",
                      )}
                    >
                      {costDelta > 0 ? "+" : "−"}
                      {formatMoney(Math.abs(costDelta), cur)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </section>

        <section className="rounded-lg border border-border bg-card shadow-panel">
          <div className="border-b border-border px-5 py-3.5">
            <h2 className="text-sm font-semibold">By country — headcount and one-off separation cost</h2>
            <p className="mt-0.5 text-[11.5px] text-muted-foreground">
              Roles without a country inherit their manager&rsquo;s market. Separation cost = notice +
              severance + legal fees, outplacement, admin, tribunal risk and any collective procedure
              cost, priced on the country cost rules below.
            </p>
          </div>
          <table className="w-full text-left text-[13px]">
            <thead className="bg-secondary text-[11px] uppercase tracking-wide text-muted-foreground">
              <tr>
                {[
                  "Country",
                  "HC now",
                  "HC planned",
                  "Exits",
                  "Notice",
                  "Severance",
                  "One-off separation (range)",
                  "Consultation risk",
                ].map((h) => (
                  <th key={h} className="px-5 py-2.5 font-semibold">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {impact.byCountry.map((c) => (
                <tr key={c.country} className={cn(c.risk === "High" && c.removed ? "bg-destructive/5" : "")}>
                  <td className="px-5 py-3 font-medium">{c.country}</td>
                  <td className="px-5 py-3 tabular-nums">{c.currentHeadcount}</td>
                  <td className="px-5 py-3 tabular-nums">{c.plannedHeadcount}</td>
                  <td className="px-5 py-3 tabular-nums">
                    {c.removed ? (
                      <span className="font-medium text-destructive">{c.removed}</span>
                    ) : (
                      "—"
                    )}
                  </td>
                  <td className="px-5 py-3 tabular-nums">
                    {c.noticeCost ? formatMoney(c.noticeCost, cur) : "—"}
                  </td>
                  <td className="px-5 py-3 tabular-nums">
                    {c.severanceCost ? formatMoney(c.severanceCost, cur) : "—"}
                  </td>
                  <td className="px-5 py-3 tabular-nums">
                    {c.separationMid ? (
                      <>
                        <span className="font-medium text-destructive">
                          {formatMoney(c.separationMid, cur)}
                        </span>
                        <span className="ml-1.5 text-[11px] text-muted-foreground">
                          {formatMoney(c.separationLow, cur)} – {formatMoney(c.separationHigh, cur)}
                        </span>
                      </>
                    ) : (
                      "—"
                    )}
                  </td>
                  <td className="px-5 py-3">
                    <RiskBadge risk={c.risk} />
                    {c.risk === "High" ? (
                      <p className="mt-1 max-w-[280px] text-[11px] leading-snug text-muted-foreground">
                        {c.riskNote}
                      </p>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        <CountryCostRules currency={cur} />

        <div className="grid gap-4 lg:grid-cols-3">
          {(
            [
              ["New capability roles", impact.newRoles, "planned"],
              ["Proposed for removal", impact.removedRoles, "to-be-removed"],
              ["Reassigned roles", impact.movedRoles, "moved"],
            ] as const
          ).map(([label, list, status]) => (
            <section
              key={label}
              className={cn(
                "rounded-lg border bg-card shadow-panel",
                status === "planned" && list.length ? "border-info/50 ring-1 ring-info/20" : "border-border",
              )}
            >
              <div className="flex items-center justify-between border-b border-border px-4 py-3">
                <div>
                  <h3 className="text-[13px] font-semibold">{label}</h3>
                  {status === "planned" ? (
                    <p className="text-[11px] text-muted-foreground">
                      {list.reduce((a, e) => a + e.plannedHeadcount, 0).toLocaleString()} positions
                      the organisation gains
                    </p>
                  ) : null}
                </div>
                <span
                  className={cn(
                    "rounded px-2 py-0.5 text-[10px] font-semibold uppercase",
                    STATUS_META[status].className,
                  )}
                >
                  {list.length}
                </span>
              </div>
              <ul className="max-h-72 divide-y divide-border overflow-y-auto">
                {list.length ? (
                  list.map((e) => (
                    <li key={e.id} className="px-4 py-2.5">
                      <p className="text-[13px] font-medium">{e.name || "Open Role"}</p>
                      <p className="text-[11.5px] text-muted-foreground">
                        {e.title} · {e.country}
                      </p>
                    </li>
                  ))
                ) : (
                  <li className="px-4 py-6 text-center text-xs text-muted-foreground">
                    No roles in this category.
                  </li>
                )}
              </ul>
            </section>
          ))}
        </div>
      </div>
    </div>
  );
}