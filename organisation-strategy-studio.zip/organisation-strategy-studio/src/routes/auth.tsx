import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  Building2,
  Check,
  Cloud,
  HardDrive,
  Minus,
  RotateCcw,
  ScrollText,
  ShieldCheck,
} from "lucide-react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { useOrgEasy } from "@/lib/orgeasy/store";
import {
  PERMISSION_LIST,
  PERMISSION_META,
  ROLE_META,
  WORKSPACE_ROLES,
  roleCan,
  type WorkspaceRole,
} from "@/lib/orgeasy/roles";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Workspace Access — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Manage workspace roles (Admin, Editor, Viewer), see the permission matrix, and control local scenario data before cloud sync is enabled.",
      },
      { property: "og:title", content: "Workspace Access — Organisation Strategy Studio" },
      {
        property: "og:description",
        content: "Role-based access, permissions and local data controls for Organisation Strategy Studio.",
      },
    ],
  }),
  component: Auth,
});

function Auth() {
  const { workspace, signIn, signOut, resetDemoData, role, setRole, can } = useOrgEasy();
  const [email, setEmail] = useState("");
  const account = workspace.account;
  const canManageRoles = can("manageRoles");

  const pickRole = (next: WorkspaceRole) => {
    if (next === role) return;
    setRole(next);
    toast.success(`Workspace role set to ${ROLE_META[next].label}`, {
      description: ROLE_META[next].description,
    });
  };

  return (
    <div className="pb-12">
      <PageHeader
        title="Workspace access"
        description="Who can do what in this workspace — roles, permissions and data controls. Cloud accounts with shared workspaces are the next step."
      />

      <div className="grid max-w-4xl gap-6 px-8 py-6 lg:grid-cols-2">
        <section className="rounded-lg border border-border bg-card p-6 shadow-panel">
          <span className="grid size-10 place-items-center rounded-md bg-accent text-brand">
            <Building2 className="size-5" />
          </span>
          <h2 className="mt-3 text-[15px] font-semibold">
            {account ? "Workspace owner" : "Claim this workspace"}
          </h2>
          {account ? (
            <>
              <p className="mt-1.5 text-[13px] text-muted-foreground">
                Signed in as <span className="font-medium text-foreground">{account.email}</span>{" "}
                since {new Date(account.signedInAt).toLocaleDateString()}.
              </p>
              <Button
                variant="outline"
                className="mt-4"
                onClick={() => {
                  signOut();
                  toast.success("Signed out of this workspace");
                }}
              >
                Sign out
              </Button>
            </>
          ) : (
            <form
              className="mt-3 space-y-3"
              onSubmit={(e) => {
                e.preventDefault();
                const value = email.trim();
                if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value)) {
                  toast.error("Enter a valid work email address");
                  return;
                }
                signIn(value);
                setEmail("");
                toast.success("Workspace claimed");
              }}
            >
              <div className="space-y-1.5">
                <Label htmlFor="email">Work email</Label>
                <Input
                  id="email"
                  type="email"
                  maxLength={255}
                  placeholder="you@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <Button type="submit" className="w-full">
                Continue
              </Button>
            </form>
          )}
        </section>

        {/* Role & access */}
        <section className="rounded-lg border border-border bg-card p-6 shadow-panel">
          <div className="flex items-start justify-between gap-3">
            <span className="grid size-10 place-items-center rounded-md bg-accent text-brand">
              <ShieldCheck className="size-5" />
            </span>
            <span
              className={cn(
                "rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide",
                ROLE_META[role].badgeClass,
              )}
            >
              {ROLE_META[role].label}
            </span>
          </div>
          <h2 className="mt-3 text-[15px] font-semibold">Role &amp; access</h2>
          <p className="mt-1.5 text-[13px] leading-relaxed text-muted-foreground">
            Roles gate every mutating action in the studio — structure edits, scenario changes,
            imports and exports. {ROLE_META[role].description}
          </p>
          <div className="mt-4 grid grid-cols-3 gap-2">
            {WORKSPACE_ROLES.map((r) => (
              <button
                key={r}
                type="button"
                disabled={!canManageRoles && r !== role}
                onClick={() => pickRole(r)}
                title={
                  canManageRoles
                    ? ROLE_META[r].description
                    : r === role
                      ? "Your current role"
                      : "Only Admins can change roles"
                }
                className={cn(
                  "rounded-lg border px-2 py-2.5 text-center transition-colors",
                  r === role
                    ? "border-brand/50 bg-brand/10"
                    : "border-border bg-secondary/40 hover:border-brand/30 hover:bg-secondary",
                  !canManageRoles && r !== role && "cursor-not-allowed opacity-50",
                )}
              >
                <span
                  className={cn(
                    "block text-[12.5px] font-semibold",
                    r === role ? "text-brand" : "text-foreground",
                  )}
                >
                  {ROLE_META[r].label}
                </span>
                <span className="mt-0.5 block text-[10px] text-muted-foreground">
                  {ROLE_META[r].tagline}
                </span>
              </button>
            ))}
          </div>
          {!canManageRoles && (
            <p className="mt-2 text-[11px] text-muted-foreground">
              Only Admins can change the workspace role.
            </p>
          )}
          <Button asChild variant="outline" size="sm" className="mt-4">
            <Link to="/activity">
              <ScrollText className="mr-1.5 size-4" /> View activity &amp; audit trail
            </Link>
          </Button>
        </section>

        {/* Permission matrix */}
        <section className="rounded-lg border border-border bg-card p-6 shadow-panel lg:col-span-2">
          <h2 className="text-[15px] font-semibold">Permission matrix</h2>
          <p className="mt-1 text-[13px] text-muted-foreground">
            Enforced in the store, not just hidden in the UI — a Viewer is read-only from every
            surface.
          </p>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-[560px] text-left text-[12.5px]">
              <thead>
                <tr className="border-b border-border text-[11px] uppercase tracking-wide text-muted-foreground">
                  <th className="py-2 pr-4 font-medium">Capability</th>
                  {WORKSPACE_ROLES.map((r) => (
                    <th key={r} className="w-28 py-2 text-center font-medium">
                      <span
                        className={cn(
                          "rounded-full border px-2 py-0.5 text-[10px] font-semibold",
                          ROLE_META[r].badgeClass,
                        )}
                      >
                        {ROLE_META[r].label}
                      </span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {PERMISSION_LIST.map((p) => (
                  <tr key={p} className="border-b border-border/60 last:border-0">
                    <td className="py-2.5 pr-4">
                      <span className="block font-medium text-foreground">
                        {PERMISSION_META[p].label}
                      </span>
                      <span className="block text-[11.5px] text-muted-foreground">
                        {PERMISSION_META[p].description}
                      </span>
                    </td>
                    {WORKSPACE_ROLES.map((r) => (
                      <td key={r} className="py-2.5 text-center">
                        {roleCan(r, p) ? (
                          <Check className="mx-auto size-4 text-success" />
                        ) : (
                          <Minus className="mx-auto size-4 text-muted-foreground/40" />
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="rounded-lg border border-border bg-card p-6 shadow-panel">
          <span className="grid size-10 place-items-center rounded-md bg-accent text-brand">
            <HardDrive className="size-5" />
          </span>
          <h2 className="mt-3 text-[15px] font-semibold">Local storage</h2>
          <p className="mt-1.5 text-[13px] leading-relaxed text-muted-foreground">
            {workspace.scenarios.length} scenario
            {workspace.scenarios.length === 1 ? "" : "s"} and the activity trail are stored in this
            browser. Use the CSV export on the People page to keep a backup.
          </p>
          <Button
            variant="outline"
            className="mt-4"
            disabled={!can("resetData")}
            title={can("resetData") ? undefined : "Only Admins can reset the workspace"}
            onClick={() => {
              resetDemoData();
              toast.success("Workspace reset to demo data");
            }}
          >
            <RotateCcw className="mr-1.5 size-4" /> Reset to demo data
          </Button>
        </section>

        <section className="rounded-lg border border-dashed border-border bg-secondary/50 p-6">
          <span className="grid size-10 place-items-center rounded-md bg-card text-brand">
            <Cloud className="size-5" />
          </span>
          <h2 className="mt-3 text-[15px] font-semibold">Cloud sync — next phase</h2>
          <p className="mt-1.5 text-[13px] leading-relaxed text-muted-foreground">
            Real accounts, shared workspaces, per-person roles and a tamper-evident audit history
            come with the cloud backend. The role model and activity trail you see here carry over
            unchanged.
          </p>
        </section>
      </div>
    </div>
  );
}
