import { createFileRoute } from "@tanstack/react-router";
import { ChartPage } from "./chart";
import type { LayoutKind } from "@/lib/orgeasy/layout";

/**
 * Popped-out modelling canvas: the same org chart designer as /chart but in a
 * dedicated minimal window, so large structures can be viewed and manipulated
 * without the studio chrome. Edits stay in sync with the main window through
 * the workspace sync channel in the store.
 */
export const Route = createFileRoute("/canvas-popout")({
  validateSearch: (search: Record<string, unknown>): { layout?: LayoutKind } =>
    typeof search["layout"] === "string" ? { layout: search["layout"] as LayoutKind } : {},
  head: () => ({
    meta: [
      { title: "Modelling Canvas — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Full-window org modelling canvas for designing current and future structures.",
      },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: PopoutCanvas,
});

function PopoutCanvas() {
  const search = Route.useSearch();
  return <ChartPage search={search} popout />;
}
