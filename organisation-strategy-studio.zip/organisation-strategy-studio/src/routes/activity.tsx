import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  FileDown,
  History as HistoryIcon,
  Layers,
  Network,
  ShieldCheck,
  Trash2,
  UserCircle2,
} from "lucide-react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { useOrgEasy } from "@/lib/orgeasy/store";
import {
  ACTIVITY_KIND_META,
  ACTIVITY_KINDS,
  ROLE_META,
  type ActivityEvent,
  type ActivityKind,
} from "@/lib/orgeasy/roles";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/activity")({
  head: () => ({
    meta: [
      { title: "Activity & Audit — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "An executive-readable trail of the important actions in this workspace: scenario changes, structure edits, exports and access events.",
      },
      { property: "og:title", content: "Activity & Audit — Organisation Strategy Studio" },
      {
        property: "og:description",
        content: "See who changed what: scenarios, structure, exports and access — in plain language.",
      },
    ],
  }),
  component: ActivityPage,
});

const KIND_ICON: Record<ActivityKind, typeof Layers> = {
  scenario: Layers,
  structure: Network,
  export: FileDown,
  access: UserCircle2,
  version: HistoryIcon,
};

const KIND_CLASS: Record<ActivityKind, string> = {
  scenario: "bg-brand/10 text-brand",
  structure: "bg-info/10 text-info",
  export: "bg-success/10 text-success",
  access: "bg-warning/10 text-warning",
  version: "bg-secondary text-secondary-foreground",
};

function dayLabel(iso: string) {
  const d = new Date(iso);
  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return "Today";
  if (d.toDateString() === yesterday.toDateString()) return "Yesterday";
  return d.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short", year: "numeric" });
}

function timeLabel(iso: string) {
  return new Date(iso).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
}

function ActivityPage() {
  const { workspace, role, clearActivity, can } = useOrgEasy();
  const [filter, setFilter] = useState<ActivityKind | "all">("all");
  const activity = useMemo(() => workspace.activity ?? [], [workspace.activity]);

  const filtered = useMemo(
    () => (filter === "all" ? activity : activity.filter((e) => e.kind === filter)),
    [activity, filter],
  );

  const groups = useMemo(() => {
    const map = new Map<string, ActivityEvent[]>();
    for (const e of filtered) {
      const key = dayLabel(e.at);
      map.set(key, [...(map.get(key) ?? []), e]);
    }
    return [...map.entries()];
  }, [filtered]);

  const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
  const thisWeek = activity.filter((e) => new Date(e.at).getTime() >= weekAgo);
  const exportCount = thisWeek.filter((e) => e.kind === "export").length;
  const structureCount = thisWeek.filter((e) => e.kind === "structure").length;
  const contributors = new Set(thisWeek.map((e) => e.actor)).size;

  return (
    <div className="pb-12">
      <PageHeader
        title="Activity & audit"
        description="A plain-language record of the actions that matter in this workspace — scenario changes, structure edits, exports and access. Stored locally with your data."
      />

      <div className="space-y-6 px-8 py-6">
        {/* Summary strip */}
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {[
            { label: "Actions this week", value: thisWeek.length },
            { label: "Structure & data changes", value: structureCount },
            { label: "Packs & files exported", value: exportCount },
            { label: "Contributors", value: contributors },
          ].map((s) => (
            <div key={s.label} className="rounded-lg border border-border bg-card px-4 py-3 shadow-panel">
              <p className="font-display text-[22px] font-bold leading-tight">{s.value}</p>
              <p className="mt-0.5 text-[11px] uppercase tracking-wide text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Filter + clear */}
        <div className="flex flex-wrap items-center gap-2">
          {(["all", ...ACTIVITY_KINDS] as const).map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => setFilter(k)}
              className={cn(
                "rounded-full border px-3 py-1 text-[12px] font-medium transition-colors",
                filter === k
                  ? "border-brand/40 bg-brand/10 text-brand"
                  : "border-border bg-card text-muted-foreground hover:text-foreground",
              )}
            >
              {k === "all" ? "All activity" : ACTIVITY_KIND_META[k].label}
            </button>
          ))}
          {can("resetData") && activity.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="ml-auto text-muted-foreground"
              onClick={() => clearActivity()}
            >
              <Trash2 className="mr-1.5 size-3.5" /> Clear log
            </Button>
          )}
        </div>

        {/* Timeline */}
        {groups.length === 0 ? (
          <div className="rounded-lg border border-dashed border-border bg-card/50 p-10 text-center">
            <ShieldCheck className="mx-auto size-8 text-brand" />
            <p className="mt-3 text-[14px] font-semibold">No activity recorded yet</p>
            <p className="mx-auto mt-1 max-w-md text-[12.5px] leading-relaxed text-muted-foreground">
              As you model — creating scenarios, editing structure, importing data or exporting
              packs — the important actions appear here in plain language, ready for governance
              reviews.
            </p>
            <Button asChild size="sm" className="mt-4">
              <Link to="/dashboard">Open the programme dashboard</Link>
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            {groups.map(([day, events]) => (
              <section key={day}>
                <h2 className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                  {day}
                </h2>
                <ul className="mt-2 overflow-hidden rounded-lg border border-border bg-card shadow-panel">
                  {events.map((e, i) => {
                    const Icon = KIND_ICON[e.kind];
                    return (
                      <li
                        key={e.id}
                        className={cn(
                          "flex items-start gap-3 px-4 py-3",
                          i > 0 && "border-t border-border/60",
                        )}
                      >
                        <span
                          className={cn(
                            "mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-md",
                            KIND_CLASS[e.kind],
                          )}
                        >
                          <Icon className="size-3.5" />
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="text-[13px] leading-snug text-foreground">{e.message}</p>
                          <p className="mt-0.5 flex flex-wrap items-center gap-x-2 text-[11px] text-muted-foreground">
                            <span>{e.actor}</span>
                            <span aria-hidden>·</span>
                            <span>{ACTIVITY_KIND_META[e.kind].label}</span>
                            {e.scenarioName && (
                              <>
                                <span aria-hidden>·</span>
                                <span className="rounded-full bg-secondary px-1.5 py-px text-[10px] font-medium text-secondary-foreground">
                                  {e.scenarioName}
                                </span>
                              </>
                            )}
                          </p>
                        </div>
                        <span className="shrink-0 pt-1 text-[11px] tabular-nums text-muted-foreground">
                          {timeLabel(e.at)}
                        </span>
                      </li>
                    );
                  })}
                </ul>
              </section>
            ))}
          </div>
        )}

        <p className="max-w-2xl text-[11.5px] leading-relaxed text-muted-foreground">
          Your current workspace role is{" "}
          <span className={cn("rounded-full border px-1.5 py-px text-[10px] font-semibold", ROLE_META[role].badgeClass)}>
            {ROLE_META[role].label}
          </span>
          . The trail keeps the {120} most recent actions and is stored with the workspace in this
          browser. Server-side, tamper-evident audit logs ship with the cloud workspace — see{" "}
          <Link to="/auth" className="font-medium text-brand hover:underline">
            Workspace access
          </Link>
          .
        </p>
      </div>
    </div>
  );
}
