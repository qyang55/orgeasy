import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  Lock,
  Database,
  Trash2,
  Globe2,
  FileWarning,
  UserCheck,
  ScrollText,
  Download,
  ShieldCheck,
} from "lucide-react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { Button } from "@/components/ui/button";
import { ConsentPreferences } from "@/components/orgeasy/ConsentControls";
import { DeleteMyDataDialog } from "@/components/orgeasy/DeleteMyDataDialog";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { downloadBlob } from "@/lib/orgeasy/csv";
import { loadPresets, savePresets } from "@/lib/orgeasy/filter-presets";
import {
  ERASURE_LOG_KEY,
  clearErasureLog,
  erasureLogToText,
  readErasureLog,
  recordErasure,
  subscribeErasureLog,
  type ErasureEntry,
} from "@/lib/orgeasy/erasure-log";

const VERIFY_STEPS = [
  "Reload this page — the workspace restarts from the built-in demo scenario, so nothing you entered can reappear.",
  "Open your browser devtools (F12) → Application (Chrome/Edge) or Storage (Firefox) → Local Storage → this site, and confirm no orgeasy.workspace.v1 or orgeasy.people.presets.v1 key is listed.",
  "Run window.localStorage.getItem('orgeasy.workspace.v1') in the devtools console — it must return null.",
  "Check the People & Roles page: names, photos, costs and ADKAR scores you entered are gone.",
  "Remember exported PPTX, PDF, PNG and CSV files live outside the browser — delete those from your device, mail and shared drives separately.",
];

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy & Data Protection — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "How Organisation Strategy Studio handles employee data: local browser storage, data minimisation, retention controls and data-subject rights support.",
      },
      { property: "og:title", content: "Privacy & Data Protection — Organisation Strategy Studio" },
      {
        property: "og:description",
        content:
          "Data protection notice for Organisation Strategy Studio: what personal data is processed, where it is stored, and how to erase it.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Privacy,
});

const FACTS = [
  {
    icon: Database,
    title: "Where your data lives",
    body: "Scenarios, roles, photos and ADKAR scores are stored in this browser's local storage on your own device. Organisation Strategy Studio does not upload employee records to a Studio-operated server, and no analytics profile is built from them.",
  },
  {
    icon: Lock,
    title: "Who can see it",
    body: "Only people with access to this browser profile. Anyone you share an exported PPTX, PDF, PNG or CSV with also receives whatever personal data those files contain.",
  },
  {
    icon: Globe2,
    title: "Cross-border transfers",
    body: "Because records stay on your device, restructuring data is not transferred by Organisation Strategy Studio to another country. If you email or upload an export, your organisation is responsible for that transfer and any required safeguards.",
  },
  {
    icon: UserCheck,
    title: "Data-subject rights",
    body: "Access, correction, erasure and objection requests are handled on the People & Roles page (edit or delete the record) and with the erase control below. Requests reach your organisation, not Organisation Strategy Studio.",
  },
];

function Privacy() {
  const { workspace, resetDemoData } = useOrgEasy();
  const [confirming, setConfirming] = useState(false);
  const [log, setLog] = useState<ErasureEntry[]>([]);

  useEffect(() => {
    setLog(readErasureLog());
    return subscribeErasureLog(setLog);
  }, []);

  const eraseNow = (reason: string) => {
    const scenarios = workspace.scenarios ?? [];
    const roles = scenarios.flatMap((s) => s.employees ?? []);
    const savedViews = loadPresets().length;
    const keysCleared = ["orgeasy.workspace.v1"];
    if (savedViews) keysCleared.push("orgeasy.people.presets.v1");

    savePresets([]);
    resetDemoData();
    recordErasure({
      reason,
      removed: {
        scenarios: scenarios.length,
        roles: roles.length,
        namedPeople: roles.filter((r) => (r.name ?? "").trim().length > 0).length,
        photos: roles.filter((r) => Boolean(r.photoUrl)).length,
        adkarGroups: scenarios.reduce((n, s) => n + (s.adkarGroups?.length ?? 0), 0),
        savedViews,
      },
      keysCleared,
      keysRemaining: ["orgeasy.consent.v1 (your consent choice)", `${ERASURE_LOG_KEY} (this log)`],
    });
  };

  return (
    <div className="pb-16">
      <PageHeader
        title="Privacy & data protection"
        description="This page is maintained by the organisation operating Organisation Strategy Studio. It explains how the tool processes personal data so your restructuring work stays defensible."
      />

      <div className="space-y-8 px-8 py-6">
        <div className="flex gap-3 rounded-md border border-info/40 bg-info/10 px-4 py-3">
          <FileWarning className="mt-0.5 size-4 shrink-0 text-info" />
          <p className="text-[12.5px] leading-relaxed text-foreground">
            <span className="font-semibold">Not a certification. </span>
            Organisation Strategy Studio describes the controls this tool provides. It is not a legal opinion, an audit
            outcome, or a statement that your organisation complies with any specific law. Your
            privacy, legal and works-council advisers must approve how you use employee data here.
          </p>
        </div>

        <section className="grid gap-4 md:grid-cols-2">
          {FACTS.map((f) => (
            <div key={f.title} className="rounded-lg border border-border bg-card p-5 shadow-panel">
              <div className="flex items-center gap-2">
                <f.icon className="size-4 text-brand" />
                <h2 className="text-[14px] font-semibold tracking-tight">{f.title}</h2>
              </div>
              <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">{f.body}</p>
            </div>
          ))}
        </section>

        <section className="rounded-lg border border-border bg-card p-6 shadow-panel">
          <h2 className="text-[15px] font-semibold tracking-tight">
            What personal data Organisation Strategy Studio processes
          </h2>
          <div className="mt-4 overflow-hidden rounded-md border border-border">
            <table className="w-full text-[12.5px]">
              <thead className="bg-muted/60 text-left text-muted-foreground">
                <tr>
                  <th className="px-3 py-2 font-semibold">Category</th>
                  <th className="px-3 py-2 font-semibold">Examples</th>
                  <th className="px-3 py-2 font-semibold">Why it is needed</th>
                </tr>
              </thead>
              <tbody>
                {[
                  [
                    "Identification",
                    "Name, employee ID, optional photo",
                    "To place a person on the chart. All three are optional — use role titles or open-role placeholders instead where possible.",
                  ],
                  [
                    "Employment",
                    "Job title, department, manager, employment type, service months, country",
                    "Reporting structure, span-of-control and Country Guidance.",
                  ],
                  [
                    "Cost",
                    "Fully loaded cost per role",
                    "Headcount and budget impact modelling. Band or averaged figures are sufficient.",
                  ],
                  [
                    "Change readiness",
                    "ADKAR scores per stakeholder group",
                    "Assessed at group level, not individual level, to avoid profiling.",
                  ],
                ].map((row) => (
                  <tr key={row[0]} className="border-t border-border align-top">
                    <td className="px-3 py-2.5 font-medium">{row[0]}</td>
                    <td className="px-3 py-2.5 text-muted-foreground">{row[1]}</td>
                    <td className="px-3 py-2.5 text-muted-foreground">{row[2]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-3 text-[12px] text-muted-foreground">
            Never enter special-category data (health, disability, union membership, ethnicity,
            religion, performance ratings or disciplinary history) into Organisation Strategy Studio. The tool has no
            field for it, and restructuring selection criteria that rely on it create significant
            legal exposure.
          </p>
        </section>

        <ConsentPreferences />

        <section className="rounded-lg border border-destructive/40 bg-destructive/5 p-6">
          <h2 className="flex items-center gap-2 text-[15px] font-semibold tracking-tight">
            <Trash2 className="size-4 text-destructive" /> Retention & erasure
          </h2>
          <p className="mt-2 max-w-3xl text-[13px] leading-relaxed text-muted-foreground">
            Keep restructuring data only while the project needs it. Use <span className="font-semibold text-foreground">Delete my data</span>{" "}
            for a full, verified removal: choose exactly what goes (workspace records, saved views,
            chart preferences, pinned notes, consent choice, audit log), optionally download a backup
            first, then receive a completion receipt confirming each storage key is gone. There is no
            Organisation Strategy Studio account or server-side profile to delete separately. The quick reset simply
            returns this browser to the built-in demo workspace.
          </p>
          <div className="mt-4 flex items-center gap-3">
            <DeleteMyDataDialog />
            <Button
              variant={confirming ? "destructive" : "outline"}
              onClick={() => {
                if (!confirming) {
                  setConfirming(true);
                  return;
                }
                eraseNow("Manual erase from Privacy & data protection page");
                setConfirming(false);
                toast.success("Local workspace data erased and reset");
              }}
            >
              {confirming ? "Confirm: quick reset to demo data" : "Quick reset to demo data"}
            </Button>
            {confirming ? (
              <Button variant="ghost" onClick={() => setConfirming(false)}>
                Cancel
              </Button>
            ) : null}
          </div>
        </section>

        <section className="rounded-lg border border-border bg-card p-6 shadow-panel">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h2 className="flex items-center gap-2 text-[15px] font-semibold tracking-tight">
                <ScrollText className="size-4 text-brand" /> Erasure audit log
              </h2>
              <p className="mt-2 max-w-3xl text-[13px] leading-relaxed text-muted-foreground">
                Every erasure run from this page is recorded here with a timestamp and what was
                removed. The log stores counts only — no names, photos or costs — and is kept
                outside the workspace record so it survives the wipe it evidences.
              </p>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={!log.length}
                onClick={() =>
                  downloadBlob(
                    erasureLogToText(log),
                    "orgeasy-erasure-log.txt",
                    "text/plain",
                  )
                }
              >
                <Download className="mr-1.5 size-3.5" /> Export log
              </Button>
              <Button
                variant="ghost"
                size="sm"
                disabled={!log.length}
                onClick={() => {
                  setLog(clearErasureLog());
                  toast.success("Erasure log cleared");
                }}
              >
                Clear log
              </Button>
            </div>
          </div>

          {log.length ? (
            <ol className="mt-5 space-y-3">
              {log.map((e, index) => (
                <li key={e.id} className="rounded-md border border-border bg-muted/30 p-4">
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <p className="text-[13.5px] font-semibold">
                      {new Date(e.at).toLocaleString()}
                      {index === 0 ? (
                        <span className="ml-2 rounded bg-brand/10 px-1.5 py-0.5 text-[10.5px] font-semibold uppercase tracking-wide text-brand">
                          Most recent
                        </span>
                      ) : null}
                    </p>
                    <p className="text-[11.5px] text-muted-foreground">{e.reason}</p>
                  </div>
                  <div className="mt-3 grid gap-2 sm:grid-cols-3 lg:grid-cols-6">
                    {[
                      ["Scenarios", e.removed.scenarios],
                      ["Role records", e.removed.roles],
                      ["Named individuals", e.removed.namedPeople],
                      ["Photos", e.removed.photos],
                      ["ADKAR groups", e.removed.adkarGroups],
                      ["Saved views", e.removed.savedViews],
                    ].map(([label, value]) => (
                      <div key={label as string} className="rounded border border-border bg-card px-3 py-2">
                        <p className="text-[16px] font-semibold tabular-nums">{value as number}</p>
                        <p className="text-[11px] text-muted-foreground">{label as string}</p>
                      </div>
                    ))}
                  </div>
                  <p className="mt-3 text-[11.5px] text-muted-foreground">
                    <span className="font-semibold text-foreground">Storage cleared: </span>
                    {e.keysCleared.join(" · ") || "none"}
                  </p>
                  <p className="mt-1 text-[11.5px] text-muted-foreground">
                    <span className="font-semibold text-foreground">Retained by design: </span>
                    {e.keysRemaining.join(" · ")}
                  </p>
                </li>
              ))}
            </ol>
          ) : (
            <p className="mt-5 rounded-md border border-dashed border-border px-4 py-6 text-center text-[12.5px] text-muted-foreground">
              No erasure has been recorded in this browser yet. Use the control above and the entry
              will appear here with a timestamp and removal counts.
            </p>
          )}

          <div className="mt-6 rounded-md border border-info/40 bg-info/10 p-4">
            <h3 className="flex items-center gap-2 text-[13.5px] font-semibold">
              <ShieldCheck className="size-4 text-info" /> How to verify the data is gone
            </h3>
            <ol className="mt-2 list-decimal space-y-1.5 pl-5 text-[12.5px] leading-relaxed text-muted-foreground">
              {VERIFY_STEPS.map((step) => (
                <li key={step}>{step}</li>
              ))}
            </ol>
          </div>
        </section>
      </div>
    </div>
  );
}