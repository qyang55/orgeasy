import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ShieldCheck, ClipboardCheck, Scale, Users2 } from "lucide-react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { Disclaimer } from "@/components/orgeasy/Disclaimer";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/compliance")({
  head: () => ({
    meta: [
      { title: "Compliance Centre — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Data protection and employment-law readiness checklist for restructuring: GDPR, UK, US, APAC and LATAM obligations, consultation duties and record-keeping.",
      },
      { property: "og:title", content: "Compliance Centre — Organisation Strategy Studio" },
      {
        property: "og:description",
        content:
          "Track lawful basis, DPIA, minimisation, consultation and retention steps before you communicate a restructuring.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Compliance,
});

const CHECKLIST: { group: string; icon: typeof ShieldCheck; items: { id: string; label: string; detail: string }[] }[] = [
  {
    group: "Lawful processing",
    icon: Scale,
    items: [
      {
        id: "basis",
        label: "Lawful basis recorded for restructuring data",
        detail:
          "Most organisations rely on legitimate interests or performance of the employment contract — not consent, which employees cannot freely give.",
      },
      {
        id: "notice",
        label: "Employee privacy notice covers workforce planning",
        detail:
          "Confirm the existing HR privacy notice already discloses organisational design and restructuring analysis as a purpose.",
      },
      {
        id: "dpia",
        label: "DPIA / risk assessment completed for the programme",
        detail:
          "Required in the EU/UK where processing is likely to result in high risk to individuals — large-scale redundancy analysis usually qualifies.",
      },
      {
        id: "roles",
        label: "Controller / processor roles documented",
        detail:
          "Your organisation is the controller. Any consultancy, HRIS vendor or advisor receiving exports is a processor or separate controller and needs a written agreement.",
      },
    ],
  },
  {
    group: "Data minimisation",
    icon: ClipboardCheck,
    items: [
      {
        id: "minimal",
        label: "Only necessary fields imported from the HRIS",
        detail:
          "Import structure, cost and country. Leave out identifiers you do not need — role-level modelling is often enough until decisions are final.",
      },
      {
        id: "pseudo",
        label: "Pseudonymised or role-only data used in wide-audience decks",
        detail:
          "Use titles and open-role placeholders for steering-committee material; keep named views to the smallest possible group.",
      },
      {
        id: "special",
        label: "No special-category data entered",
        detail:
          "No health, disability, union membership, ethnicity, religion or performance/disciplinary data anywhere in the workspace.",
      },
      {
        id: "exports",
        label: "Export distribution list controlled and logged",
        detail:
          "PPTX, PDF, PNG and CSV exports carry personal data outside this tool. Track who received which version.",
      },
    ],
  },
  {
    group: "Employee & works-council duties",
    icon: Users2,
    items: [
      {
        id: "consult",
        label: "Collective consultation obligations checked per country",
        detail:
          "Works councils, unions and thresholds differ sharply (e.g. EU collective redundancy rules, US WARN, Thailand and Japan notice practice). See Country Separation.",
      },
      {
        id: "timing",
        label: "Communications sequenced after consultation starts",
        detail:
          "Announcing before required information and consultation can void the process and trigger penalties. Check the Communications page timing.",
      },
      {
        id: "criteria",
        label: "Selection criteria objective and documented",
        detail:
          "Criteria must be job-related and non-discriminatory; retain the reasoning behind each role decision.",
      },
      {
        id: "adverse",
        label: "Adverse-impact review completed",
        detail:
          "Check proposed reductions for disproportionate impact on protected groups, age bands or specific locations before finalising.",
      },
    ],
  },
  {
    group: "Security & retention",
    icon: ShieldCheck,
    items: [
      {
        id: "device",
        label: "Device and browser profile protected",
        detail:
          "Workspace data is stored in this browser. Use full-disk encryption, screen lock and a non-shared profile.",
      },
      {
        id: "retention",
        label: "Retention period defined for the programme",
        detail:
          "Set an end date and erase the workspace via Privacy & Data when the programme closes or the record is no longer needed.",
      },
      {
        id: "breach",
        label: "Breach response owner identified",
        detail:
          "Many regimes require notification within 72 hours. Know who to call if a laptop or deck leaks.",
      },
      {
        id: "rights",
        label: "Process in place for access and erasure requests",
        detail:
          "Employees may ask what restructuring data exists about them. Decide in advance who answers and how.",
      },
    ],
  },
];

const REGIMES = [
  { region: "EU / EEA", law: "GDPR + national employment law", note: "Lawful basis, DPIA, works-council information & consultation, collective redundancy thresholds." },
  { region: "United Kingdom", law: "UK GDPR, DPA 2018, TULRCA", note: "30/45-day collective consultation triggers; HR1 filing for large redundancies." },
  { region: "United States", law: "State privacy laws, WARN Act, EEO rules", note: "60-day WARN notice at scale; adverse-impact analysis on protected classes." },
  { region: "Canada", law: "PIPEDA / provincial acts", note: "Group termination notice and provincial severance minimums." },
  { region: "Brazil / LATAM", law: "LGPD and local labour codes", note: "Union involvement is common; strict severance formulas." },
  { region: "Singapore / Malaysia", law: "PDPA", note: "Retrenchment notification and fair-consideration expectations." },
  { region: "Thailand", law: "PDPA (Thailand)", note: "Statutory severance by service length; consent rarely valid for employees." },
  { region: "Japan / Korea", law: "APPI / PIPA", note: "High bar for dismissal; consultation and redeployment expected." },
  { region: "Australia / NZ", law: "Privacy Act, Fair Work Act", note: "Genuine redundancy tests and consultation obligations in awards." },
  { region: "India / Middle East", law: "DPDP Act and local labour law", note: "Government permissions may apply; end-of-service gratuity in the Gulf." },
  { region: "China", law: "PIPL", note: "Separate consent and localisation rules; mass-layoff plan filing." },
  { region: "South Africa", law: "POPIA, LRA s189", note: "Formal retrenchment consultation procedure required." },
];

function Compliance() {
  const [done, setDone] = useState<Set<string>>(new Set());
  const total = useMemo(() => CHECKLIST.reduce((n, g) => n + g.items.length, 0), []);

  const toggle = (id: string) =>
    setDone((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  return (
    <div className="pb-16">
      <PageHeader
        title="Compliance centre"
        description="A readiness checklist covering data protection and employment-law duties that typically apply to a restructuring programme. Work through it with your legal and privacy advisers before you communicate."
        actions={
          <div className="rounded-md border border-border bg-card px-3 py-2 text-[12px] shadow-panel">
            <span className="font-semibold text-brand">{done.size}</span>
            <span className="text-muted-foreground"> / {total} steps confirmed</span>
          </div>
        }
      />

      <div className="space-y-8 px-8 py-6">
        <Disclaimer />

        <section className="grid gap-5 lg:grid-cols-2">
          {CHECKLIST.map((group) => (
            <div key={group.group} className="rounded-lg border border-border bg-card p-5 shadow-panel">
              <div className="flex items-center gap-2">
                <group.icon className="size-4 text-brand" />
                <h2 className="text-[14px] font-semibold tracking-tight">{group.group}</h2>
              </div>
              <ul className="mt-3 space-y-3">
                {group.items.map((item) => {
                  const checked = done.has(item.id);
                  return (
                    <li key={item.id} className="flex gap-3">
                      <Checkbox
                        id={item.id}
                        checked={checked}
                        onCheckedChange={() => toggle(item.id)}
                        className="mt-0.5"
                      />
                      <label htmlFor={item.id} className="cursor-pointer">
                        <span
                          className={cn(
                            "block text-[13px] font-medium leading-snug",
                            checked && "text-muted-foreground line-through",
                          )}
                        >
                          {item.label}
                        </span>
                        <span className="mt-0.5 block text-[12px] leading-relaxed text-muted-foreground">
                          {item.detail}
                        </span>
                      </label>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </section>

        <section className="rounded-lg border border-border bg-card p-6 shadow-panel">
          <h2 className="text-[15px] font-semibold tracking-tight">
            Regimes to check by region
          </h2>
          <p className="mt-1 text-[12.5px] text-muted-foreground">
            Indicative only — obligations depend on entity, headcount and local agreements.
          </p>
          <div className="mt-4 overflow-hidden rounded-md border border-border">
            <table className="w-full text-[12.5px]">
              <thead className="bg-muted/60 text-left text-muted-foreground">
                <tr>
                  <th className="px-3 py-2 font-semibold">Region</th>
                  <th className="px-3 py-2 font-semibold">Key frameworks</th>
                  <th className="px-3 py-2 font-semibold">Watch for</th>
                </tr>
              </thead>
              <tbody>
                {REGIMES.map((r) => (
                  <tr key={r.region} className="border-t border-border align-top">
                    <td className="px-3 py-2.5 font-medium">{r.region}</td>
                    <td className="px-3 py-2.5 text-muted-foreground">{r.law}</td>
                    <td className="px-3 py-2.5 text-muted-foreground">{r.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  );
}