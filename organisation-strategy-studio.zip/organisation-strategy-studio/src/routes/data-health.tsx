import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ShieldCheck, Wrench, AlertOctagon, ListChecks, Sparkles, ArrowRight } from "lucide-react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { StatCard } from "@/components/orgeasy/StatCard";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useOrgEasy } from "@/lib/orgeasy/store";
import {
  HEALTH_SEVERITY_META,
  analyseDataHealth,
  applyAllHealthFixes,
  applyHealthFix,
  type HealthIssue,
} from "@/lib/orgeasy/data-health";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/data-health")({
  head: () => ({
    meta: [
      { title: "Workforce Data Health — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Validate position data before you analyse it: orphaned roles, broken reporting lines, missing markets, missing cost and span outliers, with one-click repairs.",
      },
      { property: "og:title", content: "Workforce Data Health — Organisation Strategy Studio" },
      {
        property: "og:description",
        content:
          "A readiness pass over the active scenario: completeness scoring, critical structural errors and deterministic fixes.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DataHealthPage,
});

function IssueCard({
  issue,
  onFix,
  onInspect,
  expanded,
}: {
  issue: HealthIssue;
  onFix: () => void;
  onInspect: () => void;
  expanded: boolean;
}) {
  const meta = HEALTH_SEVERITY_META[issue.severity];
  return (
    <li className="px-5 py-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span
              className="rounded-full px-2 py-0.5 text-[10.5px] font-semibold uppercase tracking-wide"
              style={{ backgroundColor: `#${meta.hex}1F`, color: `#${meta.hex}` }}
            >
              {meta.label}
            </span>
            <p className="truncate text-[13.5px] font-semibold">{issue.title}</p>
          </div>
          <p className="mt-1.5 text-[12.5px] leading-relaxed text-muted-foreground">{issue.detail}</p>
          {issue.fixNote ? (
            <p className="mt-1 text-[11.5px] italic text-muted-foreground">{issue.fixNote}</p>
          ) : null}
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <div className="text-right">
            <p className="text-[15px] font-semibold leading-none">{issue.roleIds.length}</p>
            <p className="mt-0.5 text-[11px] text-muted-foreground">
              roles · {issue.positions} FTE
            </p>
          </div>
          <Button size="sm" variant="ghost" onClick={onInspect}>
            {expanded ? "Hide" : "Inspect"}
          </Button>
          {issue.fixable ? (
            <Button size="sm" variant="outline" onClick={onFix}>
              <Wrench className="mr-1.5 size-3.5" /> {issue.fixLabel ?? "Fix"}
            </Button>
          ) : (
            <span className="rounded-md bg-secondary px-2 py-1 text-[11px] text-muted-foreground">
              Manual review
            </span>
          )}
        </div>
      </div>
      {expanded ? (
        <div className="mt-3 rounded-md bg-secondary/60 px-3 py-2 text-[11.5px] text-muted-foreground">
          <span className="font-semibold text-foreground">Affected IDs: </span>
          {issue.roleIds.slice(0, 40).join(", ")}
          {issue.roleIds.length > 40 ? ` … +${issue.roleIds.length - 40} more` : ""}
        </div>
      ) : null}
    </li>
  );
}

function DataHealthPage() {
  const { scenario, replaceEmployees } = useOrgEasy();
  const report = useMemo(() => analyseDataHealth(scenario), [scenario]);
  const [openId, setOpenId] = useState<string | null>(null);

  const fixOne = (issue: HealthIssue) => {
    if (!scenario) return;
    const before = scenario.employees.length;
    replaceEmployees(applyHealthFix(scenario.employees, issue.id));
    toast.success(`${issue.fixLabel ?? "Fixed"} — ${issue.roleIds.length} roles updated`, {
      description: `${before} rows checked in “${scenario.name}”.`,
    });
  };

  const fixAll = () => {
    if (!scenario) return;
    const fixable = report.issues.filter((i) => i.fixable);
    if (!fixable.length) {
      toast.info("Nothing left to fix automatically");
      return;
    }
    replaceEmployees(applyAllHealthFixes(scenario.employees, report.issues));
    toast.success(`${fixable.length} issue types repaired`, {
      description: "Structural errors, blanks and negative values cleaned in one pass.",
    });
  };

  return (
    <div className="pb-12">
      <PageHeader
        title="Workforce data health"
        description="Run a readiness pass over the active scenario before you trust any span, cost or scenario number. Deterministic problems can be repaired here; judgement calls are flagged for review."
        actions={
          <Button onClick={fixAll} disabled={!report.fixableCount}>
            <Sparkles className="mr-1.5 size-4" /> Repair {report.fixableCount || "all"} fixable
          </Button>
        }
      />

      <div className="space-y-6 px-8 py-6">
        <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
          <StatCard
            label="Data health score"
            value={`${report.score}%`}
            tone={
              report.band.tone === "positive"
                ? "positive"
                : report.band.tone === "negative"
                  ? "negative"
                  : "brand"
            }
            sub={report.band.label}
            icon={<ShieldCheck className="size-4" />}
          />
          <StatCard
            label="Rows checked"
            value={report.totalRoles.toLocaleString()}
            sub={`${report.totalPositions.toLocaleString()} positions · ${report.roots} top-level role${report.roots === 1 ? "" : "s"}`}
            icon={<ListChecks className="size-4" />}
          />
          <StatCard
            label="Blocking errors"
            value={report.criticalCount.toLocaleString()}
            tone={report.criticalCount ? "negative" : "positive"}
            sub="Break hierarchy, cost or diff logic"
            icon={<AlertOctagon className="size-4" />}
          />
          <StatCard
            label="Auto-repairable"
            value={report.fixableCount.toLocaleString()}
            tone="brand"
            sub={`${report.warningCount} warnings need a decision`}
            icon={<Wrench className="size-4" />}
          />
        </div>

        <section className="rounded-lg border border-border bg-card p-5 shadow-panel">
          <h2 className="text-sm font-semibold">Field completeness</h2>
          <p className="mt-1 text-[12.5px] text-muted-foreground">
            Every downstream model depends on these six fields. Anything below 100% understates or
            distorts the result.
          </p>
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {report.completeness.map((c) => {
              const pct = c.total ? (c.filled / c.total) * 100 : 0;
              return (
                <div key={c.label}>
                  <div className="flex items-baseline justify-between">
                    <p className="text-[12.5px] font-medium">{c.label}</p>
                    <p
                      className={cn(
                        "text-[12.5px] font-semibold",
                        pct === 100 ? "text-success" : pct >= 80 ? "text-foreground" : "text-destructive",
                      )}
                    >
                      {pct.toFixed(0)}%
                    </p>
                  </div>
                  <Progress value={pct} className="mt-1.5 h-1.5" />
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    {c.filled.toLocaleString()} of {c.total.toLocaleString()} rows
                  </p>
                </div>
              );
            })}
          </div>
        </section>

        <section className="rounded-lg border border-border bg-card shadow-panel">
          <div className="flex items-center justify-between border-b border-border px-5 py-3.5">
            <h2 className="text-sm font-semibold">Findings</h2>
            <p className="text-xs text-muted-foreground">
              {report.issues.length} issue type{report.issues.length === 1 ? "" : "s"} found
            </p>
          </div>
          {report.issues.length ? (
            <ul className="divide-y divide-border">
              {report.issues.map((issue) => (
                <IssueCard
                  key={issue.id}
                  issue={issue}
                  expanded={openId === issue.id}
                  onInspect={() => setOpenId((cur) => (cur === issue.id ? null : issue.id))}
                  onFix={() => fixOne(issue)}
                />
              ))}
            </ul>
          ) : (
            <p className="px-5 py-8 text-center text-[13px] text-muted-foreground">
              No issues found — this scenario is analysis-ready.
            </p>
          )}
        </section>

        <div className="flex flex-wrap gap-2">
          <Button asChild variant="outline">
            <Link to="/people">
              Edit positions <ArrowRight className="ml-1.5 size-4" />
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link to="/chart">
              Re-parent on the chart <ArrowRight className="ml-1.5 size-4" />
            </Link>
          </Button>
          <Button asChild variant="ghost">
            <Link to="/data-input">Load different data</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
