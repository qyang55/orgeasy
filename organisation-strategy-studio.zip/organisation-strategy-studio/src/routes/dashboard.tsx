import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  Users,
  Network,
  Layers,
  Bot,
  CopyMinus,
  UserMinus,
  ArrowRight,
  Copy,
  Trash2,
  AlertTriangle,
  ClipboardCheck,
  Columns3,
} from "lucide-react";
import { CommandBand, CommandTile } from "@/components/orgeasy/CommandBand";
import { Disclaimer } from "@/components/orgeasy/Disclaimer";
import { GettingStarted } from "@/components/orgeasy/GettingStarted";
import { dismissFirstRun, isFirstRun } from "@/lib/orgeasy/first-run";
import { startGuidedDemo } from "@/lib/orgeasy/guided-demo";
import { CURRENT_STATE_ID } from "@/lib/orgeasy/seed";
import { resolveBaseline } from "@/lib/orgeasy/phases";
import {
  SEVERITY_META,
  buildChangePlan,
  loadChangeEdits,
  mergedActions,
  planProgress,
  readinessBand,
  readinessScore,
} from "@/lib/orgeasy/change-plan";
import { PhaseOrderList } from "@/components/orgeasy/PhaseOrderList";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { computeImpact, formatMoney } from "@/lib/orgeasy/impact";
import { computeProgramme } from "@/lib/orgeasy/levers";
import type { ReductionLever } from "@/lib/orgeasy/types";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/dashboard")({
  validateSearch: (search: Record<string, unknown>): { demo?: "guided" } =>
    search["demo"] === "guided" ? { demo: "guided" } : {},
  head: () => ({
    meta: [
      { title: "Organisation Options Dashboard — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Explore current-state and future-state organisation options. Compare structure, cost, capability and risk trade-offs to support leadership decisions.",
      },
      {
        property: "og:title",
        content: "Organisation Options Dashboard — Organisation Strategy Studio",
      },
      {
        property: "og:description",
        content:
          "Rapid scenario exploration for organisation design: compare current and future options across headcount, cost, capability and risk.",
      },
      { property: "og:type", content: "website" },
    ],
  }),
  component: Overview,
});

const LEVER_ICONS: Record<ReductionLever, typeof Users> = {
  headcount: UserMinus,
  span: Layers,
  duplicate: CopyMinus,
  automation: Bot,
  agent: Bot,
};

const LEVER_LINKS: Record<ReductionLever, string> = {
  headcount: "/people",
  span: "/span",
  duplicate: "/span",
  automation: "/automation",
  agent: "/automation",
};

const QUICK_LINKS = [
  { to: "/scenario-compare", label: "Compare scenarios side by side", icon: Columns3, copy: "Current state vs up to two options" },
  { to: "/span", label: "Span, layers & duplicates", icon: Layers, copy: "Delayering and structural choices" },
  { to: "/automation", label: "AI & work redesign", icon: Bot, copy: "Which work shifts to agents, and what people do instead" },
  { to: "/chart", label: "Org chart designer", icon: Network, copy: "Design future structures" },
] as const;

function Overview() {
  const { workspace, scenario, setActiveScenario, createScenario, deleteScenario } = useOrgEasy();
  const [firstRun, setFirstRun] = useState(false);
  useEffect(() => setFirstRun(isFirstRun()), []);

  // Landing CTAs ("Start free" / "Open the studio") arrive with ?demo=guided —
  // kick off the 3-step guided demo once and hand over to the demo bar.
  const search = Route.useSearch();
  const demoStartedRef = useRef(false);
  useEffect(() => {
    if (search.demo !== "guided" || demoStartedRef.current) return;
    demoStartedRef.current = true;
    startGuidedDemo();
    setActiveScenario(CURRENT_STATE_ID);
    toast.success("Guided demo started", {
      description: "Three pre-built scenarios — follow the bar at the bottom of the screen.",
    });
  }, [search.demo, setActiveScenario]);
  const showGettingStarted = firstRun || !scenario;
  const programme = computeProgramme(workspace, scenario ?? null);
  const impact = computeImpact(scenario);
  const cur = programme.currency;

  const changeBaseline = resolveBaseline(workspace.scenarios, scenario);
  const changePlan = buildChangePlan(scenario, changeBaseline);
  const changeActions = mergedActions(changePlan, loadChangeEdits(scenario?.id));
  const changeReadiness = readinessScore(changePlan, changeActions);
  const changeBand = readinessBand(changeReadiness);
  const topImpactGroups = changePlan.groups.slice(0, 3);

  const targetProgress = programme.targetReduction
    ? Math.min(100, (programme.achievedReduction / programme.targetReduction) * 100)
    : 0;
  const maxLever = Math.max(1, ...programme.levers.map((l) => l.positions));

  return (
    <div className="pb-12">
      <CommandBand
        eyebrow="Strategic modelling engine"
        title="Organisation"
        titleAccent="options dashboard"
        description={`Design the future organisation for ${programme.baselineHeadcount.toLocaleString()} current-state positions: weigh structure, capability, cost and risk across demand discipline, span of control, duplicate work, AI-led work redesign and new capability you choose to build.`}
        status={scenario ? "Scenario active" : "No scenario"}
        actions={
          <div className="flex gap-2">
            <Link
              to="/decision"
              className="inline-flex items-center rounded-md border border-border bg-card px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
            >
              <ClipboardCheck className="mr-1.5 size-4" /> Decision summary
            </Link>
            <Link
              to="/exports"
              className="inline-flex items-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Generate PowerPoint <ArrowRight className="ml-1.5 size-4" />
            </Link>
          </div>
        }
      >
        <CommandTile
          label="Current-state positions"
          value={programme.baselineHeadcount.toLocaleString()}
          unit="positions"
          sub={`${impact.byDepartment.length} functions · ${impact.byCountry.length} countries`}
        />
        <CommandTile
          label="Future-state option"
          value={programme.finalHeadcount.toLocaleString()}
          unit="target"
          tone="violet"
          progress={
            programme.baselineHeadcount
              ? (programme.finalHeadcount / programme.baselineHeadcount) * 100
              : 0
          }
          sub={`${programme.grossRemovals} role reductions · ${programme.rolesAdded} new capability roles`}
        />
        <CommandTile
          label="Headcount shift"
          value={`${(programme.achievedPct * 100).toFixed(1)}%`}
          tone={programme.achievedReduction >= programme.targetReduction ? "mint" : "alert"}
          trend={programme.achievedReduction >= 0 ? "down" : "up"}
          progress={targetProgress}
          sub={`${programme.achievedReduction} of ${programme.targetReduction} positions vs option target`}
        />
        <CommandTile
          label="Annual people cost impact"
          value={formatMoney(programme.costSaving, cur)}
          tone="mint"
          trend="down"
          progress={
            programme.baselineCost
              ? Math.min(100, (Math.abs(programme.costSaving) / programme.baselineCost) * 100)
              : 0
          }
          span={4}
          sub={`Current ${formatMoney(programme.baselineCost, cur)} → option ${formatMoney(programme.finalCost, cur)}`}
        />
        <CommandTile
          label="Transition cost estimate"
          value={formatMoney(programme.separationMid, cur)}
          tone="alert"
          span={10}
          wide
          range={{
            low: programme.separationLow,
            mid: programme.separationMid,
            high: programme.separationHigh,
            lowLabel: `Low ${formatMoney(programme.separationLow, cur)}`,
            highLabel: `High ${formatMoney(programme.separationHigh, cur)}`,
            midLabel: "Mid-point estimate",
          }}
          sub={`${programme.separationExits} exits${programme.highRiskMarkets.length ? ` · ${programme.highRiskMarkets.length} high-risk market${programme.highRiskMarkets.length === 1 ? "" : "s"}` : ""}`}
        />
      </CommandBand>

      <div className="space-y-6 px-8 py-6">
        {showGettingStarted ? (
          <GettingStarted
            onDismiss={
              firstRun
                ? () => {
                    dismissFirstRun();
                    setFirstRun(false);
                  }
                : undefined
            }
          />
        ) : null}
        <Disclaimer />

        {/* Leadership decision summary */}
        {impact.newRoles.length ? (
          <section className="rounded-lg border border-info/40 bg-info/5 p-5">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="max-w-2xl">
                <p className="text-[11px] font-semibold uppercase tracking-wider text-info">
                  New capability being built
                </p>
                <p className="mt-1.5 text-[15px] font-semibold">
                  {impact.newRoles.reduce((a, e) => a + e.plannedHeadcount, 0).toLocaleString()}{" "}
                  positions in {impact.newRoles.length} new capability role
                  {impact.newRoles.length === 1 ? "" : "s"}
                </p>
                <p className="mt-1 text-[13px] text-muted-foreground">
                  This option builds capability as well as changing cost — these roles are what the
                  organisation gains, and they need hiring and onboarding plans of their own.
                </p>
                <ul className="mt-3 flex flex-wrap gap-2">
                  {impact.newRoles.slice(0, 6).map((e) => (
                    <li
                      key={e.id}
                      className="rounded border border-info/40 bg-card px-2.5 py-1 text-[12px] font-medium"
                    >
                      {e.title}
                      <span className="ml-1.5 text-muted-foreground">
                        ×{e.plannedHeadcount} · {e.country}
                      </span>
                    </li>
                  ))}
                  {impact.newRoles.length > 6 ? (
                    <li className="px-1 py-1 text-[12px] text-muted-foreground">
                      +{impact.newRoles.length - 6} more
                    </li>
                  ) : null}
                </ul>
              </div>
              <Button asChild variant="outline">
                <Link to="/hiring">
                  Hiring pipeline <ArrowRight className="ml-1.5 size-4" />
                </Link>
              </Button>
            </div>
          </section>
        ) : null}

        <Link
          to="/decision"
          className="block rounded-lg border border-brand/40 bg-brand/5 p-5 transition-colors hover:bg-brand/10"
        >
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="max-w-2xl">
              <p className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wider text-brand">
                <ClipboardCheck className="size-3.5" /> For the leadership meeting
              </p>
              <p className="mt-1.5 text-[15px] font-semibold">Decision summary — one page, plain language</p>
              <p className="mt-1 text-[13px] text-muted-foreground">
                What is changing, why, the key numbers, the trade-offs across structure, cost,
                capability and risk, top risks to watch and the recommended next step. Copy as text
                or print to PDF.
              </p>
            </div>
            <span className="flex items-center gap-1.5 text-[13px] font-semibold text-brand">
              Open summary <ArrowRight className="size-4" />
            </span>
          </div>
        </Link>

        {/* Change readiness */}
        <div className="rounded-lg border border-border bg-card p-5 shadow-panel">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="max-w-2xl">
              <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                Change readiness
              </p>
              <div className="mt-1.5 flex items-baseline gap-3">
                <span
                  className={
                    changeBand.tone === "positive"
                      ? "text-3xl font-semibold text-success"
                      : changeBand.tone === "negative"
                        ? "text-3xl font-semibold text-destructive"
                        : "text-3xl font-semibold text-brand"
                  }
                >
                  {changeReadiness}%
                </span>
                <span className="text-[13px] font-medium text-muted-foreground">
                  {changeBand.label} · {planProgress(changeActions)}% of ADKAR actions complete
                </span>
              </div>
              <p className="mt-2 text-[13px] text-muted-foreground">{changePlan.headline}</p>
              {topImpactGroups.length ? (
                <div className="mt-3 flex flex-wrap gap-2">
                  {topImpactGroups.map((g) => (
                    <span
                      key={g.id}
                      className="rounded-full border px-2.5 py-1 text-[11px] font-semibold"
                      style={{
                        borderColor: `#${SEVERITY_META[g.severity].hex}55`,
                        color: `#${SEVERITY_META[g.severity].hex}`,
                      }}
                    >
                      {g.name} · {SEVERITY_META[g.severity].label}
                    </span>
                  ))}
                </div>
              ) : null}
            </div>
            <div className="flex flex-col items-end gap-2">
              <Button asChild variant="outline">
                <Link to="/change-plan">
                  Open change plan <ArrowRight className="ml-1.5 size-4" />
                </Link>
              </Button>
              <span className="text-[11px] text-muted-foreground">
                {changePlan.exits} exits · {changePlan.reassigned} reassigned ·{" "}
                {changePlan.spanChanges} span changes
              </span>
            </div>
          </div>
        </div>

        {programme.highRiskMarkets.length ? (
          <div className="rounded-lg border border-destructive/40 bg-destructive/5 px-5 py-4">
            <p className="flex items-center gap-2 text-[13px] font-semibold text-destructive">
              <AlertTriangle className="size-4" /> Consultation risk to plan for
            </p>
            <ul className="mt-2 grid gap-1.5 md:grid-cols-2">
              {programme.highRiskMarkets.slice(0, 6).map((c) => (
                <li key={c.country} className="text-[12px] text-muted-foreground">
                  <span className="font-medium text-foreground">{c.country}</span> · {c.exits} exits
                  · {formatMoney(c.mid, cur)} — {c.rule.riskNote}
                </li>
              ))}
            </ul>
            <p className="mt-2 text-[11.5px] text-muted-foreground">
              Full country cost rules and per-scenario overrides live on the Headcount &amp; cost
              impact page.
            </p>
          </div>
        ) : null}

        {/* Target tracker */}
        <section className="rounded-lg border border-border bg-card p-5 shadow-panel">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <h2 className="text-sm font-semibold">Headcount trajectory</h2>
              <p className="mt-1 text-[12.5px] text-muted-foreground">
                {programme.achievedReduction} of {programme.targetReduction} positions planned across{" "}
                {programme.phases.length} phased options.
              </p>
            </div>
            <p className="text-2xl font-semibold tracking-tight">
              {programme.baselineHeadcount.toLocaleString()}{" "}
              <span className="text-muted-foreground">→</span>{" "}
              <span className="text-brand">{programme.finalHeadcount.toLocaleString()}</span>
            </p>
          </div>
          <Progress value={targetProgress} className="mt-4 h-2.5" />
          <div className="mt-4 grid gap-3 sm:grid-cols-4">
            {programme.levers.map((l) => {
              const share = programme.grossRemovals
                ? (l.positions / programme.grossRemovals) * 100
                : 0;
              return (
                <div
                  key={l.lever}
                  className="rounded-md bg-secondary px-3 py-2.5 text-xs text-muted-foreground"
                >
                  <p className="font-semibold text-foreground">
                    {l.positions} <span className="font-normal">positions</span>
                  </p>
                  <p className="mt-0.5">
                    {l.short} · {share.toFixed(0)}% of option mix
                  </p>
                </div>
              );
            })}
          </div>
        </section>

        {/* Lever breakdown */}
        <section className="rounded-lg border border-border bg-card shadow-panel">
          <div className="flex items-center justify-between border-b border-border px-5 py-3.5">
            <h2 className="text-sm font-semibold">Transformation levers</h2>
            <p className="text-xs text-muted-foreground">
              {programme.grossRemovals} gross position changes
            </p>
          </div>
          <ul className="divide-y divide-border">
            {programme.levers.map((l) => {
              const Icon = LEVER_ICONS[l.lever];
              return (
                <li key={l.lever} className="flex items-center gap-4 px-5 py-4">
                  <span
                    className="grid size-10 shrink-0 place-items-center rounded-md"
                    style={{ backgroundColor: `#${l.hex}1F`, color: `#${l.hex}` }}
                  >
                    <Icon className="size-5" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-baseline gap-2">
                      <p className="truncate text-[13.5px] font-semibold">{l.label}</p>
                      <Link
                        to={LEVER_LINKS[l.lever]}
                        className="shrink-0 text-xs text-brand hover:underline"
                      >
                        Open analysis
                      </Link>
                    </div>
                    <p className="truncate text-xs text-muted-foreground">{l.description}</p>
                    <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${(l.positions / maxLever) * 100}%`,
                          backgroundColor: `#${l.hex}`,
                        }}
                      />
                    </div>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="text-lg font-semibold leading-none">{l.positions}</p>
                    <p className="mt-1 text-xs text-success">
                      {formatMoney(l.cost, cur)} <span className="text-muted-foreground">/yr</span>
                    </p>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>

        {/* Phase waterfall */}
        <section className="rounded-lg border border-border bg-card shadow-panel">
          <div className="border-b border-border px-5 py-3.5">
            <h2 className="text-sm font-semibold">Phased delivery options</h2>
            <p className="mt-0.5 text-xs text-muted-foreground">
              Cumulative position count and lever mix for each phase of the option.
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-secondary/60 text-[11px] uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-5 py-2.5 text-left font-semibold">Phase</th>
                  <th className="px-3 py-2.5 text-right font-semibold">Positions</th>
                  <th className="px-3 py-2.5 text-right font-semibold">This phase</th>
                  <th className="px-3 py-2.5 text-right font-semibold">Cumulative</th>
                  <th className="px-3 py-2.5 text-left font-semibold">Lever mix</th>
                  <th className="px-5 py-2.5 text-right font-semibold">Saving / yr</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                <tr>
                  <td className="px-5 py-3 font-semibold">Current state</td>
                  <td className="px-3 py-3 text-right font-semibold">
                    {programme.baselineHeadcount}
                  </td>
                  <td className="px-3 py-3 text-right text-muted-foreground">—</td>
                  <td className="px-3 py-3 text-right text-muted-foreground">—</td>
                  <td className="px-3 py-3 text-xs text-muted-foreground">Baseline organisation</td>
                  <td className="px-5 py-3 text-right text-muted-foreground">—</td>
                </tr>
                {programme.phases.map((p) => (
                  <tr key={p.id} className={cn(p.id === scenario?.id && "bg-accent/40")}>
                    <td className="px-5 py-3">
                      <button
                        onClick={() => setActiveScenario(p.id)}
                        className="text-left font-semibold hover:text-brand"
                      >
                        {p.title}
                      </button>
                      <p className="truncate text-xs text-muted-foreground">{p.name}</p>
                    </td>
                    <td className="px-3 py-3 text-right font-semibold">{p.headcount}</td>
                    <td className="px-3 py-3 text-right text-destructive">
                      −{p.stepReduction}
                    </td>
                    <td className="px-3 py-3 text-right">
                      −{p.cumulativeReduction}{" "}
                      <span className="text-xs text-muted-foreground">
                        ({((p.cumulativeReduction / programme.baselineHeadcount) * 100).toFixed(1)}%)
                      </span>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex h-2 w-40 overflow-hidden rounded-full bg-secondary">
                        {programme.levers.map((l) => {
                          const v = p.byLever[l.lever];
                          if (!v) return null;
                          return (
                            <span
                              key={l.lever}
                              title={`${l.label}: ${v}`}
                              style={{
                                width: `${(v / Math.max(1, p.cumulativeReduction)) * 100}%`,
                                backgroundColor: `#${l.hex}`,
                              }}
                            />
                          );
                        })}
                      </div>
                    </td>
                    <td className="px-5 py-3 text-right text-success">
                      {formatMoney(p.costSaving, cur)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
          <section className="min-w-0 rounded-lg border border-border bg-card shadow-panel">
            <div className="flex items-center justify-between border-b border-border px-5 py-3.5">
              <h2 className="text-sm font-semibold">Organisation options</h2>
              <div className="flex items-center gap-3">
                <p className="text-xs text-muted-foreground">
                  {workspace.scenarios.length} options in workspace
                </p>
                <Button asChild size="sm" variant="outline" className="h-7 text-[12px]">
                  <Link to="/scenario-compare">
                    <Columns3 className="mr-1.5 size-3.5" /> Compare side by side
                  </Link>
                </Button>
              </div>
            </div>
            <ul className="divide-y divide-border">
              {workspace.scenarios.map((s) => {
                const si = computeImpact(s);
                const active = s.id === scenario?.id;
                return (
                  <li
                    key={s.id}
                    className={cn("flex items-center gap-4 px-5 py-3.5", active && "bg-accent/50")}
                  >
                    <button
                      onClick={() => setActiveScenario(s.id)}
                      className="min-w-0 flex-1 text-left"
                    >
                      <p className="truncate text-[13.5px] font-semibold">{s.name}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {s.description || "No description"}
                      </p>
                    </button>
                    <div className="hidden shrink-0 text-right sm:block">
                      <p className="text-[13px] font-semibold">
                        {si.currentHeadcount} → {si.plannedHeadcount}
                      </p>
                      <p
                        className={cn(
                          "text-xs",
                          si.costDelta <= 0 ? "text-success" : "text-destructive",
                        )}
                      >
                        {si.costDelta <= 0 ? "−" : "+"}
                        {formatMoney(Math.abs(si.costDelta), s.currency).replace("-", "")}
                      </p>
                    </div>
                    <div className="flex shrink-0 gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        title="Duplicate scenario"
                        onClick={() => {
                          createScenario(`${s.name} (copy)`, s.id);
                          toast.success("Scenario duplicated");
                        }}
                      >
                        <Copy className="size-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        title="Delete scenario"
                        disabled={workspace.scenarios.length <= 1}
                        onClick={() => {
                          deleteScenario(s.id);
                          toast.success("Scenario deleted");
                        }}
                      >
                        <Trash2 className="size-4 text-destructive" />
                      </Button>
                    </div>
                  </li>
                );
              })}
            </ul>
          </section>

          <section className="min-w-0 space-y-3">
            {QUICK_LINKS.map((q) => (
              <Link
                key={q.to}
                to={q.to}
                className="flex items-center gap-3.5 rounded-lg border border-border bg-card px-4 py-3.5 shadow-panel transition-colors hover:border-brand/60"
              >
                <span className="grid size-9 shrink-0 place-items-center rounded-md bg-accent text-brand">
                  <q.icon className="size-4.5" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-[13.5px] font-semibold">{q.label}</span>
                  <span className="block text-xs text-muted-foreground">{q.copy}</span>
                </span>
                <ArrowRight className="size-4 shrink-0 text-muted-foreground" />
              </Link>
            ))}
          </section>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <section className="rounded-lg border border-border bg-card p-5 shadow-panel">
            <h2 className="text-sm font-semibold">Phase sequence</h2>
            <p className="mt-1 text-[12.5px] text-muted-foreground">
              Drag phases to change the rollout order. Comparisons, the roadmap slide and every
              PPT/PDF export follow this sequence.
            </p>
            <div className="mt-4">
              <PhaseOrderList />
            </div>
          </section>

          <section className="rounded-lg border border-border bg-card p-5 shadow-panel">
            <h2 className="text-sm font-semibold">Active option snapshot</h2>
            <p className="mt-1 text-[12.5px] text-muted-foreground">
              {scenario?.name ?? "No option selected"}
            </p>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              {[
                { label: "New roles", value: impact.newRoles.length, tone: "text-info" },
                {
                  label: "Roles reduced",
                  value: impact.removedRoles.length,
                  tone: "text-destructive",
                },
                { label: "Reassignments", value: impact.movedRoles.length, tone: "text-warning" },
                {
                  label: "Unchanged roles",
                  value: impact.unchanged,
                  tone: "text-muted-foreground",
                },
              ].map((item) => (
                <div key={item.label} className="rounded-md bg-secondary px-4 py-3">
                  <p className={cn("text-2xl font-semibold", item.tone)}>{item.value}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">{item.label}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
