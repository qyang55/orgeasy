import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { UserPlus, Clock, Users, Timer, ArrowRightLeft } from "lucide-react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { Disclaimer } from "@/components/orgeasy/Disclaimer";
import { StatCard } from "@/components/orgeasy/StatCard";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { resolveBaseline, phaseTitle } from "@/lib/orgeasy/phases";
import {
  analyseHiring,
  formatDays,
  DEFAULT_HIRING_ASSUMPTIONS,
  SENIORITY_META,
  type HiringAssumptions,
} from "@/lib/orgeasy/hiring";

export const Route = createFileRoute("/hiring")({
  head: () => ({
    meta: [
      { title: "Hiring Pipeline — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "See how many new roles the reduction programme creates, how long each takes to fill by seniority and market, and when recruiting capacity delivers them.",
      },
      { property: "og:title", content: "Hiring Pipeline — Organisation Strategy Studio" },
      {
        property: "og:description",
        content:
          "New role demand, blended time-to-fill by market and seniority, and recruiting capacity waves for the reduction programme.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HiringPage,
});

function NumberField({
  label,
  hint,
  value,
  onChange,
  min,
  max,
}: {
  label: string;
  hint: string;
  value: number;
  onChange: (v: number) => void;
  min: number;
  max: number;
}) {
  return (
    <div className="space-y-1.5">
      <Label className="text-[12px] font-semibold">{label}</Label>
      <Input
        type="number"
        className="h-9"
        min={min}
        max={max}
        value={value}
        onChange={(e) => {
          const n = Number(e.target.value);
          if (Number.isFinite(n)) onChange(Math.min(Math.max(n, min), max));
        }}
      />
      <p className="text-[11px] leading-snug text-muted-foreground">{hint}</p>
    </div>
  );
}

function GroupTable({
  title,
  caption,
  head,
  rows,
}: {
  title: string;
  caption: string;
  head: string;
  rows: { key: string; positions: number; avgDaysToFill: number; longestDays: number }[];
}) {
  return (
    <section className="rounded-lg border border-border bg-card shadow-panel">
      <div className="border-b border-border px-5 py-4">
        <h2 className="text-sm font-semibold">{title}</h2>
        <p className="mt-1 text-xs text-muted-foreground">{caption}</p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-5 py-2.5 text-left">{head}</th>
              <th className="px-5 py-2.5 text-left">New positions</th>
              <th className="px-5 py-2.5 text-left">Avg time to fill</th>
              <th className="px-5 py-2.5 text-left">Longest role</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={4} className="px-5 py-6 text-xs text-muted-foreground">
                  No new positions in this scenario yet.
                </td>
              </tr>
            ) : (
              rows.map((r) => (
                <tr key={r.key} className="border-t border-border/70">
                  <td className="px-5 py-2.5 font-medium">{r.key}</td>
                  <td className="px-5 py-2.5">{r.positions.toLocaleString()}</td>
                  <td className="px-5 py-2.5">{formatDays(r.avgDaysToFill)}</td>
                  <td className="px-5 py-2.5 text-muted-foreground">{formatDays(r.longestDays)}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function HiringPage() {
  const { workspace, scenario } = useOrgEasy();
  const [assumptions, setAssumptions] = useState<HiringAssumptions>(DEFAULT_HIRING_ASSUMPTIONS);
  const baseline = useMemo(
    () => resolveBaseline(workspace.scenarios, scenario),
    [workspace.scenarios, scenario],
  );
  const analysis = useMemo(
    () => analyseHiring(baseline, scenario, assumptions),
    [baseline, scenario, assumptions],
  );
  const patch = (p: Partial<HiringAssumptions>) => setAssumptions((a) => ({ ...a, ...p }));
  const maxWavePositions = Math.max(1, ...analysis.waves.map((w) => w.positions));

  return (
    <div className="pb-12">
      <PageHeader
        title="Hiring pipeline"
        description="The reduction programme also creates roles. This page sizes that new demand, estimates how long each role takes to fill by seniority and market, and shows when recruiting capacity can realistically deliver it."
      />

      <div className="space-y-6 px-8 py-6">
        <Disclaimer />

        <p className="text-xs text-muted-foreground">
          Comparing <span className="font-semibold text-foreground">{baseline ? phaseTitle(baseline) : "no baseline"}</span>{" "}
          against <span className="font-semibold text-foreground">{scenario ? phaseTitle(scenario) : "no scenario"}</span>.
          Roles that only exist in the future state count as new; surviving roles that grow count as
          incremental positions.
        </p>

        {!baseline ? (
          <p className="rounded-md border border-warning/40 bg-warning/10 px-4 py-3 text-xs text-warning-foreground">
            You are viewing the current state, so there is nothing to hire yet. Switch to a future
            phase in the scenario switcher to size its hiring demand.
          </p>
        ) : null}

        <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
          <StatCard
            label="New positions to fill"
            value={analysis.newPositions.toLocaleString()}
            tone="brand"
            sub={`${analysis.newRoleCount} brand-new roles · ${analysis.growthPositions.toLocaleString()} growth on existing roles`}
            icon={<UserPlus className="size-4" />}
          />
          <StatCard
            label="Average time to fill"
            value={formatDays(analysis.avgDaysToFill)}
            sub={`Longest single role ${formatDays(analysis.longestDaysToFill)}`}
            icon={<Clock className="size-4" />}
          />
          <StatCard
            label="Internal vs external"
            value={`${analysis.internalFills.toLocaleString()} / ${analysis.externalHires.toLocaleString()}`}
            sub={`${assumptions.internalFillPct}% assumed redeployment · ${analysis.extraOffersNeeded} extra offers for declines`}
            icon={<ArrowRightLeft className="size-4" />}
          />
          <StatCard
            label="Pipeline duration"
            value={formatDays(analysis.programmeDays)}
            tone={analysis.programmeDays > 365 ? "negative" : "positive"}
            sub={`${analysis.waves.length} waves at ${analysis.capacityPerWave} concurrent requisitions`}
            icon={<Timer className="size-4" />}
          />
        </div>

        <section className="rounded-lg border border-border bg-card p-5 shadow-panel">
          <h2 className="text-sm font-semibold">Pipeline assumptions</h2>
          <p className="mt-1 text-xs text-muted-foreground">
            Tune these to your talent-acquisition reality. Time to fill blends seniority benchmarks,
            market friction (notice periods and scarcity), role scope, and whether the work is
            delivered by a person, a hybrid, or an AI agent.
          </p>
          <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <NumberField
              label="Internal fill rate (%)"
              hint="Share of new roles filled by redeployed people leaving the programme."
              value={assumptions.internalFillPct}
              onChange={(v) => patch({ internalFillPct: v })}
              min={0}
              max={100}
            />
            <NumberField
              label="Recruiters on programme"
              hint="Dedicated talent-acquisition heads supporting the restructure."
              value={assumptions.recruiters}
              onChange={(v) => patch({ recruiters: v })}
              min={1}
              max={200}
            />
            <NumberField
              label="Requisitions per recruiter"
              hint="Concurrent open roles one recruiter can run well."
              value={assumptions.reqsPerRecruiter}
              onChange={(v) => patch({ reqsPerRecruiter: v })}
              min={1}
              max={40}
            />
            <NumberField
              label="Days saved when internal"
              hint="Sourcing and notice time avoided by redeploying an existing employee."
              value={assumptions.internalDaysSaved}
              onChange={(v) => patch({ internalDaysSaved: v })}
              min={0}
              max={90}
            />
          </div>
        </section>

        <section className="rounded-lg border border-border bg-card shadow-panel">
          <div className="border-b border-border px-5 py-4">
            <h2 className="text-sm font-semibold">Recruiting waves</h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Hardest, longest-lead roles are sequenced first so critical capability lands before
              exits complete. Each wave is limited by recruiter capacity.
            </p>
          </div>
          <div className="space-y-3 px-5 py-4">
            {analysis.waves.length === 0 ? (
              <p className="text-xs text-muted-foreground">
                No hiring demand yet — add planned roles or headcount growth to the future state.
              </p>
            ) : (
              analysis.waves.map((w) => (
                <div key={w.wave} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold">{w.label}</span>
                    <span className="text-muted-foreground">
                      {w.positions.toLocaleString()} positions · day {w.startDay} → {w.endDay}
                    </span>
                  </div>
                  <div className="h-2.5 w-full overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full bg-brand"
                      style={{ width: `${(w.positions / maxWavePositions) * 100}%` }}
                    />
                  </div>
                </div>
              ))
            )}
          </div>
        </section>

        <div className="grid gap-6 xl:grid-cols-2">
          <GroupTable
            title="Demand by seniority"
            caption="Senior roles carry the longest lead times and the highest offer-decline risk."
            head="Seniority band"
            rows={analysis.bySeniority}
          />
          <GroupTable
            title="Demand by market"
            caption="Notice periods, permits and talent scarcity drive market-level time to fill."
            head="Country"
            rows={analysis.byCountry}
          />
        </div>

        <GroupTable
          title="Demand by function"
          caption="Where the new capability sits once the reduction lands."
          head="Department"
          rows={analysis.byDepartment}
        />

        <section className="rounded-lg border border-border bg-card shadow-panel">
          <div className="border-b border-border px-5 py-4">
            <h2 className="text-sm font-semibold">Role-level pipeline</h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Every new or growing role, its seniority band, market and estimated time to fill.
            </p>
          </div>
          <div className="max-h-[520px] overflow-auto">
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-muted/80 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground backdrop-blur">
                <tr>
                  <th className="px-5 py-2.5 text-left">Role</th>
                  <th className="px-5 py-2.5 text-left">Function</th>
                  <th className="px-5 py-2.5 text-left">Market</th>
                  <th className="px-5 py-2.5 text-left">Seniority</th>
                  <th className="px-5 py-2.5 text-left">Delivery</th>
                  <th className="px-5 py-2.5 text-left">Positions</th>
                  <th className="px-5 py-2.5 text-left">Time to fill</th>
                  <th className="px-5 py-2.5 text-left">Source</th>
                </tr>
              </thead>
              <tbody>
                {analysis.roles.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="px-5 py-6 text-xs text-muted-foreground">
                      No new positions in this scenario yet.
                    </td>
                  </tr>
                ) : (
                  analysis.roles.map((r) => (
                    <tr key={`${r.id}-${r.isNewRole}`} className="border-t border-border/70">
                      <td className="px-5 py-2.5 font-medium">{r.title}</td>
                      <td className="px-5 py-2.5 text-muted-foreground">{r.department}</td>
                      <td className="px-5 py-2.5 text-muted-foreground">
                        {r.country}
                        <span className="block text-[11px]">{r.noticeWeeks} wks notice</span>
                      </td>
                      <td className="px-5 py-2.5">{SENIORITY_META[r.seniority].label}</td>
                      <td className="px-5 py-2.5 text-muted-foreground capitalize">{r.roleType}</td>
                      <td className="px-5 py-2.5">{r.positions.toLocaleString()}</td>
                      <td className="px-5 py-2.5 font-semibold">{formatDays(r.daysToFill)}</td>
                      <td className="px-5 py-2.5 text-[11px] uppercase tracking-wide text-muted-foreground">
                        {r.isNewRole ? "New role" : "Growth"}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>

        <p className="flex items-start gap-2 text-xs text-muted-foreground">
          <Users className="mt-0.5 size-3.5 shrink-0" />
          Time-to-fill figures are planning heuristics based on seniority benchmarks and market
          friction. Validate against your own requisition history before committing to a delivery
          date.
        </p>
      </div>
    </div>
  );
}