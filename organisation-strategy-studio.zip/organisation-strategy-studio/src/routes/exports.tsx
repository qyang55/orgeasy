import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { FileDown, FileSpreadsheet, FileText, Loader2, Presentation } from "lucide-react";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { Disclaimer } from "@/components/orgeasy/Disclaimer";
import { useOrgEasy } from "@/lib/orgeasy/store";
import {
  ALL_DECK_SECTIONS,
  DECK_SECTIONS,
  generateDeck,
  type DeckSectionKey,
} from "@/lib/orgeasy/pptx";
import { generateExecutiveDeck } from "@/lib/orgeasy/pptx-exec";
import { computeProgramme } from "@/lib/orgeasy/levers";
import { compareAgentModel } from "@/lib/orgeasy/agents";
import { computeImpact, formatMoney } from "@/lib/orgeasy/impact";
import { downloadBlob, employeesToCsv } from "@/lib/orgeasy/csv";
import {
  EXPORT_NOTICES,
  NOT_LEGAL_ADVICE_SHORT,
  withNotices,
} from "@/lib/orgeasy/notices";
import { buildTemplates } from "@/lib/orgeasy/templates";
import {
  buildDrilldown,
  compareScenarios,
  diffToCsv,
  drilldownToNotes,
  loadPinnedScopes,
} from "@/lib/orgeasy/diff";
import { currentStateFor, phasesFor, phaseTitle, resolveBaseline, scenarioLabel } from "@/lib/orgeasy/phases";
import { PhaseOrderList } from "@/components/orgeasy/PhaseOrderList";
import {
  buildChangePlan,
  loadChangeEdits,
  mergedActions,
} from "@/lib/orgeasy/change-plan";
import { computeImpact as impactOf } from "@/lib/orgeasy/impact";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { renderScenarioPng } from "@/lib/orgeasy/chart-image";
import { buildLegend, legendToLines, loadLegendConfig } from "@/lib/orgeasy/legend";
import { getTheme } from "@/lib/orgeasy/themes";
import { BRAND_NAVY, logoDataUrl } from "@/lib/orgeasy/brand";
import { toast } from "sonner";

export const Route = createFileRoute("/exports")({
  head: () => ({
    meta: [
      { title: "Exports & PowerPoint — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Export a leadership-ready 10-slide PowerPoint deck, PDF summary, role CSV and communication templates.",
      },
      { property: "og:title", content: "Exports & PowerPoint — Organisation Strategy Studio" },
      {
        property: "og:description",
        content: "Generate a real .pptx leadership deck plus PDF, CSV and template exports.",
      },
    ],
  }),
  component: Exports,
});

function Exports() {
  const { workspace, scenario, can, recordActivity } = useOrgEasy();
  const [includeCharts, setIncludeCharts] = useState(true);
  const [editableCharts, setEditableCharts] = useState(true);
  const [baselineId, setBaselineId] = useState("auto");
  const [phaseMode, setPhaseMode] = useState<"active" | "all" | "custom">("active");
  const [customPhaseIds, setCustomPhaseIds] = useState<string[]>([]);
  const [includeLegend, setIncludeLegend] = useState(true);
  const [sections, setSections] = useState<DeckSectionKey[]>(ALL_DECK_SECTIONS);
  const [busy, setBusy] = useState<string | null>(null);
  const [deckMode, setDeckMode] = useState<"exec" | "detailed">("exec");
  const impact = computeImpact(scenario);
  const cur = scenario?.currency ?? "USD";

  const legendConfig = loadLegendConfig();
  const chartTheme = getTheme(
    typeof localStorage !== "undefined"
      ? (localStorage.getItem("orgeasy.chart.theme") ?? "enterprise")
      : "enterprise",
  );
  const legendFor = (s: typeof scenario) =>
    includeLegend && legendConfig.show ? buildLegend(s, legendConfig, chartTheme) : [];

  const autoBaseline = resolveBaseline(workspace.scenarios, scenario);
  const baseline =
    baselineId === "auto"
      ? autoBaseline
      : baselineId === "none"
        ? null
        : (workspace.scenarios.find((s) => s.id === baselineId) ?? null);
  const diff = baseline && scenario ? compareScenarios(baseline, scenario) : null;

  /** Drill-downs pinned on the Current vs Future page. */
  const pinnedScopes = loadPinnedScopes();
  const drilldowns = diff ? pinnedScopes.map((s) => buildDrilldown(diff, s)) : [];

  // Phases of THIS scenario's programme only — a freshly generated pack must not
  // inherit the demo workspace's phase chain.
  const programmeCurrent =
    scenario && (scenario.kind ?? "") === "current"
      ? scenario
      : currentStateFor(workspace.scenarios, scenario);
  const allPhases = phasesFor(workspace.scenarios, programmeCurrent);
  const selectedPhases =
    phaseMode === "active"
      ? []
      : phaseMode === "all"
        ? allPhases
        : allPhases.filter((s) => customPhaseIds.includes(s.id));

  const togglePhase = (id: string) =>
    setCustomPhaseIds((prev) =>
      prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id],
    );

  /** Per-phase metrics + diff against that phase's own baseline. */
  const phaseSectionData = selectedPhases.map((s) => {
    const base = resolveBaseline(workspace.scenarios, s);
    const im = impactOf(s);
    const d = base ? compareScenarios(base, s) : null;
    return {
      scenario: s,
      label: phaseTitle(s),
      name: s.name,
      headcount: im.plannedHeadcount,
      cost: im.plannedCost,
      headcountDelta: d ? d.headcount.delta : 0,
      costDelta: d ? d.cost.delta : 0,
      baselineName: base?.name,
      diff: d,
    };
  });

  const phaseRows = (() => {
    const chain = allPhases;
    const start = programmeCurrent;
    const ordered = start ? [start, ...chain] : chain;
    let prevHc = 0;
    let prevCost = 0;
    return ordered.map((s, index) => {
      const im = impactOf(s);
      const hc = index === 0 ? im.currentHeadcount : im.plannedHeadcount;
      const cost = index === 0 ? im.currentCost : im.plannedCost;
      const row = {
        label: phaseTitle(s),
        name: s.name,
        headcount: hc,
        cost,
        headcountDelta: index === 0 ? 0 : hc - prevHc,
        costDelta: index === 0 ? 0 : cost - prevCost,
      };
      prevHc = hc;
      prevCost = cost;
      return row;
    });
  })();

  const toggleSection = (key: DeckSectionKey) =>
    setSections((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));

  const exportPptx = async () => {
    if (!scenario) return;
    setBusy("pptx");
    try {
      if (deckMode === "exec") {
        const plan = buildChangePlan(scenario, baseline);
        await generateExecutiveDeck(scenario, {
          programme: computeProgramme(workspace, scenario),
          impact: computeImpact(scenario),
          plan,
          baselineName: baseline?.name ?? null,
          preparedBy: workspace.account?.email ?? null,
          futureChartPng:
            includeCharts && !editableCharts
              ? await renderScenarioPng(scenario, { legend: legendFor(scenario) })
              : null,
          editableCharts: includeCharts && editableCharts,
          currentChartScenario: baseline,
          options: workspace.scenarios
            .filter((s) => s.id !== scenario.id && (s.kind ?? "") !== "current")
            .slice(0, 2)
            .map((s) => {
              const im = impactOf(s);
              return {
                name: s.name,
                positions: im.plannedHeadcount,
                costDelta: im.costDelta,
              };
            }),
          fileName: `${scenario.name}-leadership-pack`,
        });
        recordActivity("export", "Exported the 7-slide leadership decision pack", scenario.name);
        toast.success("Leadership deck downloaded (7 slides)");
        return;
      }
      const futureChartPng = includeCharts && !editableCharts
        ? await renderScenarioPng(scenario, { legend: legendFor(scenario) })
        : null;
      const currentChartPng =
        includeCharts && !editableCharts && baseline
          ? await renderScenarioPng(baseline, { legend: legendFor(baseline) })
          : null;
      const phaseSections = [];
      for (const p of phaseSectionData) {
        phaseSections.push({
          label: p.label,
          name: p.name,
          chartPng: includeCharts && !editableCharts
            ? await renderScenarioPng(p.scenario, { legend: legendFor(p.scenario) })
            : null,
          chartScenario: includeCharts && editableCharts ? p.scenario : null,
          headcount: p.headcount,
          cost: p.cost,
          headcountDelta: p.headcountDelta,
          costDelta: p.costDelta,
          ...(p.baselineName ? { baselineName: p.baselineName } : {}),
          diff: p.diff,
        });
      }
      await generateDeck(scenario, {
        currentChartPng,
        futureChartPng,
        editableCharts: includeCharts && editableCharts,
        currentChartScenario: includeCharts && editableCharts ? baseline : null,
        phases: phaseRows,
        phaseSections,
        fileName:
          phaseSections.length > 0
            ? `${scenario.name}-${phaseMode === "all" ? "all-phases" : "selected-phases"}-Strategy-Studio`
            : `${scenario.name}-Strategy-Studio`,
        drilldowns,
        sections,
        programme: computeProgramme(workspace, scenario),
        changePlan: (() => {
          const plan = buildChangePlan(scenario, baseline);
          return { plan, actions: mergedActions(plan, loadChangeEdits(scenario.id)) };
        })(),
        agents: baseline && scenario ? compareAgentModel(baseline, scenario) : null,
        ...(baseline
          ? {
              currentScenarioName: baseline.name,
              diff: diff ?? compareScenarios(baseline, scenario),
            }
          : {}),
      });
      recordActivity("export", "Exported the detailed PowerPoint pack", scenario.name);
      toast.success("PowerPoint deck downloaded");
    } catch (error) {
      console.error(error);
      toast.error("Could not build the deck. Try again with charts turned off.");
    } finally {
      setBusy(null);
    }
  };

  const exportPdf = async () => {
    if (!scenario) return;
    setBusy("pdf");
    try {
      const { jsPDF } = await import("jspdf");
      const doc = new jsPDF({ unit: "pt", format: "a4" });
      const pageW = doc.internal.pageSize.getWidth();
      doc.setFillColor(`#${BRAND_NAVY}`);
      doc.rect(0, 0, pageW, 96, "F");
      const logoPng = await logoDataUrl();
      if (logoPng) doc.addImage(logoPng, "PNG", pageW - 56 - 52, 22, 52, 52);
      doc.setTextColor("#FFFFFF");
      doc.setFont("helvetica", "bold");
      doc.setFontSize(20);
      doc.text(scenario.name, 56, 46, { maxWidth: pageW - 180 });
      doc.setFont("helvetica", "normal");
      doc.setFontSize(11);
      doc.text("Organisation design & impact summary", 56, 68);
      doc.setTextColor("#1E293B");
      let y = 132;
      const line = (text: string, size = 11, bold = false) => {
        doc.setFont("helvetica", bold ? "bold" : "normal");
        doc.setFontSize(size);
        for (const row of doc.splitTextToSize(text, 480)) {
          if (y > 780) {
            doc.addPage();
            y = 60;
          }
          doc.text(row, 56, y);
          y += size + 6;
        }
      };
      const legendLines = legendToLines(legendFor(scenario));
      if (legendLines.length) {
        line("Chart legend", 14, true);
        for (const l of legendLines) line(l);
        y += 8;
      }
      if (phaseRows.length > 1) {
        line("Phased roadmap", 14, true);
        for (const p of phaseRows) {
          line(
            `${p.label} — ${p.name}: ${p.headcount} positions · ${formatMoney(p.cost, cur)}${
              p.headcountDelta || p.costDelta
                ? ` (${p.headcountDelta >= 0 ? "+" : ""}${p.headcountDelta} positions, ${p.costDelta <= 0 ? "−" : "+"}${formatMoney(Math.abs(p.costDelta), cur)} vs prior phase)`
                : ""
            }`,
          );
        }
        y += 8;
      }
      if (phaseSectionData.length) {
        line("Phase detail", 14, true);
        for (const p of phaseSectionData) {
          line(`${p.label} — ${p.name}`, 12, true);
          line(`${p.headcount} positions · ${formatMoney(p.cost, cur)} annual people cost`);
          line(
            `${p.headcountDelta >= 0 ? "+" : ""}${p.headcountDelta} positions · ${p.costDelta <= 0 ? "−" : "+"}${formatMoney(Math.abs(p.costDelta), cur)} vs ${p.baselineName ?? "prior phase"}`,
          );
          if (p.diff) {
            line(
              `Roles added ${p.diff.added.length} · removed ${p.diff.removed.length} · changed ${p.diff.changed.length} · layers ${p.diff.layers.base} → ${p.diff.layers.target} · span ${p.diff.span.base.toFixed(1)} → ${p.diff.span.target.toFixed(1)}`,
            );
          }
          y += 4;
        }
        y += 6;
      }
      if (baseline && diff) {
        line(`Current state: ${baseline.name}`, 14, true);
        line(
          `${diff.headcount.base} positions · ${formatMoney(diff.cost.base, cur)} annual people cost · ${diff.layers.base} layers · average span ${diff.span.base.toFixed(1)}`,
        );
        y += 8;
        line("Current vs future differences", 14, true);
        line(
          `Positions: ${diff.headcount.base} → ${diff.headcount.target} (${diff.headcount.delta >= 0 ? "+" : ""}${diff.headcount.delta})`,
        );
        line(
          `Annual cost: ${formatMoney(diff.cost.base, cur)} → ${formatMoney(diff.cost.target, cur)} (${diff.cost.delta <= 0 ? "−" : "+"}${formatMoney(Math.abs(diff.cost.delta), cur)})`,
        );
        line(`Management layers: ${diff.layers.base} → ${diff.layers.target}`);
        line(
          `Average span of control: ${diff.span.base.toFixed(1)} → ${diff.span.target.toFixed(1)}`,
        );
        line(
          `Roles added ${diff.added.length} · removed ${diff.removed.length} · changed ${diff.changed.length} · unchanged ${diff.unchangedCount}`,
        );
        y += 6;
        line("Role-level change log", 12, true);
        for (const e of diff.added.slice(0, 10))
          line(
            `Added — ${e.name || "Open Role"} (${e.title}), ${e.department || "—"}, ${e.country}`,
          );
        for (const e of diff.removed.slice(0, 10))
          line(
            `Removed — ${e.name || "Open Role"} (${e.title}), ${e.department || "—"}, ${e.country}`,
          );
        for (const c of diff.changed.slice(0, 12))
          line(
            `Changed — ${c.after.name || c.before.name || "Open Role"} (${c.after.title}): ${c.changes
              .slice(0, 3)
              .map((ch) => `${ch.label} ${ch.before} → ${ch.after}`)
              .join("; ")}`,
          );
        y += 8;
      }
      line("Headcount & budget", 14, true);
      line(`Current positions: ${impact.currentHeadcount}`);
      line(
        `Planned positions: ${impact.plannedHeadcount} (${impact.headcountDelta >= 0 ? "+" : ""}${impact.headcountDelta})`,
      );
      line(`Current annual cost: ${formatMoney(impact.currentCost, cur)}`);
      line(`Planned annual cost: ${formatMoney(impact.plannedCost, cur)}`);
      line(
        `${impact.costDelta <= 0 ? "Annual saving" : "Annual increase"}: ${formatMoney(Math.abs(impact.costDelta), cur)}`,
      );
      y += 8;
      line("By department", 14, true);
      for (const d of impact.byDepartment) {
        line(
          `${d.department}: ${d.currentHeadcount} → ${d.plannedHeadcount} positions · ${formatMoney(d.currentCost, cur)} → ${formatMoney(d.plannedCost, cur)}`,
        );
      }
      y += 8;
      line("Countries with proposed removals", 14, true);
      const removals = impact.byCountry.filter((c) => c.removed > 0);
      if (removals.length) {
        for (const c of removals) {
          line(
            `${c.country}: ${c.removed} roles · illustrative separation cost ${formatMoney(c.illustrativeSeverance, cur)}`,
          );
        }
      } else {
        line("None recorded.");
      }
      y += 8;
      if (drilldowns.length) {
        y += 2;
        line("Change drill-down notes", 14, true);
        for (const d of drilldowns) {
          for (const [index, note] of drilldownToNotes(d).entries())
            line(note, index === 0 ? 12 : 11, index === 0);
          y += 6;
        }
      }
      y += 8;
      line("Important notices & disclaimer", 14, true);
      for (const n of EXPORT_NOTICES) {
        line(n.title, 11.5, true);
        line(n.body);
        y += 2;
      }
      const pageCount = doc.getNumberOfPages();
      doc.setFont("helvetica", "italic");
      doc.setFontSize(8);
      doc.setTextColor(120);
      for (let p = 1; p <= pageCount; p += 1) {
        doc.setPage(p);
        doc.text(NOT_LEGAL_ADVICE_SHORT, 56, 812);
        doc.text("Confidential — may contain personal data.", 56, 823);
      }
      doc.setTextColor(0);
      doc.save(`${scenario.name.replace(/[^a-z0-9]+/gi, "-")}-summary.pdf`);
      recordActivity("export", "Exported the PDF impact summary", scenario?.name);
      toast.success("PDF summary downloaded");
    } finally {
      setBusy(null);
    }
  };

  const CARDS = [
    {
      id: "pptx",
      icon: Presentation,
      title: deckMode === "exec" ? "Leadership PowerPoint (5–7 slides)" : "Detailed PowerPoint pack",
      copy:
        deckMode === "exec"
          ? `A short executive narrative: title and context, current-state snapshot, the proposed future organisation${
              includeCharts ? " with its chart" : ""
            }, the four trade-offs (structure, cost, capability, risk), multi-country and consultation risks to plan for, and the recommended next step with a pilot. Story first — the full tables stay in the app.`
          : (baseline
              ? `Every selected section as a real .pptx: phased roadmap, the current-state chart from “${baseline.name}”, the future structure, a side-by-side, what changed, the role-level change log, headcount, budget, country overview, ADKAR, key messages and next steps.`
              : "Every selected section as a real .pptx: phased roadmap, future structure, headcount, budget, country overview, ADKAR, key messages and next steps. Pick a baseline scenario above to add the current-state chart and difference slides.") +
            (selectedPhases.length
              ? ` Adds a detail slide for ${selectedPhases.map((s) => phaseTitle(s)).join(", ")}.`
              : "") +
            (drilldowns.length
              ? ` Appends ${drilldowns.length} pinned drill-down slide(s) with full speaker notes: ${drilldowns.map((d) => d.label).join(", ")}.`
              : " Pin a drill-down on Current vs Future to append role-level appendix slides and speaker notes."),
      cta: deckMode === "exec" ? "Generate leadership deck" : "Generate detailed pack",
      run: exportPptx,
      primary: true,
    },
    {
      id: "pdf",
      icon: FileText,
      title: "PDF summary",
      copy: `A written brief with the phased roadmap, current-state totals, current-vs-future differences, the role-level change log, department detail and countries with proposed removals.${
        selectedPhases.length ? ` Includes a per-phase section for ${selectedPhases.length} phase(s).` : ""
      }${drilldowns.length ? ` Ends with drill-down notes for ${drilldowns.length} pinned slice(s).` : ""}`,
      cta: "Download PDF",
      run: exportPdf,
    },
    {
      id: "csv",
      icon: FileSpreadsheet,
      title: "Role inventory CSV",
      copy: "Every role with headcount, cost, country, manager and status — re-importable on the People page.",
      cta: "Download CSV",
      run: async () => {
        if (!scenario) return;
        downloadBlob(employeesToCsv(scenario.employees), `${scenario.name}-roles.csv`, "text/csv");
        recordActivity("export", "Exported the role list as CSV", scenario?.name);
        toast.success("CSV downloaded");
      },
    },
    {
      id: "diff",
      icon: FileSpreadsheet,
      title: "Change log CSV",
      copy: baseline
        ? `Every added, removed and changed role between “${baseline.name}” and “${scenario?.name ?? ""}”, field by field.`
        : "Select a baseline scenario above to export the current-vs-future change log.",
      run: async () => {
        if (!scenario || !baseline) {
          toast.error("Pick a baseline scenario in Deck options first");
          return;
        }
        downloadBlob(
          diffToCsv(compareScenarios(baseline, scenario)),
          `${baseline.name}-vs-${scenario.name}-changes.csv`.replace(/[^a-z0-9.-]+/gi, "-"),
          "text/csv",
        );
        recordActivity("export", "Exported the current vs future change log", scenario?.name);
        toast.success("Change log downloaded");
      },
      cta: "Download change log",
    },
    {
      id: "txt",
      icon: FileDown,
      title: "Communication pack",
      copy: "All auto-filled announcement, manager script, FAQ and consultation templates in one text file.",
      cta: "Download templates",
      run: async () => {
        downloadBlob(
          withNotices(
            buildTemplates(scenario)
              .map((t) => `# ${t.title}\nAudience: ${t.audience}\n\n${t.body}`)
              .join("\n\n---\n\n"),
            "Important notices — communication pack",
          ),
          `${scenario?.name ?? "communications"}-templates.txt`,
          "text/plain",
        );
        recordActivity("export", "Exported communication templates", scenario?.name);
        toast.success("Templates downloaded");
      },
    },
  ];

  return (
    <div className="pb-12">
      <PageHeader
        title="Exports"
        description="Take the scenario out of the tool: a leadership deck, a written summary, the underlying data, or the communication pack."
      />

      <div className="space-y-6 px-8 py-6">
        <Disclaimer />

        <div className="rounded-lg border border-border bg-card p-5 shadow-panel">
          <h2 className="text-sm font-semibold">Deck options</h2>
          <div className="mt-3 grid gap-3 md:grid-cols-2">
            {(
              [
                {
                  id: "exec" as const,
                  title: "Leadership narrative",
                  detail:
                    "5–7 slides: context, current state, proposed future, trade-offs, country risk, next steps. Minimal tables — built for a decision meeting.",
                },
                {
                  id: "detailed" as const,
                  title: "Detailed pack",
                  detail:
                    "The full section-by-section deck with tables, change logs and appendices. Use it for working sessions and pre-reads.",
                },
              ]
            ).map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => setDeckMode(m.id)}
                className={`rounded-md border p-3 text-left transition ${
                  deckMode === m.id
                    ? "border-primary bg-accent/60 ring-1 ring-primary/40"
                    : "border-border hover:border-primary/50"
                }`}
              >
                <span className="block text-[13px] font-semibold">{m.title}</span>
                <span className="mt-0.5 block text-[11.5px] leading-relaxed text-muted-foreground">
                  {m.detail}
                </span>
              </button>
            ))}
          </div>
          {deckMode === "detailed" && (
          <div className="mt-4 rounded-md border border-border bg-muted/30 p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-sm font-semibold">Storytelling sections</p>
                <p className="text-xs text-muted-foreground">
                  Choose the slides for this leadership pack. {sections.length} of{" "}
                  {ALL_DECK_SECTIONS.length} selected.
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setSections(ALL_DECK_SECTIONS)}
                >
                  Select all
                </Button>
                <Button type="button" variant="ghost" size="sm" onClick={() => setSections([])}>
                  Clear
                </Button>
              </div>
            </div>
            <div className="mt-3 grid gap-2 md:grid-cols-2 xl:grid-cols-3">
              {DECK_SECTIONS.map((s) => (
                <label
                  key={s.key}
                  className="flex cursor-pointer items-start gap-2.5 rounded-md border border-border bg-card p-2.5 transition hover:border-primary/50"
                >
                  <Checkbox
                    checked={sections.includes(s.key)}
                    onCheckedChange={() => toggleSection(s.key)}
                    className="mt-0.5"
                  />
                  <span>
                    <span className="block text-xs font-semibold leading-tight">{s.label}</span>
                    <span className="block text-[11px] text-muted-foreground">{s.detail}</span>
                  </span>
                </label>
              ))}
            </div>
          </div>
          )}
          <div className="mt-4 flex flex-wrap items-end gap-6">
            <div className="flex items-center gap-3">
              <Switch id="charts" checked={includeCharts} onCheckedChange={setIncludeCharts} />
              <Label htmlFor="charts" className="cursor-pointer">
                Include org charts in the deck
              </Label>
            </div>
            <div className="flex items-center gap-3">
              <Switch
                id="editable"
                checked={editableCharts}
                disabled={!includeCharts}
                onCheckedChange={setEditableCharts}
              />
              <Label htmlFor="editable" className="cursor-pointer">
                Editable chart shapes (not a flat image)
              </Label>
            </div>
            <div className="flex items-center gap-3">
              <Switch id="legend" checked={includeLegend} onCheckedChange={setIncludeLegend} />
              <Label htmlFor="legend" className="cursor-pointer">
                Include the chart legend
              </Label>
            </div>
            <div className="space-y-1.5">
              <Label>Current state used for comparison</Label>
              <Select value={baselineId} onValueChange={setBaselineId}>
                <SelectTrigger className="w-72">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="auto">
                    Automatic{autoBaseline ? ` — ${autoBaseline.name}` : " — none found"}
                  </SelectItem>
                  <SelectItem value="none">No comparison</SelectItem>
                  {workspace.scenarios
                    .filter((s) => s.id !== scenario?.id)
                    .map((s) => (
                      <SelectItem key={s.id} value={s.id}>
                        {scenarioLabel(s)}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="mt-6 border-t border-border pt-5">
            <div className="flex flex-wrap items-end gap-6">
              <div className="space-y-1.5">
                <Label>Phases included in the export</Label>
                <Select
                  value={phaseMode}
                  onValueChange={(v) => setPhaseMode(v as typeof phaseMode)}
                >
                  <SelectTrigger className="w-72">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active scenario only</SelectItem>
                    <SelectItem value="all">All future phases ({allPhases.length})</SelectItem>
                    <SelectItem value="custom">Specific phases…</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <p className="max-w-md text-[13px] leading-relaxed text-muted-foreground">
                {phaseMode === "active"
                  ? "The deck and PDF cover the active scenario only, plus the roadmap table."
                  : `Each selected phase gets its own detail slide and PDF section — chart, positions, cost and changes against its own baseline (${selectedPhases.length} selected).`}
              </p>
            </div>
            {phaseMode === "custom" && (
              <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                {allPhases.length === 0 && (
                  <p className="text-[13px] text-muted-foreground">
                    No future-state phases exist yet. Add one from the sidebar.
                  </p>
                )}
                {allPhases.map((s) => (
                  <label
                    key={s.id}
                    className="flex cursor-pointer items-center gap-3 rounded-md border border-border px-3 py-2.5 text-[13px] hover:bg-accent/60"
                  >
                    <Checkbox
                      checked={customPhaseIds.includes(s.id)}
                      onCheckedChange={() => togglePhase(s.id)}
                    />
                    <span>
                      <span className="font-medium">{phaseTitle(s)}</span>
                      <span className="block text-muted-foreground">{s.name}</span>
                    </span>
                  </label>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="rounded-lg border border-border bg-card p-5 shadow-panel">
          <h2 className="text-sm font-semibold">Phase order used in the deck</h2>
          <p className="mt-1 text-[12.5px] text-muted-foreground">
            Drag to reorder. Roadmap slides, per-phase detail slides and PDF sections are generated
            in this exact order.
          </p>
          <div className="mt-4">
            <PhaseOrderList compact />
          </div>
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          {CARDS.map((card) => (
            <section
              key={card.id}
              className="flex flex-col rounded-lg border border-border bg-card p-5 shadow-panel"
            >
              <div className="flex items-center gap-3">
                <span className="grid size-10 place-items-center rounded-md bg-accent text-brand">
                  <card.icon className="size-5" />
                </span>
                <h3 className="text-[15px] font-semibold">{card.title}</h3>
              </div>
              <p className="mt-3 flex-1 text-[13px] leading-relaxed text-muted-foreground">
                {card.copy}
              </p>
              <Button
                className="mt-4 self-start"
                variant={card.primary ? "default" : "outline"}
                disabled={busy !== null || !scenario || !can("exportPacks")}
                title={can("exportPacks") ? undefined : "Your workspace role can't export packs"}
                onClick={() => void card.run()}
              >
                {busy === card.id ? (
                  <Loader2 className="mr-1.5 size-4 animate-spin" />
                ) : (
                  <FileDown className="mr-1.5 size-4" />
                )}
                {card.cta}
              </Button>
            </section>
          ))}
        </div>
      </div>
    </div>
  );
}
