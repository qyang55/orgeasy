import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Bot,
  Check,
  ChevronDown,
  Download,
  FileDown,
  FileText,
  Filter,
  Flag,
  ListPlus,
  Loader2,
  Save,
  Sparkles,
  Trash2,
  Upload,
  Wand2,
} from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/orgeasy/AppShell";
import { AutomationScoreRing } from "@/components/orgeasy/AutomationScoreRing";
import { StatCard } from "@/components/orgeasy/StatCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useOrgEasy } from "@/lib/orgeasy/store";
import {
  useAgentMonthlyCost,
  suggestRoleType,
  roleTypeOf,
  agentAnnualCost,
} from "@/lib/orgeasy/agents";
import { ROLE_TYPE_META, type RoleType } from "@/lib/orgeasy/types";
import { formatMoney } from "@/lib/orgeasy/impact";
import { cn } from "@/lib/utils";
import {
  addToBacklog,
  APPROACHES,
  BANDS,
  BAND_META,
  bandFromScore,
  computeTotals,
  deleteAnalysis,
  emptyAnalysis,
  FLAG_META,
  getAutomationState,
  heuristicAnalyze,
  removeFromBacklog,
  saveAnalysis,
  splitTasks,
  subscribeAutomation,
  suggestedSaving,
  toggleBacklogDone,
  uid,
  weightedScore,
  type AutomatabilityBand,
  type RoleAutomationAnalysis,
  type RoleFlag,
  type TaskAssessment,
} from "@/lib/orgeasy/automation";
import { generateAutomationDeck, generateAutomationPdf } from "@/lib/orgeasy/automation-pptx";

export const Route = createFileRoute("/automation")({
  validateSearch: (search: Record<string, unknown>) => ({
    role: typeof search["role"] === "string" ? (search["role"] as string) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Automation Insights — Organisation Strategy Studio" },
      {
        name: "description",
        content:
          "Analyse any role to see which tasks can be automated or AI-assisted, how many hours come back each week, and what to do next.",
      },
      { property: "og:title", content: "Automation Insights — Organisation Strategy Studio" },
      {
        property: "og:description",
        content:
          "See which parts of a role can be automated, which stay human, and the time and cost impact.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AutomationPage,
});

interface TaskRow {
  id: string;
  task: string;
  hoursPerWeek: number;
}

function AutomationPage() {
  const { scenario, upsertEmployee } = useOrgEasy();
  const agentMonthly = useAgentMonthlyCost();
  const navigate = useNavigate();
  const { role: roleParam } = Route.useSearch();

  const [store, setStore] = useState(() => getAutomationState());
  useEffect(() => {
    setStore(getAutomationState());
    return subscribeAutomation(() => setStore({ ...getAutomationState() }));
  }, []);

  const employees = scenario?.employees ?? [];
  const [employeeId, setEmployeeId] = useState<string>("adhoc");
  const [roleTitle, setRoleTitle] = useState("");
  const [department, setDepartment] = useState("");
  const [context, setContext] = useState("");
  const [tools, setTools] = useState("");
  const [hourlyCost, setHourlyCost] = useState(45);
  const [jobDescription, setJobDescription] = useState("");
  const [rows, setRows] = useState<TaskRow[]>([]);
  const [busy, setBusy] = useState(false);
  const [exporting, setExporting] = useState<"pptx" | "pdf" | null>(null);
  const [analysis, setAnalysis] = useState<RoleAutomationAnalysis | null>(null);
  const [highOnly, setHighOnly] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [openTask, setOpenTask] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [sourceFile, setSourceFile] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  /** Loads a role from the active scenario into the input form. */
  const loadEmployee = (id: string) => {
    setEmployeeId(id);
    setAnalysis(null);
    setSourceFile(null);
    setSelected(new Set());
    const employee = employees.find((e) => e.id === id);
    if (!employee) {
      setRoleTitle("");
      setDepartment("");
      setJobDescription("");
      setRows([]);
      return;
    }
    setRoleTitle(employee.title);
    setDepartment(employee.department);
    setJobDescription(employee.responsibilities);
    setRows(
      splitTasks(employee.responsibilities).map((task) => ({ id: uid(), task, hoursPerWeek: 0 })),
    );
    const headcount = employee.currentHeadcount || employee.plannedHeadcount || 1;
    if (employee.currentCost > 0) {
      setHourlyCost(Math.round(employee.currentCost / headcount / 1800) || 45);
    }
    // Surface the most recent saved analysis for this role.
    const previous = getAutomationState()
      .analyses.filter((a) => a.employeeId === id)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];
    if (previous) setAnalysis(previous);
  };

  useEffect(() => {
    if (roleParam && employees.some((e) => e.id === roleParam)) loadEmployee(roleParam);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roleParam, scenario?.id]);

  const currency = scenario?.currency ?? "USD";
  const totals = analysis ? computeTotals(analysis) : null;

  const visibleTasks = useMemo(() => {
    if (!analysis) return [];
    const sorted = [...analysis.tasks].sort((a, b) => b.score - a.score);
    return highOnly ? sorted.filter((t) => t.band === "full" || t.band === "high") : sorted;
  }, [analysis, highOnly]);

  const patchAnalysis = (patch: Partial<RoleAutomationAnalysis>) =>
    setAnalysis((prev) => (prev ? { ...prev, ...patch } : prev));

  const patchTask = (taskId: string, patch: Partial<TaskAssessment>) =>
    setAnalysis((prev) => {
      if (!prev) return prev;
      const tasks = prev.tasks.map((t) =>
        t.id === taskId ? { ...t, ...patch, overridden: true } : t,
      );
      return { ...prev, tasks, overallScore: weightedScore(tasks) };
    });

  const runAnalysis = async (override?: {
    roleTitle?: string;
    department?: string;
    jobDescription?: string;
    tasks?: TaskRow[];
  }) => {
    const title = (override?.roleTitle ?? roleTitle).trim();
    if (!title) {
      toast.error("Add a job title first");
      return;
    }
    setBusy(true);
    setSelected(new Set());
    const taskRows = override?.tasks ?? rows;
    const payload = {
      roleTitle: title,
      department: (override?.department ?? department).trim(),
      context: context.trim(),
      tools: tools.trim(),
      jobDescription: (override?.jobDescription ?? jobDescription).trim(),
      tasks: taskRows
        .filter((r) => r.task.trim())
        .map((r) => ({ task: r.task.trim(), hoursPerWeek: Number(r.hoursPerWeek) || 0 })),
    };

    const base = emptyAnalysis({
      scenarioId: scenario?.id ?? null,
      employeeId: employeeId === "adhoc" ? null : employeeId,
      roleTitle: title,
      department: payload.department,
      context: payload.context,
      tools: payload.tools,
      hourlyCost: Number(hourlyCost) || 0,
      currency,
    });

    try {
      const res = await fetch("/api/automation-analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error(await res.text());
      const data = (await res.json()) as {
        overallScore: number;
        summary: string;
        nextActions: string[];
        tasks: Omit<TaskAssessment, "id">[];
      };
      const tasks: TaskAssessment[] = (data.tasks ?? []).map((t) => ({
        ...t,
        id: uid(),
        band: (BANDS.includes(t.band) ? t.band : bandFromScore(t.score)) as AutomatabilityBand,
        hoursPerWeek: Math.max(0, Number(t.hoursPerWeek) || 0),
        hoursSavedPerWeek: Math.max(0, Number(t.hoursSavedPerWeek) || 0),
      }));
      const next: RoleAutomationAnalysis = {
        ...base,
        source: "ai",
        summary: data.summary ?? "",
        nextActions: data.nextActions ?? [],
        tasks,
        overallScore: tasks.length ? weightedScore(tasks) : Math.round(data.overallScore ?? 0),
      };
      setAnalysis(next);
      toast.success("Analysis ready", {
        description: `${next.tasks.length} tasks assessed for ${title}.`,
      });
    } catch (error) {
      const fallback = heuristicAnalyze(payload);
      setAnalysis({ ...base, ...fallback, source: "heuristic" });
      const message = error instanceof Error ? error.message : "AI unavailable";
      toast.warning("Showing a rule-based estimate", {
        description: `AI analysis was unavailable (${message.slice(0, 90)}). You can edit every suggestion below.`,
      });
    } finally {
      setBusy(false);
    }
  };


  const uploadDocument = async (file: File) => {
    if (file.size > 12 * 1024 * 1024) {
      toast.error("That file is larger than 12 MB");
      return;
    }
    setUploading(true);
    try {
      const buffer = new Uint8Array(await file.arrayBuffer());
      let binary = "";
      for (let i = 0; i < buffer.length; i += 8192) {
        binary += String.fromCharCode(...buffer.subarray(i, i + 8192));
      }
      const res = await fetch("/api/jd-extract", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filename: file.name,
          mimeType: file.type,
          dataBase64: btoa(binary),
        }),
      });
      if (!res.ok) throw new Error(await res.text());
      const data = (await res.json()) as {
        text: string;
        roleTitle?: string;
        department?: string;
      };
      const nextTitle = roleTitle.trim() || (data.roleTitle ?? "").trim();
      const nextDepartment = department.trim() || (data.department ?? "").trim();
      const nextRows = splitTasks(data.text).map((task) => ({ id: uid(), task, hoursPerWeek: 0 }));
      setEmployeeId("adhoc");
      setSourceFile(file.name);
      setJobDescription(data.text);
      setRoleTitle(nextTitle);
      setDepartment(nextDepartment);
      setRows(nextRows);
      setAnalysis(null);
      toast.success(`Read ${file.name}`, {
        description: nextTitle
          ? `${nextRows.length} tasks found — analysing now.`
          : "Add the job title, then click Analyse.",
      });
      if (nextTitle) {
        await runAnalysis({
          roleTitle: nextTitle,
          department: nextDepartment,
          jobDescription: data.text,
          tasks: nextRows,
        });
      }
    } catch (error) {
      toast.error("Could not read that document", {
        description: error instanceof Error ? error.message.slice(0, 140) : undefined,
      });
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };
  const persist = () => {
    if (!analysis) return;
    saveAnalysis(analysis);
    toast.success("Saved to this role's history");
  };

  const backlogRows = useMemo(
    () =>
      store.backlog
        .map((item) => {
          const a = store.analyses.find((x) => x.id === item.analysisId);
          const task = a?.tasks.find((t) => t.id === item.taskId);
          return a && task ? { item, analysis: a, task } : null;
        })
        .filter((r): r is { item: (typeof store.backlog)[number]; analysis: RoleAutomationAnalysis; task: TaskAssessment } => Boolean(r)),
    [store],
  );

  return (
    <div>
      <PageHeader
        title="Automation Insights"
        description="Find the repetitive work that technology can take on, so your people spend more time on judgement, relationships and growth. Estimates are indicative planning inputs — always validate with the role holder."
        actions={
          analysis ? (
            <>
              <Button
                variant="outline"
                onClick={() => {
                  setExporting("pdf");
                  generateAutomationPdf(analysis)
                    .then(() => toast.success("PDF downloaded"))
                    .catch(() => toast.error("PDF export failed"))
                    .finally(() => setExporting(null));
                }}
                disabled={exporting !== null}
              >
                {exporting === "pdf" ? (
                  <Loader2 className="mr-1.5 size-4 animate-spin" />
                ) : (
                  <FileDown className="mr-1.5 size-4" />
                )}
                PDF
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setExporting("pptx");
                  generateAutomationDeck(analysis)
                    .then(() => toast.success("Deck downloaded"))
                    .catch(() => toast.error("PowerPoint export failed"))
                    .finally(() => setExporting(null));
                }}
                disabled={exporting !== null}
              >
                {exporting === "pptx" ? (
                  <Loader2 className="mr-1.5 size-4 animate-spin" />
                ) : (
                  <Download className="mr-1.5 size-4" />
                )}
                PowerPoint
              </Button>
              <Button onClick={persist}>
                <Save className="mr-1.5 size-4" /> Save to role
              </Button>
            </>
          ) : null
        }
      />

      <div className="grid gap-5 p-8 xl:grid-cols-[380px_minmax(0,1fr)]">
        {/* ------------------------------------------------------------ input */}
        <div className="space-y-4">
          <section className="rounded-xl border border-border bg-card p-5 shadow-panel">
            <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-widest text-brand">
              <Sparkles className="size-3.5" /> Role to analyse
            </p>

            <div className="mt-3 space-y-3">
              <div>
                <Label className="text-[12px]">Upload a job description</Label>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,.docx,.xlsx,.txt,.md,.csv"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) void uploadDocument(file);
                  }}
                />
                <button
                  type="button"
                  disabled={uploading || busy}
                  onClick={() => fileInputRef.current?.click()}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    const file = e.dataTransfer.files?.[0];
                    if (file) void uploadDocument(file);
                  }}
                  className="mt-1 flex w-full flex-col items-center gap-1 rounded-lg border border-dashed border-brand/40 bg-brand/5 px-4 py-5 text-center transition hover:border-brand hover:bg-brand/10 disabled:opacity-60"
                >
                  {uploading ? (
                    <Loader2 className="size-5 animate-spin text-brand" />
                  ) : (
                    <Upload className="size-5 text-brand" />
                  )}
                  <span className="text-[12.5px] font-semibold text-foreground">
                    {uploading ? "Reading the document…" : "Drop a PDF, Word or Excel file"}
                  </span>
                  <span className="text-[11px] text-muted-foreground">
                    We read the JD and analyse it automatically — no people data needed
                  </span>
                </button>
                {sourceFile ? (
                  <p className="mt-1.5 flex items-center gap-1.5 text-[11px] text-muted-foreground">
                    <FileText className="size-3.5 text-brand" /> Analysed from {sourceFile}
                  </p>
                ) : null}
              </div>

              <div>
                <Label className="text-[12px]">Pull from this scenario</Label>
                <Select value={employeeId} onValueChange={loadEmployee}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Choose a role" />
                  </SelectTrigger>
                  <SelectContent className="max-h-72">
                    <SelectItem value="adhoc">Ad-hoc role (paste a job description)</SelectItem>
                    {employees.map((e) => (
                      <SelectItem key={e.id} value={e.id}>
                        {e.title}
                        {e.name ? ` — ${e.name}` : ""}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-[12px]">Job title</Label>
                  <Input
                    className="mt-1"
                    value={roleTitle}
                    onChange={(e) => setRoleTitle(e.target.value)}
                    placeholder="Payroll Analyst"
                  />
                </div>
                <div>
                  <Label className="text-[12px]">Department</Label>
                  <Input
                    className="mt-1"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    placeholder="Finance"
                  />
                </div>
              </div>

              <div>
                <Label className="text-[12px]">Responsibilities / job description</Label>
                <Textarea
                  className="mt-1 min-h-32 text-[13px]"
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                  placeholder="Paste the full job description, or one responsibility per line."
                />
                <Button
                  size="sm"
                  variant="outline"
                  className="mt-2 w-full"
                  onClick={() => {
                    const parsed = splitTasks(jobDescription);
                    if (!parsed.length) {
                      toast.error("Nothing to split — add some responsibilities first");
                      return;
                    }
                    setRows(parsed.map((task) => ({ id: uid(), task, hoursPerWeek: 0 })));
                    toast.success(`${parsed.length} tasks extracted`);
                  }}
                >
                  <Wand2 className="mr-1.5 size-3.5" /> Split into tasks
                </Button>
              </div>
            </div>
          </section>

          <section className="rounded-xl border border-border bg-card p-5 shadow-panel">
            <div className="flex items-center justify-between">
              <p className="text-[11px] font-semibold uppercase tracking-widest text-brand">
                Tasks &amp; weekly hours
              </p>
              <span className="text-[11px] text-muted-foreground">optional</span>
            </div>
            <p className="mt-1 text-[11.5px] text-muted-foreground">
              Hours make the score and savings far more accurate — leave blank and we will estimate.
            </p>
            <div className="mt-3 space-y-2">
              {rows.map((row) => (
                <div key={row.id} className="flex items-center gap-2">
                  <Input
                    value={row.task}
                    onChange={(e) =>
                      setRows((prev) =>
                        prev.map((r) => (r.id === row.id ? { ...r, task: e.target.value } : r)),
                      )
                    }
                    className="h-9 text-[12.5px]"
                    placeholder="Task"
                  />
                  <Input
                    type="number"
                    min={0}
                    step={0.5}
                    value={row.hoursPerWeek || ""}
                    onChange={(e) =>
                      setRows((prev) =>
                        prev.map((r) =>
                          r.id === row.id ? { ...r, hoursPerWeek: Number(e.target.value) } : r,
                        ),
                      )
                    }
                    className="h-9 w-16 shrink-0 text-[12.5px]"
                    aria-label={`Hours per week for ${row.task || "task"}`}
                    placeholder="h"
                  />
                  <Button
                    size="icon"
                    variant="ghost"
                    className="size-8 shrink-0 text-muted-foreground"
                    aria-label="Remove task"
                    onClick={() => setRows((prev) => prev.filter((r) => r.id !== row.id))}
                  >
                    <Trash2 className="size-3.5" />
                  </Button>
                </div>
              ))}
              <Button
                size="sm"
                variant="outline"
                className="w-full"
                onClick={() => setRows((prev) => [...prev, { id: uid(), task: "", hoursPerWeek: 0 }])}
              >
                Add task
              </Button>
            </div>
          </section>

          <section className="rounded-xl border border-border bg-card p-5 shadow-panel">
            <p className="text-[11px] font-semibold uppercase tracking-widest text-brand">
              Context &amp; costing
            </p>
            <div className="mt-3 space-y-3">
              <div>
                <Label className="text-[12px]">Tools used today</Label>
                <Input
                  className="mt-1"
                  value={tools}
                  onChange={(e) => setTools(e.target.value)}
                  placeholder="SAP, Excel, ServiceNow"
                />
              </div>
              <div>
                <Label className="text-[12px]">Other context</Label>
                <Input
                  className="mt-1"
                  value={context}
                  onChange={(e) => setContext(e.target.value)}
                  placeholder="Shared service centre, 3 sites, monthly close"
                />
              </div>
              <div>
                <Label className="text-[12px]">Average hourly cost ({currency})</Label>
                <Input
                  className="mt-1"
                  type="number"
                  min={0}
                  value={hourlyCost || ""}
                  onChange={(e) => setHourlyCost(Number(e.target.value))}
                />
              </div>
            </div>
            <Button
              className="mt-4 h-11 w-full text-[14px] font-semibold"
              onClick={() => runAnalysis()}
              disabled={busy}
            >
              {busy ? (
                <Loader2 className="mr-2 size-4 animate-spin" />
              ) : (
                <Bot className="mr-2 size-4" />
              )}
              {busy ? "Analysing…" : "Analyse automation potential"}
            </Button>
          </section>
        </div>

        {/* ----------------------------------------------------------- output */}
        <div className="min-w-0">
          <Tabs defaultValue="analysis">
            <TabsList>
              <TabsTrigger value="analysis">Analysis</TabsTrigger>
              <TabsTrigger value="backlog">
                Automation backlog{backlogRows.length ? ` (${backlogRows.length})` : ""}
              </TabsTrigger>
              <TabsTrigger value="history">Saved analyses ({store.analyses.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="analysis" className="mt-4 space-y-5">
              {!analysis ? (
                <div className="rounded-xl border border-dashed border-border bg-card/50 p-12 text-center">
                  <Sparkles className="mx-auto size-8 text-brand" />
                  <p className="mt-3 text-lg font-semibold">Pick a role and hit analyse</p>
                  <p className="mx-auto mt-1.5 max-w-md text-sm text-muted-foreground">
                    You will get an overall automation score, a task-by-task view of what technology
                    can take on, what should stay human, and the hours that come back to the team.
                  </p>
                </div>
              ) : (
                <>
                  <section className="rounded-xl border border-border bg-card p-6 shadow-panel">
                    <div className="flex flex-col items-center gap-6 sm:flex-row sm:items-start">
                      <AutomationScoreRing score={analysis.overallScore} />
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <h2 className="text-xl font-semibold tracking-tight">
                            {analysis.roleTitle}
                          </h2>
                          <span className="rounded-full bg-brand/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-brand">
                            {analysis.source === "ai" ? "AI-assisted" : "Rule-based estimate"}
                          </span>
                          {analysis.flag !== "none" ? (
                            <span
                              className={cn(
                                "rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide",
                                FLAG_META[analysis.flag].className,
                              )}
                            >
                              {FLAG_META[analysis.flag].label}
                            </span>
                          ) : null}
                        </div>
                        <p className="mt-2 text-[13.5px] leading-relaxed text-muted-foreground">
                          {analysis.summary}
                        </p>
                        <div className="mt-4 flex flex-wrap items-center gap-2">
                          <Select
                            value={analysis.flag}
                            onValueChange={(v) => patchAnalysis({ flag: v as RoleFlag })}
                          >
                            <SelectTrigger className="h-9 w-60">
                              <Flag className="mr-1.5 size-3.5 text-muted-foreground" />
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {(Object.keys(FLAG_META) as RoleFlag[]).map((f) => (
                                <SelectItem key={f} value={f}>
                                  {FLAG_META[f].label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {analysis.employeeId ? (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => navigate({ to: "/chart" })}
                            >
                              View in org chart
                            </Button>
                          ) : null}
                        </div>
                      </div>
                    </div>
                  </section>

                  {totals ? (
                    <>
                      {(() => {
                        const linked = employees.find((e) => e.id === analysis.employeeId) ?? null;
                        const eligibility = Math.max(
                          0,
                          Math.min(100, Math.round(analysis.overallScore)),
                        );
                        const suggestion = suggestRoleType(eligibility);
                        const currentType = linked ? roleTypeOf(linked) : null;
                        const convert = (type: RoleType) => {
                          if (!linked) return;
                          upsertEmployee({
                            ...linked,
                            roleType: type,
                            reductionLever: type === "human" ? linked.reductionLever : "agent",
                            agentMonthlyCost:
                              type === "human"
                                ? undefined
                                : (linked.agentMonthlyCost ?? agentMonthly),
                          });
                          toast.success(
                            `${linked.title || linked.name} is now ${ROLE_TYPE_META[type].label} — headcount and cost impact recalculated.`,
                          );
                        };
                        return (
                          <section className="rounded-xl border border-border bg-card p-5 shadow-panel">
                            <div className="flex flex-wrap items-start justify-between gap-4">
                              <div className="min-w-0">
                                <p className="text-[11px] font-semibold uppercase tracking-widest text-brand">
                                  Human + AI agent recommendation
                                </p>
                                <div className="mt-2 flex flex-wrap items-center gap-2">
                                  <span className="text-2xl font-semibold tabular-nums">
                                    {eligibility}%
                                  </span>
                                  <span className="text-[12px] text-muted-foreground">
                                    automation eligibility
                                  </span>
                                  <span
                                    className="rounded-full border px-2 py-0.5 text-[11px] font-semibold"
                                    style={{
                                      color: `#${ROLE_TYPE_META[suggestion.type].hex}`,
                                      borderColor: `#${ROLE_TYPE_META[suggestion.type].hex}66`,
                                      background: `#${ROLE_TYPE_META[suggestion.type].hex}14`,
                                    }}
                                  >
                                    Suggested: {ROLE_TYPE_META[suggestion.type].label}
                                  </span>
                                  {currentType ? (
                                    <span className="text-[11.5px] text-muted-foreground">
                                      currently {ROLE_TYPE_META[currentType].label}
                                    </span>
                                  ) : null}
                                </div>
                                <p className="mt-2 max-w-2xl text-[13px] leading-relaxed text-muted-foreground">
                                  {suggestion.rationale}
                                </p>
                              </div>
                              <div className="flex flex-wrap items-center gap-2">
                                <Button
                                  size="sm"
                                  disabled={!linked || currentType === "agent"}
                                  onClick={() => convert("agent")}
                                >
                                  Convert to Agent
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  disabled={!linked || currentType === "hybrid"}
                                  onClick={() => convert("hybrid")}
                                >
                                  Make Hybrid
                                </Button>
                                {linked && currentType !== "human" ? (
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => convert("human")}
                                  >
                                    Back to Human
                                  </Button>
                                ) : null}
                              </div>
                            </div>
                            {linked ? (
                              <p className="mt-3 text-[11.5px] text-muted-foreground">
                                Agent running cost for this role:{" "}
                                {formatMoney(agentAnnualCost(linked, agentMonthly), currency)} per
                                year. Edit it per role in the chart designer or change the default on
                                the impact page.
                              </p>
                            ) : (
                              <p className="mt-3 text-[11.5px] text-muted-foreground">
                                Link this analysis to a role in the scenario to apply a delivery
                                model and recalculate impact.
                              </p>
                            )}
                          </section>
                        );
                      })()}
                    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                      <StatCard
                        label="Hours back / week"
                        value={`${totals.hoursPerWeek}h`}
                        sub={`${totals.hoursPerMonth}h per month · ${totals.hoursPerYear}h per year`}
                        tone="positive"
                      />
                      <StatCard
                        label="Indicative annual value"
                        value={formatMoney(totals.annualSaving, currency)}
                        sub={`at ${formatMoney(analysis.hourlyCost, currency)} per hour`}
                        tone="brand"
                      />
                      <StatCard
                        label="Capacity released"
                        value={`${totals.fteEquivalent} FTE`}
                        sub="reinvest in higher-value work"
                      />
                      <StatCard
                        label="Quick wins"
                        value={`${totals.quickWins}`}
                        sub={`${totals.humanTasks} tasks stay human-led`}
                      />
                    </div>
                    </>
                  ) : null}

                  <section className="rounded-xl border border-border bg-card p-5 shadow-panel">
                    <p className="text-[11px] font-semibold uppercase tracking-widest text-brand">
                      Recommended next actions
                    </p>
                    <ol className="mt-3 space-y-2">
                      {analysis.nextActions.map((action, i) => (
                        <li key={i} className="flex gap-3 text-[13.5px] leading-relaxed">
                          <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-brand/10 text-[11px] font-semibold text-brand">
                            {i + 1}
                          </span>
                          {action}
                        </li>
                      ))}
                    </ol>
                  </section>

                  <section className="rounded-xl border border-border bg-card shadow-panel">
                    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border p-4">
                      <div>
                        <p className="text-[13px] font-semibold">Task-by-task breakdown</p>
                        <p className="text-[11.5px] text-muted-foreground">
                          Expand any task to edit the rating, approach or hours.
                        </p>
                      </div>
                      <div className="flex flex-wrap items-center gap-3">
                        <label className="flex items-center gap-2 text-[12px] text-muted-foreground">
                          <Filter className="size-3.5" />
                          High potential only
                          <Switch checked={highOnly} onCheckedChange={setHighOnly} />
                        </label>
                        <Button
                          size="sm"
                          disabled={selected.size === 0}
                          onClick={() => {
                            saveAnalysis(analysis);
                            const added = addToBacklog(analysis.id, [...selected]);
                            setSelected(new Set());
                            toast.success(
                              added
                                ? `${added} task${added === 1 ? "" : "s"} added to the automation backlog`
                                : "Those tasks are already in the backlog",
                            );
                          }}
                        >
                          <ListPlus className="mr-1.5 size-3.5" />
                          Add {selected.size || ""} to backlog
                        </Button>
                      </div>
                    </div>

                    <ul className="divide-y divide-border">
                      {visibleTasks.map((task) => {
                        const meta = BAND_META[task.band];
                        const open = openTask === task.id;
                        return (
                          <li key={task.id}>
                            <Collapsible
                              open={open}
                              onOpenChange={(v) => setOpenTask(v ? task.id : null)}
                            >
                              <div className="flex items-start gap-3 p-4">
                                <Checkbox
                                  checked={selected.has(task.id)}
                                  onCheckedChange={(v) =>
                                    setSelected((prev) => {
                                      const next = new Set(prev);
                                      if (v) next.add(task.id);
                                      else next.delete(task.id);
                                      return next;
                                    })
                                  }
                                  aria-label={`Select ${task.task}`}
                                  className="mt-1"
                                />
                                <div className="min-w-0 flex-1">
                                  <div className="flex flex-wrap items-center gap-2">
                                    <p className="text-[13.5px] font-medium leading-snug">
                                      {task.task}
                                    </p>
                                    <span
                                      className={cn(
                                        "rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide",
                                        meta.badgeClass,
                                      )}
                                    >
                                      {meta.label}
                                    </span>
                                    {task.overridden ? (
                                      <span className="rounded-full bg-info/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-info">
                                        Edited
                                      </span>
                                    ) : null}
                                  </div>
                                  <p className="mt-1 text-[12.5px] text-muted-foreground">
                                    {task.reason}
                                  </p>
                                  <div className="mt-2 flex items-center gap-3">
                                    <div className="h-1.5 w-40 overflow-hidden rounded-full bg-muted">
                                      <div
                                        className={cn("h-full rounded-full", meta.barClass)}
                                        style={{ width: `${Math.max(4, task.score)}%` }}
                                      />
                                    </div>
                                    <span className="text-[11.5px] text-muted-foreground">
                                      {task.score}% · {task.hoursSavedPerWeek}h/wk back
                                      {task.hoursPerWeek ? ` of ${task.hoursPerWeek}h` : ""}
                                    </span>
                                  </div>
                                </div>
                                <CollapsibleTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="shrink-0 text-muted-foreground"
                                  >
                                    {open ? "Close" : "Edit"}
                                    <ChevronDown
                                      className={cn(
                                        "ml-1 size-3.5 transition-transform",
                                        open && "rotate-180",
                                      )}
                                    />
                                  </Button>
                                </CollapsibleTrigger>
                              </div>
                              <CollapsibleContent>
                                <div className="grid gap-3 border-t border-dashed border-border bg-muted/30 p-4 sm:grid-cols-2">
                                  <div>
                                    <Label className="text-[11.5px]">Automatability</Label>
                                    <Select
                                      value={task.band}
                                      onValueChange={(v) => {
                                        const band = v as AutomatabilityBand;
                                        patchTask(task.id, {
                                          band,
                                          score:
                                            band === "full"
                                              ? 92
                                              : band === "high"
                                                ? 75
                                                : band === "partial"
                                                  ? 50
                                                  : 15,
                                          hoursSavedPerWeek: suggestedSaving(
                                            band,
                                            task.hoursPerWeek,
                                          ),
                                        });
                                      }}
                                    >
                                      <SelectTrigger className="mt-1 h-9">
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {BANDS.map((b) => (
                                          <SelectItem key={b} value={b}>
                                            {BAND_META[b].label}
                                          </SelectItem>
                                        ))}
                                      </SelectContent>
                                    </Select>
                                  </div>
                                  <div>
                                    <Label className="text-[11.5px]">Suggested approach</Label>
                                    <Select
                                      value={
                                        APPROACHES.includes(task.approach)
                                          ? task.approach
                                          : (APPROACHES[0] ?? "")
                                      }
                                      onValueChange={(v) => patchTask(task.id, { approach: v })}
                                    >
                                      <SelectTrigger className="mt-1 h-9">
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {APPROACHES.map((a) => (
                                          <SelectItem key={a} value={a}>
                                            {a}
                                          </SelectItem>
                                        ))}
                                      </SelectContent>
                                    </Select>
                                  </div>
                                  <div>
                                    <Label className="text-[11.5px]">Hours per week today</Label>
                                    <Input
                                      type="number"
                                      min={0}
                                      step={0.5}
                                      className="mt-1 h-9"
                                      value={task.hoursPerWeek || ""}
                                      onChange={(e) => {
                                        const hoursPerWeek = Number(e.target.value) || 0;
                                        patchTask(task.id, {
                                          hoursPerWeek,
                                          hoursSavedPerWeek: suggestedSaving(task.band, hoursPerWeek),
                                        });
                                      }}
                                    />
                                  </div>
                                  <div>
                                    <Label className="text-[11.5px]">Hours returned per week</Label>
                                    <Input
                                      type="number"
                                      min={0}
                                      step={0.5}
                                      className="mt-1 h-9"
                                      value={task.hoursSavedPerWeek || ""}
                                      onChange={(e) =>
                                        patchTask(task.id, {
                                          hoursSavedPerWeek: Number(e.target.value) || 0,
                                        })
                                      }
                                    />
                                  </div>
                                  <div className="sm:col-span-2">
                                    <Label className="text-[11.5px]">Reason</Label>
                                    <Textarea
                                      className="mt-1 min-h-16 text-[12.5px]"
                                      value={task.reason}
                                      onChange={(e) => patchTask(task.id, { reason: e.target.value })}
                                    />
                                  </div>
                                </div>
                              </CollapsibleContent>
                            </Collapsible>
                          </li>
                        );
                      })}
                      {visibleTasks.length === 0 ? (
                        <li className="p-6 text-center text-sm text-muted-foreground">
                          No tasks match this filter.
                        </li>
                      ) : null}
                    </ul>
                  </section>

                  <p className="text-[11.5px] leading-relaxed text-muted-foreground">
                    Automation assessments are indicative planning estimates, not commitments. They
                    are not legal, financial or employment advice and must not be the sole basis for
                    role or headcount decisions — validate with the role holder, their manager and
                    qualified local counsel.
                  </p>
                </>
              )}
            </TabsContent>

            <TabsContent value="backlog" className="mt-4">
              <section className="rounded-xl border border-border bg-card shadow-panel">
                <div className="border-b border-border p-4">
                  <p className="text-[13px] font-semibold">Automation backlog</p>
                  <p className="text-[11.5px] text-muted-foreground">
                    Candidate improvement initiatives collected from your analyses.
                  </p>
                </div>
                <ul className="divide-y divide-border">
                  {backlogRows.map(({ item, analysis: a, task }) => (
                    <li key={item.id} className="flex items-start gap-3 p-4">
                      <Checkbox
                        checked={Boolean(item.done)}
                        onCheckedChange={() => toggleBacklogDone(item.id)}
                        aria-label="Mark as done"
                        className="mt-1"
                      />
                      <div className="min-w-0 flex-1">
                        <p
                          className={cn(
                            "text-[13.5px] font-medium",
                            item.done && "text-muted-foreground line-through",
                          )}
                        >
                          {task.task}
                        </p>
                        <p className="mt-0.5 text-[12px] text-muted-foreground">
                          {a.roleTitle} · {task.approach} · {task.hoursSavedPerWeek}h/wk back
                        </p>
                      </div>
                      <span
                        className={cn(
                          "shrink-0 rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide",
                          BAND_META[task.band].badgeClass,
                        )}
                      >
                        {BAND_META[task.band].short}
                      </span>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="size-8 shrink-0 text-muted-foreground"
                        aria-label="Remove from backlog"
                        onClick={() => removeFromBacklog(item.id)}
                      >
                        <Trash2 className="size-3.5" />
                      </Button>
                    </li>
                  ))}
                  {backlogRows.length === 0 ? (
                    <li className="p-8 text-center text-sm text-muted-foreground">
                      Nothing here yet — select tasks in an analysis and add them to the backlog.
                    </li>
                  ) : null}
                </ul>
              </section>
            </TabsContent>

            <TabsContent value="history" className="mt-4">
              <section className="rounded-xl border border-border bg-card shadow-panel">
                <div className="border-b border-border p-4">
                  <p className="text-[13px] font-semibold">Saved analyses</p>
                  <p className="text-[11.5px] text-muted-foreground">
                    Saved against the role, so the org chart and impact views can use them.
                  </p>
                </div>
                <ul className="divide-y divide-border">
                  {store.analyses.map((a) => (
                    <li key={a.id} className="flex items-center gap-3 p-4">
                      <AutomationScoreRing score={a.overallScore} size={54} label="" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13.5px] font-medium">{a.roleTitle}</p>
                        <p className="text-[12px] text-muted-foreground">
                          {a.department || "—"} · {a.tasks.length} tasks ·{" "}
                          {new Date(a.createdAt).toLocaleString()} ·{" "}
                          {formatMoney(computeTotals(a).annualSaving, a.currency)} per year
                        </p>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setAnalysis(a);
                          setRoleTitle(a.roleTitle);
                          setDepartment(a.department);
                          setHourlyCost(a.hourlyCost);
                          setEmployeeId(a.employeeId ?? "adhoc");
                          toast.success("Analysis loaded");
                        }}
                      >
                        <Check className="mr-1.5 size-3.5" /> Open
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="size-8 text-muted-foreground"
                        aria-label="Delete analysis"
                        onClick={() => {
                          deleteAnalysis(a.id);
                          if (analysis?.id === a.id) setAnalysis(null);
                          toast.success("Analysis deleted");
                        }}
                      >
                        <Trash2 className="size-3.5" />
                      </Button>
                    </li>
                  ))}
                  {store.analyses.length === 0 ? (
                    <li className="p-8 text-center text-sm text-muted-foreground">
                      No saved analyses yet.
                    </li>
                  ) : null}
                </ul>
              </section>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}