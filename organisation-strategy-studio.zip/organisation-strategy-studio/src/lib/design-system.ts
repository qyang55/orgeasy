/**
 * Design-system class helpers — the canonical way to compose the
 * "Ocean Teal" look outside of the ui/ primitives.
 *
 * Token values live in src/styles.css (see the header comment there for the
 * full token reference). Use these helpers instead of inventing one-off
 * class strings so surfaces, chips, headings and metrics stay consistent.
 *
 * RULE: never hardcode colors (text-white, bg-black, hex values, raw
 * palette utilities like bg-emerald-500/15) in components — use tokens or
 * the tone map below.
 */
import { cn } from "@/lib/utils";

/** Semantic tone pairs: subtle tinted background + solid status text/border. */
export const tones = {
  brand: "border-brand/25 bg-brand-subtle text-brand",
  success: "border-success/25 bg-success-subtle text-success",
  warning: "border-warning/25 bg-warning-subtle text-warning",
  danger: "border-destructive/25 bg-destructive-subtle text-destructive",
  info: "border-info/25 bg-info-subtle text-info",
  neutral: "border-border bg-surface-3 text-muted-foreground",
} as const;

export type Tone = keyof typeof tones;

/** Small status chip (change badges, counts, flags). */
export const chip = (tone: Tone, className?: string) =>
  cn(
    "inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-2xs font-semibold",
    tones[tone],
    className,
  );

export const ds = {
  /** Standard card / panel surface. */
  panel: "rounded-xl border border-border bg-card text-card-foreground shadow-raised",
  /** Floating surface (popovers, command palettes, canvas toolbars). */
  floating: "rounded-xl border border-border-strong bg-popover text-popover-foreground shadow-panel",
  /** Inset well inside a panel. */
  inset: "rounded-lg border border-border bg-surface-3",
  /** Section heading inside a panel. */
  sectionTitle: "font-display text-sm font-semibold tracking-tight text-foreground",
  /** Eyebrow label above a heading. */
  eyebrow: "font-display text-2xs font-bold uppercase tracking-[0.18em] text-muted-foreground",
  /** Primary KPI numeral. */
  kpi: "font-display text-[34px] font-semibold leading-none tracking-tight tabular-nums text-foreground",
  /** Secondary/medium numeral. */
  metric: "font-display text-xl font-semibold tracking-tight tabular-nums text-foreground",
  /** Muted helper copy. */
  caption: "text-xs leading-relaxed text-muted-foreground",
  /** Shared focus ring for custom interactive elements. */
  focusRing:
    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50 focus-visible:ring-offset-0",
} as const;
