import type PptxGenJSType from "pptxgenjs";
import type { Scenario } from "./types";
import { computeImpact, formatMoney } from "./impact";
import { getGuidance } from "./countries";
import { buildTemplates } from "./templates";
import { DISCLAIMER } from "./types";
import { EXPORT_NOTICES, NOT_LEGAL_ADVICE_SHORT } from "./notices";
import type { ScenarioDiff } from "./diff";
import { drilldownToNotes, type Drilldown } from "./diff";
import { addEditableChart } from "./pptx-chart";
import { BRAND_NAVY, LOGO_COVER, LOGO_MARK, logoData } from "./brand";
import type { ProgrammeSummary } from "./levers";
import type { AgentComparison } from "./agents";
import { analyseSpans } from "./span";
import {
  ADKAR_STAGES,
  SEVERITY_META,
  planProgress,
  readinessBand,
  readinessScore,
  type ChangePlan,
  type MergedAction,
} from "./change-plan";

const NAVY = BRAND_NAVY;
const BLUE = "2563EB";
const INK = "1E293B";
const MUTED = "64748B";
const LIGHT = "F1F5F9";
const WHITE = "FFFFFF";
const RED = "DC2626";
const GREEN = "047857";

const HEAD = "Georgia";
const BODY = "Calibri";

/* ------------------------------------------------------- selectable story */

export const DECK_SECTIONS = [
  { key: "objective", label: "Title & objective", detail: "Purpose, scope and design principles." },
  { key: "currentState", label: "Current state summary", detail: "Positions, cost, layers and span today." },
  { key: "levers", label: "Transformation levers", detail: "Where the reduction comes from, lever by lever." },
  { key: "roadmap", label: "Phase roadmap", detail: "Phase-by-phase headcount and cost path." },
  { key: "phaseDetail", label: "Per-phase detail", detail: "One slide per selected phase." },
  { key: "charts", label: "Structure charts", detail: "Current and future organisation charts." },
  { key: "sideBySide", label: "Side-by-side structures", detail: "Current and future on one slide." },
  { key: "changes", label: "Key changes", detail: "What changed plus the role-level change log." },
  { key: "headcount", label: "Headcount impact", detail: "Totals and department breakdown." },
  { key: "budget", label: "Cost impact", detail: "Annualised people cost movement." },
  { key: "separation", label: "One-off separation costs", detail: "Country cost and consultation risk." },
  { key: "agents", label: "AI agent vs human", detail: "Delivery-model split and agent savings." },
  { key: "adkar", label: "Change readiness (ADKAR)", detail: "Group scores and barrier point." },
  { key: "changePlan", label: "Change impact & stakeholders", detail: "Who is most affected, ordered by severity." },
  { key: "adkarRoadmap", label: "ADKAR roadmap", detail: "Awareness to reinforcement actions, owners and dates." },
  { key: "changeImpact", label: "Change impact & next steps", detail: "Impacted population, messages, actions." },
  { key: "appendix", label: "Appendix drill-downs", detail: "Pinned role-level appendix slides." },
] as const;

export type DeckSectionKey = (typeof DECK_SECTIONS)[number]["key"];

export const ALL_DECK_SECTIONS: DeckSectionKey[] = DECK_SECTIONS.map((s) => s.key);

export interface PptxOptions {
  currentChartPng?: string | null;
  futureChartPng?: string | null;
  /**
   * When set, org charts are drawn as native PowerPoint shapes (editable in
   * PowerPoint) instead of a flat picture.
   */
  editableCharts?: boolean;
  /** Baseline scenario used to draw the editable current-state chart. */
  currentChartScenario?: Scenario | null;
  currentScenarioName?: string;
  diff?: ScenarioDiff | null;
  /** Phase roadmap: one entry per phase, in order. */
  phases?: {
    label: string;
    name: string;
    headcount: number;
    cost: number;
    headcountDelta: number;
    costDelta: number;
  }[];
  /** Per-phase detail sections (chart + changes) for the phases the user selected. */
  phaseSections?: PhaseSection[];
  /** Overrides the downloaded file name (without extension). */
  fileName?: string;
  /** Pinned drill-downs: appended as an appendix slide + speaker notes. */
  drilldowns?: Drilldown[];
  /** Sections the user chose to include. Omit for the full deck. */
  sections?: DeckSectionKey[];
  /** Programme-level lever attribution for the transformation levers slide. */
  programme?: ProgrammeSummary | null;
  /** Human vs agent delivery-model comparison. */
  agents?: AgentComparison | null;
  /** One-line objective shown on the opening slide. */
  objective?: string;
  /** Generated change plan plus user edits, for the change impact + ADKAR roadmap slides. */
  changePlan?: { plan: ChangePlan; actions: MergedAction[] } | null;
}

export interface PhaseSection {
  label: string;
  name: string;
  chartPng?: string | null;
  /** Source scenario so the phase chart can be drawn as editable shapes. */
  chartScenario?: Scenario | null;
  headcount: number;
  cost: number;
  headcountDelta: number;
  costDelta: number;
  baselineName?: string;
  diff?: ScenarioDiff | null;
}

export async function generateDeck(scenario: Scenario, options: PptxOptions = {}) {
  const PptxGenJS = (await import("pptxgenjs")).default;
  const pptx = new PptxGenJS();
  pptx.layout = "LAYOUT_16x9";
  pptx.author = "Organisation Strategy Studio";
  pptx.title = `${scenario.name} — Organisation Design Review`;
  const logo = await logoData();

  const impact = computeImpact(scenario);
  const cur = scenario.currency;
  const has = (key: DeckSectionKey) => !options.sections || options.sections.includes(key);
  const dateLabel = new Date().toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const addDark = () => {
    const s = pptx.addSlide();
    s.background = { color: NAVY };
    if (logo) {
      s.addImage({
        data: logo,
        x: LOGO_COVER.x,
        y: LOGO_COVER.y,
        w: LOGO_COVER.size,
        h: LOGO_COVER.size,
      });
    }
    return s;
  };
  const addLight = (title: string, kicker?: string) => {
    const s = pptx.addSlide();
    s.background = { color: WHITE };
    s.addShape("rect", { x: 0, y: 0, w: 0.22, h: 5.63, fill: { color: BLUE } });
    if (logo) {
      s.addImage({
        data: logo,
        x: LOGO_MARK.x,
        y: LOGO_MARK.y,
        w: LOGO_MARK.size,
        h: LOGO_MARK.size,
      });
    }
    if (kicker) {
      s.addText(kicker.toUpperCase(), {
        x: 0.6,
        y: 0.35,
        w: 8.8,
        h: 0.3,
        fontFace: BODY,
        fontSize: 14,
        color: BLUE,
        bold: true,
        charSpacing: 2,
      });
    }
    s.addText(title, {
      x: 0.6,
      y: kicker ? 0.68 : 0.5,
      w: 8.8,
      h: 0.8,
      fontFace: HEAD,
      fontSize: 40,
      bold: true,
      color: NAVY,
    });
    return s;
  };
  const footnote = (slide: PptxGenJSType.Slide, text = DISCLAIMER) => {
    slide.addText(text, {
      x: 0.6,
      y: 5.02,
      w: 8.8,
      h: 0.5,
      fontFace: BODY,
      fontSize: 10,
      italic: true,
      color: MUTED,
    });
  };

  /**
   * Places a chart on a slide: native editable shapes when the user asked for
   * them, otherwise the pre-rendered picture.
   */
  const drawChart = (
    slide: PptxGenJSType.Slide,
    png: string | null | undefined,
    source: Scenario | null | undefined,
    box: { x: number; y: number; w: number; h: number },
  ) => {
    if (options.editableCharts && source && addEditableChart(slide, source, box)) return true;
    if (!png) return false;
    slide.addImage({
      data: png,
      x: box.x,
      y: box.y,
      w: box.w,
      h: box.h,
      sizing: { type: "contain", w: box.w, h: box.h },
    });
    return true;
  };

  // 1. Title
  const title = addDark();
  title.addShape("rect", { x: 0, y: 4.9, w: 10, h: 0.73, fill: { color: BLUE } });
  title.addText("Organisation Design Review", {
    x: 0.8,
    y: 1.5,
    w: 8.4,
    h: 0.5,
    fontFace: BODY,
    fontSize: 18,
    color: LIGHT,
    charSpacing: 3,
  });
  title.addText(scenario.name, {
    x: 0.8,
    y: 2.05,
    w: 8.4,
    h: 1.5,
    fontFace: HEAD,
    fontSize: 48,
    bold: true,
    color: WHITE,
  });
  title.addText(dateLabel, {
    x: 0.8,
    y: 3.6,
    w: 8.4,
    h: 0.4,
    fontFace: BODY,
    fontSize: 20,
    color: LIGHT,
  });
  title.addText("Prepared with Organisation Strategy Studio — illustrative, not legal advice", {
    x: 0.8,
    y: 5.02,
    w: 8.4,
    h: 0.4,
    fontFace: BODY,
    fontSize: 12,
    color: WHITE,
  });

  // 1a. Objective & scope
  if (has("objective")) {
    const obj = addLight("Objective & Scope", "Why we are doing this");
    obj.addText(
      options.objective ??
        `Design and test a future organisation for “${scenario.name}” that protects delivery while removing structural cost, duplication and unnecessary layers.`,
      { x: 0.6, y: 1.5, w: 8.8, h: 0.8, fontFace: BODY, fontSize: 20, color: INK },
    );
    obj.addText(
      [
        `Scope: ${impact.currentHeadcount.toLocaleString()} positions across ${impact.byCountry.length} markets and ${impact.byDepartment.length} functions.`,
        "Design principles: clear accountability, spans of 5–9 reports, no duplicated ownership of the same outcome.",
        "Levers assessed: headcount, span of control, duplicate roles, AI and automation, agent deployment.",
        "Every proposal is modelled first, then tested against local legal and consultation requirements.",
        "Decisions requested: confirm the target operating model, the phasing and the consultation calendar.",
      ].map((text) => ({
        text,
        options: { bullet: true, fontFace: BODY, fontSize: 16, color: INK, paraSpaceAfter: 9 },
      })),
      { x: 0.75, y: 2.45, w: 8.55, h: 2.4 },
    );
    footnote(obj);
  }

  // 1b. Current state summary
  if (has("currentState")) {
    const span = analyseSpans(options.currentChartScenario ?? scenario);
    const cs = addLight("Current State Summary", "Where we are today");
    const tiles: [string, string][] = [
      ["Positions", impact.currentHeadcount.toLocaleString()],
      ["Annual people cost", formatMoney(impact.currentCost, cur)],
      ["Management layers", String(span.maxLayer)],
      ["Average span", span.avgSpan.toFixed(1)],
    ];
    tiles.forEach(([label, value], i) => {
      const x = 0.6 + i * 2.25;
      cs.addShape("rect", { x, y: 1.5, w: 2.05, h: 1.25, fill: { color: LIGHT } });
      cs.addText(value, {
        x: x + 0.14,
        y: 1.62,
        w: 1.8,
        h: 0.65,
        fontFace: HEAD,
        fontSize: 26,
        bold: true,
        color: NAVY,
      });
      cs.addText(label, {
        x: x + 0.14,
        y: 2.28,
        w: 1.8,
        h: 0.32,
        fontFace: BODY,
        fontSize: 12,
        color: MUTED,
      });
    });
    cs.addTable(
      [
        [
          { text: "Function", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Positions", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Annual cost", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
        ],
        ...impact.byDepartment
          .slice(0, 7)
          .map((d) => [
            { text: d.department },
            { text: String(d.currentHeadcount) },
            { text: formatMoney(d.currentCost, cur) },
          ]),
      ],
      {
        x: 0.6,
        y: 2.95,
        w: 8.8,
        colW: [4.6, 2.1, 2.1],
        fontFace: BODY,
        fontSize: 12,
        color: INK,
        border: { type: "solid", color: "D9E2EC", pt: 1 },
        margin: 5,
      },
    );
    if (span.duplicates.length || span.narrow.length) {
      cs.addText(
        `Structural signals: ${span.narrow.length} managers below the span benchmark · ${span.duplicates.length} potential duplicate role clusters.`,
        { x: 0.6, y: 4.78, w: 8.8, h: 0.35, fontFace: BODY, fontSize: 12, italic: true, color: MUTED },
      );
    }
  }

  // 1c. Transformation levers
  const programme = options.programme;
  if (has("levers") && programme && programme.levers.some((l) => l.positions > 0)) {
    const lev = addLight("Transformation Levers", "Where the change comes from");
    lev.addText(
      `${programme.achievedReduction.toLocaleString()} positions removed (${(programme.achievedPct * 100).toFixed(1)}% of a ${(programme.targetPct * 100).toFixed(0)}% target) · ${formatMoney(programme.costSaving, programme.currency)} annual saving.`,
      { x: 0.6, y: 1.48, w: 8.8, h: 0.4, fontFace: BODY, fontSize: 15, color: INK },
    );
    lev.addTable(
      [
        [
          { text: "Lever", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Positions", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Annual saving", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "How it is delivered", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
        ],
        ...programme.levers
          .filter((l) => l.positions > 0)
          .map((l) => [
            { text: l.label, options: { bold: true, color: `${l.hex}` } },
            { text: l.positions.toLocaleString() },
            { text: formatMoney(l.cost, programme.currency) },
            { text: l.description, options: { color: MUTED } },
          ]),
      ],
      {
        x: 0.6,
        y: 2.0,
        w: 8.8,
        colW: [1.9, 1.1, 1.6, 4.2],
        fontFace: BODY,
        fontSize: 12,
        color: INK,
        border: { type: "solid", color: "D9E2EC", pt: 1 },
        margin: 5,
      },
    );
    footnote(lev);
  }

  // 1d. Phased roadmap
  const phases = options.phases ?? [];
  if (has("roadmap") && phases.length > 1) {
    const road = addLight("Phased Roadmap", "Programme view");
    road.addTable(
      [
        [
          { text: "Phase", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Scenario", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Positions", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Annual cost", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          {
            text: "Change vs prior",
            options: { bold: true, color: WHITE, fill: { color: NAVY } },
          },
        ],
        ...phases.slice(0, 8).map((p) => [
          { text: p.label, options: { bold: true, color: NAVY } },
          { text: p.name },
          { text: p.headcount.toLocaleString() },
          { text: formatMoney(p.cost, cur) },
          {
            text: `${p.headcountDelta > 0 ? "+" : ""}${p.headcountDelta} pos · ${p.costDelta <= 0 ? "−" : "+"}${formatMoney(Math.abs(p.costDelta), cur)}`,
            options: { color: p.costDelta <= 0 ? GREEN : RED },
          },
        ]),
      ],
      {
        x: 0.6,
        y: 1.55,
        w: 8.8,
        colW: [1.5, 3.1, 1.2, 1.6, 1.4],
        fontFace: BODY,
        fontSize: 12,
        color: INK,
        border: { type: "solid", color: "D9E2EC", pt: 1 },
        margin: 6,
      },
    );
    road.addText(
      "Each phase is measured against the phase before it, so cumulative impact is visible across the programme.",
      { x: 0.6, y: 4.8, w: 8.8, h: 0.4, fontFace: BODY, fontSize: 11, italic: true, color: MUTED },
    );
  }

  // 1c. Per-phase detail sections
  for (const section of has("phaseDetail") ? (options.phaseSections ?? []) : []) {
    const s = addLight(`${section.label} — ${section.name}`, "Phase detail");
    const hasChart = drawChart(s, section.chartPng, section.chartScenario, {
      x: 0.6,
      y: 1.5,
      w: 5.3,
      h: 3.3,
    });
    const infoX = hasChart ? 6.1 : 0.6;
    const infoW = hasChart ? 3.3 : 8.8;
    const lines: string[] = [
      `${section.headcount.toLocaleString()} positions`,
      `${formatMoney(section.cost, cur)} annual people cost`,
      `${section.headcountDelta > 0 ? "+" : ""}${section.headcountDelta} positions vs ${section.baselineName ?? "prior phase"}`,
      `${section.costDelta <= 0 ? "−" : "+"}${formatMoney(Math.abs(section.costDelta), cur)} annual cost vs ${section.baselineName ?? "prior phase"}`,
    ];
    if (section.diff) {
      lines.push(
        `${section.diff.added.length} roles added · ${section.diff.removed.length} removed · ${section.diff.changed.length} changed`,
        `${section.diff.layers.base} → ${section.diff.layers.target} management layers`,
        `Average span ${section.diff.span.base.toFixed(1)} → ${section.diff.span.target.toFixed(1)}`,
      );
    }
    s.addText(
      lines.map((text) => ({
        text,
        options: { bullet: true, fontFace: BODY, fontSize: 14, color: INK, paraSpaceAfter: 8 },
      })),
      { x: infoX, y: 1.55, w: infoW, h: 3.2 },
    );
    footnote(s);
  }

  // 2. Current org chart
  let currentDrawn = false;
  let futureDrawn = false;
  if (has("charts")) {
    const currentSlide = addLight(
      options.currentScenarioName
        ? `Current Organisation — ${options.currentScenarioName}`
        : "Current Organisation",
      "Baseline",
    );
    currentDrawn = drawChart(
      currentSlide,
      options.currentChartPng,
      options.currentChartScenario,
      { x: 0.6, y: 1.5, w: 8.8, h: 3.3 },
    );
    if (!currentDrawn) {
      currentSlide.addText(
        `${impact.currentHeadcount.toLocaleString()} positions across ${impact.byCountry.length} countries and ${impact.byDepartment.length} departments.`,
        { x: 0.6, y: 1.7, w: 8.8, h: 0.5, fontFace: BODY, fontSize: 22, color: INK },
      );
      currentSlide.addText(
        impact.byDepartment.map((d) => ({
          text: `${d.department}: ${d.currentHeadcount} positions · ${formatMoney(d.currentCost, cur)}`,
          options: { bullet: true, fontFace: BODY, fontSize: 18, color: INK },
        })),
        { x: 0.8, y: 2.4, w: 8.6, h: 2.4 },
      );
    }

    // 3. Future org chart
    const futureSlide = addLight("Future Organisation", "Proposed");
    futureDrawn = drawChart(futureSlide, options.futureChartPng, scenario, {
      x: 0.6,
      y: 1.5,
      w: 8.8,
      h: 3.3,
    });
    if (!futureDrawn) {
      futureSlide.addText(
        `${impact.plannedHeadcount.toLocaleString()} planned positions. ${impact.newRoles.length} new, ${impact.removedRoles.length} proposed for removal, ${impact.movedRoles.length} reassigned.`,
        { x: 0.6, y: 1.7, w: 8.8, h: 0.6, fontFace: BODY, fontSize: 22, color: INK },
      );
    }
  }

  // 4. Side-by-side comparison
  if (has("sideBySide") && currentDrawn && futureDrawn) {
    const cmp = addLight("Current vs Future", "Side by side");
    cmp.addText("Current", {
      x: 0.6,
      y: 1.5,
      w: 4.2,
      h: 0.35,
      fontFace: BODY,
      fontSize: 16,
      bold: true,
      color: MUTED,
    });
    cmp.addText("Future", {
      x: 5.2,
      y: 1.5,
      w: 4.2,
      h: 0.35,
      fontFace: BODY,
      fontSize: 16,
      bold: true,
      color: BLUE,
    });
    drawChart(cmp, options.currentChartPng, options.currentChartScenario, {
      x: 0.6,
      y: 1.9,
      w: 4.2,
      h: 2.9,
    });
    drawChart(cmp, options.futureChartPng, scenario, { x: 5.2, y: 1.9, w: 4.2, h: 2.9 });
  }

  // 5. Current vs future difference summary
  const diff = options.diff;
  if (has("changes") && diff) {
    const delta = addLight("What Changed", "Current vs future");
    const rows: PptxGenJSType.TableRow[] = [
      [
        { text: "Measure", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
        { text: diff.base.name, options: { bold: true, color: WHITE, fill: { color: NAVY } } },
        { text: diff.target.name, options: { bold: true, color: WHITE, fill: { color: NAVY } } },
        { text: "Change", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
      ],
      [
        { text: "Positions" },
        { text: diff.headcount.base.toLocaleString() },
        { text: diff.headcount.target.toLocaleString() },
        {
          text: `${diff.headcount.delta > 0 ? "+" : ""}${diff.headcount.delta}`,
          options: { color: diff.headcount.delta < 0 ? RED : GREEN, bold: true },
        },
      ],
      [
        { text: "Annual people cost" },
        { text: formatMoney(diff.cost.base, cur) },
        { text: formatMoney(diff.cost.target, cur) },
        {
          text: `${diff.cost.delta <= 0 ? "−" : "+"}${formatMoney(Math.abs(diff.cost.delta), cur)}`,
          options: { color: diff.cost.delta <= 0 ? GREEN : RED, bold: true },
        },
      ],
      [
        { text: "Management layers" },
        { text: String(diff.layers.base) },
        { text: String(diff.layers.target) },
        {
          text: `${diff.layers.target - diff.layers.base > 0 ? "+" : ""}${diff.layers.target - diff.layers.base}`,
        },
      ],
      [
        { text: "Average span of control" },
        { text: diff.span.base.toFixed(1) },
        { text: diff.span.target.toFixed(1) },
        {
          text: `${diff.span.target - diff.span.base > 0 ? "+" : ""}${(diff.span.target - diff.span.base).toFixed(1)}`,
        },
      ],
      [
        { text: "Roles added / removed / changed" },
        { text: "—" },
        { text: `${diff.added.length} / ${diff.removed.length} / ${diff.changed.length}` },
        { text: `${diff.unchangedCount} unchanged` },
      ],
    ];
    delta.addTable(rows, {
      x: 0.6,
      y: 1.55,
      w: 8.8,
      colW: [3.1, 1.9, 1.9, 1.9],
      fontFace: BODY,
      fontSize: 13,
      color: INK,
      border: { type: "solid", color: "D9E2EC", pt: 1 },
      margin: 6,
    });
    delta.addText(
      `Baseline “${diff.base.name}” compared against “${diff.target.name}”. Costs are fully loaded annual figures.`,
      { x: 0.6, y: 4.75, w: 8.8, h: 0.4, fontFace: BODY, fontSize: 11, italic: true, color: MUTED },
    );

    // 5b. Role-level change log
    const log = addLight("Role-Level Change Log", "Difference detail");
    const logRows: PptxGenJSType.TableRow[] = [
      [
        { text: "Change", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
        { text: "Role", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
        { text: "Detail", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
      ],
      ...diff.added
        .slice(0, 5)
        .map((e) => [
          { text: "Added", options: { color: GREEN, bold: true } },
          { text: `${e.name || "Open Role"} — ${e.title}` },
          { text: `${e.department || "—"} · ${e.country} · ${formatMoney(e.plannedCost, cur)}` },
        ]),
      ...diff.removed
        .slice(0, 5)
        .map((e) => [
          { text: "Removed", options: { color: RED, bold: true } },
          { text: `${e.name || "Open Role"} — ${e.title}` },
          { text: `${e.department || "—"} · ${e.country} · ${formatMoney(e.currentCost, cur)}` },
        ]),
      ...diff.changed.slice(0, 6).map((c) => [
        { text: "Changed", options: { color: BLUE, bold: true } },
        { text: `${c.after.name || c.before.name || "Open Role"} — ${c.after.title}` },
        {
          text: c.changes
            .slice(0, 3)
            .map((ch) => `${ch.label}: ${ch.before} → ${ch.after}`)
            .join("; "),
        },
      ]),
    ];
    log.addTable(logRows, {
      x: 0.6,
      y: 1.5,
      w: 8.8,
      colW: [1.2, 3.2, 4.4],
      fontFace: BODY,
      fontSize: 11,
      color: INK,
      border: { type: "solid", color: "D9E2EC", pt: 1 },
      margin: 5,
    });
    if (diff.added.length + diff.removed.length + diff.changed.length > 16) {
      log.addText("Full change log available as CSV from the Exports page.", {
        x: 0.6,
        y: 5.02,
        w: 8.8,
        h: 0.4,
        fontFace: BODY,
        fontSize: 11,
        italic: true,
        color: MUTED,
      });
    }
  }

  const stat = (
    slide: PptxGenJSType.Slide,
    x: number,
    label: string,
    value: string,
    color: string,
  ) => {
    slide.addShape("rect", { x, y: 1.55, w: 2.7, h: 1.5, fill: { color: LIGHT } });
    slide.addText(value, {
      x: x + 0.15,
      y: 1.7,
      w: 2.4,
      h: 0.85,
      fontFace: HEAD,
      fontSize: 40,
      bold: true,
      color,
    });
    slide.addText(label, {
      x: x + 0.15,
      y: 2.58,
      w: 2.4,
      h: 0.35,
      fontFace: BODY,
      fontSize: 14,
      color: MUTED,
    });
  };

  // 6. Headcount impact
  if (has("headcount")) {
  const hc = addLight("Headcount Impact", "Summary");
  stat(hc, 0.6, "Current positions", impact.currentHeadcount.toLocaleString(), NAVY);
  stat(hc, 3.65, "Planned positions", impact.plannedHeadcount.toLocaleString(), BLUE);
  stat(
    hc,
    6.7,
    "Net change",
    `${impact.headcountDelta > 0 ? "+" : ""}${impact.headcountDelta}`,
    impact.headcountDelta < 0 ? RED : GREEN,
  );
  hc.addTable(
    [
      [
        { text: "Department", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
        { text: "Current", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
        { text: "Planned", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
        { text: "Change", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
      ],
      ...impact.byDepartment.slice(0, 7).map((d) => [
        { text: d.department },
        { text: String(d.currentHeadcount) },
        { text: String(d.plannedHeadcount) },
        {
          text: `${d.plannedHeadcount - d.currentHeadcount > 0 ? "+" : ""}${d.plannedHeadcount - d.currentHeadcount}`,
          options: { color: d.plannedHeadcount < d.currentHeadcount ? RED : GREEN },
        },
      ]),
    ],
    {
      x: 0.6,
      y: 3.3,
      w: 8.8,
      colW: [4.3, 1.5, 1.5, 1.5],
      fontFace: BODY,
      fontSize: 13,
      color: INK,
      border: { type: "solid", color: "D9E2EC", pt: 1 },
      margin: 6,
    },
  );
  }

  // 6. Budget impact
  if (has("budget")) {
  const budget = addLight("Budget Impact", "Annualised people cost");
  stat(budget, 0.6, "Current cost", formatMoney(impact.currentCost, cur), NAVY);
  stat(budget, 3.65, "Planned cost", formatMoney(impact.plannedCost, cur), BLUE);
  stat(
    budget,
    6.7,
    impact.costDelta <= 0 ? "Annual saving" : "Annual increase",
    formatMoney(Math.abs(impact.costDelta), cur),
    impact.costDelta <= 0 ? GREEN : RED,
  );
  budget.addTable(
    [
      [
        { text: "Department", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
        { text: "Current cost", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
        { text: "Planned cost", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
      ],
      ...impact.byDepartment
        .slice(0, 7)
        .map((d) => [
          { text: d.department },
          { text: formatMoney(d.currentCost, cur) },
          { text: formatMoney(d.plannedCost, cur) },
        ]),
    ],
    {
      x: 0.6,
      y: 3.3,
      w: 8.8,
      colW: [4.3, 2.25, 2.25],
      fontFace: BODY,
      fontSize: 13,
      color: INK,
      border: { type: "solid", color: "D9E2EC", pt: 1 },
      margin: 6,
    },
  );
  }

  // 7. Country separation overview
  if (has("separation")) {
  const sep = addLight("One-Off Separation Cost", "Country view");
  const separation = impact.separation;
  if (separation.exits > 0) {
    stat(sep, 0.6, "Exits modelled", separation.exits.toLocaleString(), NAVY);
    stat(sep, 3.65, "Mid-case one-off cost", formatMoney(separation.mid, cur), BLUE);
    stat(
      sep,
      6.7,
      "High-risk markets",
      String(separation.highRiskCountries.length),
      separation.highRiskCountries.length ? RED : GREEN,
    );
    sep.addText(
      `Range ${formatMoney(separation.low, cur)} – ${formatMoney(separation.high, cur)}. Includes legal fees ${formatMoney(separation.legalFees, cur)}, tribunal/labour-court exposure ${formatMoney(separation.tribunalRisk, cur)} (~${separation.expectedClaims.toFixed(0)} expected claims) and collective procedure cost ${formatMoney(separation.collectiveCost, cur)} in ${separation.collectiveMarkets.length} market${separation.collectiveMarkets.length === 1 ? "" : "s"}.`,
      { x: 0.6, y: 3.15, w: 8.8, h: 0.32, fontFace: BODY, fontSize: 12, italic: true, color: MUTED },
    );
    sep.addTable(
      [
        [
          { text: "Country", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Exits", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Notice + severance", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Legal fees", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Tribunal risk", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Collective", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Mid case", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Risk", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
        ],
        ...separation.byCountry.slice(0, 7).map((c) => [
          { text: c.country },
          { text: String(c.exits) },
          { text: formatMoney(c.noticeCost + c.severanceCost, cur) },
          { text: formatMoney(c.legalFees + c.outplacement + c.adminCost, cur) },
          { text: formatMoney(c.tribunalRisk, cur) },
          { text: c.collectiveTriggered ? formatMoney(c.collectiveCost, cur) : "—" },
          { text: formatMoney(c.mid, cur), options: { bold: true } },
          {
            text: c.rule.risk,
            options: {
              color: c.rule.risk === "High" ? RED : c.rule.risk === "Medium" ? "B45309" : GREEN,
            },
          },
        ]),
      ],
      {
        x: 0.6,
        y: 3.55,
        w: 8.8,
        colW: [1.7, 0.6, 1.5, 1.2, 1.2, 1.0, 1.1, 0.5],
        fontFace: BODY,
        fontSize: 9,
        color: INK,
        border: { type: "solid", color: "D9E2EC", pt: 1 },
        margin: 5,
      },
    );
  } else {
    sep.addText("No exits are currently modelled in this scenario.", {
      x: 0.6,
      y: 1.7,
      w: 8.8,
      h: 0.5,
      fontFace: BODY,
      fontSize: 20,
      color: INK,
    });
  }
  footnote(sep);

  const guide = addLight("Country Guidance", "Legal considerations");
  const removalCountries = impact.byCountry.filter((c) => c.removed > 0);
  if (removalCountries.length) {
    guide.addTable(
      [
        [
          { text: "Country", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Roles", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          {
            text: "Illustrative cost",
            options: { bold: true, color: WHITE, fill: { color: NAVY } },
          },
          {
            text: "Key consideration",
            options: { bold: true, color: WHITE, fill: { color: NAVY } },
          },
        ],
        ...removalCountries
          .slice(0, 8)
          .map((c) => [
            { text: c.country },
            { text: String(c.removed) },
            { text: formatMoney(c.illustrativeSeverance, cur) },
            { text: getGuidance(c.country)?.considerations[0] ?? "Seek local legal counsel." },
          ]),
      ],
      {
        x: 0.6,
        y: 1.55,
        w: 8.8,
        colW: [1.7, 0.8, 1.8, 4.5],
        fontFace: BODY,
        fontSize: 12,
        color: INK,
        border: { type: "solid", color: "D9E2EC", pt: 1 },
        margin: 6,
      },
    );
  } else {
    guide.addText("No roles are currently marked as To Be Removed in this scenario.", {
      x: 0.6,
      y: 1.7,
      w: 8.8,
      h: 0.5,
      fontFace: BODY,
      fontSize: 20,
      color: INK,
    });
  }
  footnote(guide);
  }

  // 7b. AI agent vs human delivery model
  const agents = options.agents;
  if (has("agents") && agents && (agents.agentsAdded > 0 || impact.agentPositions > 0)) {
    const ag = addLight("AI Agents vs Human Delivery", "Operating model");
    stat(ag, 0.6, "Human positions", agents.agentHeavy.humanHeadcount.toLocaleString(), NAVY);
    stat(ag, 3.65, "Agent & hybrid roles", agents.agentsAdded.toLocaleString(), BLUE);
    stat(
      ag,
      6.7,
      agents.costSaving >= 0 ? "Annual saving" : "Annual increase",
      formatMoney(Math.abs(agents.costSaving), agents.currency),
      agents.costSaving >= 0 ? GREEN : RED,
    );
    ag.addTable(
      [
        [
          { text: "Measure", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Human-only baseline", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Agent-enabled target", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
        ],
        [
          { text: "Human positions" },
          { text: agents.traditional.humanHeadcount.toLocaleString() },
          { text: agents.agentHeavy.humanHeadcount.toLocaleString() },
        ],
        [
          { text: "Agent roles" },
          { text: "0" },
          { text: agents.agentHeavy.agentHeadcount.toLocaleString() },
        ],
        [
          { text: "Hybrid roles" },
          { text: "0" },
          { text: agents.agentHeavy.hybridHeadcount.toLocaleString() },
        ],
        [
          { text: "People cost" },
          { text: formatMoney(agents.traditional.humanCost, agents.currency) },
          { text: formatMoney(agents.agentHeavy.humanCost, agents.currency) },
        ],
        [
          { text: "Agent running cost" },
          { text: formatMoney(0, agents.currency) },
          { text: formatMoney(agents.agentHeavy.agentCost, agents.currency) },
        ],
        [
          { text: "Total annual cost", options: { bold: true } },
          { text: formatMoney(agents.traditional.totalCost, agents.currency), options: { bold: true } },
          { text: formatMoney(agents.agentHeavy.totalCost, agents.currency), options: { bold: true } },
        ],
      ],
      {
        x: 0.6,
        y: 3.2,
        w: 8.8,
        colW: [3.4, 2.7, 2.7],
        fontFace: BODY,
        fontSize: 11.5,
        color: INK,
        border: { type: "solid", color: "D9E2EC", pt: 1 },
        margin: 5,
      },
    );
    ag.addNotes(
      agents.convertedRoles
        .slice(0, 25)
        .map((r) => `${r.employee.title}: ${r.from} → ${r.to}`)
        .join("\n"),
    );
  }

  // 8. ADKAR
  if (has("adkar")) {
  const adkar = addLight("ADKAR Assessment", "Change readiness");
  const keys = ["awareness", "desire", "knowledge", "ability", "reinforcement"] as const;
  if (scenario.adkarGroups.length) {
    adkar.addTable(
      [
        [
          { text: "Group", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          ...keys.map((k) => ({
            text: k.charAt(0).toUpperCase() + k.slice(1),
            options: { bold: true, color: WHITE, fill: { color: NAVY } },
          })),
        ],
        ...scenario.adkarGroups.map((g) => [
          { text: g.name },
          ...keys.map((k) => ({
            text: `${g.scores[k]}/5`,
            options: { color: g.scores[k] <= 2 ? RED : g.scores[k] >= 4 ? GREEN : INK },
          })),
        ]),
      ],
      {
        x: 0.6,
        y: 1.55,
        w: 8.8,
        colW: [2.8, 1.2, 1.2, 1.2, 1.2, 1.2],
        fontFace: BODY,
        fontSize: 13,
        color: INK,
        border: { type: "solid", color: "D9E2EC", pt: 1 },
        margin: 6,
      },
    );
    const weakest = keys
      .map((k) => ({
        k,
        avg:
          scenario.adkarGroups.reduce((a, g) => a + g.scores[k], 0) / scenario.adkarGroups.length,
      }))
      .sort((a, b) => a.avg - b.avg)[0];
    adkar.addText(
      `Barrier point: ${weakest ? weakest.k.toUpperCase() : "n/a"} — focus change effort here before moving downstream.`,
      { x: 0.6, y: 4.4, w: 8.8, h: 0.5, fontFace: BODY, fontSize: 16, bold: true, color: BLUE },
    );
  } else {
    adkar.addText("No ADKAR assessment has been recorded for this scenario yet.", {
      x: 0.6,
      y: 1.7,
      w: 8.8,
      h: 0.5,
      fontFace: BODY,
      fontSize: 20,
      color: INK,
    });
  }
  }

  // 8b. Change impact & stakeholder severity
  const cp = options.changePlan ?? null;
  if (has("changePlan") && cp) {
    const plan = cp.plan;
    const s = addLight("Change Impact & Stakeholders", "Change management");
    s.addText(plan.headline, {
      x: 0.6,
      y: 1.45,
      w: 8.8,
      h: 0.5,
      fontFace: BODY,
      fontSize: 14,
      color: INK,
    });
    const groups = plan.groups.slice(0, 7);
    if (groups.length) {
      s.addTable(
        [
          [
            { text: "Group", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
            { text: "Severity", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
            { text: "Positions", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
            { text: "Affected", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
            { text: "What is changing", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          ],
          ...groups.map((g) => [
            { text: g.name },
            {
              text: SEVERITY_META[g.severity].label,
              options: { bold: true, color: SEVERITY_META[g.severity].hex },
            },
            { text: String(g.positions) },
            { text: `${Math.round(g.touchRate * 100)}%` },
            { text: g.drivers.join(" · "), options: { fontSize: 11, color: MUTED } },
          ]),
        ],
        {
          x: 0.6,
          y: 2.05,
          w: 8.8,
          colW: [2.2, 1.1, 0.9, 0.9, 3.7],
          fontFace: BODY,
          fontSize: 12,
          color: INK,
          border: { type: "solid", color: "D9E2EC", pt: 1 },
          margin: 6,
        },
      );
    }
    const readiness = readinessScore(plan, cp.actions);
    s.addText(
      `Change readiness ${readiness}% (${readinessBand(readiness).label}) · ${planProgress(cp.actions)}% of ADKAR actions complete${plan.barrier ? ` · barrier point: ${plan.barrier.toUpperCase()}` : ""}`,
      { x: 0.6, y: 4.65, w: 8.8, h: 0.4, fontFace: BODY, fontSize: 13, bold: true, color: BLUE },
    );
  }

  // 8c. High-level ADKAR roadmap
  if (has("adkarRoadmap") && cp) {
    const s = addLight("ADKAR Roadmap", "Change management");
    s.addText("Awareness through reinforcement — owners and dates as agreed with the programme.", {
      x: 0.6,
      y: 1.45,
      w: 8.8,
      h: 0.35,
      fontFace: BODY,
      fontSize: 13,
      color: MUTED,
    });
    const rows: PptxGenJSType.TableRow[] = [
      [
        { text: "Stage", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
        { text: "Actions", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
        { text: "Owner / by", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
      ],
    ];
    for (const stage of ADKAR_STAGES) {
      const items = cp.actions.filter((a) => a.stage === stage.key);
      if (!items.length) continue;
      rows.push([
        { text: stage.label, options: { bold: true, color: stage.hex } },
        {
          text: items.map((a) => `• ${a.title}${a.done ? " (done)" : ""}`).join("\n"),
          options: { fontSize: 11 },
        },
        {
          text: items
            .map((a) => `${a.owner || a.suggestedOwner}${a.due ? ` — ${a.due}` : ` — wk ${a.week}`}`)
            .join("\n"),
          options: { fontSize: 10, color: MUTED },
        },
      ]);
    }
    s.addTable(rows, {
      x: 0.6,
      y: 1.9,
      w: 8.8,
      colW: [1.5, 5.2, 2.1],
      fontFace: BODY,
      fontSize: 11,
      color: INK,
      border: { type: "solid", color: "D9E2EC", pt: 1 },
      margin: 5,
      valign: "top",
    });
    s.addNotes(
      cp.actions
        .map(
          (a) =>
            `[${a.stage}] ${a.title} — ${a.detail} (owner: ${a.owner || a.suggestedOwner}${a.due ? `, due ${a.due}` : ""})`,
        )
        .join("\n"),
    );
  }

  // 9. Key communication messages
  if (has("changeImpact")) {
  const comms = addLight("Key Messages & Recommendations", "Communication");
  const templates = buildTemplates(scenario);
  comms.addText(
    [
      `Announce the change centrally, then hold individual conversations before any team briefing.`,
      `Equip ${impact.movedRoles.length + impact.removedRoles.length} manager conversations with scripted talking points and an agreed escalation path.`,
      `Publish the FAQ and timeline at the same moment as the announcement to prevent rumour filling the gap.`,
      `Run consultation to local requirements in each affected country before confirming any outcome.`,
      `Reinforce at 30/60/90 days with measured outcomes, not restated intentions.`,
    ].map((text) => ({
      text,
      options: { bullet: true, fontFace: BODY, fontSize: 17, color: INK, paraSpaceAfter: 10 },
    })),
    { x: 0.7, y: 1.6, w: 8.6, h: 2.6 },
  );
  comms.addText(
    `Ready-to-send templates in this pack: ${templates.map((t) => t.title).join(", ")}.`,
    { x: 0.7, y: 4.35, w: 8.6, h: 0.5, fontFace: BODY, fontSize: 13, italic: true, color: MUTED },
  );
  }

  // 9b. Drill-down appendix — exactly which roles sit behind each pinned delta
  const drilldowns = has("appendix") ? (options.drilldowns ?? []) : [];
  for (const d of drilldowns) {
    const slide = addLight(d.label, "Change drill-down");
    const hcDelta = d.targetHeadcount - d.baseHeadcount;
    const costDelta = d.targetCost - d.baseCost;
    slide.addText(
      `${d.baseName} → ${d.targetName} · positions ${d.baseHeadcount} → ${d.targetHeadcount} (${hcDelta >= 0 ? "+" : ""}${hcDelta}) · cost ${formatMoney(d.baseCost, cur)} → ${formatMoney(d.targetCost, cur)} (${costDelta <= 0 ? "−" : "+"}${formatMoney(Math.abs(costDelta), cur)})`,
      { x: 0.6, y: 1.5, w: 8.8, h: 0.4, fontFace: BODY, fontSize: 13, color: MUTED },
    );
    type Row = { change: string; role: string; detail: string; colour: string };
    const rows: Row[] = [
      ...d.added.map((e) => ({
        change: "Added",
        role: `${e.name || "Open role"} — ${e.title}`,
        detail: `${e.department || "—"} · ${e.country} · +${formatMoney(e.plannedCost, cur)}`,
        colour: GREEN,
      })),
      ...d.removed.map((e) => ({
        change: "Removed",
        role: `${e.name || "Open role"} — ${e.title}`,
        detail: `${e.department || "—"} · ${e.country} · −${formatMoney(e.currentCost, cur)}`,
        colour: RED,
      })),
      ...d.changed.map((c) => ({
        change: "Changed",
        role: `${c.after.name || c.before.name || "Open role"} — ${c.after.title}`,
        detail: c.changes.map((ch) => `${ch.label}: ${ch.before} → ${ch.after}`).join("; "),
        colour: BLUE,
      })),
    ];
    if (rows.length) {
      slide.addTable(
        [
          [
            { text: "Change", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
            { text: "Role", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
            { text: "Detail", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          ],
          ...rows.slice(0, 11).map((r) => [
            { text: r.change, options: { bold: true, color: r.colour } },
            { text: r.role },
            { text: r.detail, options: { color: MUTED } },
          ]),
        ],
        {
          x: 0.6,
          y: 2.0,
          w: 8.8,
          colW: [1.2, 3.2, 4.4],
          fontFace: BODY,
          fontSize: 11,
          color: INK,
          border: { type: "solid", color: "D9E2EC", pt: 1 },
          margin: 5,
        },
      );
      if (rows.length > 11) {
        slide.addText(`…and ${rows.length - 11} further changes — see the speaker notes.`, {
          x: 0.6,
          y: 4.7,
          w: 8.8,
          h: 0.3,
          fontFace: BODY,
          fontSize: 11,
          italic: true,
          color: MUTED,
        });
      }
    } else {
      slide.addText("No role-level changes in this slice.", {
        x: 0.6,
        y: 2.0,
        w: 8.8,
        h: 0.5,
        fontFace: BODY,
        fontSize: 18,
        color: INK,
      });
    }
    slide.addNotes(drilldownToNotes(d, 40).join("\n"));
    footnote(slide);
  }

  // Important notices & disclaimer
  const notices = addLight("Important Notices & Disclaimer", "Privacy, compliance & legal");
  notices.addText(
    EXPORT_NOTICES.map((n) => ({
      text: `${n.title} — ${n.body}`,
      options: { fontFace: BODY, fontSize: 10.5, color: INK, paraSpaceAfter: 7 },
    })),
    { x: 0.6, y: 1.6, w: 8.8, h: 3.3, valign: "top" },
  );
  notices.addText(NOT_LEGAL_ADVICE_SHORT, {
    x: 0.6,
    y: 5.02,
    w: 8.8,
    h: 0.4,
    fontFace: BODY,
    fontSize: 10,
    italic: true,
    bold: true,
    color: RED,
  });
  notices.addNotes(EXPORT_NOTICES.map((n) => `${n.title}: ${n.body}`).join("\n\n"));

  // 10. Next steps
  if (has("changeImpact")) {
  const next = addDark();
  next.addText("Next Steps", {
    x: 0.8,
    y: 0.7,
    w: 8.4,
    h: 0.8,
    fontFace: HEAD,
    fontSize: 40,
    bold: true,
    color: WHITE,
  });
  next.addText(
    [
      "1. Confirm the future structure and selection criteria with the executive sponsor.",
      "2. Obtain local legal review for every country with proposed role removals.",
      "3. Finalise consultation calendar and manager briefing sessions.",
      "4. Approve the communication pack and publish FAQ plus timeline.",
      "5. Launch ADKAR interventions at the identified barrier point.",
      "6. Set the 30/60/90 day reinforcement and measurement plan.",
    ].map((text) => ({
      text,
      options: { fontFace: BODY, fontSize: 18, color: LIGHT, paraSpaceAfter: 12 },
    })),
    { x: 0.9, y: 1.65, w: 8.2, h: 3 },
  );
  next.addText(DISCLAIMER, {
    x: 0.9,
    y: 4.85,
    w: 8.2,
    h: 0.6,
    fontFace: BODY,
    fontSize: 10,
    italic: true,
    color: LIGHT,
  });
  }

  await pptx.writeFile({
    fileName: `${(options.fileName ?? `${scenario.name}-Strategy-Studio`).replace(/[^a-z0-9]+/gi, "-")}.pptx`,
  });
}
