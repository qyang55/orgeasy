/**
 * Change Management layer: turns the structural delta of a scenario into a
 * practical, executive-friendly ADKAR plan with stakeholder impact severity.
 */
import { hasConsent } from "./consent";
import { compareScenarios, type ScenarioDiff } from "./diff";
import { analyseSpans } from "./span";
import { formatMoney } from "./impact";
import type { AdkarKey, Scenario } from "./types";

export const ADKAR_STAGES: {
  key: AdkarKey;
  label: string;
  question: string;
  focus: string;
  hex: string;
}[] = [
  {
    key: "awareness",
    label: "Awareness",
    question: "Do people understand why the change is happening?",
    focus: "Key messages and communication needs",
    hex: "2563EB",
  },
  {
    key: "desire",
    label: "Desire",
    question: "Do they personally want to take part?",
    focus: "Benefits and resistance points",
    hex: "7C3AED",
  },
  {
    key: "knowledge",
    label: "Knowledge",
    question: "Do they know how to work in the new model?",
    focus: "Training and upskilling required",
    hex: "0891B2",
  },
  {
    key: "ability",
    label: "Ability",
    question: "Can they actually do it day to day?",
    focus: "Support and tools needed",
    hex: "D97706",
  },
  {
    key: "reinforcement",
    label: "Reinforcement",
    question: "What keeps the change in place?",
    focus: "How to sustain the change",
    hex: "047857",
  },
];

export type Severity = "critical" | "high" | "moderate" | "low";

export const SEVERITY_META: Record<
  Severity,
  { label: string; hex: string; className: string; note: string }
> = {
  critical: {
    label: "Critical",
    hex: "DC2626",
    className: "bg-destructive/15 text-destructive border-destructive/30",
    note: "Named leader, dedicated comms and consultation support.",
  },
  high: {
    label: "High",
    hex: "EA580C",
    className: "bg-amber-500/15 text-amber-700 border-amber-500/30",
    note: "Manager-led conversations with weekly tracking.",
  },
  moderate: {
    label: "Moderate",
    hex: "2563EB",
    className: "bg-primary/10 text-primary border-primary/25",
    note: "Team briefings plus FAQ; monitor sentiment.",
  },
  low: {
    label: "Low",
    hex: "64748B",
    className: "bg-muted text-muted-foreground border-border",
    note: "Keep informed through business-as-usual channels.",
  },
};

export interface ImpactGroup {
  id: string;
  name: string;
  positions: number;
  exits: number;
  newRoles: number;
  reassigned: number;
  changed: number;
  spanChanges: number;
  headcountDelta: number;
  costDelta: number;
  /** 0-100 change impact severity score. */
  score: number;
  severity: Severity;
  drivers: string[];
  /** Share of the group's positions that are directly touched, 0-1. */
  touchRate: number;
}

export interface ChangeAction {
  id: string;
  stage: AdkarKey;
  title: string;
  detail: string;
  /** Suggested accountable function; the user can overwrite it. */
  suggestedOwner: string;
  /** Suggested week offset from programme start. */
  week: number;
}

export interface ChangePlan {
  scenarioName: string;
  baselineName: string | null;
  currency: string;
  totalPositions: number;
  impacted: number;
  exits: number;
  newRoles: number;
  reassigned: number;
  changed: number;
  spanChanges: number;
  costDelta: number;
  groups: ImpactGroup[];
  actions: ChangeAction[];
  /** 0-100 readiness from recorded ADKAR scores; null when nothing scored yet. */
  readiness: number | null;
  barrier: AdkarKey | null;
  /** Plain-language headline for leadership. */
  headline: string;
  diff: ScenarioDiff | null;
}

const MOVE_FIELDS = ["managerId", "department", "country"];

function severityFor(score: number): Severity {
  if (score >= 70) return "critical";
  if (score >= 45) return "high";
  if (score >= 20) return "moderate";
  return "low";
}

function slug(text: string) {
  return text.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "group";
}

/** Managers whose direct-report count moves between the two states. */
function spanShiftByDepartment(base: Scenario, target: Scenario) {
  const b = analyseSpans(base);
  const t = analyseSpans(target);
  const before = new Map(b.rows.map((r) => [r.id, r]));
  const map = new Map<string, number>();
  let total = 0;
  for (const row of t.rows) {
    const prev = before.get(row.id);
    if (!prev) continue;
    if (prev.directReports === row.directReports) continue;
    const dept = row.department || "Unassigned";
    map.set(dept, (map.get(dept) ?? 0) + 1);
    total += 1;
  }
  return { byDepartment: map, total };
}

export function buildChangePlan(
  scenario: Scenario | null | undefined,
  baseline: Scenario | null | undefined,
): ChangePlan {
  const currency = scenario?.currency ?? "USD";
  const empty: ChangePlan = {
    scenarioName: scenario?.name ?? "No scenario",
    baselineName: baseline?.name ?? null,
    currency,
    totalPositions: 0,
    impacted: 0,
    exits: 0,
    newRoles: 0,
    reassigned: 0,
    changed: 0,
    spanChanges: 0,
    costDelta: 0,
    groups: [],
    actions: [],
    readiness: null,
    barrier: null,
    headline: "Pick a baseline scenario to generate the change plan.",
    diff: null,
  };
  if (!scenario) return empty;

  const readinessOf = () => {
    const groups = scenario.adkarGroups ?? [];
    if (!groups.length) return { readiness: null as number | null, barrier: null as AdkarKey | null };
    const avg = (key: AdkarKey) =>
      groups.reduce((a, g) => a + (g.scores[key] ?? 0), 0) / groups.length;
    const scored = ADKAR_STAGES.map((s) => ({ key: s.key, avg: avg(s.key) }));
    const overall = scored.reduce((a, s) => a + s.avg, 0) / scored.length;
    const weakest = [...scored].sort((a, b) => a.avg - b.avg)[0];
    return {
      readiness: Math.round((overall / 5) * 100),
      barrier: weakest && weakest.avg < 4 ? weakest.key : null,
    };
  };
  const { readiness, barrier } = readinessOf();

  if (!baseline) {
    return { ...empty, readiness, barrier };
  }

  const diff = compareScenarios(baseline, scenario);
  const spans = spanShiftByDepartment(baseline, scenario);

  type Bucket = Omit<ImpactGroup, "score" | "severity" | "drivers" | "touchRate">;
  const buckets = new Map<string, Bucket>();
  const bucket = (name: string) => {
    const key = name || "Unassigned";
    const existing = buckets.get(key);
    if (existing) return existing;
    const created: Bucket = {
      id: slug(key),
      name: key,
      positions: 0,
      exits: 0,
      newRoles: 0,
      reassigned: 0,
      changed: 0,
      spanChanges: 0,
      headcountDelta: 0,
      costDelta: 0,
    };
    buckets.set(key, created);
    return created;
  };

  for (const d of diff.byDepartment) {
    const b = bucket(d.key);
    b.positions = Math.max(d.baseHeadcount, d.targetHeadcount);
    b.headcountDelta = d.targetHeadcount - d.baseHeadcount;
    b.costDelta = d.targetCost - d.baseCost;
  }
  for (const e of diff.removed) bucket(e.department || "Unassigned").exits += 1;
  for (const e of diff.added) bucket(e.department || "Unassigned").newRoles += 1;
  for (const c of diff.changed) {
    const b = bucket(c.after.department || c.before.department || "Unassigned");
    if (c.changes.some((ch) => MOVE_FIELDS.includes(ch.field))) b.reassigned += 1;
    else b.changed += 1;
  }
  for (const [dept, count] of spans.byDepartment) bucket(dept).spanChanges += count;

  const groups: ImpactGroup[] = [...buckets.values()]
    .map((b) => {
      const touched = b.exits + b.newRoles + b.reassigned + b.changed;
      const denom = Math.max(b.positions, touched, 1);
      const touchRate = Math.min(touched / denom, 1);
      // Blend how much of the group is touched with the absolute scale of the
      // change, so a large function losing many positions is not scored low
      // just because it is large.
      const rate =
        (b.exits / denom) * 120 +
        (b.reassigned / denom) * 70 +
        (b.newRoles / denom) * 35 +
        (b.changed / denom) * 20 +
        Math.min(b.spanChanges, 12) * 2.5;
      const scale =
        Math.min(b.exits, 20) * 4 +
        Math.min(Math.abs(Math.min(b.headcountDelta, 0)), 25) * 2.4 +
        Math.min(b.reassigned, 20) * 2.5 +
        Math.min(b.newRoles, 15) * 1.5 +
        Math.min(b.spanChanges, 15) * 1.5 +
        Math.min(b.changed, 20) * 0.8;
      const raw = rate * 0.45 + scale * 0.55;
      const score = Math.max(0, Math.min(100, Math.round(raw)));
      const drivers: string[] = [];
      if (b.exits) drivers.push(`${b.exits} role${b.exits === 1 ? "" : "s"} exiting`);
      if (b.reassigned) drivers.push(`${b.reassigned} reporting-line or location moves`);
      if (b.newRoles) drivers.push(`${b.newRoles} new role${b.newRoles === 1 ? "" : "s"} to fill`);
      if (b.spanChanges) drivers.push(`${b.spanChanges} manager span change${b.spanChanges === 1 ? "" : "s"}`);
      if (b.changed) drivers.push(`${b.changed} scope or grade change${b.changed === 1 ? "" : "s"}`);
      if (!drivers.length) drivers.push("No direct structural change");
      return { ...b, score, severity: severityFor(score), drivers, touchRate };
    })
    .sort((a, b) => b.score - a.score || b.exits - a.exits || a.name.localeCompare(b.name));

  const exits = diff.removed.length;
  const newRoles = diff.added.length;
  const reassigned = diff.changed.filter((c) =>
    c.changes.some((ch) => MOVE_FIELDS.includes(ch.field)),
  ).length;
  const changed = diff.changed.length - reassigned;
  const impacted = exits + newRoles + diff.changed.length;
  const top = groups.filter((g) => g.severity === "critical" || g.severity === "high").slice(0, 3);

  const headline = `${impacted.toLocaleString()} of ${diff.headcount.base.toLocaleString()} positions are directly affected moving from ${baseline.name} to ${scenario.name}${
    top.length ? `. Most affected: ${top.map((g) => g.name).join(", ")}.` : "."
  }`;

  const groupList = top.length ? top.map((g) => g.name).join(", ") : "the affected functions";
  const savingLabel = formatMoney(Math.abs(diff.cost.delta), currency);

  const actions: ChangeAction[] = [
    {
      id: "awareness-case",
      stage: "awareness",
      title: "Land one business case, told the same way everywhere",
      detail: `Announce why the structure is changing before what changes: the ${savingLabel} ${diff.cost.delta <= 0 ? "cost reduction" : "investment"}, the delivery outcomes it protects and the cost of standing still. Executive sponsor presents; managers repeat the same words.`,
      suggestedOwner: "Executive sponsor",
      week: 1,
    },
    {
      id: "awareness-cascade",
      stage: "awareness",
      title: "Cascade in the right order, within 48 hours",
      detail: `Sequence: sponsor announcement → ${exits ? "individual conversations for affected people" : "manager one-to-ones"} → team briefings → all-hands Q&A. Publish the FAQ and timeline at the announcement moment so rumour does not fill the gap.`,
      suggestedOwner: "Internal communications",
      week: 1,
    },
    {
      id: "awareness-groups",
      stage: "awareness",
      title: `Tailor messages for ${groupList}`,
      detail: `These groups carry the highest impact score. Give each one a two-page brief: what changes, what does not, what happens next week, and where to ask questions.`,
      suggestedOwner: "HR business partner",
      week: 2,
    },
    {
      id: "desire-benefits",
      stage: "desire",
      title: "Name the benefit for each audience, not just the company",
      detail: `Clearer accountability, fewer approval layers${spans.total ? ` (${spans.total} manager spans reset)` : ""}, and time returned from duplicated work. Ask leaders to state one thing that gets easier for their team.`,
      suggestedOwner: "Function leaders",
      week: 2,
    },
    {
      id: "desire-resistance",
      stage: "desire",
      title: "Address the predictable resistance points openly",
      detail: `Expect: job-security anxiety${exits ? ` (${exits} exits)` : ""}, loss of status where spans shrink, workload fear where roles are absorbed, and scepticism about automation replacing judgement. Answer each in the FAQ rather than waiting to be asked.`,
      suggestedOwner: "HR business partner",
      week: 2,
    },
    {
      id: "desire-listening",
      stage: "desire",
      title: "Run a listening loop with visible responses",
      detail: `Weekly pulse question plus an open channel. Publish "you said / we did" fortnightly — silence is read as bad news.`,
      suggestedOwner: "Change lead",
      week: 3,
    },
    {
      id: "knowledge-manager",
      stage: "knowledge",
      title: "Brief and rehearse every manager before day one",
      detail: `${Math.max(spans.total, top.length)} manager${Math.max(spans.total, top.length) === 1 ? "" : "s"} need scripted talking points, escalation routes and practice conversations. No manager should hear the plan at the same time as their team.`,
      suggestedOwner: "HR business partner",
      week: 1,
    },
    {
      id: "knowledge-upskill",
      stage: "knowledge",
      title: "Build role-specific upskilling for changed and new roles",
      detail: `${newRoles + reassigned} role${newRoles + reassigned === 1 ? "" : "s"} are new or reassigned. Map the two or three capabilities each one needs, then deliver short, job-shaped training before go-live rather than a generic catalogue.`,
      suggestedOwner: "Talent & learning",
      week: 4,
    },
    {
      id: "knowledge-process",
      stage: "knowledge",
      title: "Rewrite the handful of processes that actually change",
      detail: `Update decision rights, approval thresholds and service handoffs where work moves between teams. One page per process, owned by the receiving leader.`,
      suggestedOwner: "Function leaders",
      week: 5,
    },
    {
      id: "ability-support",
      stage: "ability",
      title: "Give people a supported first 60 days",
      detail: `Coaching for newly widened spans, shadowing for absorbed work, and a named buddy for every new role. Protect capacity: remove something before adding something.`,
      suggestedOwner: "Function leaders",
      week: 6,
    },
    {
      id: "ability-tools",
      stage: "ability",
      title: "Have systems and access ready on day one",
      detail: `Update HRIS reporting lines, cost centres, approval workflows, distribution lists and system access to match the new structure. Nothing erodes confidence faster than an org chart that only exists in slides.`,
      suggestedOwner: "HR operations & IT",
      week: 6,
    },
    {
      id: "ability-transition",
      stage: "ability",
      title: "Run structured knowledge transfer for exiting roles",
      detail: exits
        ? `${exits} exiting role${exits === 1 ? "" : "s"} hold undocumented knowledge. Agree a handover pack, receiving owner and a cut-off date for each before the last working day.`
        : `Where work is consolidated, document the handover and confirm the receiving owner in writing.`,
      suggestedOwner: "Line managers",
      week: 7,
    },
    {
      id: "reinforcement-measure",
      stage: "reinforcement",
      title: "Track adoption at 30 / 60 / 90 days",
      detail: `Report against a short set: span compliance, vacancy fill for new roles, sentiment score, attrition in the most affected groups, and realised versus modelled saving.`,
      suggestedOwner: "Change lead",
      week: 8,
    },
    {
      id: "reinforcement-governance",
      stage: "reinforcement",
      title: "Keep a standing item on the leadership agenda",
      detail: `Fifteen minutes monthly for six months: what has stuck, what has drifted back, one corrective action. Close the programme deliberately rather than letting it fade.`,
      suggestedOwner: "Executive sponsor",
      week: 10,
    },
    {
      id: "reinforcement-recognise",
      stage: "reinforcement",
      title: "Recognise the new behaviours, retire the old ones",
      detail: `Update objectives and recognition to reward the new operating model. Remove legacy reports, forums and approvals that quietly pull people back to the old structure.`,
      suggestedOwner: "HR business partner",
      week: 12,
    },
  ];

  return {
    scenarioName: scenario.name,
    baselineName: baseline.name,
    currency,
    totalPositions: diff.headcount.base,
    impacted,
    exits,
    newRoles,
    reassigned,
    changed,
    spanChanges: spans.total,
    costDelta: diff.cost.delta,
    groups,
    actions,
    readiness,
    barrier,
    headline,
    diff,
  };
}

/* ------------------------------------------------------------ user edits */

export interface ActionOverride {
  title?: string;
  detail?: string;
  owner?: string;
  due?: string;
  done?: boolean;
}

export type ChangePlanEdits = Record<string, ActionOverride>;

const KEY = "orgeasy.changeplan.v1";

function readAll(): Record<string, ChangePlanEdits> {
  if (typeof localStorage === "undefined") return {};
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Record<string, ChangePlanEdits>) : {};
  } catch {
    return {};
  }
}

export function loadChangeEdits(scenarioId: string | null | undefined): ChangePlanEdits {
  if (!scenarioId) return {};
  return readAll()[scenarioId] ?? {};
}

export function saveChangeEdits(scenarioId: string, edits: ChangePlanEdits) {
  if (typeof localStorage === "undefined" || !hasConsent("preferences")) return;
  const all = readAll();
  all[scenarioId] = edits;
  try {
    localStorage.setItem(KEY, JSON.stringify(all));
  } catch {
    /* storage full or blocked */
  }
}

/** Applies the user's edits on top of a generated action. */
export function mergeAction(action: ChangeAction, edits: ChangePlanEdits) {
  const o = edits[action.id] ?? {};
  return {
    ...action,
    title: o.title?.trim() ? o.title : action.title,
    detail: o.detail?.trim() ? o.detail : action.detail,
    owner: o.owner ?? "",
    due: o.due ?? "",
    done: o.done === true,
  };
}

export type MergedAction = ReturnType<typeof mergeAction>;

export function mergedActions(plan: ChangePlan, edits: ChangePlanEdits): MergedAction[] {
  return plan.actions.map((a) => mergeAction(a, edits));
}

export function actionsByStage(actions: MergedAction[], stage: AdkarKey) {
  return actions.filter((a) => a.stage === stage);
}

/** Simple delivery progress across the plan, 0-100. */
export function planProgress(actions: MergedAction[]) {
  if (!actions.length) return 0;
  return Math.round((actions.filter((a) => a.done).length / actions.length) * 100);
}

/** Blended readiness: recorded ADKAR scores plus plan delivery progress. */
export function readinessScore(plan: ChangePlan, actions: MergedAction[]) {
  const progress = planProgress(actions);
  if (plan.readiness === null) return progress;
  return Math.round(plan.readiness * 0.6 + progress * 0.4);
}

export function readinessBand(score: number) {
  if (score >= 75) return { label: "On track", tone: "positive" as const };
  if (score >= 50) return { label: "Watch", tone: "default" as const };
  if (score > 0) return { label: "At risk", tone: "negative" as const };
  return { label: "Not started", tone: "default" as const };
}