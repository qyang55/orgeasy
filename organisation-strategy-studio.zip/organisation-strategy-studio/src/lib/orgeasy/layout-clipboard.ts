import type { Employee, Scenario } from "./types";
import { hasConsent } from "./consent";

/**
 * "Copy layout" / "Apply layout": lets a user reuse card sizing, canvas
 * positions and the reporting structure from one scenario in another, matching
 * roles across scenarios by id first and then by name/title.
 */

export const LAYOUT_CLIPBOARD_KEY = "orgeasy.chart.layoutClipboard";

/** Identity of a role, resilient to ids differing between scenarios. */
export interface RoleIdentity {
  id: string;
  /** name + title */
  nameKey: string;
  /** title + department */
  titleKey: string;
}

export interface LayoutEntry {
  role: RoleIdentity;
  size?: { w: number; h: number } | undefined;
  position?: { x: number; y: number } | undefined;
  manager: RoleIdentity | null;
  dotted: RoleIdentity[];
}

export interface LayoutSnapshot {
  version: 1;
  scenarioId: string;
  scenarioName: string;
  copiedAt: string;
  entries: LayoutEntry[];
}

export interface ApplyLayoutOptions {
  sizes: boolean;
  positions: boolean;
  managers: boolean;
}

export const DEFAULT_APPLY_OPTIONS: ApplyLayoutOptions = {
  sizes: true,
  positions: true,
  managers: true,
};

const norm = (value: string | null | undefined) => (value ?? "").trim().toLowerCase();

function identity(employee: Employee): RoleIdentity {
  return {
    id: employee.id,
    nameKey: `${norm(employee.name)}|${norm(employee.title)}`,
    titleKey: `${norm(employee.title)}|${norm(employee.department)}`,
  };
}

export function captureLayout(scenario: Scenario): LayoutSnapshot {
  const byId = new Map(scenario.employees.map((e) => [e.id, e]));
  return {
    version: 1,
    scenarioId: scenario.id,
    scenarioName: scenario.name,
    copiedAt: new Date().toISOString(),
    entries: scenario.employees.map((employee) => {
      const manager = employee.managerId ? byId.get(employee.managerId) : undefined;
      return {
        role: identity(employee),
        size: scenario.nodeSizes?.[employee.id],
        position: scenario.positions?.[employee.id],
        manager: manager ? identity(manager) : null,
        dotted: (employee.dottedManagerIds ?? [])
          .map((id) => byId.get(id))
          .filter((e): e is Employee => Boolean(e))
          .map(identity),
      };
    }),
  };
}

/** Lookup tables so a snapshot role can be matched to a role in the target. */
function buildIndex(employees: Employee[]) {
  const byId = new Map<string, Employee>();
  const byName = new Map<string, Employee>();
  const byTitle = new Map<string, Employee>();
  for (const employee of employees) {
    const ident = identity(employee);
    byId.set(ident.id, employee);
    if (norm(employee.name) && !byName.has(ident.nameKey)) byName.set(ident.nameKey, employee);
    if (norm(employee.title) && !byTitle.has(ident.titleKey)) byTitle.set(ident.titleKey, employee);
  }
  return { byId, byName, byTitle };
}

function matchRole(index: ReturnType<typeof buildIndex>, role: RoleIdentity) {
  return (
    index.byId.get(role.id) ??
    index.byName.get(role.nameKey) ??
    index.byTitle.get(role.titleKey) ??
    null
  );
}

export interface ApplyLayoutResult {
  employees: Employee[];
  positions: Record<string, { x: number; y: number }>;
  nodeSizes: Record<string, { w: number; h: number }>;
  /** How many roles in the snapshot were matched in the target scenario. */
  matched: number;
  total: number;
  /** Reporting lines actually changed. */
  managerChanges: number;
  /** Reporting lines skipped because they would have created a loop. */
  skipped: number;
}

/** Returns how many snapshot roles exist in a scenario, without changing it. */
export function countMatches(scenario: Scenario, snapshot: LayoutSnapshot) {
  const index = buildIndex(scenario.employees);
  return snapshot.entries.filter((entry) => matchRole(index, entry.role)).length;
}

export function applyLayout(
  scenario: Scenario,
  snapshot: LayoutSnapshot,
  options: ApplyLayoutOptions,
): ApplyLayoutResult {
  const index = buildIndex(scenario.employees);
  const positions = { ...(scenario.positions ?? {}) };
  const nodeSizes = { ...(scenario.nodeSizes ?? {}) };
  const managerMap = new Map<string, string | null>();
  const dottedMap = new Map<string, string[]>();
  let matched = 0;

  for (const entry of snapshot.entries) {
    const target = matchRole(index, entry.role);
    if (!target) continue;
    matched++;
    if (options.sizes) {
      if (entry.size) nodeSizes[target.id] = entry.size;
      else delete nodeSizes[target.id];
    }
    if (options.positions && entry.position) positions[target.id] = entry.position;
    if (options.managers) {
      const manager = entry.manager ? matchRole(index, entry.manager) : null;
      if (entry.manager && !manager) continue; // manager missing here — keep existing line
      managerMap.set(target.id, manager && manager.id !== target.id ? manager.id : null);
      const dotted = entry.dotted
        .map((role) => matchRole(index, role))
        .filter((e): e is Employee => Boolean(e) && e!.id !== target.id)
        .map((e) => e.id);
      dottedMap.set(target.id, Array.from(new Set(dotted)));
    }
  }

  let managerChanges = 0;
  let skipped = 0;
  const employees = scenario.employees.map((employee) => {
    if (!managerMap.has(employee.id)) return employee;
    const nextManager = managerMap.get(employee.id) ?? null;
    let next: Employee = employee;
    if (nextManager !== (employee.managerId ?? null)) {
      if (createsCycle(employee.id, nextManager, managerMap, scenario.employees)) skipped++;
      else {
        managerChanges++;
        next = { ...next, managerId: nextManager };
      }
    }
    const dotted = dottedMap.get(employee.id);
    if (dotted) next = { ...next, dottedManagerIds: dotted.filter((id) => id !== next.managerId) };
    return next;
  });

  return {
    employees,
    positions,
    nodeSizes,
    matched,
    total: snapshot.entries.length,
    managerChanges,
    skipped,
  };
}

/** Walks the proposed manager chain (snapshot first, existing lines second). */
function createsCycle(
  childId: string,
  managerId: string | null,
  managerMap: Map<string, string | null>,
  employees: Employee[],
) {
  const existing = new Map(employees.map((e) => [e.id, e.managerId ?? null]));
  let cursor = managerId;
  let guard = 0;
  while (cursor && guard++ < 500) {
    if (cursor === childId) return true;
    cursor = managerMap.has(cursor)
      ? (managerMap.get(cursor) ?? null)
      : (existing.get(cursor) ?? null);
  }
  return false;
}

export function saveLayoutSnapshot(snapshot: LayoutSnapshot) {
  if (typeof localStorage === "undefined" || !hasConsent("workspace")) return;
  try {
    localStorage.setItem(LAYOUT_CLIPBOARD_KEY, JSON.stringify(snapshot));
  } catch {
    /* storage full — the in-memory copy still works this session */
  }
}

export function loadLayoutSnapshot(): LayoutSnapshot | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem(LAYOUT_CLIPBOARD_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as LayoutSnapshot;
    return parsed?.version === 1 && Array.isArray(parsed.entries) ? parsed : null;
  } catch {
    return null;
  }
}

export function clearLayoutSnapshot() {
  try {
    localStorage.removeItem(LAYOUT_CLIPBOARD_KEY);
  } catch {
    /* ignore */
  }
}
