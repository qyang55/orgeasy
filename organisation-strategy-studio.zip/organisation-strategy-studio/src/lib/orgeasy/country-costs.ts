/**
 * Country Cost Rules — simplified, illustrative separation-cost parameters per
 * market. Values are deliberately simple heuristics so the programme can price
 * exits consistently; they are NOT legal or actuarial advice and every scenario
 * can override any parameter.
 */
import type { CountryCostOverride, Employee, Scenario } from "./types";

export type ConsultationRisk = "Low" | "Medium" | "High";

export interface CountryCostRule {
  country: string;
  region: string;
  /** Average notice period, in weeks (paid in lieu for costing purposes). */
  noticeWeeks: number;
  /** Severance formula: weeks of pay per completed year of service. */
  severanceWeeksPerYear: number;
  /** Floor and ceiling on total severance weeks. */
  minSeveranceWeeks: number;
  capSeveranceWeeks: number;
  /** Consultation / works council risk. */
  risk: ConsultationRisk;
  riskNote: string;
  /** External counsel / documentation cost per exit, USD. */
  legalFeePerExit: number;
  /** Outplacement or career-transition support per exit, USD. */
  outplacementPerExit: number;
  /** Payroll, immigration and administrative wind-down cost per exit, USD. */
  adminPerExit: number;
  /** Share of exits expected to bring a tribunal / labour-court claim, %. */
  claimRatePct: number;
  /** Typical award or settlement on a claim, in months of pay. */
  avgClaimMonths: number;
  /** Defence cost per claim (counsel, hearings, internal time), USD. */
  defenceCostPerClaim: number;
  /** Exits in-country that trigger a collective consultation procedure. */
  collectiveThreshold: number;
  /** One-off cost of running that collective procedure in-country, USD. */
  collectiveProcessCost: number;
  /** What drives litigation exposure in this market. */
  legalNote: string;
  formulaNote: string;
}

export const RISK_META: Record<ConsultationRisk, { className: string; label: string }> = {
  Low: { className: "bg-success/15 text-success", label: "Low" },
  Medium: { className: "bg-warning/20 text-warning-foreground", label: "Medium" },
  High: { className: "bg-destructive/15 text-destructive", label: "High" },
};

/** Add a market by appending a row here — nothing else needs to change. */
export const COUNTRY_COST_RULES: CountryCostRule[] = [
  {
    country: "Thailand",
    region: "APAC",
    noticeWeeks: 4,
    severanceWeeksPerYear: 4.3,
    minSeveranceWeeks: 4.3,
    capSeveranceWeeks: 57,
    risk: "Medium",
    riskNote: "Banded statutory severance up to ~400 days; Labour Court claims are common.",
    legalFeePerExit: 700,
    outplacementPerExit: 400,
    adminPerExit: 250,
    claimRatePct: 12,
    avgClaimMonths: 6,
    defenceCostPerClaim: 6000,
    collectiveThreshold: 20,
    collectiveProcessCost: 15000,
    legalNote: "Labour Court claims are cheap to file; settlement at the Labour Inspector is common.",
    formulaNote: "Banded severance ≈ 1 month per year, capped near 400 days of pay.",
  },
  {
    country: "Australia",
    region: "APAC",
    noticeWeeks: 4,
    severanceWeeksPerYear: 2,
    minSeveranceWeeks: 4,
    capSeveranceWeeks: 16,
    risk: "Medium",
    riskNote: "Genuine redundancy test plus award/enterprise-agreement consultation.",
    legalFeePerExit: 1500,
    outplacementPerExit: 1800,
    adminPerExit: 400,
    claimRatePct: 8,
    avgClaimMonths: 4,
    defenceCostPerClaim: 25000,
    collectiveThreshold: 15,
    collectiveProcessCost: 40000,
    legalNote: "Unfair dismissal / general protections claims run through the Fair Work Commission.",
    formulaNote: "NES redundancy pay is banded by service and caps around 16 weeks.",
  },
  {
    country: "South Africa",
    region: "EMEA",
    noticeWeeks: 4,
    severanceWeeksPerYear: 1,
    minSeveranceWeeks: 1,
    capSeveranceWeeks: 26,
    risk: "High",
    riskNote: "Section 189/189A consultation is mandatory; CCMA facilitation for large exits.",
    legalFeePerExit: 900,
    outplacementPerExit: 600,
    adminPerExit: 300,
    claimRatePct: 18,
    avgClaimMonths: 6,
    defenceCostPerClaim: 12000,
    collectiveThreshold: 10,
    collectiveProcessCost: 45000,
    legalNote: "CCMA referral is free for employees; s189A facilitation adds programme cost.",
    formulaNote: "Statutory minimum 1 week per year; enhanced packages are common.",
  },
  {
    country: "UAE",
    region: "EMEA",
    noticeWeeks: 4,
    severanceWeeksPerYear: 3,
    minSeveranceWeeks: 0,
    capSeveranceWeeks: 104,
    risk: "Low",
    riskNote: "No collective consultation, but visa cancellation and repatriation must be planned.",
    legalFeePerExit: 900,
    outplacementPerExit: 500,
    adminPerExit: 900,
    claimRatePct: 5,
    avgClaimMonths: 3,
    defenceCostPerClaim: 8000,
    collectiveThreshold: 50,
    collectiveProcessCost: 10000,
    legalNote: "Arbitrary dismissal compensation up to 3 months; MOHRE complaints are low-cost.",
    formulaNote: "End-of-service gratuity ≈ 21–30 days per year, capped near 2 years' pay.",
  },
  {
    country: "Vietnam",
    region: "APAC",
    noticeWeeks: 6,
    severanceWeeksPerYear: 2.2,
    minSeveranceWeeks: 8.6,
    capSeveranceWeeks: 52,
    risk: "High",
    riskNote: "Labour usage plan and union consultation are typically required.",
    legalFeePerExit: 500,
    outplacementPerExit: 300,
    adminPerExit: 250,
    claimRatePct: 8,
    avgClaimMonths: 4,
    defenceCostPerClaim: 4000,
    collectiveThreshold: 20,
    collectiveProcessCost: 12000,
    legalNote: "Labour arbitration and People's Court claims follow an invalid labour usage plan.",
    formulaNote: "Job-loss allowance ≈ 0.5 month per year, minimum 2 months.",
  },
  {
    country: "Philippines",
    region: "APAC",
    noticeWeeks: 4.3,
    severanceWeeksPerYear: 4.3,
    minSeveranceWeeks: 4.3,
    capSeveranceWeeks: 60,
    risk: "Medium",
    riskNote: "30-day notice to employee and DOLE; good-faith redundancy criteria required.",
    legalFeePerExit: 500,
    outplacementPerExit: 300,
    adminPerExit: 200,
    claimRatePct: 15,
    avgClaimMonths: 6,
    defenceCostPerClaim: 7000,
    collectiveThreshold: 20,
    collectiveProcessCost: 12000,
    legalNote: "NLRC illegal dismissal claims carry back-wages plus reinstatement exposure.",
    formulaNote: "Redundancy pay ≈ 1 month per year of service.",
  },
  {
    country: "United States",
    region: "Americas",
    noticeWeeks: 0,
    severanceWeeksPerYear: 2,
    minSeveranceWeeks: 4,
    capSeveranceWeeks: 26,
    risk: "Medium",
    riskNote: "WARN / mini-WARN notice and OWBPA release rules apply to larger reductions.",
    legalFeePerExit: 2500,
    outplacementPerExit: 3500,
    adminPerExit: 500,
    claimRatePct: 6,
    avgClaimMonths: 6,
    defenceCostPerClaim: 60000,
    collectiveThreshold: 50,
    collectiveProcessCost: 75000,
    legalNote: "Discrimination / ADEA exposure; OWBPA releases and WARN notices drive counsel fees.",
    formulaNote: "No statutory severance; policy norm ≈ 2 weeks per year with a floor.",
  },
  {
    country: "Germany",
    region: "EMEA",
    noticeWeeks: 8,
    severanceWeeksPerYear: 2.2,
    minSeveranceWeeks: 4.3,
    capSeveranceWeeks: 78,
    risk: "High",
    riskNote: "Works council consultation typically required, plus social selection criteria.",
    legalFeePerExit: 3500,
    outplacementPerExit: 2500,
    adminPerExit: 600,
    claimRatePct: 25,
    avgClaimMonths: 9,
    defenceCostPerClaim: 20000,
    collectiveThreshold: 20,
    collectiveProcessCost: 120000,
    legalNote: "Kündigungsschutz claims are frequent; settlements typically buy off reinstatement risk.",
    formulaNote: "Customary settlement ≈ 0.5 month per year of service.",
  },
  {
    country: "United Kingdom",
    region: "EMEA",
    noticeWeeks: 6,
    severanceWeeksPerYear: 1.5,
    minSeveranceWeeks: 2,
    capSeveranceWeeks: 30,
    risk: "High",
    riskNote: "Collective consultation thresholds at 20+ and 100+ proposed redundancies.",
    legalFeePerExit: 2200,
    outplacementPerExit: 2000,
    adminPerExit: 450,
    claimRatePct: 10,
    avgClaimMonths: 6,
    defenceCostPerClaim: 35000,
    collectiveThreshold: 20,
    collectiveProcessCost: 80000,
    legalNote: "Employment Tribunal unfair dismissal plus uncapped discrimination risk; s188 protective awards.",
    formulaNote: "Statutory redundancy pay is age-banded with a capped weekly amount.",
  },
  {
    country: "France",
    region: "EMEA",
    noticeWeeks: 8,
    severanceWeeksPerYear: 1.1,
    minSeveranceWeeks: 4.3,
    capSeveranceWeeks: 60,
    risk: "High",
    riskNote: "CSE consultation, redeployment search and PSE obligations for larger reductions.",
    legalFeePerExit: 4500,
    outplacementPerExit: 3500,
    adminPerExit: 700,
    claimRatePct: 20,
    avgClaimMonths: 9,
    defenceCostPerClaim: 30000,
    collectiveThreshold: 10,
    collectiveProcessCost: 150000,
    legalNote: "Conseil de prud'hommes scale (Macron barème); PSE design and expert fees are material.",
    formulaNote: "Legal indemnity ≈ 1/4 month per year, rising to 1/3 after 10 years.",
  },
  {
    country: "China",
    region: "APAC",
    noticeWeeks: 4.3,
    severanceWeeksPerYear: 4.3,
    minSeveranceWeeks: 2.2,
    capSeveranceWeeks: 52,
    risk: "Medium",
    riskNote: "Mass layoffs require plan reporting to the local labour bureau.",
    legalFeePerExit: 800,
    outplacementPerExit: 500,
    adminPerExit: 300,
    claimRatePct: 12,
    avgClaimMonths: 4,
    defenceCostPerClaim: 8000,
    collectiveThreshold: 20,
    collectiveProcessCost: 20000,
    legalNote: "Labour arbitration is mandatory first step; invalid termination means 2N damages.",
    formulaNote: "1 month per year (N+1 practice), monthly pay capped at 3x local average wage.",
  },
  {
    country: "South Korea",
    region: "APAC",
    noticeWeeks: 4.3,
    severanceWeeksPerYear: 4.3,
    minSeveranceWeeks: 4.3,
    capSeveranceWeeks: 78,
    risk: "High",
    riskNote: "60 days of consultation with the union or employee representatives.",
    legalFeePerExit: 2200,
    outplacementPerExit: 1500,
    adminPerExit: 500,
    claimRatePct: 15,
    avgClaimMonths: 6,
    defenceCostPerClaim: 25000,
    collectiveThreshold: 10,
    collectiveProcessCost: 90000,
    legalNote: "Labour Relations Commission remedy orders can require reinstatement plus back pay.",
    formulaNote: "Retirement allowance ≈ 30 days pay per year of service.",
  },
  {
    country: "Japan",
    region: "APAC",
    noticeWeeks: 4.3,
    severanceWeeksPerYear: 4.3,
    minSeveranceWeeks: 8.6,
    capSeveranceWeeks: 104,
    risk: "High",
    riskNote: "Four-factor dismissal test; voluntary retirement programmes are the norm.",
    legalFeePerExit: 3000,
    outplacementPerExit: 3000,
    adminPerExit: 600,
    claimRatePct: 10,
    avgClaimMonths: 12,
    defenceCostPerClaim: 40000,
    collectiveThreshold: 30,
    collectiveProcessCost: 100000,
    legalNote: "Dismissal is hard to defend; tribunal (rōdō shinpan) settlements often 6–12 months' pay.",
    formulaNote: "No statutory formula; packages follow policy and negotiated practice.",
  },
  {
    country: "Taiwan",
    region: "APAC",
    noticeWeeks: 4,
    severanceWeeksPerYear: 2.2,
    minSeveranceWeeks: 2.2,
    capSeveranceWeeks: 26,
    risk: "Medium",
    riskNote: "Mass redundancy plan filing and job-seeking leave during notice.",
    legalFeePerExit: 900,
    outplacementPerExit: 700,
    adminPerExit: 300,
    claimRatePct: 10,
    avgClaimMonths: 4,
    defenceCostPerClaim: 10000,
    collectiveThreshold: 10,
    collectiveProcessCost: 25000,
    legalNote: "Mandatory mediation before litigation; reinstatement claims possible.",
    formulaNote: "0.5 month per year under the new pension scheme, capped at 6 months.",
  },
  {
    country: "Malaysia",
    region: "APAC",
    noticeWeeks: 4,
    severanceWeeksPerYear: 2.5,
    minSeveranceWeeks: 2,
    capSeveranceWeeks: 30,
    risk: "Medium",
    riskNote: "PK form notification to the Labour Department before retrenchment.",
    legalFeePerExit: 600,
    outplacementPerExit: 400,
    adminPerExit: 250,
    claimRatePct: 14,
    avgClaimMonths: 6,
    defenceCostPerClaim: 8000,
    collectiveThreshold: 20,
    collectiveProcessCost: 15000,
    legalNote: "Industrial Court unfair dismissal claims can award back wages plus compensation.",
    formulaNote: "Termination benefits ≈ 10–20 days wages per year for covered employees.",
  },
  {
    country: "Singapore",
    region: "APAC",
    noticeWeeks: 4,
    severanceWeeksPerYear: 2.5,
    minSeveranceWeeks: 2,
    capSeveranceWeeks: 26,
    risk: "Low",
    riskNote: "Tripartite Advisory expectations and MOM retrenchment notification.",
    legalFeePerExit: 1400,
    outplacementPerExit: 1500,
    adminPerExit: 400,
    claimRatePct: 5,
    avgClaimMonths: 3,
    defenceCostPerClaim: 15000,
    collectiveThreshold: 10,
    collectiveProcessCost: 20000,
    legalNote: "TADM mediation and ECT claims; low quantum but reputational and MOM scrutiny.",
    formulaNote: "No statutory severance; norm is 2 weeks to 1 month per year.",
  },
  {
    country: "Netherlands",
    region: "EMEA",
    noticeWeeks: 6,
    severanceWeeksPerYear: 1.4,
    minSeveranceWeeks: 2,
    capSeveranceWeeks: 40,
    risk: "High",
    riskNote: "UWV or court route plus works council consultation for collective changes.",
    legalFeePerExit: 3200,
    outplacementPerExit: 2500,
    adminPerExit: 600,
    claimRatePct: 15,
    avgClaimMonths: 6,
    defenceCostPerClaim: 22000,
    collectiveThreshold: 20,
    collectiveProcessCost: 110000,
    legalNote: "Fair-process defects trigger additional (billijke vergoeding) compensation.",
    formulaNote: "Transition payment ≈ 1/3 month per year of service.",
  },
  {
    country: "Belgium",
    region: "EMEA",
    noticeWeeks: 12,
    severanceWeeksPerYear: 3,
    minSeveranceWeeks: 4,
    capSeveranceWeeks: 65,
    risk: "High",
    riskNote: "Renault Act procedure and outplacement obligations for collective dismissals.",
    legalFeePerExit: 3500,
    outplacementPerExit: 3000,
    adminPerExit: 700,
    claimRatePct: 12,
    avgClaimMonths: 6,
    defenceCostPerClaim: 22000,
    collectiveThreshold: 10,
    collectiveProcessCost: 130000,
    legalNote: "Outplacement is a statutory obligation; manifestly unreasonable dismissal penalties apply.",
    formulaNote: "Notice scales steeply with seniority; pay in lieu is common.",
  },
  {
    country: "Spain",
    region: "EMEA",
    noticeWeeks: 2,
    severanceWeeksPerYear: 2.9,
    minSeveranceWeeks: 2.9,
    capSeveranceWeeks: 52,
    risk: "High",
    riskNote: "ERE procedure and consultation with worker representatives above thresholds.",
    legalFeePerExit: 2500,
    outplacementPerExit: 1500,
    adminPerExit: 500,
    claimRatePct: 22,
    avgClaimMonths: 8,
    defenceCostPerClaim: 18000,
    collectiveThreshold: 10,
    collectiveProcessCost: 90000,
    legalNote: "Unfair dismissal is 33 days/year capped at 24 months; null dismissal means reinstatement.",
    formulaNote: "Objective dismissal: 20 days pay per year, capped at 12 months.",
  },
  {
    country: "Turkey",
    region: "EMEA",
    noticeWeeks: 4,
    severanceWeeksPerYear: 4.3,
    minSeveranceWeeks: 4.3,
    capSeveranceWeeks: 52,
    risk: "Medium",
    riskNote: "Reinstatement claims possible where job-security provisions apply.",
    legalFeePerExit: 700,
    outplacementPerExit: 400,
    adminPerExit: 250,
    claimRatePct: 25,
    avgClaimMonths: 8,
    defenceCostPerClaim: 6000,
    collectiveThreshold: 30,
    collectiveProcessCost: 15000,
    legalNote: "Mandatory mediation then reinstatement claims worth 4–8 months' pay plus 4 months' wages.",
    formulaNote: "30 days pay per year, subject to a statutory ceiling per year.",
  },
  {
    country: "Italy",
    region: "EMEA",
    noticeWeeks: 6,
    severanceWeeksPerYear: 3.2,
    minSeveranceWeeks: 3.2,
    capSeveranceWeeks: 65,
    risk: "High",
    riskNote: "Collective dismissal procedure with union notification; CCNL may add obligations.",
    legalFeePerExit: 2500,
    outplacementPerExit: 1500,
    adminPerExit: 500,
    claimRatePct: 20,
    avgClaimMonths: 9,
    defenceCostPerClaim: 20000,
    collectiveThreshold: 5,
    collectiveProcessCost: 90000,
    legalNote: "Collective dismissal procedural defects are the main litigation trigger; Fornero/Jobs Act regimes differ.",
    formulaNote: "TFR accrues ≈ 1 month's pay per year and is payable on any exit.",
  },
  {
    country: "New Zealand",
    region: "APAC",
    noticeWeeks: 4,
    severanceWeeksPerYear: 0,
    minSeveranceWeeks: 0,
    capSeveranceWeeks: 26,
    risk: "Medium",
    riskNote: "Good-faith consultation obligations are substantive, not procedural only.",
    legalFeePerExit: 1500,
    outplacementPerExit: 1500,
    adminPerExit: 400,
    claimRatePct: 10,
    avgClaimMonths: 4,
    defenceCostPerClaim: 20000,
    collectiveThreshold: 20,
    collectiveProcessCost: 30000,
    legalNote: "Personal grievance claims to the Employment Relations Authority; process fairness is decisive.",
    formulaNote: "No statutory redundancy compensation; contract and policy govern.",
  },
  {
    country: "Brazil",
    region: "LATAM",
    noticeWeeks: 4.3,
    severanceWeeksPerYear: 1.7,
    minSeveranceWeeks: 4.3,
    capSeveranceWeeks: 60,
    risk: "High",
    riskNote: "Union homologation for collective dismissals; FGTS penalty and 13th/vacation accruals apply.",
    legalFeePerExit: 1800,
    outplacementPerExit: 900,
    adminPerExit: 450,
    claimRatePct: 30,
    avgClaimMonths: 6,
    defenceCostPerClaim: 12000,
    collectiveThreshold: 20,
    collectiveProcessCost: 45000,
    legalNote: "Labour Court claims are very common and cheap for the employee; unpaid accruals drive quantum.",
    formulaNote: "40% FGTS fine plus notice and proportional 13th salary and vacation.",
  },
  {
    country: "Mexico",
    region: "LATAM",
    noticeWeeks: 0,
    severanceWeeksPerYear: 1.7,
    minSeveranceWeeks: 13,
    capSeveranceWeeks: 52,
    risk: "Medium",
    riskNote: "No at-will termination; mutual-separation agreements ratified before the labour authority.",
    legalFeePerExit: 1600,
    outplacementPerExit: 800,
    adminPerExit: 350,
    claimRatePct: 20,
    avgClaimMonths: 6,
    defenceCostPerClaim: 10000,
    collectiveThreshold: 20,
    collectiveProcessCost: 25000,
    legalNote: "Reinstatement plus accrued back pay is the main exposure if the exit is not ratified.",
    formulaNote: "3 months' pay plus 20 days per year and seniority premium is the negotiated norm.",
  },
  {
    country: "Poland",
    region: "EMEA",
    noticeWeeks: 12,
    severanceWeeksPerYear: 1,
    minSeveranceWeeks: 4.3,
    capSeveranceWeeks: 13,
    risk: "High",
    riskNote: "Collective redundancy consultation with trade unions and PUP notification above thresholds.",
    legalFeePerExit: 1400,
    outplacementPerExit: 900,
    adminPerExit: 350,
    claimRatePct: 12,
    avgClaimMonths: 3,
    defenceCostPerClaim: 9000,
    collectiveThreshold: 10,
    collectiveProcessCost: 40000,
    legalNote: "Labour court claims focus on selection criteria; awards are capped at ~3 months' pay.",
    formulaNote: "Statutory severance 1–3 months' pay, capped at 15× minimum wage.",
  },
  {
    country: "India",
    region: "APAC",
    noticeWeeks: 4.3,
    severanceWeeksPerYear: 2.2,
    minSeveranceWeeks: 4.3,
    capSeveranceWeeks: 52,
    risk: "High",
    riskNote: "Government approval may be needed for larger establishments; state rules vary widely.",
    legalFeePerExit: 1200,
    outplacementPerExit: 600,
    adminPerExit: 350,
    claimRatePct: 15,
    avgClaimMonths: 6,
    defenceCostPerClaim: 8000,
    collectiveThreshold: 20,
    collectiveProcessCost: 35000,
    legalNote: "Industrial dispute references are slow; 'last in, first out' breaches are the usual challenge.",
    formulaNote: "Retrenchment compensation 15 days' pay per year plus gratuity where eligible.",
  },
];

/**
 * HRIS extracts rarely use one canonical spelling. Normalise common aliases
 * to the rule-table names so costs never silently fall back to the generic
 * placeholder row.
 */
const COUNTRY_ALIASES: Record<string, string> = {
  "United Arab Emirates": "UAE",
  "U.A.E.": "UAE",
  UK: "United Kingdom",
  "Great Britain": "United Kingdom",
  USA: "United States",
  "U.S.": "United States",
  "U.S.A.": "United States",
  "United States of America": "United States",
  "The Netherlands": "Netherlands",
  Holland: "Netherlands",
  "Viet Nam": "Vietnam",
};

/** Fallback used when a role's country has no rule row. */
export const FALLBACK_RULE: CountryCostRule = {
  country: "Unspecified",
  region: "—",
  noticeWeeks: 4,
  severanceWeeksPerYear: 2,
  minSeveranceWeeks: 2,
  capSeveranceWeeks: 26,
  risk: "Medium",
  riskNote: "No country rule found — assign a country to price this exit properly.",
  legalFeePerExit: 1200,
  outplacementPerExit: 800,
  adminPerExit: 350,
  claimRatePct: 10,
  avgClaimMonths: 5,
  defenceCostPerClaim: 12000,
  collectiveThreshold: 20,
  collectiveProcessCost: 25000,
  legalNote: "No country rule found — legal fee and tribunal exposure are generic placeholders.",
  formulaNote: "Generic global placeholder assumption.",
};

export const COST_RULE_COUNTRIES = COUNTRY_COST_RULES.map((r) => r.country);

/** Rules for a scenario, with any scenario-level overrides applied. */
export function effectiveRules(scenario?: Scenario | null): CountryCostRule[] {
  const overrides = scenario?.countryCostOverrides ?? {};
  const base = COUNTRY_COST_RULES.map((r) => ({ ...r, ...(overrides[r.country] ?? {}) }));
  // Overrides may also introduce brand new markets.
  for (const [country, patch] of Object.entries(overrides)) {
    if (!base.some((r) => r.country === country)) {
      base.push({ ...FALLBACK_RULE, ...patch, country });
    }
  }
  return base;
}

export function ruleFor(country: string, rules: CountryCostRule[]): CountryCostRule {
  const name = COUNTRY_ALIASES[country] ?? country;
  return (
    rules.find((r) => r.country === name) ?? { ...FALLBACK_RULE, country: country || "Unspecified" }
  );
}

export function isOverridden(scenario: Scenario | null | undefined, country: string) {
  const patch = scenario?.countryCostOverrides?.[country];
  return !!patch && Object.keys(patch).length > 0;
}

/**
 * Resolves each role's country: use its own, otherwise inherit from the nearest
 * manager that has one. Keeps separation costing correct for positions marked
 * for removal that were created without a country.
 */
export function resolveCountries(employees: Employee[]): Map<string, string> {
  const byId = new Map(employees.map((e) => [e.id, e]));
  const out = new Map<string, string>();
  for (const e of employees) {
    let cursor: Employee | undefined = e;
    const seen = new Set<string>();
    let country = "";
    while (cursor && !seen.has(cursor.id)) {
      seen.add(cursor.id);
      if (cursor.country?.trim()) {
        country = cursor.country.trim();
        break;
      }
      cursor = cursor.managerId ? byId.get(cursor.managerId) : undefined;
    }
    out.set(e.id, country || "Unspecified");
  }
  return out;
}

export interface ExitCost {
  exits: number;
  years: number;
  noticeCost: number;
  severanceCost: number;
  legalFees: number;
  outplacement: number;
  adminCost: number;
  /** Expected value of tribunal / labour-court exposure (mid case). */
  tribunalRisk: number;
  expectedClaims: number;
  extraLow: number;
  extraHigh: number;
  low: number;
  high: number;
  mid: number;
}

/** Multipliers that shape the low and high ends of the litigation range. */
const CLAIM_LOW_FACTOR = 0.5;
const CLAIM_HIGH_FACTOR = 1.6;

/** Number of positions leaving this role in the scenario. */
export function exitCount(e: Employee) {
  if (e.status === "to-be-removed") return Math.max(e.currentHeadcount, 1);
  // Partial reductions also incur separation cost.
  return Math.max(0, e.currentHeadcount - e.plannedHeadcount);
}

/** Illustrative one-off separation cost for a role, priced on its country rule. */
export function exitCostForRole(e: Employee, rule: CountryCostRule, exits = exitCount(e)): ExitCost {
  const years = Math.max(0, (e.serviceMonths || 0) / 12);
  const weekly = (e.currentCost || 0) / 52;
  const monthly = (e.currentCost || 0) / 12;
  const sevWeeks = Math.min(
    rule.capSeveranceWeeks,
    Math.max(rule.minSeveranceWeeks, rule.severanceWeeksPerYear * years),
  );
  const severanceCost = Math.round(weekly * sevWeeks * exits);
  const noticeCost = Math.round(weekly * rule.noticeWeeks * exits);
  const legalFees = Math.round(rule.legalFeePerExit * exits);
  const outplacement = Math.round(rule.outplacementPerExit * exits);
  const adminCost = Math.round(rule.adminPerExit * exits);
  const expectedClaims = (rule.claimRatePct / 100) * exits;
  const perClaim = rule.defenceCostPerClaim + rule.avgClaimMonths * monthly;
  const tribunalRisk = Math.round(expectedClaims * perClaim);
  const extraLow = Math.round(
    legalFees + outplacement + adminCost + tribunalRisk * CLAIM_LOW_FACTOR,
  );
  const extraHigh = Math.round(
    legalFees * 1.4 + outplacement + adminCost * 1.2 + tribunalRisk * CLAIM_HIGH_FACTOR,
  );
  const low = severanceCost + noticeCost + extraLow;
  const high = severanceCost + noticeCost + extraHigh;
  return {
    exits,
    years,
    noticeCost,
    severanceCost,
    legalFees,
    outplacement,
    adminCost,
    tribunalRisk,
    expectedClaims,
    extraLow,
    extraHigh,
    low,
    high,
    mid: Math.round((low + high) / 2),
  };
}

export interface CountrySeparation {
  country: string;
  region: string;
  rule: CountryCostRule;
  exits: number;
  noticeCost: number;
  severanceCost: number;
  legalFees: number;
  outplacement: number;
  adminCost: number;
  tribunalRisk: number;
  expectedClaims: number;
  /** Collective consultation programme cost, charged once when the threshold is met. */
  collectiveCost: number;
  collectiveTriggered: boolean;
  extraLow: number;
  extraHigh: number;
  low: number;
  high: number;
  mid: number;
}

export interface SeparationSummary {
  byCountry: CountrySeparation[];
  exits: number;
  low: number;
  high: number;
  mid: number;
  legalFees: number;
  tribunalRisk: number;
  collectiveCost: number;
  expectedClaims: number;
  highRiskCountries: CountrySeparation[];
  collectiveMarkets: CountrySeparation[];
}

/** Aggregates one-off separation cost across a scenario, by country. */
export function separationSummary(
  employees: Employee[],
  rules: CountryCostRule[] = COUNTRY_COST_RULES,
): SeparationSummary {
  const countries = resolveCountries(employees);
  const map = new Map<string, CountrySeparation>();
  for (const e of employees) {
    const exits = exitCount(e);
    if (exits <= 0) continue;
    const country = countries.get(e.id) ?? "Unspecified";
    const rule = ruleFor(country, rules);
    const cost = exitCostForRole(e, rule, exits);
    const row =
      map.get(country) ??
      ({
        country,
        region: rule.region,
        rule,
        exits: 0,
        noticeCost: 0,
        severanceCost: 0,
        legalFees: 0,
        outplacement: 0,
        adminCost: 0,
        tribunalRisk: 0,
        expectedClaims: 0,
        collectiveCost: 0,
        collectiveTriggered: false,
        extraLow: 0,
        extraHigh: 0,
        low: 0,
        high: 0,
        mid: 0,
      } satisfies CountrySeparation);
    row.exits += exits;
    row.noticeCost += cost.noticeCost;
    row.severanceCost += cost.severanceCost;
    row.legalFees += cost.legalFees;
    row.outplacement += cost.outplacement;
    row.adminCost += cost.adminCost;
    row.tribunalRisk += cost.tribunalRisk;
    row.expectedClaims += cost.expectedClaims;
    row.extraLow += cost.extraLow;
    row.extraHigh += cost.extraHigh;
    row.low += cost.low;
    row.high += cost.high;
    row.mid += cost.mid;
    map.set(country, row);
  }
  // Collective consultation is a country-level programme cost, not a per-exit one.
  for (const row of map.values()) {
    if (row.exits >= row.rule.collectiveThreshold && row.rule.collectiveProcessCost > 0) {
      row.collectiveTriggered = true;
      row.collectiveCost = row.rule.collectiveProcessCost;
      row.extraLow += row.collectiveCost;
      row.extraHigh += Math.round(row.collectiveCost * 1.35);
      row.low += row.collectiveCost;
      row.high += Math.round(row.collectiveCost * 1.35);
      row.mid = Math.round((row.low + row.high) / 2);
    }
  }
  const byCountry = [...map.values()].sort((a, b) => b.mid - a.mid);
  return {
    byCountry,
    exits: byCountry.reduce((a, c) => a + c.exits, 0),
    low: byCountry.reduce((a, c) => a + c.low, 0),
    high: byCountry.reduce((a, c) => a + c.high, 0),
    mid: byCountry.reduce((a, c) => a + c.mid, 0),
    legalFees: byCountry.reduce((a, c) => a + c.legalFees, 0),
    tribunalRisk: byCountry.reduce((a, c) => a + c.tribunalRisk, 0),
    collectiveCost: byCountry.reduce((a, c) => a + c.collectiveCost, 0),
    expectedClaims: byCountry.reduce((a, c) => a + c.expectedClaims, 0),
    highRiskCountries: byCountry.filter((c) => c.rule.risk === "High"),
    collectiveMarkets: byCountry.filter((c) => c.collectiveTriggered),
  };
}

/** Numeric fields a user can override per scenario. */
export const OVERRIDE_FIELDS = [
  { key: "noticeWeeks", label: "Notice (weeks)", step: 0.5 },
  { key: "severanceWeeksPerYear", label: "Severance weeks / year", step: 0.1 },
  { key: "minSeveranceWeeks", label: "Min weeks", step: 0.5 },
  { key: "capSeveranceWeeks", label: "Cap weeks", step: 1 },
  { key: "legalFeePerExit", label: "Legal fees / exit", step: 100 },
  { key: "outplacementPerExit", label: "Outplacement / exit", step: 100 },
  { key: "adminPerExit", label: "Admin / exit", step: 50 },
  { key: "claimRatePct", label: "Claim rate %", step: 1 },
  { key: "avgClaimMonths", label: "Award (months)", step: 0.5 },
  { key: "defenceCostPerClaim", label: "Defence / claim", step: 1000 },
  { key: "collectiveThreshold", label: "Collective threshold (exits)", step: 1 },
  { key: "collectiveProcessCost", label: "Collective process cost", step: 5000 },
] as const satisfies readonly { key: keyof CountryCostOverride; label: string; step: number }[];

export const RISK_LEVELS: ConsultationRisk[] = ["Low", "Medium", "High"];