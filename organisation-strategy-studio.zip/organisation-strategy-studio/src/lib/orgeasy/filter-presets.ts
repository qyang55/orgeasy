/** Saved People & Roles filter views, persisted per browser. */
import { hasConsent } from "./consent";

export interface PeopleFilterState {
  query: string;
  status: string;
  department: string;
  country: string;
  employmentType: string;
  manager: string;
  openRolesOnly: boolean;
}

export interface FilterPreset extends PeopleFilterState {
  id: string;
  name: string;
}

export const EMPTY_FILTERS: PeopleFilterState = {
  query: "",
  status: "all",
  department: "all",
  country: "all",
  employmentType: "all",
  manager: "all",
  openRolesOnly: false,
};

const KEY = "orgeasy.people.presets.v1";

export function countActiveFilters(f: PeopleFilterState) {
  return (
    (f.query.trim() ? 1 : 0) +
    [f.status, f.department, f.country, f.employmentType, f.manager].filter((v) => v !== "all")
      .length +
    (f.openRolesOnly ? 1 : 0)
  );
}

export function sameFilters(a: PeopleFilterState, b: PeopleFilterState) {
  return (
    a.query.trim() === b.query.trim() &&
    a.status === b.status &&
    a.department === b.department &&
    a.country === b.country &&
    a.employmentType === b.employmentType &&
    a.manager === b.manager &&
    a.openRolesOnly === b.openRolesOnly
  );
}

/** Human-readable summary, e.g. "Operations · Thailand · open roles only". */
export function describeFilters(f: PeopleFilterState, managerLabel?: string) {
  const parts: string[] = [];
  if (f.department !== "all") parts.push(f.department);
  if (f.country !== "all") parts.push(f.country);
  if (f.employmentType !== "all") parts.push(f.employmentType);
  if (f.status !== "all") parts.push(f.status.replace(/-/g, " "));
  if (f.manager === "none") parts.push("top level");
  else if (f.manager !== "all") parts.push(`reports to ${managerLabel ?? "manager"}`);
  if (f.openRolesOnly) parts.push("open roles only");
  if (f.query.trim()) parts.push(`“${f.query.trim()}”`);
  return parts.length ? parts.join(" · ") : "All roles";
}

/** Suggests a preset name from the filters when the user hasn't typed one. */
export function suggestPresetName(f: PeopleFilterState) {
  return describeFilters(f);
}

export function loadPresets(): FilterPreset[] {
  if (typeof localStorage === "undefined") return [];
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) ?? "[]");
    if (!Array.isArray(raw)) return [];
    return raw
      .filter((p) => p && typeof p.id === "string" && typeof p.name === "string")
      .map((p) => ({ ...EMPTY_FILTERS, ...p }) as FilterPreset);
  } catch {
    return [];
  }
}

export function savePresets(presets: FilterPreset[]) {
  if (typeof localStorage === "undefined") return;
  // Saved views are a preference: honour the consent choice from Privacy & Data.
  if (!hasConsent("preferences")) {
    localStorage.removeItem(KEY);
    return;
  }
  localStorage.setItem(KEY, JSON.stringify(presets));
}
