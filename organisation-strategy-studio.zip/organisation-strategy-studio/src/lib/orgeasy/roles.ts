/**
 * Workspace role-based access control (RBAC) and the executive activity trail.
 *
 * Roles are workspace-scoped and enforced centrally in the store: every
 * mutating action checks its permission before applying, so a "Viewer" is
 * read-only no matter which surface (canvas, people grid, import, exports)
 * the action comes from. Identity-provider-backed roles (SSO/SCIM) arrive
 * with cloud sync; the permission model here is the one they will map onto.
 */

export type WorkspaceRole = "admin" | "editor" | "viewer";

export const WORKSPACE_ROLES: WorkspaceRole[] = ["admin", "editor", "viewer"];

export const ROLE_META: Record<
  WorkspaceRole,
  { label: string; tagline: string; description: string; badgeClass: string }
> = {
  admin: {
    label: "Admin",
    tagline: "Full control",
    description:
      "Everything an Editor can do, plus deleting scenarios, resetting or restoring the workspace, and managing roles.",
    badgeClass: "border-brand/30 bg-brand/10 text-brand",
  },
  editor: {
    label: "Editor",
    tagline: "Model & export",
    description:
      "Design future states end to end: edit structure, create scenarios, import data and export board packs. Cannot delete scenarios, reset the workspace or manage roles.",
    badgeClass: "border-success/30 bg-success/10 text-success",
  },
  viewer: {
    label: "Viewer",
    tagline: "Read-only",
    description:
      "Sees every scenario, metric and comparison, but cannot change structure, import data or export packs. Ideal for executive reviewers and pilot stakeholders.",
    badgeClass: "border-border bg-muted text-muted-foreground",
  },
};

export type Permission =
  | "editStructure"
  | "manageScenarios"
  | "deleteScenarios"
  | "importData"
  | "exportPacks"
  | "resetData"
  | "manageRoles";

export const PERMISSION_META: Record<Permission, { label: string; description: string }> = {
  editStructure: {
    label: "Edit structure & roles",
    description: "Change reporting lines, roles, headcount, costs and ADKAR data.",
  },
  manageScenarios: {
    label: "Create & edit scenarios",
    description: "Create, duplicate, rename, reorder and restore scenarios and phases.",
  },
  deleteScenarios: {
    label: "Delete scenarios",
    description: "Permanently remove scenarios from the workspace.",
  },
  importData: {
    label: "Import data",
    description: "Load CSV, Excel or HRIS extracts into a scenario.",
  },
  exportPacks: {
    label: "Export packs",
    description: "Download board packs, decks, PDF summaries and role CSVs.",
  },
  resetData: {
    label: "Reset & restore workspace",
    description: "Reset demo data, clear the activity log and restore workspace versions.",
  },
  manageRoles: {
    label: "Manage roles",
    description: "Change the workspace access role.",
  },
};

export const PERMISSION_LIST = Object.keys(PERMISSION_META) as Permission[];

const ROLE_PERMISSIONS: Record<WorkspaceRole, readonly Permission[]> = {
  admin: PERMISSION_LIST,
  editor: ["editStructure", "manageScenarios", "importData", "exportPacks"],
  viewer: [],
};

export function roleCan(role: WorkspaceRole, permission: Permission): boolean {
  return ROLE_PERMISSIONS[role].includes(permission);
}

/** Boolean map for convenient UI gating, e.g. `permissions.exportPacks`. */
export function permissionsFor(role: WorkspaceRole): Record<Permission, boolean> {
  return Object.fromEntries(PERMISSION_LIST.map((p) => [p, roleCan(role, p)])) as Record<
    Permission,
    boolean
  >;
}

/* ------------------------------------------------------------------------ */
/* Activity trail                                                            */
/* ------------------------------------------------------------------------ */

export type ActivityKind = "scenario" | "structure" | "export" | "access" | "version";

export interface ActivityEvent {
  id: string;
  /** ISO timestamp. */
  at: string;
  kind: ActivityKind;
  /** Human, executive-readable sentence, e.g. 'Created scenario "Phase 2".' */
  message: string;
  /** Workspace account email, or "Guest session" when unclaimed. */
  actor: string;
  scenarioName?: string;
}

export const ACTIVITY_KIND_META: Record<ActivityKind, { label: string }> = {
  scenario: { label: "Scenarios" },
  structure: { label: "Structure & data" },
  export: { label: "Exports" },
  access: { label: "Access & roles" },
  version: { label: "Restore points" },
};

export const ACTIVITY_KINDS = Object.keys(ACTIVITY_KIND_META) as ActivityKind[];

/** Keep the trail bounded so large workspaces never hit the storage budget. */
export const ACTIVITY_LIMIT = 120;

/**
 * Returns a new activity array with the event prepended. Consecutive identical
 * events within a minute (e.g. a drag session on the canvas) collapse into one
 * entry instead of flooding the trail.
 */
export function logEvent(
  activity: ActivityEvent[] | undefined,
  actor: string,
  kind: ActivityKind,
  message: string,
  scenarioName?: string,
): ActivityEvent[] {
  const list = activity ?? [];
  const latest = list[0];
  if (
    latest &&
    latest.kind === kind &&
    latest.message === message &&
    latest.scenarioName === scenarioName &&
    Date.now() - new Date(latest.at).getTime() < 60_000
  ) {
    return list;
  }
  const entry: ActivityEvent = {
    id: Math.random().toString(36).slice(2, 10),
    at: new Date().toISOString(),
    kind,
    message,
    actor,
    ...(scenarioName ? { scenarioName } : {}),
  };
  return [entry, ...list].slice(0, ACTIVITY_LIMIT);
}
