import type { Scenario, Workspace } from "./types";
import { computeImpact } from "./impact";
import { computeProgramme } from "./levers";
import { buildChangePlan } from "./change-plan";
import { resolveBaseline } from "./phases";
import { generateExecutiveDeck } from "./pptx-exec";

/**
 * One-click leadership board pack: the same 5–7 slide executive deck the
 * Exports page builds, with sensible defaults — editable native charts,
 * automatic baseline resolution and the top alternative options on the table.
 * Everything renders from scenario data, so no canvas or DOM is needed.
 */
export async function downloadBoardPack(
  workspace: Workspace,
  scenario: Scenario,
  preparedBy?: string | null,
) {
  const baseline = resolveBaseline(workspace.scenarios, scenario);
  await generateExecutiveDeck(scenario, {
    programme: computeProgramme(workspace, scenario),
    impact: computeImpact(scenario),
    plan: buildChangePlan(scenario, baseline),
    baselineName: baseline?.name ?? null,
    preparedBy: preparedBy ?? null,
    editableCharts: true,
    currentChartScenario: baseline,
    options: workspace.scenarios
      .filter((s) => s.id !== scenario.id && (s.kind ?? "") !== "current")
      .slice(0, 2)
      .map((s) => {
        const im = computeImpact(s);
        return { name: s.name, positions: im.plannedHeadcount, costDelta: im.costDelta };
      }),
    fileName: `${scenario.name}-leadership-pack`,
  });
}
