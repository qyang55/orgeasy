import type { Workspace } from "./types";
import { hasConsent } from "./consent";

/**
 * Workspace version history: point-in-time snapshots of the whole workspace
 * (scenarios, roles, cost model, agents, positions and operating models) so a
 * generated pack, a cost-model edit or a hiring input can be restored after a
 * mistake.
 */
export interface WorkspaceVersion {
  id: string;
  createdAt: string;
  /** Short human label, e.g. "Automotive — Mid-size · Global". */
  label: string;
  /** Why the snapshot exists: manual save, or the automatic change capture. */
  reason: "manual" | "auto" | "pre-restore";
  /** Where the user was when it was taken (route path). */
  origin?: string;
  scenarioCount: number;
  roleCount: number;
  plannedPositions: number;
  annualCost: number;
  currency: string;
  bytes: number;
  workspace: Workspace;
}

const STORAGE_KEY = "orgeasy.versions.v1";
/** Keep history useful without exhausting browser storage. */
export const VERSION_LIMITS = {
  maxVersions: 20,
  /** Skip snapshots of very large workspaces (enterprise imports). */
  maxSnapshotBytes: 3_000_000,
  /** Minimum gap between automatic snapshots. */
  autoIntervalMs: 90_000,
};

function store(): Storage | null {
  if (typeof window === "undefined") return null;
  // Mirrors the workspace itself: durable storage only with consent, otherwise
  // tab-scoped so history still protects the current session.
  return hasConsent("workspace") ? window.localStorage : window.sessionStorage;
}

export function loadVersions(): WorkspaceVersion[] {
  try {
    const raw = store()?.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as WorkspaceVersion[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function persist(versions: WorkspaceVersion[]) {
  const target = store();
  if (!target) return;
  let list = versions.slice(0, VERSION_LIMITS.maxVersions);
  // Drop oldest entries until the payload fits the storage budget.
  for (;;) {
    try {
      target.setItem(STORAGE_KEY, JSON.stringify(list));
      return;
    } catch {
      if (list.length <= 1) {
        try {
          target.removeItem(STORAGE_KEY);
        } catch {
          /* ignore */
        }
        return;
      }
      list = list.slice(0, list.length - 1);
    }
  }
}

export function summarise(workspace: Workspace) {
  const active =
    workspace.scenarios.find((s) => s.id === workspace.activeScenarioId) ?? workspace.scenarios[0];
  const roles = active?.employees ?? [];
  return {
    label: active?.name ?? "Empty workspace",
    scenarioCount: workspace.scenarios.length,
    roleCount: roles.length,
    plannedPositions: roles.reduce((sum, e) => sum + (e.plannedHeadcount || 0), 0),
    annualCost: roles.reduce((sum, e) => sum + (e.plannedHeadcount || 0) * (e.plannedCost || 0), 0),
    currency: active?.currency ?? "USD",
  };
}

/**
 * Writes a snapshot. Returns the new version, or null when it was skipped
 * (workspace too large, or identical to the newest snapshot).
 */
export function saveVersion(
  workspace: Workspace,
  options: { reason?: WorkspaceVersion["reason"]; label?: string; origin?: string } = {},
): WorkspaceVersion | null {
  let payload: string;
  try {
    payload = JSON.stringify(workspace);
  } catch {
    return null;
  }
  if (payload.length > VERSION_LIMITS.maxSnapshotBytes) return null;

  const existing = loadVersions();
  const newest = existing[0];
  if (newest && newest.bytes === payload.length && JSON.stringify(newest.workspace) === payload) {
    return null;
  }

  const summary = summarise(workspace);
  const version: WorkspaceVersion = {
    id: `v-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
    createdAt: new Date().toISOString(),
    label: options.label?.trim() || summary.label,
    reason: options.reason ?? "manual",
    ...(options.origin ? { origin: options.origin } : {}),
    scenarioCount: summary.scenarioCount,
    roleCount: summary.roleCount,
    plannedPositions: summary.plannedPositions,
    annualCost: summary.annualCost,
    currency: summary.currency,
    bytes: payload.length,
    workspace: JSON.parse(payload) as Workspace,
  };
  persist([version, ...existing]);
  return version;
}

export function deleteVersion(id: string) {
  persist(loadVersions().filter((v) => v.id !== id));
}

export function clearVersions() {
  try {
    store()?.removeItem(STORAGE_KEY);
  } catch {
    /* ignore */
  }
}

export function renameVersion(id: string, label: string) {
  persist(loadVersions().map((v) => (v.id === id ? { ...v, label } : v)));
}

/** True when enough time has passed to take another automatic snapshot. */
export function shouldAutoSnapshot(versions: WorkspaceVersion[] = loadVersions()) {
  const newest = versions[0];
  if (!newest) return true;
  return Date.now() - new Date(newest.createdAt).getTime() > VERSION_LIMITS.autoIntervalMs;
}