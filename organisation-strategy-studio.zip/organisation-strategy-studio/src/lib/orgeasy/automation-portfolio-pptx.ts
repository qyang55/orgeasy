/** PowerPoint export for a multi-JD automation portfolio review. */
import { BAND_META, computeTotals, type RoleAutomationAnalysis } from "./automation";
import {
  bandDistribution,
  departmentRollups,
  allTaskRows,
  portfolioTotals,
  recommendPhases,
  futureRoleTitle,
} from "./automation-portfolio";
import { formatMoney } from "./impact";
import { EXPORT_NOTICES, NOT_LEGAL_ADVICE_SHORT } from "./notices";
import { BRAND_NAVY, LOGO_COVER, LOGO_MARK, logoData } from "./brand";

const BLUE = "2563EB";
const INK = "1E293B";
const MUTED = "64748B";
const LIGHT = "F1F5F9";
const WHITE = "FFFFFF";
const HEAD = "Georgia";
const BODY = "Calibri";

export async function generatePortfolioDeck(
  analyses: RoleAutomationAnalysis[],
  meta: { title?: string } = {},
) {
  const PptxGenJS = (await import("pptxgenjs")).default;
  const pptx = new PptxGenJS();
  pptx.layout = "LAYOUT_16x9";
  pptx.author = "Organisation Strategy Studio";
  pptx.title = meta.title ?? "Automation Portfolio Review";
  const logo = await logoData();

  const totals = portfolioTotals(analyses);
  const cur = totals.currency;
  const dateLabel = new Date().toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const slide = (title: string, kicker?: string) => {
    const s = pptx.addSlide();
    s.background = { color: WHITE };
    s.addShape("rect", { x: 0, y: 0, w: 0.22, h: 5.63, fill: { color: BLUE } });
    if (logo) {
      s.addImage({ data: logo, x: LOGO_MARK.x, y: LOGO_MARK.y, w: LOGO_MARK.size, h: LOGO_MARK.size });
    }
    if (kicker) {
      s.addText(kicker.toUpperCase(), {
        x: 0.6, y: 0.32, w: 8.8, h: 0.3,
        fontFace: BODY, fontSize: 12, color: BLUE, bold: true, charSpacing: 2,
      });
    }
    s.addText(title, {
      x: 0.6, y: kicker ? 0.62 : 0.45, w: 8.8, h: 0.55,
      fontFace: HEAD, fontSize: 26, color: INK, bold: true,
    });
    s.addText(NOT_LEGAL_ADVICE_SHORT, {
      x: 0.6, y: 5.15, w: 8.8, h: 0.3, fontFace: BODY, fontSize: 8, color: MUTED,
    });
    return s;
  };

  /* ---------------------------------------------------------------- cover */
  const cover = pptx.addSlide();
  cover.background = { color: BRAND_NAVY };
  if (logo) {
    cover.addImage({
      data: logo,
      x: LOGO_COVER.x,
      y: LOGO_COVER.y,
      w: LOGO_COVER.size,
      h: LOGO_COVER.size,
    });
  }
  cover.addText("Automation Portfolio Review", {
    x: 0.7, y: 1.6, w: 8.6, h: 0.8, fontFace: HEAD, fontSize: 36, color: WHITE, bold: true,
  });
  cover.addText(
    `${totals.roles} job descriptions analysed · ${totals.tasks} tasks assessed · ${dateLabel}`,
    { x: 0.7, y: 2.5, w: 8.6, h: 0.4, fontFace: BODY, fontSize: 15, color: "BFDBFE" },
  );
  cover.addText(
    "A workforce planning aid: where routine work can move to technology, and where human judgement stays.",
    { x: 0.7, y: 3.0, w: 8.0, h: 0.7, fontFace: BODY, fontSize: 12, color: "E2E8F0" },
  );

  /* ------------------------------------------------------------ headlines */
  const s1 = slide("Portfolio at a glance", "Executive summary");
  const cards: [string, string][] = [
    ["Average automatability", `${totals.averageScore}%`],
    ["Hours returned / week", `${totals.hoursPerWeek}`],
    ["Capacity released", `${totals.fteEquivalent} FTE`],
    ["Indicative annual value", formatMoney(totals.annualSaving, cur)],
  ];
  cards.forEach(([label, value], i) => {
    const x = 0.6 + i * 2.2;
    s1.addShape("roundRect", {
      x, y: 1.4, w: 2.0, h: 1.2, fill: { color: LIGHT }, line: { color: "E2E8F0" },
      rectRadius: 0.08,
    });
    s1.addText(label.toUpperCase(), {
      x: x + 0.12, y: 1.52, w: 1.8, h: 0.3, fontFace: BODY, fontSize: 8, color: MUTED, bold: true,
    });
    s1.addText(value, {
      x: x + 0.12, y: 1.82, w: 1.8, h: 0.5, fontFace: HEAD, fontSize: 20, color: INK, bold: true,
    });
  });
  const dist = bandDistribution(analyses);
  s1.addText(
    Object.entries(dist.counts).map(([band, count]) => ({
      text: `${BAND_META[band as keyof typeof BAND_META].label}: ${count} task${count === 1 ? "" : "s"} (${dist.total ? Math.round((count / dist.total) * 100) : 0}%)`,
      options: { bullet: true, fontSize: 12, color: INK, fontFace: BODY, breakLine: true },
    })),
    { x: 0.6, y: 2.9, w: 8.6, h: 1.6 },
  );

  /* ----------------------------------------------------------- department */
  const s2 = slide("Where the capacity sits", "By department");
  const deptRows = departmentRollups(analyses).slice(0, 10);
  s2.addTable(
    [
      ["Department", "Roles", "Avg score", "Hrs/week", "FTE", `Annual (${cur})`].map((t) => ({
        text: t,
        options: { bold: true, color: WHITE, fill: { color: BLUE }, fontSize: 11, fontFace: BODY },
      })),
      ...deptRows.map((d) => [
        d.department,
        String(d.roles),
        `${d.averageScore}%`,
        String(d.hoursPerWeek),
        String(d.fteEquivalent),
        formatMoney(d.annualSaving, cur),
      ].map((t) => ({ text: t, options: { fontSize: 11, color: INK, fontFace: BODY } }))),
    ],
    { x: 0.6, y: 1.35, w: 8.7, colW: [3.0, 0.8, 1.1, 1.1, 0.8, 1.9], border: { pt: 0.5, color: "E2E8F0" } },
  );

  /* ---------------------------------------------------------- top by role */
  const s3 = slide("Roles with the largest upside", "Prioritisation");
  const roleRows = [...analyses]
    .map((a) => ({ a, t: computeTotals(a) }))
    .sort((x, y) => y.t.hoursPerWeek - x.t.hoursPerWeek)
    .slice(0, 10);
  s3.addTable(
    [
      ["Role", "Department", "Score", "Hrs/week", "Quick wins"].map((t) => ({
        text: t,
        options: { bold: true, color: WHITE, fill: { color: BLUE }, fontSize: 11, fontFace: BODY },
      })),
      ...roleRows.map(({ a, t }) => [
        a.roleTitle,
        a.department || "—",
        `${a.overallScore}%`,
        String(t.hoursPerWeek),
        String(t.quickWins),
      ].map((text) => ({ text, options: { fontSize: 11, color: INK, fontFace: BODY } }))),
    ],
    { x: 0.6, y: 1.35, w: 8.7, colW: [3.2, 2.2, 1.0, 1.1, 1.2], border: { pt: 0.5, color: "E2E8F0" } },
  );

  /* --------------------------------------------------------- quick wins */
  const s4 = slide("Top automation candidates", "Task level");
  s4.addText(
    allTaskRows(analyses)
      .filter((r) => r.band === "full" || r.band === "high")
      .slice(0, 12)
      .map((r) => ({
        text: `${r.task} — ${r.analysis.roleTitle} · ${r.approach} · ${r.hoursSavedPerWeek}h/week`,
        options: { bullet: true, fontSize: 11.5, color: INK, fontFace: BODY, breakLine: true },
      })),
    { x: 0.6, y: 1.35, w: 8.7, h: 3.6 },
  );

  /* ------------------------------------------------------------- phases */
  for (const phase of recommendPhases(analyses)) {
    const s = slide(`Phase ${phase.order} — ${phase.name}`, phase.window);
    s.addText(phase.focus, {
      x: 0.6, y: 1.25, w: 8.7, h: 0.5, fontFace: BODY, fontSize: 13, color: MUTED,
    });
    s.addText(
      `${phase.hoursPerWeek} hours/week · ${formatMoney(phase.annualSaving, cur)} indicative annual value · ${phase.items.length} tasks`,
      { x: 0.6, y: 1.75, w: 8.7, h: 0.3, fontFace: BODY, fontSize: 12, color: BLUE, bold: true },
    );
    s.addText(
      [
        ...phase.items.slice(0, 7).map((r) => ({
          text: `${r.task} (${r.analysis.roleTitle})`,
          options: { bullet: true, fontSize: 11, color: INK, fontFace: BODY, breakLine: true },
        })),
        ...phase.actions.map((a) => ({
          text: a,
          options: { bullet: true, fontSize: 11, color: MUTED, fontFace: BODY, italic: true, breakLine: true },
        })),
      ],
      { x: 0.6, y: 2.15, w: 8.7, h: 2.8 },
    );
  }

  /* ------------------------------------------------------- future state */
  const s6 = slide("Proposed future-state shape", "Structure");
  s6.addText(
    departmentRollups(analyses)
      .slice(0, 8)
      .flatMap((d) => [
        {
          text: `${d.department} — ${d.roles} roles, ${d.fteEquivalent} FTE of capacity released`,
          options: { bullet: false, bold: true, fontSize: 12, color: INK, fontFace: BODY, breakLine: true },
        },
        ...d.analyses.slice(0, 4).map((a) => ({
          text: futureRoleTitle(a),
          options: { bullet: true, fontSize: 10.5, color: MUTED, fontFace: BODY, breakLine: true },
        })),
      ]),
    { x: 0.6, y: 1.3, w: 8.7, h: 3.7 },
  );

  /* ----------------------------------------------------------- notices */
  const s7 = slide("Important notices & disclaimer", "Governance");
  s7.addText(
    EXPORT_NOTICES.map((n) => ({
      text: `${n.title}: ${n.body}`,
      options: { bullet: true, fontSize: 10.5, color: INK, fontFace: BODY, breakLine: true },
    })),
    { x: 0.6, y: 1.3, w: 8.7, h: 3.6 },
  );

  await pptx.writeFile({ fileName: "Strategy-Studio-Automation-Portfolio.pptx" });
}

/** CSV of every analysed role for offline review. */
export function portfolioCsv(analyses: RoleAutomationAnalysis[]) {
  const esc = (v: string | number) => `"${String(v).replace(/"/g, '""')}"`;
  const lines = [
    ["Role", "Department", "Score", "Tasks", "Hours/week", "Annual value", "Currency", "Source", "Flag", "Summary"]
      .map(esc)
      .join(","),
  ];
  for (const a of analyses) {
    const t = computeTotals(a);
    lines.push(
      [
        a.roleTitle,
        a.department,
        a.overallScore,
        a.tasks.length,
        t.hoursPerWeek,
        t.annualSaving,
        a.currency,
        a.source,
        a.flag,
        a.summary,
      ]
        .map(esc)
        .join(","),
    );
  }
  return lines.join("\n");
}
