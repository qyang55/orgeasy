/**
 * Guided demo: a lightweight, local-only walkthrough that takes a first-time
 * visitor through 2–3 pre-built scenarios (general baseline, general future
 * programme, automotive/regional pack). State lives in localStorage so the
 * demo bar survives navigation and reloads; nothing leaves the browser.
 */
import type { Employee, Scenario } from "./types";
import { CURRENT_STATE_ID } from "./seed";
import { AUTOMOTIVE_PACK, SIZE_TARGET, generatePackScenario } from "./industry-packs";

const KEY = "oss.guided-demo.v1";
const EVENT = "oss:guided-demo";

/** Name of the generated automotive scenario, reused for idempotency. */
export const AUTOMOTIVE_DEMO_NAME = "Demo – Automotive · ASEAN (Human + AI)";

export interface GuidedDemoStep {
  title: string;
  blurb: string;
  route: "/chart" | "/compare";
  /** Fixed scenario id, or "automotive" to generate/find the pack scenario. */
  scenarioId: string;
}

export const GUIDED_DEMO_STEPS: GuidedDemoStep[] = [
  {
    title: "Current state — Global 500",
    blurb:
      "A fixed 500-position baseline across 8 functions and 18 countries. Drag, re-parent and resize cards — spans, layers and cost recalculate live.",
    route: "/chart",
    scenarioId: CURRENT_STATE_ID,
  },
  {
    title: "Future option — 10% programme",
    blurb:
      "Three phased levers (demand discipline, span & duplicates, AI work redesign) compared against the baseline with quantified headcount, cost and risk deltas.",
    route: "/compare",
    scenarioId: "future-p3",
  },
  {
    title: "Automotive — ASEAN operating model",
    blurb:
      "Generated one click ago from the automotive industry pack: JV-aware regional structure, dealer and fleet functions, and human + AI agent delivery.",
    route: "/chart",
    scenarioId: "automotive",
  },
];

export interface GuidedDemoState {
  step: number;
}

export function readGuidedDemo(): GuidedDemoState | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as GuidedDemoState;
    if (typeof parsed.step !== "number") return null;
    return parsed;
  } catch {
    return null;
  }
}

function write(state: GuidedDemoState | null) {
  try {
    if (state) window.localStorage.setItem(KEY, JSON.stringify(state));
    else window.localStorage.removeItem(KEY);
  } catch {
    /* storage unavailable */
  }
  window.dispatchEvent(new Event(EVENT));
}

export function startGuidedDemo() {
  write({ step: 0 });
}

export function setGuidedDemoStep(step: number) {
  write({ step: Math.max(0, Math.min(GUIDED_DEMO_STEPS.length - 1, step)) });
}

export function exitGuidedDemo() {
  write(null);
}

/** Subscribe to guided-demo state changes (same tab + other tabs). */
export function subscribeGuidedDemo(cb: () => void): () => void {
  window.addEventListener(EVENT, cb);
  window.addEventListener("storage", cb);
  return () => {
    window.removeEventListener(EVENT, cb);
    window.removeEventListener("storage", cb);
  };
}

type CreateScenario = (
  name: string,
  employees: Employee[],
  meta?: Partial<
    Pick<Scenario, "baselineId" | "currency" | "description" | "kind" | "phaseLabel" | "phaseOrder">
  >,
) => string;

/**
 * Returns the id of the pre-built automotive demo scenario, generating it
 * from the industry pack on first use. Idempotent: safe to call repeatedly.
 */
export function ensureAutomotiveDemo(
  scenarios: Scenario[],
  create: CreateScenario,
): string {
  const existing = scenarios.find((s) => s.name === AUTOMOTIVE_DEMO_NAME);
  if (existing) return existing.id;
  const built = generatePackScenario(AUTOMOTIVE_PACK, {
    size: "midsize",
    region: "asean",
    variant: "hybrid",
    targetPositions: SIZE_TARGET.midsize,
  });
  return create(AUTOMOTIVE_DEMO_NAME, built.employees, {
    kind: "current",
    description: `${built.description} Pre-built guided-demo scenario — edit freely.`,
  });
}

/* ------------------------------------------------ conversion nudge state */

const NUDGE_DISMISS_KEY = "oss.nudge.dismissed.v1";
const NUDGE_SESSION_KEY = "oss.nudge.session.v1";
const NUDGE_READY_KEY = "oss.nudge.ready.v1";

export function isNudgeDismissed(): boolean {
  try {
    return window.localStorage.getItem(NUDGE_DISMISS_KEY) === "1";
  } catch {
    return false;
  }
}

export function dismissNudge() {
  try {
    window.localStorage.setItem(NUDGE_DISMISS_KEY, "1");
  } catch {
    /* ignore */
  }
}

export interface NudgeSession {
  start: number;
  routes: string[];
  later: boolean;
}

export function readNudgeSession(): NudgeSession {
  try {
    const raw = window.sessionStorage.getItem(NUDGE_SESSION_KEY);
    if (raw) return JSON.parse(raw) as NudgeSession;
  } catch {
    /* ignore */
  }
  return { start: Date.now(), routes: [], later: false };
}

export function writeNudgeSession(s: NudgeSession) {
  try {
    window.sessionStorage.setItem(NUDGE_SESSION_KEY, JSON.stringify(s));
  } catch {
    /* ignore */
  }
}

/** Arms the nudge to show immediately (called when the guided demo finishes). */
export function armNudge() {
  try {
    window.sessionStorage.setItem(NUDGE_READY_KEY, "1");
  } catch {
    /* ignore */
  }
}

export function consumeNudgeArmed(): boolean {
  try {
    const armed = window.sessionStorage.getItem(NUDGE_READY_KEY) === "1";
    if (armed) window.sessionStorage.removeItem(NUDGE_READY_KEY);
    return armed;
  } catch {
    return false;
  }
}

const DEMO_SCENARIO_IDS = new Set([
  CURRENT_STATE_ID,
  "future-p1",
  "future-p2",
  "future-p3",
  "future-capability",
]);

/**
 * True while every scenario in the workspace is studio-generated demo content
 * (fixed seed, guided-demo automotive, or a pack generation). Once the user
 * imports real data the nudge stops appearing.
 */
export function isDemoOnlyWorkspace(scenarios: Scenario[]): boolean {
  return scenarios.every(
    (s) =>
      DEMO_SCENARIO_IDS.has(s.id) ||
      s.name.startsWith("Demo –") ||
      s.name.startsWith("Automotive —"),
  );
}
