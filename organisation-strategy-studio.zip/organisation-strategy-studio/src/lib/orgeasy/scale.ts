import type { Employee, Scenario } from "./types";

/**
 * Scale guard rails. The studio models positions (a row can carry many
 * positions via headcount), so a 1M-employee organisation is usually a few
 * hundred thousand rows. These limits keep rendering and O(n^2) analytics
 * bounded while every aggregate stays computed on the full data set.
 */
export const SCALE_LIMITS = {
  /** Cards drawn on the interactive canvas at once. */
  canvasNodes: 1200,
  /** Rows rendered per page in the People & roles table. */
  tableRows: 200,
  /** Rows included in the pairwise duplicate-role similarity scan. */
  duplicateScan: 4000,
  /** Rows above which we treat the workspace as an enterprise-scale data set. */
  largeOrg: 5000,
  /** Serialised workspace size (bytes) we are willing to keep in the browser. */
  persistBytes: 4_000_000,
} as const;

export type ScaleTier = "standard" | "large" | "enterprise";

export function rowCount(scenario: Scenario | null | undefined) {
  return scenario?.employees.length ?? 0;
}

/** Total employees represented (positions, not rows). */
export function totalPositions(employees: Employee[]) {
  return employees.reduce(
    (a, e) => a + Math.max(e.plannedHeadcount || 0, e.currentHeadcount || 0, 0),
    0,
  );
}

export function scaleTier(rows: number): ScaleTier {
  if (rows >= 50_000) return "enterprise";
  if (rows >= SCALE_LIMITS.largeOrg) return "large";
  return "standard";
}

export function formatCount(value: number) {
  return new Intl.NumberFormat("en-US").format(Math.round(value || 0));
}

/**
 * Breadth-first slice of the hierarchy: keeps the top of the house and works
 * down, so very large organisations still render a meaningful chart. Roles whose
 * manager was dropped are re-rooted so no edges dangle.
 */
export function capHierarchy(
  employees: Employee[],
  cap = SCALE_LIMITS.canvasNodes,
): { employees: Employee[]; truncated: number } {
  if (employees.length <= cap) return { employees, truncated: 0 };

  const byId = new Map(employees.map((e) => [e.id, e]));
  const children = new Map<string, Employee[]>();
  const roots: Employee[] = [];
  for (const e of employees) {
    const parent = e.managerId && byId.has(e.managerId) ? e.managerId : null;
    if (parent) children.set(parent, [...(children.get(parent) ?? []), e]);
    else roots.push(e);
  }

  const kept: Employee[] = [];
  const queue = [...roots];
  const seen = new Set<string>();
  while (queue.length && kept.length < cap) {
    const node = queue.shift()!;
    if (seen.has(node.id)) continue;
    seen.add(node.id);
    kept.push(node);
    queue.push(...(children.get(node.id) ?? []));
  }

  const keptIds = new Set(kept.map((e) => e.id));
  return {
    employees: kept.map((e) => ({
      ...e,
      managerId: e.managerId && keptIds.has(e.managerId) ? e.managerId : null,
      dottedManagerIds: (e.dottedManagerIds ?? []).filter((id) => keptIds.has(id)),
    })),
    truncated: employees.length - kept.length,
  };
}
