import { createContext, useContext } from "react";

/**
 * Portal targets owned by the AppShell top bar. Pages (currently Baseline &
 * design) render their view-specific actions and metrics strip into these
 * nodes, so the shell owns the chrome layout while pages own their controls.
 */
export type StudioChrome = {
  actionsEl: HTMLElement | null;
  metricsEl: HTMLElement | null;
};

export const StudioChromeContext = createContext<StudioChrome>({
  actionsEl: null,
  metricsEl: null,
});

export function useStudioChrome(): StudioChrome {
  return useContext(StudioChromeContext);
}
