import type { Scenario } from "./types";
import { hasConsent } from "./consent";

/**
 * Per-scenario snapshots. Unlike workspace restore points (versions.ts), these
 * capture a single scenario — its roster, positions, card sizes, phase metadata
 * and ADKAR groups — so an import, a bulk edit or a reset can be rolled back
 * without touching the rest of the workspace.
 */
export interface ScenarioSnapshot {
  id: string;
  scenarioId: string;
  scenarioName: string;
  createdAt: string;
  label: string;
  /** Manual save, or one captured automatically before a destructive change. */
  reason: "manual" | "pre-import" | "pre-reset" | "pre-restore";
  roleCount: number;
  plannedPositions: number;
  annualCost: number;
  currency: string;
  bytes: number;
  scenario: Scenario;
}

const STORAGE_KEY = "orgeasy.scenario-snapshots.v1";

export const SNAPSHOT_LIMITS = {
  /** Per scenario, so a busy scenario can't crowd out the others. */
  maxPerScenario: 15,
  maxSnapshotBytes: 3_000_000,
};

export const SNAPSHOT_REASONS: Record<ScenarioSnapshot["reason"], string> = {
  manual: "Saved by you",
  "pre-import": "Before an import",
  "pre-reset": "Before a reset",
  "pre-restore": "Before a restore",
};

function store(): Storage | null {
  if (typeof window === "undefined") return null;
  return hasConsent("workspace") ? window.localStorage : window.sessionStorage;
}

function readAll(): ScenarioSnapshot[] {
  try {
    const raw = store()?.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as ScenarioSnapshot[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function persist(list: ScenarioSnapshot[]) {
  const target = store();
  if (!target) return;
  // Cap per scenario (newest first), then trim globally if storage complains.
  const perScenario = new Map<string, number>();
  let capped = list.filter((s) => {
    const n = (perScenario.get(s.scenarioId) ?? 0) + 1;
    perScenario.set(s.scenarioId, n);
    return n <= SNAPSHOT_LIMITS.maxPerScenario;
  });
  for (;;) {
    try {
      target.setItem(STORAGE_KEY, JSON.stringify(capped));
      return;
    } catch {
      if (capped.length <= 1) {
        try {
          target.removeItem(STORAGE_KEY);
        } catch {
          /* ignore */
        }
        return;
      }
      capped = capped.slice(0, capped.length - 1);
    }
  }
}

function summarise(scenario: Scenario) {
  const roles = scenario.employees ?? [];
  return {
    roleCount: roles.length,
    plannedPositions: roles.reduce((sum, e) => sum + (e.plannedHeadcount || 0), 0),
    annualCost: roles.reduce((sum, e) => sum + (e.plannedHeadcount || 0) * (e.plannedCost || 0), 0),
    currency: scenario.currency ?? "USD",
  };
}

/** Newest-first snapshots for one scenario. */
export function loadScenarioSnapshots(scenarioId: string): ScenarioSnapshot[] {
  return readAll()
    .filter((s) => s.scenarioId === scenarioId)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function loadAllScenarioSnapshots(): ScenarioSnapshot[] {
  return readAll().sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

/**
 * Writes a snapshot of one scenario. Returns null when skipped (too large, or
 * byte-identical to the newest snapshot of that scenario).
 */
export function saveScenarioSnapshot(
  scenario: Scenario,
  options: { reason?: ScenarioSnapshot["reason"]; label?: string } = {},
): ScenarioSnapshot | null {
  let payload: string;
  try {
    payload = JSON.stringify(scenario);
  } catch {
    return null;
  }
  if (payload.length > SNAPSHOT_LIMITS.maxSnapshotBytes) return null;

  const all = readAll();
  const newest = loadScenarioSnapshots(scenario.id)[0];
  if (newest && newest.bytes === payload.length && JSON.stringify(newest.scenario) === payload) {
    return null;
  }

  const summary = summarise(scenario);
  const snapshot: ScenarioSnapshot = {
    id: `sn-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
    scenarioId: scenario.id,
    scenarioName: scenario.name,
    createdAt: new Date().toISOString(),
    label: options.label?.trim() || `${scenario.name} · ${summary.roleCount} roles`,
    reason: options.reason ?? "manual",
    ...summary,
    bytes: payload.length,
    scenario: JSON.parse(payload) as Scenario,
  };
  persist([snapshot, ...all]);
  return snapshot;
}

export function findScenarioSnapshot(id: string): ScenarioSnapshot | null {
  return readAll().find((s) => s.id === id) ?? null;
}

export function renameScenarioSnapshot(id: string, label: string) {
  persist(readAll().map((s) => (s.id === id ? { ...s, label } : s)));
}

export function deleteScenarioSnapshot(id: string) {
  persist(readAll().filter((s) => s.id !== id));
}

export function clearScenarioSnapshots(scenarioId?: string) {
  if (!scenarioId) {
    try {
      store()?.removeItem(STORAGE_KEY);
    } catch {
      /* ignore */
    }
    return;
  }
  persist(readAll().filter((s) => s.scenarioId !== scenarioId));
}
