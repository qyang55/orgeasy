import type { Employee, Scenario } from "./types";

/**
 * Workforce data health.
 *
 * Before any span, cost or scenario analysis can be trusted, the underlying
 * position data has to hold together: every role needs a valid manager, a
 * market, a cost and a headcount. This module runs that readiness pass and,
 * where the repair is unambiguous, returns a fixed employee list.
 */

export type HealthSeverity = "critical" | "warning" | "info";

export const HEALTH_SEVERITY_META: Record<
  HealthSeverity,
  { label: string; hex: string; weight: number }
> = {
  critical: { label: "Blocks analysis", hex: "DC2626", weight: 3 },
  warning: { label: "Distorts numbers", hex: "D97706", weight: 1.6 },
  info: { label: "Worth a look", hex: "2563EB", weight: 0.5 },
};

export type HealthFixId =
  | "duplicate-ids"
  | "broken-manager"
  | "self-manager"
  | "cycle"
  | "missing-title"
  | "missing-department"
  | "missing-country"
  | "missing-cost"
  | "zero-headcount"
  | "negative-values";

export interface HealthIssue {
  id: HealthFixId | string;
  severity: HealthSeverity;
  title: string;
  detail: string;
  /** Roles affected. */
  roleIds: string[];
  /** Positions (FTE) behind those roles. */
  positions: number;
  /** Whether applyHealthFix can repair it deterministically. */
  fixable: boolean;
  fixLabel?: string | undefined;
  fixNote?: string | undefined;
}

export interface HealthReport {
  totalRoles: number;
  totalPositions: number;
  score: number;
  band: { label: string; tone: "positive" | "neutral" | "negative" };
  issues: HealthIssue[];
  criticalCount: number;
  warningCount: number;
  fixableCount: number;
  completeness: { label: string; filled: number; total: number }[];
  roots: number;
}

const positionsOf = (e: Employee) =>
  Math.max(e.plannedHeadcount || e.currentHeadcount || 0, 0);

function median(values: number[]) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid]! : (sorted[mid - 1]! + sorted[mid]!) / 2;
}

function modeOf(values: string[]) {
  const counts = new Map<string, number>();
  for (const v of values) if (v) counts.set(v, (counts.get(v) ?? 0) + 1);
  let best = "";
  let bestCount = 0;
  for (const [v, c] of counts) if (c > bestCount) [best, bestCount] = [v, c];
  return best;
}

/** Ids that appear more than once in the list. */
function duplicateIds(employees: Employee[]) {
  const seen = new Set<string>();
  const dupes = new Set<string>();
  for (const e of employees) {
    if (seen.has(e.id)) dupes.add(e.id);
    seen.add(e.id);
  }
  return dupes;
}

/** Roles that sit inside a reporting cycle (A → B → A). */
function cycleMembers(employees: Employee[]) {
  const byId = new Map(employees.map((e) => [e.id, e]));
  const state = new Map<string, 0 | 1 | 2>();
  const bad = new Set<string>();
  const visit = (id: string, path: string[]) => {
    const mark = state.get(id);
    if (mark === 2) return;
    if (mark === 1) {
      const from = path.indexOf(id);
      for (const p of path.slice(from >= 0 ? from : 0)) bad.add(p);
      return;
    }
    state.set(id, 1);
    const mid = byId.get(id)?.managerId;
    if (mid && byId.has(mid) && mid !== id) visit(mid, [...path, id]);
    state.set(id, 2);
  };
  for (const e of employees) visit(e.id, []);
  return bad;
}

export function analyseDataHealth(scenario: Scenario | null | undefined): HealthReport {
  const employees = scenario?.employees ?? [];
  const totalRoles = employees.length;
  const totalPositions = employees.reduce((s, e) => s + positionsOf(e), 0);
  const ids = new Set(employees.map((e) => e.id));
  const issues: HealthIssue[] = [];

  const push = (
    issue: Omit<HealthIssue, "positions"> & { positions?: number },
    matched: Employee[],
  ) => {
    if (!matched.length) return;
    issues.push({
      ...issue,
      roleIds: matched.map((e) => e.id),
      positions: matched.reduce((s, e) => s + positionsOf(e), 0),
    });
  };

  const dupes = duplicateIds(employees);
  push(
    {
      id: "duplicate-ids",
      severity: "critical",
      title: "Duplicate position IDs",
      detail:
        "Two or more rows share the same id. Reporting lines, diffs and exports will silently point at the wrong role.",
      roleIds: [],
      fixable: true,
      fixLabel: "Assign fresh IDs",
      fixNote: "Keeps the first occurrence and re-keys the rest, repointing their reports.",
    },
    employees.filter((e) => dupes.has(e.id)),
  );

  push(
    {
      id: "broken-manager",
      severity: "critical",
      title: "Manager ID does not exist",
      detail:
        "The role points at a manager that is not in this scenario, so the whole branch is orphaned from the hierarchy.",
      roleIds: [],
      fixable: true,
      fixLabel: "Detach to top level",
      fixNote: "Clears the invalid manager so the role becomes a visible root you can re-parent.",
    },
    employees.filter((e) => e.managerId && !ids.has(e.managerId)),
  );

  push(
    {
      id: "self-manager",
      severity: "critical",
      title: "Role reports to itself",
      detail: "Self-referencing manager IDs break layer and span calculations.",
      roleIds: [],
      fixable: true,
      fixLabel: "Clear manager",
    },
    employees.filter((e) => e.managerId && e.managerId === e.id),
  );

  const cycles = cycleMembers(employees);
  push(
    {
      id: "cycle",
      severity: "critical",
      title: "Circular reporting line",
      detail:
        "A chain of roles reports back into itself. Layer depth, span roll-ups and the org chart cannot resolve.",
      roleIds: [],
      fixable: true,
      fixLabel: "Break the loop",
      fixNote: "Detaches the highest-cost role in each loop to the top level.",
    },
    employees.filter((e) => cycles.has(e.id)),
  );

  push(
    {
      id: "missing-title",
      severity: "warning",
      title: "No job title",
      detail: "Titles drive duplicate-role detection, seniority banding and hiring lead times.",
      roleIds: [],
      fixable: true,
      fixLabel: "Set to “Untitled role”",
    },
    employees.filter((e) => !e.title?.trim()),
  );

  push(
    {
      id: "missing-department",
      severity: "warning",
      title: "No function / department",
      detail: "Cost heat maps, duplicate scanning and department deltas all bucket on function.",
      roleIds: [],
      fixable: true,
      fixLabel: "Set to “Unassigned”",
    },
    employees.filter((e) => !e.department?.trim()),
  );

  const modeCountry = modeOf(employees.map((e) => e.country));
  push(
    {
      id: "missing-country",
      severity: "critical",
      title: "No market / country",
      detail:
        "Country drives notice, severance, tribunal risk and consultation thresholds. Without it, separation cost is understated.",
      roleIds: [],
      fixable: !!modeCountry,
      fixLabel: modeCountry ? `Default to ${modeCountry}` : undefined,
      fixNote: modeCountry
        ? "Uses the most common market in the scenario — review before relying on the cost model."
        : undefined,
    },
    employees.filter((e) => !e.country?.trim()),
  );

  const costs = employees.map((e) => e.currentCost || e.plannedCost).filter((v) => v > 0);
  push(
    {
      id: "missing-cost",
      severity: "warning",
      title: "No annual cost per position",
      detail:
        "Roles with zero cost make savings, cost-per-layer and heat maps look better than reality.",
      roleIds: [],
      fixable: costs.length > 0,
      fixLabel: costs.length ? "Fill with function median" : undefined,
      fixNote: costs.length
        ? "Applies the median cost of the role's own function, falling back to the scenario median."
        : undefined,
    },
    employees.filter((e) => !(e.currentCost || e.plannedCost)),
  );

  push(
    {
      id: "zero-headcount",
      severity: "warning",
      title: "Zero positions on both sides",
      detail:
        "The row exists but carries no current or planned headcount, so it contributes nothing to the model.",
      roleIds: [],
      fixable: true,
      fixLabel: "Set planned to 1",
    },
    employees.filter((e) => !e.currentHeadcount && !e.plannedHeadcount),
  );

  push(
    {
      id: "negative-values",
      severity: "critical",
      title: "Negative headcount or cost",
      detail: "Negative inputs invert savings and corrupt every roll-up that touches the role.",
      roleIds: [],
      fixable: true,
      fixLabel: "Clamp to zero",
    },
    employees.filter(
      (e) =>
        e.currentHeadcount < 0 ||
        e.plannedHeadcount < 0 ||
        e.currentCost < 0 ||
        e.plannedCost < 0,
    ),
  );

  // Structural observations — flagged, never auto-fixed.
  const validParent = (e: Employee) => e.managerId && ids.has(e.managerId) && e.managerId !== e.id;
  const roots = employees.filter((e) => !validParent(e));
  if (roots.length > 1) {
    push(
      {
        id: "multiple-roots",
        severity: "warning",
        title: `${roots.length} roles sit at the top with no manager`,
        detail:
          "A single top-of-house makes layer depth comparable to benchmarks. Re-parent the extras on the chart designer.",
        roleIds: [],
        fixable: false,
      },
      roots,
    );
  }

  const spans = new Map<string, number>();
  for (const e of employees) if (validParent(e)) spans.set(e.managerId!, (spans.get(e.managerId!) ?? 0) + 1);
  push(
    {
      id: "span-outliers",
      severity: "info",
      title: "Span outliers (20+ direct reports)",
      detail:
        "Very wide spans are often a data artefact — a placeholder manager absorbing unmapped roles.",
      roleIds: [],
      fixable: false,
    },
    employees.filter((e) => (spans.get(e.id) ?? 0) >= 20),
  );

  const dupKeys = new Map<string, Employee[]>();
  for (const e of employees) {
    const key = `${(e.name || "").trim().toLowerCase()}|${(e.title || "").trim().toLowerCase()}|${e.country}`;
    if (!e.name?.trim()) continue;
    dupKeys.set(key, [...(dupKeys.get(key) ?? []), e]);
  }
  push(
    {
      id: "duplicate-people",
      severity: "info",
      title: "Same person and title appears more than once",
      detail: "Usually a double-counted extract row, which inflates baseline headcount and cost.",
      roleIds: [],
      fixable: false,
    },
    [...dupKeys.values()].filter((g) => g.length > 1).flat(),
  );

  push(
    {
      id: "missing-service",
      severity: "info",
      title: "No length of service recorded",
      detail: "Severance is service-based, so exits from these roles are costed at the minimum.",
      roleIds: [],
      fixable: false,
    },
    employees.filter((e) => !e.serviceMonths && e.status !== "planned"),
  );

  const order: HealthSeverity[] = ["critical", "warning", "info"];
  issues.sort(
    (a, b) =>
      order.indexOf(a.severity) - order.indexOf(b.severity) || b.roleIds.length - a.roleIds.length,
  );

  const penalty = issues.reduce((sum, i) => {
    const share = totalRoles ? i.roleIds.length / totalRoles : 0;
    return sum + share * HEALTH_SEVERITY_META[i.severity].weight * 100;
  }, 0);
  const score = totalRoles ? Math.max(0, Math.min(100, Math.round(100 - penalty))) : 0;

  const filled = (fn: (e: Employee) => boolean) => employees.filter(fn).length;
  const completeness = [
    { label: "Job title", filled: filled((e) => !!e.title?.trim()), total: totalRoles },
    { label: "Function", filled: filled((e) => !!e.department?.trim()), total: totalRoles },
    { label: "Market", filled: filled((e) => !!e.country?.trim()), total: totalRoles },
    { label: "Annual cost", filled: filled((e) => !!(e.currentCost || e.plannedCost)), total: totalRoles },
    {
      label: "Valid manager",
      filled: filled((e) => !e.managerId || (ids.has(e.managerId) && e.managerId !== e.id)),
      total: totalRoles,
    },
    { label: "Length of service", filled: filled((e) => e.serviceMonths > 0), total: totalRoles },
  ];

  return {
    totalRoles,
    totalPositions,
    score,
    band:
      score >= 85
        ? { label: "Analysis-ready", tone: "positive" }
        : score >= 65
          ? { label: "Usable with caveats", tone: "neutral" }
          : { label: "Clean before deciding", tone: "negative" },
    issues,
    criticalCount: issues.filter((i) => i.severity === "critical").length,
    warningCount: issues.filter((i) => i.severity === "warning").length,
    fixableCount: issues.filter((i) => i.fixable).length,
    completeness,
    roots: roots.length,
  };
}

function newId() {
  return Math.random().toString(36).slice(2, 10);
}

/** Applies one deterministic repair and returns the new employee list. */
export function applyHealthFix(employees: Employee[], issueId: string): Employee[] {
  const ids = new Set(employees.map((e) => e.id));
  const positionsCost = employees.map((e) => e.currentCost || e.plannedCost).filter((v) => v > 0);
  const globalMedian = median(positionsCost);

  switch (issueId) {
    case "duplicate-ids": {
      const seen = new Set<string>();
      const remap = new Map<string, string>();
      const next = employees.map((e) => {
        if (!seen.has(e.id)) {
          seen.add(e.id);
          return e;
        }
        let fresh = newId();
        while (ids.has(fresh)) fresh = newId();
        ids.add(fresh);
        remap.set(e.id, fresh);
        return { ...e, id: fresh };
      });
      // Reports of a re-keyed role keep pointing at the surviving original, which
      // is the safe reading of a duplicated extract row.
      return next.map((e) => (remap.has(e.managerId ?? "") ? { ...e } : e));
    }
    case "broken-manager":
      return employees.map((e) =>
        e.managerId && !ids.has(e.managerId) ? { ...e, managerId: null } : e,
      );
    case "self-manager":
      return employees.map((e) => (e.managerId === e.id ? { ...e, managerId: null } : e));
    case "cycle": {
      const loop = cycleMembers(employees);
      if (!loop.size) return employees;
      const inLoop = employees.filter((e) => loop.has(e.id));
      const anchor = inLoop.sort(
        (a, b) => (b.currentCost || b.plannedCost) - (a.currentCost || a.plannedCost),
      )[0];
      return employees.map((e) => (e.id === anchor?.id ? { ...e, managerId: null } : e));
    }
    case "missing-title":
      return employees.map((e) => (e.title?.trim() ? e : { ...e, title: "Untitled role" }));
    case "missing-department":
      return employees.map((e) => (e.department?.trim() ? e : { ...e, department: "Unassigned" }));
    case "missing-country": {
      const fallback = modeOf(employees.map((e) => e.country));
      if (!fallback) return employees;
      return employees.map((e) => (e.country?.trim() ? e : { ...e, country: fallback }));
    }
    case "missing-cost": {
      const byDept = new Map<string, number[]>();
      for (const e of employees) {
        const rate = e.currentCost || e.plannedCost;
        if (rate > 0) {
          const key = e.department || "Unassigned";
          byDept.set(key, [...(byDept.get(key) ?? []), rate]);
        }
      }
      return employees.map((e) => {
        if (e.currentCost || e.plannedCost) return e;
        const rate = Math.round(median(byDept.get(e.department || "Unassigned") ?? []) || globalMedian);
        if (!rate) return e;
        return { ...e, currentCost: rate, plannedCost: rate };
      });
    }
    case "zero-headcount":
      return employees.map((e) =>
        !e.currentHeadcount && !e.plannedHeadcount ? { ...e, plannedHeadcount: 1 } : e,
      );
    case "negative-values":
      return employees.map((e) => ({
        ...e,
        currentHeadcount: Math.max(e.currentHeadcount, 0),
        plannedHeadcount: Math.max(e.plannedHeadcount, 0),
        currentCost: Math.max(e.currentCost, 0),
        plannedCost: Math.max(e.plannedCost, 0),
      }));
    default:
      return employees;
  }
}

/** Runs every deterministic repair in one pass. */
export function applyAllHealthFixes(employees: Employee[], issues: HealthIssue[]): Employee[] {
  return issues
    .filter((i) => i.fixable)
    .reduce((list, i) => applyHealthFix(list, i.id), employees);
}
