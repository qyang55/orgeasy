import type { Employee, EmployeeStatus, EmploymentType } from "./types";
import { parseCsv } from "./csv";
import { uid } from "./store";

/**
 * Smart org-chart import: takes a CSV / Excel sheet with loosely named columns
 * and produces a connected Employee hierarchy. Manager links resolve by id,
 * email or name, so exports that only carry "Manager Name" still build a tree.
 */

export type ImportField =
  | "id"
  | "name"
  | "title"
  | "manager"
  | "managerId"
  | "department"
  | "country"
  | "photoUrl"
  | "email"
  | "headcount"
  | "status"
  | "costCenter"
  | "employmentType"
  | "cost"
  | "responsibilities";

const ALIASES: Record<ImportField, string[]> = {
  id: ["id", "employeeid", "employeenumber", "workerid", "personid", "positionid", "empid"],
  name: ["name", "fullname", "employeename", "workername", "preferredname", "displayname"],
  title: ["title", "jobtitle", "position", "positiontitle", "role", "jobrole", "businesstitle"],
  manager: [
    "manager",
    "managername",
    "reportsto",
    "reportstoname",
    "supervisor",
    "supervisorname",
    "linemanager",
    "parent",
  ],
  managerId: [
    "managerid",
    "manageremployeeid",
    "reportstoid",
    "supervisorid",
    "parentid",
    "manageremail",
    "supervisoremail",
  ],
  department: ["department", "dept", "function", "team", "orgunit", "organisationunit", "division"],
  country: ["country", "location", "site", "office", "region", "workcountry", "city"],
  photoUrl: ["photo", "photourl", "avatar", "image", "imageurl", "picture"],
  email: ["email", "emailaddress", "workemail", "mail"],
  headcount: ["headcount", "headcountunderthem", "teamsize", "directreports", "fte", "positions"],
  status: ["status", "employmentstatus", "workerstatus", "vacancystatus", "roletype"],
  costCenter: ["costcenter", "costcentre", "cc", "budgetcode", "gl"],
  employmentType: ["employmenttype", "workertype", "contracttype", "fulltimeparttime", "timetype"],
  cost: ["cost", "salary", "basesalary", "annualcost", "compensation", "totalcost", "pay"],
  responsibilities: ["responsibilities", "notes", "jobdescription", "jd", "accountabilities", "scope"],
};

const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, "");

/** Best-guess column index for every field, given the sheet header row. */
export function mapHeaders(headers: string[]): Partial<Record<ImportField, number>> {
  const cleaned = headers.map((h) => norm(String(h ?? "")));
  const out: Partial<Record<ImportField, number>> = {};
  for (const field of Object.keys(ALIASES) as ImportField[]) {
    const aliases = ALIASES[field];
    let idx = cleaned.findIndex((h) => aliases.includes(h));
    if (idx === -1)
      idx = cleaned.findIndex((h) => h.length > 2 && aliases.some((a) => h.includes(a)));
    if (idx >= 0) out[field] = idx;
  }
  return out;
}

function toNumber(value: unknown, fallback = 0) {
  const n = Number(String(value ?? "").replace(/[^0-9.-]/g, ""));
  return Number.isFinite(n) ? n : fallback;
}

function toStatus(raw: string): { status: EmployeeStatus; open: boolean; contractor: boolean } {
  const v = norm(raw);
  if (!v) return { status: "current", open: false, contractor: false };
  if (v.includes("vacant") || v.includes("open") || v.includes("unfilled"))
    return { status: "planned", open: true, contractor: false };
  if (v.includes("contractor") || v.includes("contingent") || v.includes("agency"))
    return { status: "current", open: false, contractor: true };
  if (v.includes("remove") || v.includes("terminat") || v.includes("exit") || v.includes("leaver"))
    return { status: "to-be-removed", open: false, contractor: false };
  if (v.includes("plan") || v.includes("new") || v.includes("future"))
    return { status: "planned", open: false, contractor: false };
  return { status: "current", open: false, contractor: false };
}

function toEmploymentType(raw: string, contractor: boolean): EmploymentType {
  const v = norm(raw);
  if (contractor || v.includes("contract") || v.includes("contingent")) return "Contract";
  if (v.includes("part")) return "Part-time";
  if (v.includes("temp") || v.includes("fixed")) return "Contract";
  return "Full-time";
}

export interface SheetImportResult {
  employees: Employee[];
  errors: string[];
  warnings: string[];
  detected: Partial<Record<ImportField, string>>;
  stats: { rows: number; roots: number; linked: number; unlinked: number; vacant: number };
}

/** Reads a CSV / TSV text body or a parsed sheet matrix into employees. */
export function rowsToEmployees(
  rows: string[][],
  overrides?: Partial<Record<ImportField, number | null>>,
): SheetImportResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  if (rows.length < 2)
    return {
      employees: [],
      errors: ["The file needs a header row and at least one data row."],
      warnings,
      detected: {},
      stats: { rows: 0, roots: 0, linked: 0, unlinked: 0, vacant: 0 },
    };

  const headers = (rows[0] ?? []).map((h) => String(h ?? "").trim());
  const map = mapHeaders(headers);
  if (overrides)
    for (const [field, idx] of Object.entries(overrides) as [ImportField, number | null][]) {
      if (idx === null || idx === undefined) delete map[field];
      else map[field] = idx;
    }
  const detected: Partial<Record<ImportField, string>> = {};
  for (const [field, idx] of Object.entries(map) as [ImportField, number][])
    detected[field] = headers[idx] ?? "";

  if (map.title === undefined && map.name === undefined)
    errors.push("Could not find a Title or Name column — map one above, or add one and re-import.");

  const cell = (row: string[], field: ImportField) => {
    const idx = map[field];
    return idx === undefined ? "" : String(row[idx] ?? "").trim();
  };

  const body = rows.slice(1).filter((r) => r.some((c) => String(c ?? "").trim() !== ""));

  // Pass 1: build roles and remember every key a manager column might use.
  const byKey = new Map<string, string>(); // lookup key -> employee id
  const drafts = body.map((row) => {
    const sourceId = cell(row, "id");
    const id = sourceId || uid();
    const name = cell(row, "name");
    const email = cell(row, "email");
    const title = cell(row, "title") || name || "Untitled role";
    const raw = toStatus(cell(row, "status"));
    const open = raw.open || !name;
    const headcount = Math.max(1, toNumber(cell(row, "headcount"), 1));
    const cost = toNumber(cell(row, "cost"));
    const employee: Employee = {
      id,
      name: open ? "" : name,
      isOpenRole: open,
      title,
      department: cell(row, "department"),
      country: cell(row, "country") || "United States",
      responsibilities: cell(row, "responsibilities"),
      currentHeadcount: raw.status === "planned" ? 0 : headcount,
      plannedHeadcount: raw.status === "to-be-removed" ? 0 : headcount,
      employmentType: toEmploymentType(cell(row, "employmentType"), raw.contractor),
      managerId: null,
      status: raw.status,
      currentCost: raw.status === "planned" ? 0 : cost,
      plannedCost: raw.status === "to-be-removed" ? 0 : cost,
      serviceMonths: 0,
      photoUrl: cell(row, "photoUrl") || undefined,
      email: email || undefined,
      costCenter: cell(row, "costCenter") || undefined,
    };
    for (const key of [sourceId, email, name].filter(Boolean))
      if (!byKey.has(norm(key))) byKey.set(norm(key), id);
    return { employee, managerRef: cell(row, "managerId") || cell(row, "manager") };
  });

  // Pass 2: resolve reporting lines and break any cycles.
  let linked = 0;
  const unresolved = new Set<string>();
  for (const d of drafts) {
    const ref = d.managerRef;
    if (!ref) continue;
    const targetId = byKey.get(norm(ref));
    if (!targetId || targetId === d.employee.id) {
      if (ref) unresolved.add(ref);
      continue;
    }
    d.employee.managerId = targetId;
    linked += 1;
  }

  const employees = drafts.map((d) => d.employee);
  const byId = new Map(employees.map((e) => [e.id, e]));
  for (const e of employees) {
    const seen = new Set<string>([e.id]);
    let cursor = e.managerId;
    while (cursor) {
      if (seen.has(cursor)) {
        e.managerId = null;
        warnings.push(`Circular reporting line removed for “${e.title}”.`);
        break;
      }
      seen.add(cursor);
      cursor = byId.get(cursor)?.managerId ?? null;
    }
  }

  const roots = employees.filter((e) => !e.managerId);
  if (unresolved.size)
    warnings.push(
      `${unresolved.size} manager reference${unresolved.size === 1 ? "" : "s"} did not match a row (${[
        ...unresolved,
      ]
        .slice(0, 3)
        .join(", ")}${unresolved.size > 3 ? "…" : ""}) — those roles sit at the top level.`,
    );
  if (roots.length > 1)
    warnings.push(`${roots.length} roles have no manager, so the chart shows ${roots.length} trees.`);

  return {
    employees,
    errors,
    warnings,
    detected,
    stats: {
      rows: employees.length,
      roots: roots.length,
      linked,
      unlinked: employees.length - linked,
      vacant: employees.filter((e) => e.isOpenRole).length,
    },
  };
}

export function csvTextToEmployees(text: string): SheetImportResult {
  return rowsToEmployees(parseCsv(text));
}

/** Reads .csv / .tsv / .xlsx / .xls into a raw row matrix (Excel parsed lazily). */
export async function fileToRows(file: File): Promise<string[][]> {
  const isExcel = /\.(xlsx|xlsm|xlsb|xls)$/i.test(file.name);
  if (!isExcel) return parseCsv(await file.text());
  const XLSX = await import("xlsx");
  const wb = XLSX.read(await file.arrayBuffer(), { type: "array" });
  const first = wb.SheetNames[0];
  if (!first) return [];
  const rows = XLSX.utils.sheet_to_json<string[]>(wb.Sheets[first]!, {
    header: 1,
    raw: false,
    defval: "",
  });
  return rows.map((r) => (Array.isArray(r) ? r.map((c) => String(c ?? "")) : []));
}

/** Reads .csv / .tsv / .xlsx / .xls into employees (Excel parsed lazily). */
export async function fileToEmployees(file: File): Promise<SheetImportResult> {
  const rows = await fileToRows(file);
  if (!rows.length && /\.(xlsx|xlsm|xlsb|xls)$/i.test(file.name))
    return {
      employees: [],
      errors: ["That workbook has no sheets."],
      warnings: [],
      detected: {},
      stats: { rows: 0, roots: 0, linked: 0, unlinked: 0, vacant: 0 },
    };
  return rowsToEmployees(rows);
}

/**
 * Refresh mode: keeps existing role ids (so canvas positions, sizes and
 * scenario edits survive) and folds in the incoming sheet by email, then by
 * name + title. New rows are added; rows missing from the sheet are kept.
 */
export function mergeImport(existing: Employee[], incoming: Employee[]) {
  const keyOf = (e: Employee) =>
    e.email ? `e:${norm(e.email)}` : `n:${norm(e.name)}|${norm(e.title)}`;
  const existingByKey = new Map(existing.map((e) => [keyOf(e), e]));
  const idRemap = new Map<string, string>();
  for (const inc of incoming) {
    const match = existingByKey.get(keyOf(inc));
    if (match) idRemap.set(inc.id, match.id);
  }
  const merged = incoming.map((inc) => {
    const id = idRemap.get(inc.id) ?? inc.id;
    const prior = existing.find((e) => e.id === id);
    return {
      ...(prior ?? {}),
      ...inc,
      id,
      managerId: inc.managerId ? (idRemap.get(inc.managerId) ?? inc.managerId) : null,
    } as Employee;
  });
  const mergedIds = new Set(merged.map((e) => e.id));
  const untouched = existing.filter((e) => !mergedIds.has(e.id));
  return {
    employees: [
      ...merged,
      ...untouched.map((e) => ({
        ...e,
        managerId: e.managerId && mergedIds.has(e.managerId) ? e.managerId : e.managerId,
      })),
    ],
    updated: idRemap.size,
    added: merged.length - idRemap.size,
    kept: untouched.length,
  };
}
