/**
 * Automation Opportunity Analyzer — model, scoring bands, heuristic fallback
 * analysis, savings maths and per-browser persistence.
 *
 * Positioning: a workforce *planning* aid. Language is framed around freeing
 * people from repetitive work, never about cutting jobs.
 */
import { hasConsent } from "./consent";
import type { Employee, Scenario } from "./types";

export type AutomatabilityBand = "full" | "high" | "partial" | "human";

export const BAND_META: Record<
  AutomatabilityBand,
  {
    label: string;
    short: string;
    savingFactor: number;
    badgeClass: string;
    barClass: string;
    ringHex: string;
    hex: string;
  }
> = {
  full: {
    label: "Fully automatable",
    short: "Full",
    savingFactor: 0.9,
    badgeClass: "bg-success/15 text-success border-success/30",
    barClass: "bg-success",
    ringHex: "#047857",
    hex: "047857",
  },
  high: {
    label: "Highly automatable",
    short: "High",
    savingFactor: 0.65,
    badgeClass: "bg-success/10 text-success border-success/25",
    barClass: "bg-success/70",
    ringHex: "#059669",
    hex: "059669",
  },
  partial: {
    label: "Partially automatable",
    short: "Partial",
    savingFactor: 0.35,
    badgeClass: "bg-warning/20 text-warning-foreground border-warning/40",
    barClass: "bg-warning",
    ringHex: "#D97706",
    hex: "D97706",
  },
  human: {
    label: "Human-led",
    short: "Human",
    savingFactor: 0.05,
    badgeClass: "bg-muted text-muted-foreground border-border",
    barClass: "bg-muted-foreground/50",
    ringHex: "#64748B",
    hex: "64748B",
  },
};

export const BANDS: AutomatabilityBand[] = ["full", "high", "partial", "human"];

export const APPROACHES = [
  "AI agent / LLM assistant",
  "RPA (robotic process automation)",
  "Simple script or integration",
  "Workflow / system configuration",
  "Self-service or template",
  "Process redesign (remove the work)",
  "Keep human — coach and upskill",
];

export interface TaskAssessment {
  id: string;
  task: string;
  band: AutomatabilityBand;
  score: number;
  reason: string;
  approach: string;
  hoursPerWeek: number;
  hoursSavedPerWeek: number;
  overridden?: boolean;
}

export type RoleFlag = "none" | "redesign" | "headcount-review" | "upskill";

export const FLAG_META: Record<RoleFlag, { label: string; className: string }> = {
  none: { label: "No flag", className: "bg-muted text-muted-foreground" },
  redesign: { label: "Flagged for role redesign", className: "bg-info/15 text-info" },
  "headcount-review": {
    label: "Flagged for headcount review",
    className: "bg-warning/20 text-warning-foreground",
  },
  upskill: { label: "Flagged for upskilling", className: "bg-success/15 text-success" },
};

export interface RoleAutomationAnalysis {
  id: string;
  scenarioId: string | null;
  employeeId: string | null;
  roleTitle: string;
  department: string;
  context: string;
  tools: string;
  hourlyCost: number;
  currency: string;
  createdAt: string;
  source: "ai" | "heuristic" | "manual";
  overallScore: number;
  summary: string;
  nextActions: string[];
  tasks: TaskAssessment[];
  flag: RoleFlag;
}

export interface AnalyzeInput {
  roleTitle: string;
  department: string;
  context: string;
  tools: string;
  jobDescription: string;
  tasks: { task: string; hoursPerWeek: number }[];
}

export function uid() {
  return Math.random().toString(36).slice(2, 10);
}

export function bandFromScore(score: number): AutomatabilityBand {
  if (score >= 85) return "full";
  if (score >= 65) return "high";
  if (score >= 35) return "partial";
  return "human";
}

/** Suggested weekly hours returned to the person for a task. */
export function suggestedSaving(band: AutomatabilityBand, hoursPerWeek: number) {
  return Math.round(hoursPerWeek * BAND_META[band].savingFactor * 10) / 10;
}

/** Splits free-text responsibilities or a pasted job description into tasks. */
export function splitTasks(text: string): string[] {
  return text
    .split(/\r?\n|•|\u00b7|\u2022/g)
    .flatMap((line) => (line.length > 220 ? line.split(/(?<=[.;])\s+(?=[A-Z])/g) : [line]))
    .map((line) =>
      line
        .replace(/^\s*(?:[-*\u2022\u00b7]|\d+[.)])\s*/, "")
        .replace(/\s+/g, " ")
        .trim(),
    )
    .filter((line) => line.length > 8)
    .slice(0, 24);
}

export function tasksFromEmployee(employee: Employee | null | undefined): string[] {
  if (!employee?.responsibilities) return [];
  return splitTasks(employee.responsibilities);
}

const RULES: {
  band: AutomatabilityBand;
  score: number;
  approach: string;
  words: RegExp;
  reason: string;
}[] = [
  {
    band: "human",
    score: 14,
    approach: "Keep human — coach and upskill",
    words:
      /\b(coach|mentor|lead(ership)?|manage the team|negotiat|stakeholder|relationship|conflict|disciplinar|strateg|culture|ethic|interview|performance conversation|counsel|advis|represent)\w*/i,
    reason: "Depends on trust, complex judgement and accountability that must stay with a person.",
  },
  {
    band: "full",
    score: 92,
    approach: "RPA (robotic process automation)",
    words:
      /\b(data entry|rekey|re-key|copy|paste|upload|download|extract|reconcil|invoic|expense|timesheet|payroll|filing|archiv|logging)\w*/i,
    reason: "High-volume, rule-based data handling with a stable input format.",
  },
  {
    band: "high",
    score: 78,
    approach: "AI agent / LLM assistant",
    words:
      /\b(report|dashboard|summar|draft|minutes|template|screen|schedul|calendar|triage|faq|translat|format)\w*/i,
    reason:
      "Repeatable drafting and summarising an AI assistant can produce for quick human review.",
  },
  {
    band: "high",
    score: 72,
    approach: "Simple script or integration",
    words: /\b(export|import|sync|integrat|api|quer|notif|remind|track)\w*/i,
    reason: "Deterministic movement of data between systems on a predictable trigger.",
  },
  {
    band: "partial",
    score: 52,
    approach: "Workflow / system configuration",
    words: /\b(analys|analyz|forecast|budget|plan|review|audit|assess|monitor|quality|complian|approv)\w*/i,
    reason: "Preparation and checks can be automated; the judgement call stays with a person.",
  },
  {
    band: "partial",
    score: 45,
    approach: "Self-service or template",
    words: /\b(onboard|training|documentation|process|policy|coordinat|administ|support)\w*/i,
    reason: "Much of the administration can be self-service, with people handling exceptions.",
  },
];

/**
 * Deterministic keyword analysis. Powers the instant preview and the fallback
 * when the AI service is unavailable, so the page always returns something useful.
 */
export function heuristicAnalyze(input: AnalyzeInput) {
  const rows = input.tasks.length
    ? input.tasks
    : splitTasks(input.jobDescription).map((task) => ({ task, hoursPerWeek: 0 }));

  const tasks: TaskAssessment[] = rows.map(({ task, hoursPerWeek }) => {
    const rule = RULES.find((r) => r.words.test(task));
    const band = rule?.band ?? "partial";
    const score = rule?.score ?? 40;
    return {
      id: uid(),
      task,
      band,
      score,
      reason: rule?.reason ?? "Mixed activity — parts follow clear rules, parts need human context.",
      approach: rule?.approach ?? "Process redesign (remove the work)",
      hoursPerWeek,
      hoursSavedPerWeek: suggestedSaving(band, hoursPerWeek),
    };
  });

  const overallScore = weightedScore(tasks);
  const top = tasks
    .filter((t) => t.band === "full" || t.band === "high")
    .sort((a, b) => b.score - a.score)
    .slice(0, 3);

  return {
    overallScore,
    summary: tasks.length
      ? `Around ${overallScore}% of this role's work looks automatable or AI-assisted. The strongest early wins are ${
          top.length ? top.map((t) => shorten(t.task)).join(", ") : "the routine administrative steps"
        } — freeing time for the judgement-heavy work only people can do.`
      : "Add a few tasks or paste the job description to see where this role's time can be given back.",
    nextActions: [
      "Validate the task list and weekly hours with the role holder and their manager.",
      top[0]
        ? `Pilot one automation on “${shorten(top[0].task)}” and measure hours returned over four weeks.`
        : "Run a one-week time diary to confirm where the hours actually go.",
      "Agree what the freed hours will be reinvested in before any automation goes live.",
    ],
    tasks,
  };
}

function shorten(text: string, max = 48) {
  return text.length <= max ? text : `${text.slice(0, max - 1).trimEnd()}…`;
}

/** Hours-weighted overall score, falling back to a plain average. */
export function weightedScore(tasks: TaskAssessment[]) {
  if (!tasks.length) return 0;
  const totalHours = tasks.reduce((sum, t) => sum + (t.hoursPerWeek || 0), 0);
  if (totalHours > 0) {
    const weighted = tasks.reduce((sum, t) => sum + t.score * (t.hoursPerWeek || 0), 0);
    return Math.round(weighted / totalHours);
  }
  return Math.round(tasks.reduce((sum, t) => sum + t.score, 0) / tasks.length);
}

export interface AutomationTotals {
  hoursPerWeek: number;
  hoursPerMonth: number;
  hoursPerYear: number;
  annualSaving: number;
  fteEquivalent: number;
  quickWins: number;
  humanTasks: number;
  trackedHours: number;
}

export function computeTotals(analysis: RoleAutomationAnalysis): AutomationTotals {
  const hoursPerWeek =
    Math.round(analysis.tasks.reduce((sum, t) => sum + (t.hoursSavedPerWeek || 0), 0) * 10) / 10;
  const hoursPerYear = Math.round(hoursPerWeek * 46);
  return {
    hoursPerWeek,
    hoursPerMonth: Math.round(hoursPerWeek * 4.33 * 10) / 10,
    hoursPerYear,
    annualSaving: Math.round(hoursPerYear * (analysis.hourlyCost || 0)),
    fteEquivalent: Math.round((hoursPerWeek / 38) * 100) / 100,
    quickWins: analysis.tasks.filter((t) => t.band === "full" || t.band === "high").length,
    humanTasks: analysis.tasks.filter((t) => t.band === "human").length,
    trackedHours:
      Math.round(analysis.tasks.reduce((s, t) => s + (t.hoursPerWeek || 0), 0) * 10) / 10,
  };
}

export function emptyAnalysis(partial: Partial<RoleAutomationAnalysis> = {}): RoleAutomationAnalysis {
  return {
    id: uid(),
    scenarioId: null,
    employeeId: null,
    roleTitle: "",
    department: "",
    context: "",
    tools: "",
    hourlyCost: 45,
    currency: "USD",
    createdAt: new Date().toISOString(),
    source: "heuristic",
    overallScore: 0,
    summary: "",
    nextActions: [],
    tasks: [],
    flag: "none",
    ...partial,
  };
}

/* ------------------------------------------------------------------ storage */

const KEY = "orgeasy.automation.v1";

export interface BacklogItem {
  id: string;
  analysisId: string;
  taskId: string;
  addedAt: string;
  done?: boolean;
}

interface AutomationState {
  analyses: RoleAutomationAnalysis[];
  backlog: BacklogItem[];
}

const EMPTY: AutomationState = { analyses: [], backlog: [] };

let state: AutomationState = EMPTY;
let loaded = false;
const listeners = new Set<() => void>();

function read(): AutomationState {
  if (typeof localStorage === "undefined") return EMPTY;
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) ?? "null");
    if (!raw || !Array.isArray(raw.analyses)) return EMPTY;
    return { analyses: raw.analyses, backlog: Array.isArray(raw.backlog) ? raw.backlog : [] };
  } catch {
    return EMPTY;
  }
}

function write(next: AutomationState) {
  state = next;
  if (typeof localStorage !== "undefined") {
    // Analyses describe identifiable roles: only persist with workspace consent.
    if (hasConsent("workspace")) {
      try {
        localStorage.setItem(KEY, JSON.stringify(next));
      } catch {
        /* storage full */
      }
    } else {
      localStorage.removeItem(KEY);
    }
  }
  listeners.forEach((fn) => fn());
}

export function getAutomationState(): AutomationState {
  if (!loaded) {
    state = read();
    loaded = true;
  }
  return state;
}

export function subscribeAutomation(fn: () => void) {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

export function saveAnalysis(analysis: RoleAutomationAnalysis) {
  const current = getAutomationState();
  const exists = current.analyses.some((a) => a.id === analysis.id);
  write({
    ...current,
    analyses: exists
      ? current.analyses.map((a) => (a.id === analysis.id ? analysis : a))
      : [analysis, ...current.analyses].slice(0, 60),
  });
}

export function deleteAnalysis(id: string) {
  const current = getAutomationState();
  write({
    analyses: current.analyses.filter((a) => a.id !== id),
    backlog: current.backlog.filter((b) => b.analysisId !== id),
  });
}

export function addToBacklog(analysisId: string, taskIds: string[]) {
  const current = getAutomationState();
  const fresh = taskIds
    .filter(
      (taskId) => !current.backlog.some((b) => b.analysisId === analysisId && b.taskId === taskId),
    )
    .map((taskId) => ({ id: uid(), analysisId, taskId, addedAt: new Date().toISOString() }));
  write({ ...current, backlog: [...current.backlog, ...fresh] });
  return fresh.length;
}

export function removeFromBacklog(id: string) {
  const current = getAutomationState();
  write({ ...current, backlog: current.backlog.filter((b) => b.id !== id) });
}

export function toggleBacklogDone(id: string) {
  const current = getAutomationState();
  write({
    ...current,
    backlog: current.backlog.map((b) => (b.id === id ? { ...b, done: !b.done } : b)),
  });
}

/** Latest analysis per employee for the given scenario, keyed by employee id. */
export function analysisByEmployee(scenarioId?: string | null) {
  const map = new Map<string, RoleAutomationAnalysis>();
  for (const a of getAutomationState().analyses) {
    if (!a.employeeId) continue;
    if (scenarioId && a.scenarioId && a.scenarioId !== scenarioId) continue;
    const existing = map.get(a.employeeId);
    if (!existing || existing.createdAt < a.createdAt) map.set(a.employeeId, a);
  }
  return map;
}

/** Roles with the largest automation upside, for restructuring simulations. */
export function topAutomationRoles(scenario: Scenario | null | undefined, limit = 6) {
  if (!scenario) return [];
  const map = analysisByEmployee(scenario.id);
  const rows: { employee: Employee; analysis: RoleAutomationAnalysis }[] = [];
  for (const employee of scenario.employees) {
    const analysis = map.get(employee.id);
    if (analysis) rows.push({ employee, analysis });
  }
  return rows.sort((a, b) => b.analysis.overallScore - a.analysis.overallScore).slice(0, limit);
}