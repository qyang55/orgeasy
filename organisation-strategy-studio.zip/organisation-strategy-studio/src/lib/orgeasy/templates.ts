import type { Scenario } from "./types";
import { computeImpact, formatMoney } from "./impact";

export interface CommsTemplate {
  id: string;
  title: string;
  audience: string;
  body: string;
}

export function buildTemplates(scenario: Scenario | null): CommsTemplate[] {
  const name = scenario?.name ?? "Proposed Change";
  const impact = computeImpact(scenario);
  const cur = scenario?.currency ?? "USD";
  const countries = impact.byCountry.filter((c) => c.removed > 0).map((c) => c.country);
  const savings = -impact.costDelta;
  const removedCount = impact.removedRoles.length;
  const newCount = impact.newRoles.length;
  const movedCount = impact.movedRoles.length;

  return [
    {
      id: "leadership",
      title: "Leadership Announcement",
      audience: "All employees, from the CEO or business unit leader",
      body: `Subject: An update on how we are organising for the next phase

Team,

Today we are sharing a proposed change to how our organisation is structured, referred to internally as "${name}".

Why we are doing this
Our operating model needs to match where our customers and our growth are heading. The proposal focuses effort on fewer, clearer priorities and moves work closer to the teams that own outcomes.

What is changing
- Planned headcount moves from ${impact.currentHeadcount.toLocaleString()} to ${impact.plannedHeadcount.toLocaleString()} positions.
- ${newCount} new role${newCount === 1 ? "" : "s"} will be created, ${removedCount} role${removedCount === 1 ? "" : "s"} are proposed for removal, and ${movedCount} role${movedCount === 1 ? "" : "s"} will report differently.
- The annualised people cost changes by ${formatMoney(impact.costDelta, cur)}${savings > 0 ? ` (a reduction of ${formatMoney(savings, cur)})` : ""}.

How we will handle this
Where roles are affected, we will follow the consultation process required in each country${countries.length ? ` (${countries.join(", ")})` : ""}. Colleagues who are personally impacted will hear from their manager directly, and never for the first time in a group setting.

What happens next
Managers receive briefing materials today. Team conversations begin this week, followed by individual conversations. We will publish a full FAQ and a timeline alongside this note.

Thank you for the care I know you will show each other through this.

[Leader name]
[Title]`,
    },
    {
      id: "manager",
      title: "Manager Talking Points",
      audience: "People managers, before team and individual conversations",
      body: `Manager talking points — ${name}

Before you speak to anyone
- Read the FAQ end to end. Do not improvise answers on severance, timing, or selection.
- Confirm which of your people are impacted and which are not.
- Book individual conversations before any team conversation.

Open the conversation
"I want to talk with you about a change to our structure. I would rather you hear this from me directly and have the chance to ask me anything."

Key messages
- The change is about the shape of the work, not a judgement about individuals.
- Planned positions move from ${impact.currentHeadcount.toLocaleString()} to ${impact.plannedHeadcount.toLocaleString()}.
- ${newCount} new role${newCount === 1 ? "" : "s"} are being created; internal candidates are encouraged to apply.
- Local consultation and notice requirements will be followed in every country involved.

If you are asked something you cannot answer
"That is a fair question and I do not want to guess. I will find out and come back to you by [date]."

Do not say
- Anything implying a decision is final before consultation concludes.
- Any figure for severance or notice — direct these to HR.
- Any comment about another person's situation.

After the conversation
- Log the date and key points discussed.
- Flag any wellbeing concerns to HR the same day.
- Follow up in writing within 24 hours with the agreed next step.`,
    },
    {
      id: "faq",
      title: "Employee FAQ",
      audience: "All employees",
      body: `Employee FAQ — ${name}

Why is this change happening now?
The current structure spreads effort too thinly. This proposal concentrates capability where it creates most value and simplifies decision making.

How many roles are affected?
${removedCount} role${removedCount === 1 ? " is" : "s are"} proposed for removal, ${newCount} new role${newCount === 1 ? " is" : "s are"} being created, and ${movedCount} role${movedCount === 1 ? "" : "s"} will change reporting line. Total planned positions: ${impact.plannedHeadcount.toLocaleString()}.

Which locations are involved?
${countries.length ? countries.join(", ") : "Impacted locations will be confirmed as consultation progresses."}

Is my role affected?
If your role is affected, your manager will speak with you individually. If you have not been contacted individually, your role is not in scope of this proposal.

How were roles selected?
Selection was based on the future structure requirements and objective, documented criteria applied consistently within each affected group.

Can I apply for one of the new roles?
Yes. New roles will be posted internally first and impacted colleagues will receive priority consideration.

What support is available?
Support includes access to the employee assistance programme, career transition support, and time during working hours for job search where notice applies.

What are the timings?
Consultation begins this week. Individual outcomes and any notice periods follow the requirements of each country. The published timeline has current dates.

Who do I ask if I have another question?
Your manager first, or [HR contact] for anything confidential.`,
    },
    {
      id: "personal",
      title: "Personal Impact Notification",
      audience: "Individual whose role is proposed for removal",
      body: `Private and confidential — for [Employee name]

Dear [Employee name],

Following the announcement about ${name}, I am writing to confirm what we discussed today: your role of [Job title] is proposed for removal as part of the new structure.

This is a proposal, not a final decision. Before anything is confirmed we will follow the consultation process that applies in [Country], and your input during that process is genuinely part of the outcome.

What happens next
1. Consultation meeting on [date] — you may be accompanied where local law or policy allows.
2. We will discuss redeployment options, including the [n] new roles being created.
3. If no suitable alternative is agreed, we will confirm next steps in writing, including notice and any payments you are entitled to under local law and company policy.

Support available to you
- A named HR contact: [name, contact].
- Career transition and CV support.
- Employee assistance programme: [details].

I know this is difficult news. I am available at [time/date] and any time you need before then.

With respect,
[Manager name]
[Title]

Note: any figures discussed are indicative until confirmed in writing following consultation and local legal review.`,
    },
    {
      id: "timeline",
      title: "Change Timeline",
      audience: "All employees and managers",
      body: `Change timeline — ${name}

Week 1 — Announce
- Leadership announcement published.
- Manager briefing and talking points issued.
- FAQ and timeline published.

Week 1-2 — Individual conversations
- Impacted colleagues notified individually.
- Named HR contact assigned to each impacted colleague.

Week 2-5 — Consultation
- Formal consultation per country requirements${countries.length ? ` (${countries.join(", ")})` : ""}.
- Redeployment and internal application window for ${newCount} new role${newCount === 1 ? "" : "s"}.

Week 5-6 — Confirm
- Outcomes confirmed in writing.
- Notice periods commence where applicable.

Week 6-10 — Transition
- Knowledge transfer and handover plans complete.
- New structure and reporting lines effective.

Week 10 onwards — Reinforce
- 30/60/90 day check-ins.
- Pulse survey on clarity, workload, and confidence.
- Adjust and communicate what changed as a result.`,
    },
    {
      id: "reinforcement",
      title: "Reinforcement Messages",
      audience: "All employees, post go-live",
      body: `Reinforcement pack — ${name}

Day 30 note from the leader
"Thirty days into the new structure, here is what is working and what we are still fixing. [Two specifics on each.] Thank you for the way you have handled a hard change."

Day 60 manager prompt
In your next one-to-one, ask three questions and record the answers:
1. What is clearer for you now than it was before?
2. What is still ambiguous about your remit or decision rights?
3. What should we stop doing that the old structure required?

Day 90 all-hands slide
- Planned positions delivered: ${impact.plannedHeadcount.toLocaleString()}.
- Annualised cost impact realised: ${formatMoney(impact.costDelta, cur)}.
- Two customer or delivery outcomes attributable to the new structure.
- What we are changing next based on your feedback.

Recognition prompts
- Name specific people who carried extra load during transition.
- Recognise managers who handled individual conversations well.
- Close the loop publicly on at least one thing the feedback changed.`,
    },
  ];
}