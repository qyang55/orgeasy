import type { Scenario } from "./types";
import { computeLayout, nodeSize } from "./layout";
import { STATUS_META } from "./types";
import { drawLegend, type LegendSection } from "./legend";

/**
 * Renders a scenario's org chart to a PNG data URL on an offscreen canvas.
 * Canvas keeps the PPTX export independent of what is mounted on screen.
 */
export async function renderScenarioPng(
  scenario: Scenario,
  options: { legend?: LegendSection[] } = {},
): Promise<string | null> {
  const { w, h } = nodeSize("vertical");
  const { positions, visible } = computeLayout(scenario.employees, "vertical", new Set());
  if (!positions.length) return null;

  const byId = new Map(positions.map((p) => [p.id, p]));
  const pad = 60;
  const minX = Math.min(...positions.map((p) => p.x));
  const maxX = Math.max(...positions.map((p) => p.x));
  const minY = Math.min(...positions.map((p) => p.y));
  const maxY = Math.max(...positions.map((p) => p.y));

  const width = maxX - minX + w + pad * 2;
  const chartHeight = maxY - minY + h + pad * 2;

  // Measure the legend band first so the canvas can reserve space for it.
  const legend = options.legend ?? [];
  const legendWidth = Math.min(width - pad, Math.max(520, width * 0.6));
  let legendHeight = 0;
  if (legend.length) {
    const probe = document.createElement("canvas").getContext("2d");
    if (probe) {
      legendHeight =
        drawLegend(probe, legend, { x: 0, y: 0, maxWidth: legendWidth }) + 24;
    }
  }

  const height = chartHeight + legendHeight;
  const scale = Math.min(2, 2400 / width);

  const canvas = document.createElement("canvas");
  canvas.width = Math.round(width * scale);
  canvas.height = Math.round(height * scale);
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;
  ctx.scale(scale, scale);
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, width, height);

  if (legendHeight) {
    drawLegend(ctx, legend, {
      x: pad / 2,
      y: 12,
      maxWidth: legendWidth,
      surface: "#F8FAFC",
      border: "#CBD5E1",
    });
    ctx.translate(0, legendHeight);
  }

  const px = (x: number) => x - minX + pad;
  const py = (y: number) => y - minY + pad;

  // Connectors
  ctx.strokeStyle = "#94a3b8";
  ctx.lineWidth = 1.5;
  for (const e of scenario.employees) {
    if (!e.managerId || !visible.has(e.id) || !visible.has(e.managerId)) continue;
    const child = byId.get(e.id);
    const parent = byId.get(e.managerId);
    if (!child || !parent) continue;
    const sx = px(parent.x) + w / 2;
    const sy = py(parent.y) + h;
    const tx = px(child.x) + w / 2;
    const ty = py(child.y);
    const mid = (sy + ty) / 2;
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.lineTo(sx, mid);
    ctx.lineTo(tx, mid);
    ctx.lineTo(tx, ty);
    ctx.stroke();
  }

  const roundRect = (x: number, y: number, rw: number, rh: number, r: number) => {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + rw, y, x + rw, y + rh, r);
    ctx.arcTo(x + rw, y + rh, x, y + rh, r);
    ctx.arcTo(x, y + rh, x, y, r);
    ctx.arcTo(x, y, x + rw, y, r);
    ctx.closePath();
  };

  for (const e of scenario.employees) {
    const pos = byId.get(e.id);
    if (!pos || !visible.has(e.id)) continue;
    const x = px(pos.x);
    const y = py(pos.y);

    ctx.fillStyle = "#ffffff";
    roundRect(x, y, w, h, 8);
    ctx.fill();
    ctx.strokeStyle = "#cbd5e1";
    ctx.lineWidth = 1;
    ctx.stroke();

    ctx.fillStyle = `#${STATUS_META[e.status].hex}`;
    roundRect(x, y, 5, h, 3);
    ctx.fill();

    ctx.fillStyle = "#0f172a";
    ctx.font = "600 14px Helvetica, Arial, sans-serif";
    ctx.fillText(truncate(ctx, e.name || "Open Role", w - 28), x + 16, y + 28);

    ctx.fillStyle = "#64748b";
    ctx.font = "12px Helvetica, Arial, sans-serif";
    ctx.fillText(truncate(ctx, e.title, w - 28), x + 16, y + 48);
    ctx.fillText(
      truncate(ctx, `${e.country} · ${e.currentHeadcount} → ${e.plannedHeadcount}`, w - 28),
      x + 16,
      y + 70,
    );
  }

  return canvas.toDataURL("image/png");
}

function truncate(ctx: CanvasRenderingContext2D, text: string, maxWidth: number) {
  if (ctx.measureText(text).width <= maxWidth) return text;
  let out = text;
  while (out.length > 3 && ctx.measureText(`${out}…`).width > maxWidth) out = out.slice(0, -1);
  return `${out}…`;
}