/**
 * First-run state for the getting-started panel. Deliberately independent of
 * workspace consent: this is a UI preference, not personal data, and it falls
 * back to sessionStorage when localStorage is unavailable.
 */
const KEY = "orgeasy.gettingstarted.v1";

function read(store: Storage | undefined) {
  try {
    return store?.getItem(KEY) === "1";
  } catch {
    return false;
  }
}

/** True when the getting-started panel has never been dismissed. */
export function isFirstRun(): boolean {
  if (typeof window === "undefined") return false;
  return !(read(window.localStorage) || read(window.sessionStorage));
}

export function dismissFirstRun() {
  try {
    window.localStorage.setItem(KEY, "1");
  } catch {
    try {
      window.sessionStorage.setItem(KEY, "1");
    } catch {
      /* storage unavailable */
    }
  }
}

export function restoreFirstRun() {
  try {
    window.localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
  try {
    window.sessionStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}

/** Event the getting-started panel fires so the sidebar can replay its tour. */
export const TOUR_REPLAY_EVENT = "orgeasy:replay-tour";

export function requestTourReplay() {
  window.dispatchEvent(new Event(TOUR_REPLAY_EVENT));
}
