import type { AdkarGroup, Employee, Scenario } from "./types";

export type ScenarioTemplateId = "blank" | "restructure" | "hiring-plan" | "cost-reduction";

export interface ScenarioTemplate {
  id: ScenarioTemplateId;
  label: string;
  tagline: string;
  /** Bullets shown in the picker so users know what gets prefilled. */
  prefills: string[];
  /** Suggested scenario name; {n} is replaced with the next phase number. */
  namePattern: string;
  phaseLabelPattern: string;
  description: string;
  /** Preferred starting point when the user has not chosen one explicitly. */
  startFrom: "none" | "current" | "latest";
  adkarGroups: { name: string; scores: [number, number, number, number, number]; notes: string }[];
}

export const SCENARIO_TEMPLATES: ScenarioTemplate[] = [
  {
    id: "blank",
    label: "Blank",
    tagline: "Start from scratch and build the structure yourself.",
    prefills: ["No roles or ADKAR groups", "You choose the starting point"],
    namePattern: "Future State — Phase {n}",
    phaseLabelPattern: "Phase {n}",
    description: "New phase of the target organisation.",
    startFrom: "none",
    adkarGroups: [],
  },
  {
    id: "restructure",
    label: "Restructure",
    tagline: "Reshape reporting lines, merge teams and retire duplicate roles.",
    prefills: [
      "Copies the current state as the baseline",
      "ADKAR groups for leaders, impacted teams and HR/works council",
      "Roles ready to mark as moved or to be removed",
    ],
    namePattern: "Restructure — Phase {n}",
    phaseLabelPattern: "Phase {n} — Restructure",
    description:
      "Reorganise reporting lines and consolidate duplicated roles. Mark affected roles as Moved or To Be Removed, then review the Impact and Legal pages before communicating.",
    startFrom: "current",
    adkarGroups: [
      {
        name: "Leadership team",
        scores: [4, 4, 3, 3, 2],
        notes: "Align leaders on the rationale and the story they tell their teams.",
      },
      {
        name: "Directly impacted teams",
        scores: [2, 2, 2, 2, 1],
        notes: "Roles changing manager, scope or status. Needs 1:1 conversations.",
      },
      {
        name: "HR & works council",
        scores: [3, 3, 3, 2, 2],
        notes: "Consultation, notice periods and country-specific obligations.",
      },
    ],
  },
  {
    id: "hiring-plan",
    label: "Hiring Plan",
    tagline: "Add planned open roles and phase in new capability.",
    prefills: [
      "Copies the current state as the baseline",
      "Three open-role placeholders ready to edit",
      "ADKAR groups for hiring managers and recruiting",
    ],
    namePattern: "Hiring Plan — Phase {n}",
    phaseLabelPattern: "Phase {n} — Hiring",
    description:
      "Grow the organisation with planned open roles. Placeholder roles are added as Open Role / Planned so headcount and budget deltas show up immediately in Impact.",
    startFrom: "current",
    adkarGroups: [
      {
        name: "Hiring managers",
        scores: [4, 4, 3, 3, 3],
        notes: "Own role scoping, interview loops and onboarding readiness.",
      },
      {
        name: "Talent acquisition",
        scores: [4, 3, 3, 3, 2],
        notes: "Sequencing of requisitions against budget approval.",
      },
    ],
  },
  {
    id: "cost-reduction",
    label: "Cost Reduction",
    tagline: "Model a savings target across the existing structure.",
    prefills: [
      "Copies the current state as the baseline",
      "Planned costs pre-set to a 10% reduction target",
      "ADKAR groups for finance, leaders and impacted teams",
    ],
    namePattern: "Cost Reduction — Phase {n}",
    phaseLabelPattern: "Phase {n} — Cost",
    description:
      "Model a cost-out target. Planned costs start at a 10% reduction so you can adjust role by role and read the saving on the Impact page.",
    startFrom: "current",
    adkarGroups: [
      {
        name: "Finance & budget owners",
        scores: [5, 4, 4, 3, 3],
        notes: "Validate savings assumptions, severance provisions and phasing.",
      },
      {
        name: "People leaders",
        scores: [3, 3, 2, 2, 2],
        notes: "Trade-offs between scope, service levels and cost.",
      },
      {
        name: "Impacted teams",
        scores: [2, 1, 2, 2, 1],
        notes: "Highest risk group — sequence communications carefully.",
      },
    ],
  },
];

export const COST_REDUCTION_TARGET = 0.1;

export function getScenarioTemplate(id: ScenarioTemplateId): ScenarioTemplate {
  return SCENARIO_TEMPLATES.find((t) => t.id === id) ?? SCENARIO_TEMPLATES[0]!;
}

export function fillPattern(pattern: string, phaseNumber: number): string {
  return pattern.replace("{n}", String(phaseNumber));
}

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

function adkarGroupsFor(template: ScenarioTemplate): AdkarGroup[] {
  return template.adkarGroups.map((g) => ({
    id: uid(),
    name: g.name,
    scores: {
      awareness: g.scores[0],
      desire: g.scores[1],
      knowledge: g.scores[2],
      ability: g.scores[3],
      reinforcement: g.scores[4],
    },
    notes: g.notes,
  }));
}

function openRolePlaceholders(source: Employee[]): Employee[] {
  const anchor = source.find((e) => !e.managerId) ?? source[0];
  const department = anchor?.department ?? "";
  const country = anchor?.country ?? "";
  return ["New Hire — Role 1", "New Hire — Role 2", "New Hire — Role 3"].map((title) => ({
    id: uid(),
    name: "",
    isOpenRole: true,
    title,
    department,
    country,
    responsibilities: "",
    currentHeadcount: 0,
    plannedHeadcount: 1,
    employmentType: "Open Role",
    managerId: anchor?.id ?? null,
    status: "planned",
    currentCost: 0,
    plannedCost: 0,
    serviceMonths: 0,
  }));
}

/**
 * Prefilled scenario content for a template, applied on top of whatever the
 * scenario was cloned from.
 */
export function templatePatch(
  template: ScenarioTemplate,
  base: Pick<Scenario, "employees" | "adkarGroups">,
): Partial<Scenario> {
  const patch: Partial<Scenario> = {};
  const groups = adkarGroupsFor(template);
  if (groups.length) patch.adkarGroups = [...base.adkarGroups, ...groups];

  if (template.id === "hiring-plan") {
    patch.employees = [...base.employees, ...openRolePlaceholders(base.employees)];
  }
  if (template.id === "cost-reduction") {
    patch.employees = base.employees.map((e) => ({
      ...e,
      plannedHeadcount: e.plannedHeadcount || e.currentHeadcount,
      plannedCost: Math.round((e.currentCost || e.plannedCost) * (1 - COST_REDUCTION_TARGET)),
    }));
  }
  return patch;
}
