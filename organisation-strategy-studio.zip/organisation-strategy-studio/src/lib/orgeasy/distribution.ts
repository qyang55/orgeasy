import type { Employee, Scenario } from "./types";
import { LEVER_META, type ReductionLever } from "./types";
import { analyseSpans } from "./span";
import { compareScenarios, effHeadcount } from "./diff";

/**
 * Workforce distributions.
 *
 * Tables tell you what the org is; distributions tell you what shape it is.
 * This module produces the span histogram, layer pyramid, cost-per-layer curve
 * and a current → future flow model (Sankey) of where every position goes.
 */

export interface Bucket {
  label: string;
  count: number;
  positions: number;
  cost: number;
  tone: "good" | "watch" | "bad" | "neutral";
}

export interface PyramidRow {
  layer: number;
  positions: number;
  managers: number;
  cost: number;
  costPerPosition: number;
  avgSpan: number;
  share: number;
}

export interface DistributionModel {
  spanBuckets: Bucket[];
  costBuckets: Bucket[];
  pyramid: PyramidRow[];
  managerShare: number;
  medianSpan: number;
  topHeavyIndex: number;
  totalPositions: number;
  totalCost: number;
  byDepartment: { key: string; positions: number; cost: number; managers: number }[];
}

const positionsOf = (e: Employee) => Math.max(e.plannedHeadcount || e.currentHeadcount || 0, 0);

const SPAN_BUCKETS: { label: string; min: number; max: number; tone: Bucket["tone"] }[] = [
  { label: "0 (individual contributor)", min: 0, max: 0, tone: "neutral" },
  { label: "1–2 reports", min: 1, max: 2, tone: "bad" },
  { label: "3–4 reports", min: 3, max: 4, tone: "watch" },
  { label: "5–9 reports", min: 5, max: 9, tone: "good" },
  { label: "10–14 reports", min: 10, max: 14, tone: "watch" },
  { label: "15+ reports", min: 15, max: Infinity, tone: "bad" },
];

export function buildDistribution(scenario: Scenario | null | undefined): DistributionModel {
  const analysis = analyseSpans(scenario);
  const employees = (scenario?.employees ?? []).filter((e) => e.status !== "to-be-removed");
  const totalPositions = employees.reduce((s, e) => s + positionsOf(e), 0);
  const totalCost = analysis.rows.reduce((s, r) => s + r.cost, 0);

  const spanBuckets: Bucket[] = SPAN_BUCKETS.map((b) => {
    const rows = analysis.rows.filter((r) => r.directReports >= b.min && r.directReports <= b.max);
    return {
      label: b.label,
      tone: b.tone,
      count: rows.length,
      positions: rows.length,
      cost: rows.reduce((s, r) => s + r.cost, 0),
    };
  });

  const rates = analysis.rows.map((r) => (r.cost > 0 ? r.cost : 0)).filter((v) => v > 0);
  const lo = rates.length ? Math.min(...rates) : 0;
  const hi = rates.length ? Math.max(...rates) : 0;
  const step = hi > lo ? (hi - lo) / 5 : 0;
  const costBuckets: Bucket[] = step
    ? Array.from({ length: 5 }, (_, i) => {
        const from = lo + step * i;
        const to = i === 4 ? hi : from + step;
        const rows = analysis.rows.filter((r) => r.cost >= from && (i === 4 ? true : r.cost < to));
        return {
          label: `${Math.round(from / 1000)}k – ${Math.round(to / 1000)}k`,
          count: rows.length,
          positions: rows.length,
          cost: rows.reduce((s, r) => s + r.cost, 0),
          tone: i >= 3 ? "watch" : "neutral",
        } satisfies Bucket;
      })
    : [];

  const pyramid: PyramidRow[] = analysis.layers.map((l) => ({
    layer: l.layer,
    positions: l.positions,
    managers: l.managers,
    cost: l.cost,
    costPerPosition: l.positions ? l.cost / l.positions : 0,
    avgSpan: l.avgSpan,
    share: totalPositions ? l.positions / totalPositions : 0,
  }));

  const spanValues = analysis.rows.filter((r) => r.directReports > 0).map((r) => r.directReports).sort((a, b) => a - b);
  const medianSpan = spanValues.length
    ? spanValues[Math.floor(spanValues.length / 2)]!
    : 0;

  // Top-heavy index: share of total cost sitting in the top three layers.
  const topCost = pyramid.filter((p) => p.layer <= 3).reduce((s, p) => s + p.cost, 0);

  const deptMap = new Map<string, { positions: number; cost: number; managers: number }>();
  for (const r of analysis.rows) {
    const cur = deptMap.get(r.department) ?? { positions: 0, cost: 0, managers: 0 };
    cur.positions += 1;
    cur.cost += r.cost;
    if (r.directReports > 0) cur.managers += 1;
    deptMap.set(r.department, cur);
  }

  return {
    spanBuckets,
    costBuckets,
    pyramid,
    managerShare: analysis.rows.length ? analysis.managerCount / analysis.rows.length : 0,
    medianSpan,
    topHeavyIndex: totalCost ? topCost / totalCost : 0,
    totalPositions,
    totalCost,
    byDepartment: [...deptMap.entries()]
      .map(([key, v]) => ({ key, ...v }))
      .sort((a, b) => b.positions - a.positions),
  };
}

/* --------------------------------------------------------------- flow model */

export interface FlowNode {
  id: string;
  label: string;
  value: number;
  side: "left" | "right";
  hex: string;
}

export interface FlowLink {
  source: string;
  target: string;
  value: number;
}

export interface FlowModel {
  nodes: FlowNode[];
  links: FlowLink[];
  total: number;
  retained: number;
  reassigned: number;
  reduced: number;
  created: number;
  baseName: string;
  targetName: string;
}

const OUTCOME_HEX = {
  retained: "16A34A",
  reassigned: "EA580C",
  created: "2563EB",
} as const;

const MOVE_FIELDS = new Set(["managerId", "department", "country"]);
const TOP_SOURCES = 7;

/**
 * Where every baseline position ends up: retained, reassigned, or removed by a
 * named transformation lever — plus the new demand the future state creates.
 */
export function buildFlowModel(
  baseline: Scenario | null | undefined,
  target: Scenario | null | undefined,
): FlowModel {
  const empty: FlowModel = {
    nodes: [],
    links: [],
    total: 0,
    retained: 0,
    reassigned: 0,
    reduced: 0,
    created: 0,
    baseName: baseline?.name ?? "Baseline",
    targetName: target?.name ?? "Future state",
  };
  if (!baseline || !target || baseline.id === target.id) return empty;

  const diff = compareScenarios(baseline, target);
  const changedByBefore = new Map(diff.changed.map((c) => [c.before.id, c]));
  const removedIds = new Set(diff.removed.map((e) => e.id));

  const linkMap = new Map<string, number>();
  const sourceTotals = new Map<string, number>();
  const targetTotals = new Map<string, number>();
  const addLink = (source: string, target_: string, value: number) => {
    if (value <= 0) return;
    linkMap.set(`${source}→${target_}`, (linkMap.get(`${source}→${target_}`) ?? 0) + value);
    sourceTotals.set(source, (sourceTotals.get(source) ?? 0) + value);
    targetTotals.set(target_, (targetTotals.get(target_) ?? 0) + value);
  };

  // Group small functions together so the diagram stays legible.
  const deptPositions = new Map<string, number>();
  for (const e of baseline.employees) {
    const key = e.department || "Unassigned";
    deptPositions.set(key, (deptPositions.get(key) ?? 0) + effHeadcount(e, "base"));
  }
  const keep = new Set(
    [...deptPositions.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, TOP_SOURCES)
      .map(([k]) => k),
  );
  const sourceOf = (e: Employee) => {
    const key = e.department || "Unassigned";
    return `src:${keep.has(key) ? key : "Other functions"}`;
  };

  let retained = 0;
  let reassigned = 0;
  let reduced = 0;

  for (const before of baseline.employees) {
    const basePositions = effHeadcount(before, "base");
    if (basePositions <= 0) continue;
    const source = sourceOf(before);
    const change = changedByBefore.get(before.id);
    const after = change?.after;
    const lever: ReductionLever =
      (after?.reductionLever ?? before.reductionLever ?? "headcount") as ReductionLever;

    if (removedIds.has(before.id) || (after && effHeadcount(after, "target") <= 0)) {
      addLink(source, `out:${lever}`, basePositions);
      reduced += basePositions;
      continue;
    }
    const afterPositions = after ? effHeadcount(after, "target") : basePositions;
    const cut = Math.max(basePositions - afterPositions, 0);
    if (cut) {
      addLink(source, `out:${lever}`, cut);
      reduced += cut;
    }
    const survived = basePositions - cut;
    const moved = change?.changes.some((c) => MOVE_FIELDS.has(c.field)) ?? false;
    if (moved) {
      addLink(source, "out:reassigned", survived);
      reassigned += survived;
    } else {
      addLink(source, "out:retained", survived);
      retained += survived;
    }
  }

  // New demand created by the future state.
  let created = 0;
  for (const e of diff.added) {
    const positions = effHeadcount(e, "target");
    if (positions <= 0) continue;
    created += positions;
    addLink("src:New capability", "out:created", positions);
  }
  for (const c of diff.changed) {
    const growth = effHeadcount(c.after, "target") - effHeadcount(c.before, "base");
    if (growth > 0) {
      created += growth;
      addLink("src:New capability", "out:created", growth);
    }
  }

  const nodes: FlowNode[] = [];
  for (const [id, value] of sourceTotals) {
    nodes.push({
      id,
      label: id.replace("src:", ""),
      value,
      side: "left",
      hex: id.includes("New capability") ? OUTCOME_HEX.created : "64748B",
    });
  }
  const outcomeLabel = (id: string) => {
    const key = id.replace("out:", "");
    if (key === "retained") return "Retained in place";
    if (key === "reassigned") return "Reassigned / moved";
    if (key === "created") return "New & open roles";
    return `Removed — ${LEVER_META[key as ReductionLever]?.label ?? key}`;
  };
  const outcomeHex = (id: string) => {
    const key = id.replace("out:", "");
    if (key === "retained") return OUTCOME_HEX.retained;
    if (key === "reassigned") return OUTCOME_HEX.reassigned;
    if (key === "created") return OUTCOME_HEX.created;
    return LEVER_META[key as ReductionLever]?.hex ?? "DC2626";
  };
  for (const [id, value] of targetTotals) {
    nodes.push({ id, label: outcomeLabel(id), value, side: "right", hex: outcomeHex(id) });
  }

  const links: FlowLink[] = [...linkMap.entries()].map(([key, value]) => {
    const [source, target_] = key.split("→");
    return { source: source!, target: target_!, value };
  });

  return {
    nodes: nodes.sort((a, b) => b.value - a.value),
    links: links.sort((a, b) => b.value - a.value),
    total: retained + reassigned + reduced + created,
    retained,
    reassigned,
    reduced,
    created,
    baseName: baseline.name,
    targetName: target.name,
  };
}
