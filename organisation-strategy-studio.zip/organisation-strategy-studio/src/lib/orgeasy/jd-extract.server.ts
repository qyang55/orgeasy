/**
 * Server-side extraction of job-description text from an uploaded document.
 * PDFs are read by the AI model (no native binaries in the Worker runtime);
 * Word/Excel files are OOXML zips, unzipped in pure JS and stripped to text.
 */
import { unzipSync, strFromU8 } from "fflate";
import { generateText } from "ai";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";

export type ExtractKind = "pdf" | "docx" | "xlsx" | "text";

export function detectKind(filename: string, mimeType: string): ExtractKind | null {
  const name = filename.toLowerCase();
  if (mimeType.includes("pdf") || name.endsWith(".pdf")) return "pdf";
  if (name.endsWith(".docx") || mimeType.includes("wordprocessingml")) return "docx";
  if (name.endsWith(".xlsx") || mimeType.includes("spreadsheetml")) return "xlsx";
  if (name.endsWith(".txt") || name.endsWith(".md") || name.endsWith(".csv")) return "text";
  return null;
}

function stripTags(xml: string) {
  return xml
    .replace(/<w:p[ >]/g, "\n<w:p ")
    .replace(/<w:br\s*\/?>/g, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function docxText(bytes: Uint8Array) {
  const files = unzipSync(bytes);
  const doc = files["word/document.xml"];
  if (!doc) throw new Error("This Word file has no readable document body.");
  return stripTags(strFromU8(doc));
}

function xlsxText(bytes: Uint8Array) {
  const files = unzipSync(bytes);
  const shared = files["xl/sharedStrings.xml"]
    ? Array.from(strFromU8(files["xl/sharedStrings.xml"]).matchAll(/<si>([\s\S]*?)<\/si>/g)).map(
        (m) => stripTags(m[1] ?? ""),
      )
    : [];
  const lines: string[] = [];
  for (const path of Object.keys(files).filter((p) => /^xl\/worksheets\/sheet\d+\.xml$/.test(p))) {
    const xml = strFromU8(files[path]!);
    for (const row of xml.matchAll(/<row[^>]*>([\s\S]*?)<\/row>/g)) {
      const cells: string[] = [];
      for (const cell of (row[1] ?? "").matchAll(/<c[^>]*?(t="[^"]*")?[^>]*>([\s\S]*?)<\/c>/g)) {
        const isShared = (cell[1] ?? "").includes('"s"');
        const raw = stripTags(cell[2] ?? "");
        const value = isShared ? (shared[Number(raw)] ?? "") : raw;
        if (value) cells.push(value);
      }
      if (cells.length) lines.push(cells.join(" — "));
    }
  }
  return lines.join("\n").trim();
}

async function pdfText(base64: string, mimeType: string, apiKey: string, runId?: string) {
  const gateway = createLovableAiGatewayProvider(apiKey, runId);
  const { text } = await generateText({
    model: gateway("google/gemini-3.6-flash"),
    messages: [
      {
        role: "user",
        content: [
          {
            type: "text",
            text: "Extract the full text of this job description document as plain text. Keep every responsibility, duty and bullet on its own line, in the original wording. Do not summarise, comment or add headings that are not in the document.",
          },
          { type: "file", data: base64, mediaType: mimeType || "application/pdf" },
        ],
      },
    ],
  });
  return text.trim();
}

/** Best-effort job title / department guess from the extracted text. */
export function guessMeta(text: string) {
  const lines = text
    .split(/\r?\n/)
    .map((l) => l.replace(/\s+/g, " ").trim())
    .filter(Boolean);
  const field = (labels: string[]) => {
    for (const line of lines.slice(0, 40)) {
      const match = line.match(
        new RegExp(`^(?:${labels.join("|")})\\s*[:\\-–]\\s*(.{2,80})$`, "i"),
      );
      if (match) return match[1]!.trim();
    }
    return "";
  };
  const roleTitle =
    field(["job title", "position title", "position", "role", "job"]) ||
    (lines[0] && lines[0].length <= 70 ? lines[0] : "");
  const department = field(["department", "function", "business unit", "team", "division"]);
  return { roleTitle, department };
}

export async function extractJobDescription(args: {
  filename: string;
  mimeType: string;
  dataBase64: string;
  runId?: string | undefined;
}) {
  const kind = detectKind(args.filename, args.mimeType);
  if (!kind) throw new Error("Unsupported file type — upload a PDF, Word (.docx), Excel (.xlsx) or text file.");

  let text = "";
  if (kind === "pdf") {
    const key = process.env["LOVABLE_API_KEY"];
    if (!key) throw new Error("AI is not configured for this workspace, so PDFs cannot be read.");
    text = await pdfText(args.dataBase64, args.mimeType, key, args.runId);
  } else {
    const bytes = Uint8Array.from(atob(args.dataBase64), (c) => c.charCodeAt(0));
    if (kind === "docx") text = docxText(bytes);
    else if (kind === "xlsx") text = xlsxText(bytes);
    else text = strFromU8(bytes).trim();
  }

  if (text.length < 40) throw new Error("Could not find readable text in that file.");
  return { kind, text: text.slice(0, 24000), ...guessMeta(text) };
}
