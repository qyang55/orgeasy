/**
 * "Delete my data" engine.
 *
 * Organisation Strategy Studio is local-first: there is no Studio-operated account or server copy of
 * your records. This module enumerates every storage location the app can write
 * to, deletes the selected scopes, then re-reads each key to prove it is gone and
 * returns a receipt you can keep as evidence.
 */
import { ERASURE_LOG_KEY } from "./erasure-log";

export type DeletionScopeId =
  | "workspace"
  | "savedViews"
  | "preferences"
  | "pins"
  | "consent"
  | "auditLog";

export interface DeletionScope {
  id: DeletionScopeId;
  label: string;
  description: string;
  keys: string[];
  defaultSelected: boolean;
}

export const DELETION_SCOPES: DeletionScope[] = [
  {
    id: "workspace",
    label: "Workspace & employee records",
    description:
      "Every scenario and phase, all role records, names, employee IDs, costs, photos and ADKAR scores.",
    keys: ["orgeasy.workspace.v1"],
    defaultSelected: true,
  },
  {
    id: "savedViews",
    label: "Saved People & Roles views",
    description: "Named filter presets for departments, countries and role status.",
    keys: ["orgeasy.people.presets.v1"],
    defaultSelected: true,
  },
  {
    id: "preferences",
    label: "Chart preferences",
    description: "Colour theme, colour-by choice and legend configuration.",
    keys: ["orgeasy.chart.theme", "orgeasy.chart.colorBy", "orgeasy.chart.legend"],
    defaultSelected: true,
  },
  {
    id: "pins",
    label: "Pinned comparison notes",
    description: "Drill-down deltas you pinned for export speaker notes.",
    keys: ["orgeasy.drilldown.pins.v1"],
    defaultSelected: true,
  },
  {
    id: "consent",
    label: "Cookie & storage consent choice",
    description:
      "Removing this makes the consent banner appear again on your next visit, as if this were a new device.",
    keys: ["orgeasy.consent.v1"],
    defaultSelected: false,
  },
  {
    id: "auditLog",
    label: "Erasure audit log",
    description:
      "Timestamped record of previous erasures (counts only, no personal data). Most organisations keep this as evidence.",
    keys: [ERASURE_LOG_KEY],
    defaultSelected: false,
  },
];

export interface DeletionKeyResult {
  key: string;
  existedBefore: boolean;
  bytesBefore: number;
  removed: boolean;
  verifiedGone: boolean;
}

export interface DeletionReceipt {
  id: string;
  at: string;
  scopes: DeletionScopeId[];
  keys: DeletionKeyResult[];
  keysRetained: string[];
  sessionKeysCleared: string[];
  removed: {
    scenarios: number;
    roles: number;
    namedPeople: number;
    photos: number;
    adkarGroups: number;
    savedViews: number;
  };
  serverCopies: string;
  allVerified: boolean;
}

const ALL_KEYS = DELETION_SCOPES.flatMap((s) => s.keys);

function byteSize(value: string | null) {
  return value ? new TextEncoder().encode(value).length : 0;
}

/** Snapshot of every Organisation Strategy Studio key, for the optional pre-deletion backup. */
export function buildBackup(): string {
  const data: Record<string, unknown> = {};
  for (const key of ALL_KEYS) {
    const raw = typeof localStorage === "undefined" ? null : localStorage.getItem(key);
    if (raw === null) continue;
    try {
      data[key] = JSON.parse(raw);
    } catch {
      data[key] = raw;
    }
  }
  return JSON.stringify(
    { app: "Organisation Strategy Studio", exportedAt: new Date().toISOString(), localStorage: data },
    null,
    2,
  );
}

export function listPresentKeys(): string[] {
  if (typeof localStorage === "undefined") return [];
  return ALL_KEYS.filter((k) => localStorage.getItem(k) !== null);
}

export function runDeletion(
  selected: DeletionScopeId[],
  counts: DeletionReceipt["removed"],
): DeletionReceipt {
  const scopes = DELETION_SCOPES.filter((s) => selected.includes(s.id));
  const targetKeys = scopes.flatMap((s) => s.keys);
  const keys: DeletionKeyResult[] = [];

  for (const key of targetKeys) {
    const before = typeof localStorage === "undefined" ? null : localStorage.getItem(key);
    let removed = false;
    try {
      localStorage.removeItem(key);
      removed = true;
    } catch {
      removed = false;
    }
    const after = typeof localStorage === "undefined" ? null : localStorage.getItem(key);
    keys.push({
      key,
      existedBefore: before !== null,
      bytesBefore: byteSize(before),
      removed,
      verifiedGone: after === null,
    });
  }

  const sessionKeysCleared: string[] = [];
  try {
    if (sessionStorage.getItem("orgeasy:chunk-reloaded") !== null) {
      sessionStorage.removeItem("orgeasy:chunk-reloaded");
      sessionKeysCleared.push("orgeasy:chunk-reloaded");
    }
  } catch {
    /* ignore */
  }

  return {
    id: `del_${Date.now().toString(36)}`,
    at: new Date().toISOString(),
    scopes: selected,
    keys,
    keysRetained: ALL_KEYS.filter((k) => !targetKeys.includes(k)),
    sessionKeysCleared,
    removed: counts,
    serverCopies:
      "None. Organisation Strategy Studio stores employee records only in this browser, so there is no Organisation Strategy Studio account, profile or server-side database row to delete. Only anonymous, record-free AI prompts you chose to send in the OD Copilot ever leave the device, and they are not stored against an account.",
    allVerified: keys.every((k) => k.verifiedGone),
  };
}

export function receiptToText(receipt: DeletionReceipt): string {
  const scopeLabel = (id: DeletionScopeId) =>
    DELETION_SCOPES.find((s) => s.id === id)?.label ?? id;
  return [
    "Organisation Strategy Studio — data deletion confirmation receipt",
    `Receipt ID: ${receipt.id}`,
    `Completed at: ${new Date(receipt.at).toISOString()} (local: ${new Date(receipt.at).toLocaleString()})`,
    `Outcome: ${receipt.allVerified ? "COMPLETED — every selected key verified absent" : "PARTIAL — see key list below"}`,
    "",
    "Scopes deleted:",
    ...receipt.scopes.map((s) => `  - ${scopeLabel(s)}`),
    "",
    "Records removed (counts only, no personal data):",
    `  Scenarios: ${receipt.removed.scenarios}`,
    `  Role records: ${receipt.removed.roles}`,
    `  Named individuals: ${receipt.removed.namedPeople}`,
    `  Photos: ${receipt.removed.photos}`,
    `  ADKAR groups: ${receipt.removed.adkarGroups}`,
    `  Saved views: ${receipt.removed.savedViews}`,
    "",
    "Storage keys:",
    ...receipt.keys.map(
      (k) =>
        `  ${k.key} — ${k.existedBefore ? `${k.bytesBefore} bytes present` : "not present"} → ${
          k.verifiedGone ? "verified removed" : "STILL PRESENT"
        }`,
    ),
    ...(receipt.sessionKeysCleared.length
      ? ["", `Session storage cleared: ${receipt.sessionKeysCleared.join(", ")}`]
      : []),
    ...(receipt.keysRetained.length
      ? ["", `Retained by your choice: ${receipt.keysRetained.join(", ")}`]
      : []),
    "",
    "Account / server-side data:",
    `  ${receipt.serverCopies}`,
    "",
    "Outside Organisation Strategy Studio's control: exported PPTX, PDF, PNG and CSV files already saved to your device,",
    "email or shared drives must be deleted separately, as must any copy held in your HRIS.",
    "",
    "This receipt is a record of an action taken in this browser. It is not legal advice.",
  ].join("\n");
}
