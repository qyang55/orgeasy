import type { Employee, Scenario } from "./types";
import { compareScenarios, effHeadcount } from "./diff";
import { SENIORITY_META, seniorityFor, type SeniorityBand } from "./hiring";

/**
 * Redeployment matching.
 *
 * A reduction programme creates two piles at the same time: people whose
 * positions disappear, and new positions nobody is in yet. Matching the two
 * before going to market cuts exit cost, protects knowledge and shortens the
 * hiring pipeline. This module scores every displaced-to-vacancy pairing on
 * function, market, seniority and role content, then allocates greedily.
 */

const BANDS: SeniorityBand[] = [
  "executive",
  "leadership",
  "manager",
  "professional",
  "operational",
];

export interface RedeployAssumptions {
  /** Annual voluntary attrition, %. Natural leavers reduce the exits you must manage. */
  attritionPct: number;
  /** Months of the programme over which attrition can be relied on. */
  windowMonths: number;
  /** Allow matches across markets (relocation or remote delivery). */
  crossBorder: boolean;
  /** Allow a one-band step up or down with reskilling. */
  allowReskill: boolean;
  /** Minimum match score accepted as a redeployment. */
  minScore: number;
}

export const DEFAULT_REDEPLOY_ASSUMPTIONS: RedeployAssumptions = {
  attritionPct: 9,
  windowMonths: 12,
  crossBorder: false,
  allowReskill: true,
  minScore: 45,
};

export type MatchBand = "strong" | "reskill" | "stretch";

export const MATCH_BAND_META: Record<
  MatchBand,
  { label: string; hex: string; note: string }
> = {
  strong: {
    label: "Direct match",
    hex: "16A34A",
    note: "Same function, market and level — move without a formal selection process.",
  },
  reskill: {
    label: "Match with reskilling",
    hex: "D97706",
    note: "Adjacent level or function. Budget training time before the role goes live.",
  },
  stretch: {
    label: "Stretch match",
    hex: "2563EB",
    note: "Plausible on paper only. Confirm with the hiring manager before promising a move.",
  },
};

const STOP = new Set([
  "the","and","of","for","to","a","an","with","in","on","at","by","or","as","senior","junior",
  "lead","head","manager","director","specialist","officer","associate","assistant","global",
  "regional","local","group","team","chief","vp","svp","evp",
]);

function tokens(text: string) {
  return new Set(
    (text || "")
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, " ")
      .split(/\s+/)
      .filter((t) => t.length > 2 && !STOP.has(t)),
  );
}

function overlap(a: Set<string>, b: Set<string>) {
  if (!a.size || !b.size) return 0;
  let inter = 0;
  for (const t of a) if (b.has(t)) inter += 1;
  return inter / Math.min(a.size, b.size);
}

interface Pool {
  role: Employee;
  positions: number;
  band: SeniorityBand;
  words: Set<string>;
}

export interface RedeployMatch {
  id: string;
  vacancyId: string;
  vacancyTitle: string;
  vacancyDepartment: string;
  vacancyCountry: string;
  vacancyBand: SeniorityBand;
  sourceId: string;
  sourceTitle: string;
  sourceDepartment: string;
  sourceCountry: string;
  sourceBand: SeniorityBand;
  positions: number;
  score: number;
  band: MatchBand;
  reasons: string[];
}

export interface RedeployGap {
  key: string;
  vacancies: number;
  matched: number;
  external: number;
}

export interface RedeployAnalysis {
  displacedPositions: number;
  vacancyPositions: number;
  attritionAbsorbed: number;
  redeployedPositions: number;
  externalHires: number;
  managedExits: number;
  coveragePct: number;
  matches: RedeployMatch[];
  gapsByDepartment: RedeployGap[];
  unmatchedVacancies: { id: string; title: string; department: string; country: string; positions: number }[];
  unmatchedDisplaced: { id: string; title: string; department: string; country: string; positions: number }[];
}

function scorePair(
  vacancy: Pool,
  candidate: Pool,
  assumptions: RedeployAssumptions,
): { score: number; reasons: string[] } | null {
  const reasons: string[] = [];
  let score = 0;

  const sameDept =
    (vacancy.role.department || "").trim().toLowerCase() ===
    (candidate.role.department || "").trim().toLowerCase();
  if (sameDept) {
    score += 34;
    reasons.push("Same function");
  }

  const sameCountry = vacancy.role.country === candidate.role.country;
  if (sameCountry) {
    score += 24;
    reasons.push("Same market");
  } else {
    if (!assumptions.crossBorder) return null;
    score += 4;
    reasons.push("Cross-border move required");
  }

  const gap = Math.abs(BANDS.indexOf(vacancy.band) - BANDS.indexOf(candidate.band));
  if (gap === 0) {
    score += 24;
    reasons.push(`Same level (${SENIORITY_META[vacancy.band].label})`);
  } else if (gap === 1) {
    if (!assumptions.allowReskill) return null;
    score += 11;
    reasons.push(
      BANDS.indexOf(vacancy.band) < BANDS.indexOf(candidate.band)
        ? "One level up — development move"
        : "One level down — retention move",
    );
  } else {
    return null;
  }

  const content = overlap(vacancy.words, candidate.words);
  if (content > 0) {
    score += Math.round(content * 18);
    if (content >= 0.4) reasons.push("Overlapping responsibilities");
  }

  // Agent-designed roles need supervision skills, not the displaced task work.
  if ((vacancy.role.roleType ?? "human") === "agent" && (candidate.role.roleType ?? "human") === "human") {
    score -= 8;
    reasons.push("Agent-run role — supervision reskilling needed");
  }

  return { score: Math.max(0, Math.min(100, score)), reasons };
}

export function analyseRedeployment(
  baseline: Scenario | null | undefined,
  target: Scenario | null | undefined,
  assumptions: RedeployAssumptions = DEFAULT_REDEPLOY_ASSUMPTIONS,
): RedeployAnalysis {
  const empty: RedeployAnalysis = {
    displacedPositions: 0,
    vacancyPositions: 0,
    attritionAbsorbed: 0,
    redeployedPositions: 0,
    externalHires: 0,
    managedExits: 0,
    coveragePct: 0,
    matches: [],
    gapsByDepartment: [],
    unmatchedVacancies: [],
    unmatchedDisplaced: [],
  };
  if (!baseline || !target || baseline.id === target.id) return empty;

  const diff = compareScenarios(baseline, target);
  const reportCount = new Map<string, number>();
  for (const e of [...baseline.employees, ...target.employees]) {
    if (e.managerId) reportCount.set(e.managerId, (reportCount.get(e.managerId) ?? 0) + 1);
  }
  const toPool = (role: Employee, positions: number): Pool => ({
    role,
    positions,
    band: seniorityFor(role, reportCount.get(role.id) ?? 0),
    words: tokens(`${role.title} ${role.responsibilities}`),
  });

  const displaced: Pool[] = [];
  for (const e of diff.removed) {
    const positions = effHeadcount(e, "base");
    if (positions > 0) displaced.push(toPool(e, positions));
  }
  for (const c of diff.changed) {
    const cut = effHeadcount(c.before, "base") - effHeadcount(c.after, "target");
    if (cut > 0) displaced.push(toPool(c.before, cut));
  }

  const vacancies: Pool[] = [];
  for (const e of diff.added) {
    const positions = effHeadcount(e, "target");
    if (positions > 0) vacancies.push(toPool(e, positions));
  }
  for (const c of diff.changed) {
    const growth = effHeadcount(c.after, "target") - effHeadcount(c.before, "base");
    if (growth > 0) vacancies.push(toPool(c.after, growth));
  }

  const displacedPositions = displaced.reduce((s, d) => s + d.positions, 0);
  const vacancyPositions = vacancies.reduce((s, v) => s + v.positions, 0);

  // Natural attrition over the programme window reduces the exits you must manage.
  const baselinePositions = baseline.employees.reduce((s, e) => s + effHeadcount(e, "base"), 0);
  const attritionAbsorbed = Math.min(
    displacedPositions,
    Math.round(
      baselinePositions * (assumptions.attritionPct / 100) * (assumptions.windowMonths / 12),
    ),
  );

  // Greedy allocation: score every viable pair, take the best first.
  const remainingSource = new Map(displaced.map((d, i) => [`${d.role.id}#${i}`, d.positions]));
  const remainingVacancy = new Map(vacancies.map((v, i) => [`${v.role.id}#${i}`, v.positions]));
  const sourceByKey = new Map(displaced.map((d, i) => [`${d.role.id}#${i}`, d]));
  const vacancyByKey = new Map(vacancies.map((v, i) => [`${v.role.id}#${i}`, v]));

  const candidates: { vKey: string; sKey: string; score: number; reasons: string[] }[] = [];
  for (const [vKey, vacancy] of vacancyByKey) {
    for (const [sKey, source] of sourceByKey) {
      const scored = scorePair(vacancy, source, assumptions);
      if (!scored || scored.score < assumptions.minScore) continue;
      candidates.push({ vKey, sKey, ...scored });
    }
  }
  candidates.sort((a, b) => b.score - a.score);

  const matches: RedeployMatch[] = [];
  for (const c of candidates) {
    const vLeft = remainingVacancy.get(c.vKey) ?? 0;
    const sLeft = remainingSource.get(c.sKey) ?? 0;
    const take = Math.min(vLeft, sLeft);
    if (take <= 0) continue;
    remainingVacancy.set(c.vKey, vLeft - take);
    remainingSource.set(c.sKey, sLeft - take);
    const vacancy = vacancyByKey.get(c.vKey)!;
    const source = sourceByKey.get(c.sKey)!;
    matches.push({
      id: `${c.vKey}|${c.sKey}`,
      vacancyId: vacancy.role.id,
      vacancyTitle: vacancy.role.title || vacancy.role.name || "New role",
      vacancyDepartment: vacancy.role.department || "Unassigned",
      vacancyCountry: vacancy.role.country || "Unassigned",
      vacancyBand: vacancy.band,
      sourceId: source.role.id,
      sourceTitle: source.role.title || source.role.name || "Displaced role",
      sourceDepartment: source.role.department || "Unassigned",
      sourceCountry: source.role.country || "Unassigned",
      sourceBand: source.band,
      positions: take,
      score: c.score,
      band: c.score >= 70 ? "strong" : c.score >= 55 ? "reskill" : "stretch",
      reasons: c.reasons,
    });
  }

  const redeployedPositions = matches.reduce((s, m) => s + m.positions, 0);
  const externalHires = Math.max(vacancyPositions - redeployedPositions, 0);
  const managedExits = Math.max(displacedPositions - redeployedPositions - attritionAbsorbed, 0);

  const gapMap = new Map<string, RedeployGap>();
  for (const [vKey, left] of remainingVacancy) {
    const vacancy = vacancyByKey.get(vKey)!;
    const key = vacancy.role.department || "Unassigned";
    const row = gapMap.get(key) ?? { key, vacancies: 0, matched: 0, external: 0 };
    row.vacancies += vacancy.positions;
    row.external += left;
    row.matched += vacancy.positions - left;
    gapMap.set(key, row);
  }

  return {
    displacedPositions,
    vacancyPositions,
    attritionAbsorbed,
    redeployedPositions,
    externalHires,
    managedExits,
    coveragePct: vacancyPositions ? (redeployedPositions / vacancyPositions) * 100 : 0,
    matches: matches.sort((a, b) => b.positions - a.positions || b.score - a.score),
    gapsByDepartment: [...gapMap.values()].sort((a, b) => b.external - a.external),
    unmatchedVacancies: [...remainingVacancy.entries()]
      .filter(([, left]) => left > 0)
      .map(([key, left]) => {
        const v = vacancyByKey.get(key)!;
        return {
          id: v.role.id,
          title: v.role.title || v.role.name || "New role",
          department: v.role.department || "Unassigned",
          country: v.role.country || "Unassigned",
          positions: left,
        };
      })
      .sort((a, b) => b.positions - a.positions),
    unmatchedDisplaced: [...remainingSource.entries()]
      .filter(([, left]) => left > 0)
      .map(([key, left]) => {
        const s = sourceByKey.get(key)!;
        return {
          id: s.role.id,
          title: s.role.title || s.role.name || "Displaced role",
          department: s.role.department || "Unassigned",
          country: s.role.country || "Unassigned",
          positions: left,
        };
      })
      .sort((a, b) => b.positions - a.positions),
  };
}
