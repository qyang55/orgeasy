/**
 * Human + AI Agent operating model helpers: role typing, agent running cost,
 * suggested role types from automation scores, and the traditional vs
 * agent-heavy comparison used across the analysis pages.
 */
import { hasConsent } from "./consent";
import { useSyncExternalStore } from "react";
import type { Employee, RoleType, Scenario } from "./types";
import { ROLE_TYPE_META } from "./types";

export function roleTypeOf(e: Employee): RoleType {
  return e.roleType ?? "human";
}

export function isAgentic(e: Employee) {
  const t = roleTypeOf(e);
  return t === "agent" || t === "hybrid";
}

/** Share of a hybrid role's delivery carried by the agent. */
export const HYBRID_AGENT_SHARE = 0.4;

/* ------------------------------------------------ agent running cost setting */

const KEY = "orgeasy.agentcost.v1";
export const DEFAULT_AGENT_MONTHLY_COST = 900;

let monthly = DEFAULT_AGENT_MONTHLY_COST;
let loaded = false;
const listeners = new Set<() => void>();

/** Default monthly running cost per agent, editable by the user. */
export function agentMonthlyDefault() {
  if (!loaded) {
    loaded = true;
    if (typeof localStorage !== "undefined") {
      const raw = Number(localStorage.getItem(KEY));
      if (Number.isFinite(raw) && raw > 0) monthly = raw;
    }
  }
  return monthly;
}

export function setAgentMonthlyDefault(value: number) {
  monthly = Math.max(0, Math.round(value || 0));
  loaded = true;
  if (typeof localStorage !== "undefined" && hasConsent("workspace")) {
    try {
      localStorage.setItem(KEY, String(monthly));
    } catch {
      /* storage full */
    }
  }
  listeners.forEach((fn) => fn());
}

export function subscribeAgentCost(fn: () => void) {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

/** Live subscription to the editable default agent running cost. */
export function useAgentMonthlyCost() {
  return useSyncExternalStore(
    subscribeAgentCost,
    () => agentMonthlyDefault(),
    () => DEFAULT_AGENT_MONTHLY_COST,
  );
}

/** Annual running cost of the agent behind a role, per planned position. */
export function agentAnnualCost(e: Employee, fallbackMonthly = agentMonthlyDefault()) {
  const type = roleTypeOf(e);
  if (type === "human") return 0;
  const perYear = (e.agentMonthlyCost ?? fallbackMonthly) * 12;
  return type === "hybrid" ? Math.round(perYear * HYBRID_AGENT_SHARE) : perYear;
}

export interface CostSplit {
  humanCost: number;
  agentCost: number;
  humanHeadcount: number;
  agentRoles: number;
  hybridRoles: number;
}

/**
 * Splits a scenario's planned cost into people cost and agent running cost.
 * A hybrid role keeps its person, at a reduced people cost.
 */
export function splitPlannedCost(
  employees: Employee[],
  fallbackMonthly = agentMonthlyDefault(),
): CostSplit {
  let humanCost = 0;
  let agentCost = 0;
  let humanHeadcount = 0;
  let agentRoles = 0;
  let hybridRoles = 0;

  for (const e of employees) {
    const hc = e.plannedHeadcount;
    const type = roleTypeOf(e);
    agentCost += agentAnnualCost(e, fallbackMonthly) * hc;
    if (type === "agent") {
      agentRoles += hc;
      continue;
    }
    if (type === "hybrid") {
      hybridRoles += hc;
      humanHeadcount += hc;
      humanCost += e.plannedCost * hc * (1 - HYBRID_AGENT_SHARE);
      continue;
    }
    humanHeadcount += hc;
    humanCost += e.plannedCost * hc;
  }

  return {
    humanCost: Math.round(humanCost),
    agentCost: Math.round(agentCost),
    humanHeadcount,
    agentRoles,
    hybridRoles,
  };
}

/* ------------------------------------------------------- suggested role type */

export interface RoleTypeSuggestion {
  type: RoleType;
  rationale: string;
}

/** Suggested delivery model from an automation eligibility score (0-100). */
export function suggestRoleType(eligibility: number): RoleTypeSuggestion {
  if (eligibility >= 80)
    return {
      type: "agent",
      rationale:
        "Almost all of the work is rule-based and repeatable, so an agent can run it end to end with human exception handling.",
    };
  if (eligibility >= 45)
    return {
      type: "hybrid",
      rationale:
        "An agent can prepare, draft and check the work while a person keeps the judgement, decisions and relationships.",
    };
  return {
    type: "human",
    rationale:
      "The value sits in judgement, trust and accountability — keep this human and use AI only as a lightweight assistant.",
  };
}

export function roleTypeLabel(type: RoleType) {
  return ROLE_TYPE_META[type].label;
}

/* --------------------------------------------- traditional vs agent-heavy */

export interface AgentModelSummary {
  humanHeadcount: number;
  agentHeadcount: number;
  hybridHeadcount: number;
  totalHeadcount: number;
  humanCost: number;
  agentCost: number;
  totalCost: number;
}

export interface AgentComparison {
  currency: string;
  traditional: AgentModelSummary;
  agentHeavy: AgentModelSummary;
  humanReduction: number;
  agentsAdded: number;
  costSaving: number;
  convertedRoles: { employee: Employee; from: RoleType; to: RoleType }[];
}

function summarise(
  employees: Employee[],
  mode: "current" | "planned",
  fallbackMonthly: number,
): AgentModelSummary {
  if (mode === "current") {
    // The traditional structure is human-only by definition.
    const humanHeadcount = employees.reduce((a, e) => a + e.currentHeadcount, 0);
    const humanCost = employees.reduce((a, e) => a + e.currentCost * e.currentHeadcount, 0);
    return {
      humanHeadcount,
      agentHeadcount: 0,
      hybridHeadcount: 0,
      totalHeadcount: humanHeadcount,
      humanCost: Math.round(humanCost),
      agentCost: 0,
      totalCost: Math.round(humanCost),
    };
  }
  const split = splitPlannedCost(employees, fallbackMonthly);
  return {
    humanHeadcount: split.humanHeadcount,
    agentHeadcount: split.agentRoles,
    hybridHeadcount: split.hybridRoles,
    totalHeadcount: employees.reduce((a, e) => a + e.plannedHeadcount, 0),
    humanCost: split.humanCost,
    agentCost: split.agentCost,
    totalCost: split.humanCost + split.agentCost,
  };
}

/**
 * Side-by-side view of the human-only baseline and the agent-enabled target
 * state, with the net human reduction, agents added and cost saving.
 */
export function compareAgentModel(
  base: Scenario | null | undefined,
  target: Scenario | null | undefined,
  fallbackMonthly = agentMonthlyDefault(),
): AgentComparison | null {
  if (!base || !target) return null;
  const traditional = summarise(base.employees, "current", fallbackMonthly);
  const agentHeavy = summarise(target.employees, "planned", fallbackMonthly);
  const baseById = new Map(base.employees.map((e) => [e.id, e]));

  const convertedRoles = target.employees
    .filter((e) => isAgentic(e))
    .map((e) => ({
      employee: e,
      from: roleTypeOf(baseById.get(e.id) ?? { ...e, roleType: "human" }),
      to: roleTypeOf(e),
    }))
    .filter((row) => row.from !== row.to || row.to !== "human")
    .sort((a, b) => b.employee.plannedHeadcount - a.employee.plannedHeadcount);

  return {
    currency: target.currency ?? base.currency ?? "USD",
    traditional,
    agentHeavy,
    humanReduction: traditional.humanHeadcount - agentHeavy.humanHeadcount,
    agentsAdded: agentHeavy.agentHeadcount + agentHeavy.hybridHeadcount,
    costSaving: traditional.totalCost - agentHeavy.totalCost,
    convertedRoles,
  };
}