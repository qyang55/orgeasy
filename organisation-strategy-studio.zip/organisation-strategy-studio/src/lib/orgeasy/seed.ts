import type { Employee, ReductionLever, Scenario } from "./types";

/* ------------------------------------------------------------------ *
 * Global demo organisation: ~500 positions across 8 functions,
 * 18 countries, used to simulate a 10% reduction programme through
 * four levers (headcount, span of control, duplicates, automation).
 * ------------------------------------------------------------------ */

type Row = {
  id: string;
  title: string;
  department: string;
  country: string;
  managerId: string | null;
  hc: number;
  cost: number;
  responsibilities: string;
  scope?: Employee["roleScope"];
  unit?: Employee["unitKind"];
  name?: string;
};

function row(r: Row): Employee {
  return {
    id: r.id,
    name: r.name ?? "",
    isOpenRole: false,
    title: r.title,
    department: r.department,
    country: r.country,
    responsibilities: r.responsibilities,
    currentHeadcount: r.hc,
    plannedHeadcount: r.hc,
    employmentType: "Full-time",
    managerId: r.managerId,
    status: "current",
    currentCost: r.cost,
    plannedCost: r.cost,
    serviceMonths: 48,
    roleScope: r.scope ?? "unset",
    unitKind: r.unit ?? "line",
  };
}

const ROWS: Row[] = [
  // Executive (4)
  { id: "ceo", name: "Amara Okafor", title: "Chief Executive Officer", department: "Executive", country: "United Kingdom", managerId: null, hc: 1, cost: 460000, responsibilities: "Group strategy, board reporting, capital allocation.", scope: "global" },
  { id: "cos", name: "Elena Rossi", title: "Chief of Staff", department: "Executive", country: "United Kingdom", managerId: "ceo", hc: 1, cost: 210000, responsibilities: "Executive agenda, transformation PMO oversight.", scope: "global" },
  { id: "exec-support", title: "Executive Support", department: "Executive", country: "United Kingdom", managerId: "cos", hc: 2, cost: 78000, responsibilities: "Executive assistance and governance administration." },

  // Operations (102)
  { id: "coo", name: "Daniel Kim", title: "Chief Operating Officer", department: "Operations", country: "Singapore", managerId: "ceo", hc: 1, cost: 330000, responsibilities: "Global service delivery, operating discipline.", scope: "global" },
  { id: "ops-emea", name: "Lena Fischer", title: "Director, Operations EMEA", department: "Operations", country: "Germany", managerId: "coo", hc: 1, cost: 178000, responsibilities: "EMEA delivery, works council engagement.", scope: "regional" },
  { id: "ops-apac", name: "Somchai Pratya", title: "Director, Operations APAC", department: "Operations", country: "Thailand", managerId: "coo", hc: 1, cost: 152000, responsibilities: "APAC delivery centres, capacity planning.", scope: "regional" },
  { id: "ops-amer", name: "Rachel Nolan", title: "Director, Operations Americas", department: "Operations", country: "United States", managerId: "coo", hc: 1, cost: 186000, responsibilities: "Americas field operations and service partners.", scope: "regional" },
  { id: "svc-emea", title: "Service Desk EMEA", department: "Operations", country: "Poland", managerId: "ops-emea", hc: 24, cost: 41000, responsibilities: "Tier 1/2 customer support, SLA handling." },
  { id: "svc-apac", title: "Service Desk APAC", department: "Operations", country: "Philippines", managerId: "ops-apac", hc: 30, cost: 24000, responsibilities: "Tier 1 support, ticket triage, back-office processing.", unit: "gbs" },
  { id: "field-amer", title: "Field Operations Americas", department: "Operations", country: "Mexico", managerId: "ops-amer", hc: 26, cost: 46000, responsibilities: "On-site installation and maintenance." },
  { id: "ops-quality", title: "Quality & Process Supervisors", department: "Operations", country: "Brazil", managerId: "ops-amer", hc: 10, cost: 62000, responsibilities: "Process audits, shift supervision, QA reporting." },
  { id: "ops-vendor", title: "Vendor Management Specialists", department: "Operations", country: "Singapore", managerId: "coo", hc: 8, cost: 88000, responsibilities: "Outsourcing partners, SLA governance.", unit: "coe" },

  // Supply chain (84)
  { id: "csco", name: "Marcus Vogel", title: "Chief Supply Chain Officer", department: "Supply Chain", country: "Germany", managerId: "ceo", hc: 1, cost: 305000, responsibilities: "End-to-end supply chain and procurement.", scope: "global" },
  { id: "sc-plan", name: "Ana Duarte", title: "Head of Planning", department: "Supply Chain", country: "Spain", managerId: "csco", hc: 1, cost: 158000, responsibilities: "Demand and supply planning leadership.", scope: "global" },
  { id: "sc-log", name: "Hiroshi Sato", title: "Head of Logistics", department: "Supply Chain", country: "Japan", managerId: "csco", hc: 1, cost: 164000, responsibilities: "Freight, warehousing, trade compliance.", scope: "global" },
  { id: "sc-proc", name: "Priya Nair", title: "Head of Procurement", department: "Supply Chain", country: "India", managerId: "csco", hc: 1, cost: 149000, responsibilities: "Category strategy and supplier negotiation.", scope: "global" },
  { id: "sc-demand", title: "Demand Planners", department: "Supply Chain", country: "Spain", managerId: "sc-plan", hc: 14, cost: 74000, responsibilities: "Forecast accuracy, S&OP inputs." },
  { id: "sc-logco", title: "Logistics Coordinators", department: "Supply Chain", country: "Poland", managerId: "sc-log", hc: 22, cost: 48000, responsibilities: "Shipment booking, carrier coordination, documentation." },
  { id: "sc-wh", title: "Warehouse Supervisors", department: "Supply Chain", country: "China", managerId: "sc-log", hc: 16, cost: 39000, responsibilities: "Inbound/outbound supervision, stock accuracy." },
  { id: "sc-buy", title: "Buyers", department: "Supply Chain", country: "India", managerId: "sc-proc", hc: 18, cost: 42000, responsibilities: "PO processing, supplier follow-up, price checks." },
  { id: "sc-sq", title: "Supplier Quality Supervisors", department: "Supply Chain", country: "China", managerId: "sc-proc", hc: 10, cost: 52000, responsibilities: "Supplier audits, non-conformance handling." },

  // Technology (96)
  { id: "cto", name: "Ibrahim Farouk", title: "Chief Technology Officer", department: "Technology", country: "United States", managerId: "ceo", hc: 1, cost: 345000, responsibilities: "Technology strategy, architecture, digital products.", scope: "global" },
  { id: "tech-plat", name: "Wei Chen", title: "Head of Platform Engineering", department: "Technology", country: "Singapore", managerId: "cto", hc: 1, cost: 196000, responsibilities: "Core platform, cloud, reliability.", scope: "global" },
  { id: "tech-data", name: "Julia Kowalski", title: "Head of Data", department: "Technology", country: "Poland", managerId: "cto", hc: 1, cost: 172000, responsibilities: "Data platform, governance, AI enablement.", scope: "global" },
  { id: "tech-sec", name: "Tom Okada", title: "Head of Security", department: "Technology", country: "Japan", managerId: "cto", hc: 1, cost: 181000, responsibilities: "Cyber security, risk, incident response.", scope: "global" },
  { id: "tech-it", name: "Sara Meyer", title: "IT Support Manager", department: "Technology", country: "Germany", managerId: "cto", hc: 1, cost: 118000, responsibilities: "End-user computing, helpdesk supervision." },
  { id: "tech-eng", title: "Software Engineers", department: "Technology", country: "India", managerId: "tech-plat", hc: 40, cost: 62000, responsibilities: "Product and platform development." },
  { id: "tech-de", title: "Data Engineers", department: "Technology", country: "Poland", managerId: "tech-data", hc: 14, cost: 71000, responsibilities: "Pipelines, warehouse modelling." },
  { id: "tech-ba", title: "Business Intelligence Analysts", department: "Technology", country: "United Kingdom", managerId: "tech-data", hc: 10, cost: 84000, responsibilities: "Dashboards, reporting, ad-hoc analysis." },
  { id: "tech-secops", title: "Security Operations Analysts", department: "Technology", country: "United Arab Emirates", managerId: "tech-sec", hc: 9, cost: 79000, responsibilities: "Monitoring, alert triage, vulnerability management." },
  { id: "tech-helpdesk", title: "IT Helpdesk Agents", department: "Technology", country: "Philippines", managerId: "tech-it", hc: 18, cost: 22000, responsibilities: "Password resets, device support, ticket logging.", unit: "gbs" },

  // Commercial (91)
  { id: "cco", name: "Grace Mahlangu", title: "Chief Commercial Officer", department: "Commercial", country: "South Africa", managerId: "ceo", hc: 1, cost: 318000, responsibilities: "Revenue, pricing, go-to-market.", scope: "global" },
  { id: "sales-emea", name: "Marc Dubois", title: "Sales Director EMEA", department: "Commercial", country: "France", managerId: "cco", hc: 1, cost: 174000, responsibilities: "EMEA revenue and key accounts.", scope: "regional" },
  { id: "sales-apac", name: "Nurul Aziz", title: "Sales Director APAC", department: "Commercial", country: "Singapore", managerId: "cco", hc: 1, cost: 168000, responsibilities: "APAC revenue and distributor network.", scope: "regional" },
  { id: "sales-amer", name: "Peter Hall", title: "Sales Director Americas", department: "Commercial", country: "United States", managerId: "cco", hc: 1, cost: 192000, responsibilities: "Americas revenue and enterprise accounts.", scope: "regional" },
  { id: "mktg", name: "Chiara Bruno", title: "Head of Marketing", department: "Commercial", country: "Italy", managerId: "cco", hc: 1, cost: 156000, responsibilities: "Brand, demand generation, product marketing.", scope: "global" },
  { id: "am-emea", title: "Account Managers EMEA", department: "Commercial", country: "Germany", managerId: "sales-emea", hc: 20, cost: 96000, responsibilities: "Account growth, renewals, pipeline." },
  { id: "am-apac", title: "Account Managers APAC", department: "Commercial", country: "Australia", managerId: "sales-apac", hc: 18, cost: 92000, responsibilities: "Account growth in APAC markets.", scope: "local" },
  { id: "am-amer", title: "Account Managers Americas", department: "Commercial", country: "United States", managerId: "sales-amer", hc: 22, cost: 104000, responsibilities: "Enterprise account coverage." },
  { id: "inside-sales", title: "Inside Sales Representatives", department: "Commercial", country: "Mexico", managerId: "sales-amer", hc: 14, cost: 44000, responsibilities: "Lead qualification, quotes, small deals." },
  { id: "mktg-spec", title: "Marketing Specialists", department: "Commercial", country: "Italy", managerId: "mktg", hc: 12, cost: 62000, responsibilities: "Campaigns, content, events, regional collateral." },

  // Finance (60)
  { id: "cfo", name: "Sofia Marchetti", title: "Chief Financial Officer", department: "Finance", country: "Italy", managerId: "ceo", hc: 1, cost: 312000, responsibilities: "Financial planning, controls, investor relations.", scope: "global" },
  { id: "fin-ctrl", name: "Owen Bennett", title: "Group Controller", department: "Finance", country: "United Kingdom", managerId: "cfo", hc: 1, cost: 168000, responsibilities: "Statutory reporting, controls, audit.", scope: "global" },
  { id: "fin-fpa", name: "Laura Sanchez", title: "Head of FP&A", department: "Finance", country: "Spain", managerId: "cfo", hc: 1, cost: 162000, responsibilities: "Budgeting, forecasting, business partnering.", scope: "global" },
  { id: "fin-gbs", name: "Jose Ramirez", title: "GBS Finance Manager", department: "Finance", country: "Philippines", managerId: "cfo", hc: 1, cost: 96000, responsibilities: "Transactional finance hub leadership.", unit: "gbs" },
  { id: "fin-ap", title: "Accounts Payable Clerks", department: "Finance", country: "Philippines", managerId: "fin-gbs", hc: 16, cost: 21000, responsibilities: "Invoice entry, matching, supplier queries.", unit: "gbs" },
  { id: "fin-ar", title: "Accounts Receivable Clerks", department: "Finance", country: "Brazil", managerId: "fin-gbs", hc: 12, cost: 26000, responsibilities: "Collections, cash application, reconciliation." },
  { id: "fin-analyst", title: "Financial Analysts", department: "Finance", country: "United Kingdom", managerId: "fin-fpa", hc: 14, cost: 88000, responsibilities: "Reporting packs, variance analysis." },
  { id: "fin-payroll", title: "Payroll Administrators", department: "Finance", country: "Poland", managerId: "fin-ctrl", hc: 8, cost: 38000, responsibilities: "Payroll input, checks, statutory filings." },
  { id: "fin-tax", title: "Tax & Treasury Specialists", department: "Finance", country: "Netherlands", managerId: "fin-ctrl", hc: 6, cost: 112000, responsibilities: "Tax compliance, cash and FX management.", unit: "coe" },

  // People (43)
  { id: "chro", name: "Nadia Haddad", title: "Chief People Officer", department: "People", country: "United Arab Emirates", managerId: "ceo", hc: 1, cost: 275000, responsibilities: "Talent, reward, change and employee relations.", scope: "global" },
  { id: "hr-ops", name: "Yuki Tanaka", title: "HR Operations Manager", department: "People", country: "Japan", managerId: "chro", hc: 1, cost: 108000, responsibilities: "HRIS data quality, payroll interface, service centre." },
  { id: "hr-ta", name: "Kofi Mensah", title: "Talent Acquisition Lead", department: "People", country: "South Africa", managerId: "chro", hc: 1, cost: 112000, responsibilities: "Hiring pipeline, employer brand." },
  { id: "hr-od", name: "Anneke Visser", title: "Head of Reward & OD", department: "People", country: "Netherlands", managerId: "chro", hc: 1, cost: 148000, responsibilities: "Job architecture, reward, org design.", unit: "coe" },
  { id: "hr-advisor", title: "HR Advisors", department: "People", country: "United Kingdom", managerId: "hr-ops", hc: 14, cost: 68000, responsibilities: "Employee queries, case management, policy advice." },
  { id: "hr-rec", title: "Recruiters", department: "People", country: "India", managerId: "hr-ta", hc: 10, cost: 39000, responsibilities: "Sourcing, screening, offer administration." },
  { id: "hr-admin", title: "HR Administrators", department: "People", country: "Philippines", managerId: "hr-ops", hc: 9, cost: 20000, responsibilities: "Contract letters, data entry, filing.", unit: "gbs" },
  { id: "hr-ld", title: "Learning & Development Specialists", department: "People", country: "Thailand", managerId: "hr-od", hc: 6, cost: 46000, responsibilities: "Training delivery, capability programmes." },

  // Legal & Compliance (20)
  { id: "gc", name: "Helena Brandt", title: "General Counsel", department: "Legal & Compliance", country: "Germany", managerId: "ceo", hc: 1, cost: 285000, responsibilities: "Legal risk, governance, regulatory strategy.", scope: "global" },
  { id: "legal-counsel", title: "Legal Counsels", department: "Legal & Compliance", country: "United Kingdom", managerId: "gc", hc: 6, cost: 142000, responsibilities: "Commercial contracts, employment law support." },
  { id: "legal-comp", title: "Compliance Analysts", department: "Legal & Compliance", country: "Singapore", managerId: "gc", hc: 6, cost: 86000, responsibilities: "Policy monitoring, privacy, third-party due diligence." },
  { id: "legal-admin", title: "Contract Administrators", department: "Legal & Compliance", country: "Thailand", managerId: "gc", hc: 7, cost: 32000, responsibilities: "Contract templates, signature routing, records." },
];

/**
 * The immutable demo baseline. Frozen so no page, calculation or drag
 * interaction can mutate the shared constant — every consumer gets a clone.
 */
const BASE: readonly Employee[] = Object.freeze(ROWS.map(row).map((e) => Object.freeze(e)));

/** Fixed baseline roster: identical on every app open. */
export function baselineEmployees(): Employee[] {
  return structuredClone(BASE) as Employee[];
}

/** Stable creation timestamp so the seeded demo never differs run to run. */
export const SEED_CREATED_AT = "2026-01-05T09:00:00.000Z";

/** Id of the fixed default scenario users always land on. */
export const CURRENT_STATE_ID = "current-state";

/**
 * The default demo baseline is read-only for bulk generators and importers:
 * it must always show the same fixed numbers, so sample/import data goes into a
 * new scenario instead of overwriting it.
 */
export function isFixedDemoScenario(id: string | null | undefined): boolean {
  return id === CURRENT_STATE_ID;
}

export const BASELINE_HEADCOUNT = BASE.reduce((a, e) => a + e.currentHeadcount, 0);
export const TARGET_REDUCTION_PCT = 0.1;

/** A single reduction action attributed to one transformation lever. */
export interface LeverAction {
  targetId: string;
  lever: ReductionLever;
  cut: number;
  phase: 1 | 2 | 3;
  rationale: string;
}

export const LEVER_ACTIONS: LeverAction[] = [
  // Phase 1 — headcount discipline (15)
  { targetId: "tech-helpdesk", lever: "headcount", cut: 4, phase: 1, rationale: "Vacancy freeze on helpdesk backfills." },
  { targetId: "hr-admin", lever: "headcount", cut: 3, phase: 1, rationale: "Contractor exits in HR administration." },
  { targetId: "inside-sales", lever: "headcount", cut: 4, phase: 1, rationale: "Low-yield inside sales territories closed." },
  { targetId: "sc-wh", lever: "headcount", cut: 4, phase: 1, rationale: "Shift consolidation in warehouse supervision." },

  // Phase 2 — span of control (12) and duplicates (10)
  { targetId: "ops-amer", lever: "span", cut: 1, phase: 2, rationale: "Americas ops folded under COO; layer removed." },
  { targetId: "sales-apac", lever: "span", cut: 1, phase: 2, rationale: "APAC sales leadership merged into CCO span." },
  { targetId: "tech-it", lever: "span", cut: 1, phase: 2, rationale: "IT support supervision merged with platform." },
  { targetId: "sc-plan", lever: "span", cut: 1, phase: 2, rationale: "Planning head absorbed by CSCO." },
  { targetId: "ops-quality", lever: "span", cut: 4, phase: 2, rationale: "Supervisor layer widened from 3 to 8 reports." },
  { targetId: "sc-sq", lever: "span", cut: 4, phase: 2, rationale: "Supplier quality supervision consolidated regionally." },
  { targetId: "fin-ar", lever: "duplicate", cut: 4, phase: 2, rationale: "AR merged into the GBS order-to-cash team." },
  { targetId: "tech-ba", lever: "duplicate", cut: 3, phase: 2, rationale: "BI analysts overlap with data engineering analytics." },
  { targetId: "mktg-spec", lever: "duplicate", cut: 3, phase: 2, rationale: "Regional campaign duplication removed." },

  // Phase 3 — AI & work redesign (16 positions of transactional work redesigned out)
  { targetId: "fin-ap", lever: "automation", cut: 6, phase: 3, rationale: "Invoice capture and matching redesigned end-to-end; remaining team moves to exception handling and supplier queries." },
  { targetId: "svc-apac", lever: "automation", cut: 6, phase: 3, rationale: "AI triage and self-service take repeat Tier 1 contacts; advisors move to complex and escalated cases." },
  { targetId: "fin-payroll", lever: "automation", cut: 2, phase: 3, rationale: "Payroll validation checks automated; capacity redirected to controls and audit readiness." },
  { targetId: "hr-advisor", lever: "automation", cut: 2, phase: 3, rationale: "AI HR assistant answers routine queries; advisors shift to manager coaching and ER casework." },
];

/** New capability roles created by the transformation (capability in, not only headcount out). */
const NEW_ROLES: (Employee & { phase: 1 | 2 | 3 })[] = [
  {
    ...row({ id: "new-auto-coe", title: "Automation CoE Lead", department: "Operations", country: "Singapore", managerId: "coo", hc: 0, cost: 0, responsibilities: "Automation pipeline, AI agent governance, benefits tracking.", scope: "global", unit: "coe" }),
    isOpenRole: true,
    status: "planned",
    plannedHeadcount: 1,
    plannedCost: 172000,
    serviceMonths: 0,
    phase: 3,
  },
  {
    ...row({ id: "new-ai-po", title: "AI Product Owner", department: "Technology", country: "Poland", managerId: "tech-data", hc: 0, cost: 0, responsibilities: "AI use-case backlog, model rollout, adoption metrics.", scope: "global" }),
    isOpenRole: true,
    status: "planned",
    plannedHeadcount: 1,
    plannedCost: 124000,
    serviceMonths: 0,
    phase: 3,
  },
  {
    ...row({ id: "new-wf-analytics", title: "Workforce Analytics Manager", department: "People", country: "United Kingdom", managerId: "hr-od", hc: 0, cost: 0, responsibilities: "Span, layer and cost analytics; savings assurance.", scope: "global", unit: "coe" }),
    isOpenRole: true,
    status: "planned",
    plannedHeadcount: 1,
    plannedCost: 118000,
    serviceMonths: 0,
    phase: 2,
  },
  {
    ...row({ id: "new-svc-design", title: "Service Design Lead", department: "Customer Service", country: "United Kingdom", managerId: "cco", hc: 0, cost: 0, responsibilities: "Redesign customer journeys around human + agent delivery; own the escalation model.", scope: "global", unit: "coe" }),
    isOpenRole: true,
    status: "planned",
    plannedHeadcount: 2,
    plannedCost: 108000,
    serviceMonths: 0,
    phase: 3,
  },
  {
    ...row({ id: "new-data-eng", title: "Data Engineers", department: "Technology", country: "Poland", managerId: "tech-data", hc: 0, cost: 0, responsibilities: "Data pipelines and quality that the redesigned processes and agents depend on.", scope: "global" }),
    isOpenRole: true,
    status: "planned",
    plannedHeadcount: 3,
    plannedCost: 96000,
    serviceMonths: 0,
    phase: 3,
  },
];

/** Reparenting applied when a supervisory layer is removed. */
const REPARENT: Record<string, string> = {
  "field-amer": "coo",
  "ops-quality": "coo",
  "am-apac": "cco",
  "tech-helpdesk": "tech-plat",
  "sc-demand": "csco",
};

function buildPhase(upTo: 1 | 2 | 3): Employee[] {
  const clone = baselineEmployees();
  const byId = new Map(clone.map((e) => [e.id, e]));

  for (const action of LEVER_ACTIONS) {
    if (action.phase > upTo) continue;
    const target = byId.get(action.targetId);
    if (!target) continue;
    target.plannedHeadcount = Math.max(0, target.plannedHeadcount - action.cut);
    target.status = "to-be-removed";
    target.reductionLever = action.lever;
    target.responsibilities = `${target.responsibilities} — ${action.rationale}`;
  }

  if (upTo >= 2) {
    for (const [childId, managerId] of Object.entries(REPARENT)) {
      const child = byId.get(childId);
      if (child && child.managerId !== managerId) {
        child.managerId = managerId;
        if (child.status === "current") child.status = "moved";
      }
    }
  }

  for (const role of NEW_ROLES) {
    if (role.phase > upTo) continue;
    const { phase: _phase, ...employee } = role;
    clone.push(structuredClone(employee));
  }

  return clone;
}

/* ------------------------------------------------------------------ *
 * A deliberately non-cost-cutting design option: stand up a shared
 * service centre and add digital capability. Work relocates and new
 * capability is created, so positions stay broadly flat.
 * ------------------------------------------------------------------ */

const GBS_MOVES: { id: string; rationale: string }[] = [
  { id: "fin-ap", rationale: "Accounts payable processing moves into the shared service centre." },
  { id: "fin-ar", rationale: "Order-to-cash moves into the shared service centre." },
  { id: "hr-admin", rationale: "People administration moves into the shared service centre." },
  { id: "legal-admin", rationale: "Contract administration moves into the shared service centre." },
];

const CAPABILITY_ROLES: Employee[] = [
  { ...row({ id: "cap-gbs-lead", title: "Shared Service Centre Director", department: "Operations", country: "Poland", managerId: "coo", hc: 0, cost: 0, responsibilities: "Runs the multi-function service centre: service levels, migration waves, continuous improvement.", scope: "global", unit: "gbs" }), isOpenRole: true, status: "planned", plannedHeadcount: 1, plannedCost: 168000, serviceMonths: 0 },
  { ...row({ id: "cap-gbs-ops", title: "Service Centre Team Leads", department: "Operations", country: "Poland", managerId: "cap-gbs-lead", hc: 0, cost: 0, responsibilities: "Lead finance, people and contract service pods; own quality and turnaround.", scope: "regional", unit: "gbs" }), isOpenRole: true, status: "planned", plannedHeadcount: 4, plannedCost: 74000, serviceMonths: 0 },
  { ...row({ id: "cap-gbs-ci", title: "Continuous Improvement Analysts", department: "Operations", country: "Malaysia", managerId: "cap-gbs-lead", hc: 0, cost: 0, responsibilities: "Process mining, standardisation and automation candidates inside the service centre.", scope: "global", unit: "coe" }), isOpenRole: true, status: "planned", plannedHeadcount: 3, plannedCost: 42000, serviceMonths: 0 },
  { ...row({ id: "cap-digital-lead", title: "Digital Product Lead", department: "Technology", country: "United Kingdom", managerId: "cto", hc: 0, cost: 0, responsibilities: "Owns the customer-facing digital roadmap and the value case behind it.", scope: "global" }), isOpenRole: true, status: "planned", plannedHeadcount: 1, plannedCost: 156000, serviceMonths: 0 },
  { ...row({ id: "cap-digital-eng", title: "Digital Engineers", department: "Technology", country: "Poland", managerId: "cap-digital-lead", hc: 0, cost: 0, responsibilities: "Build self-service and integration capability that the growth plan depends on.", scope: "global" }), isOpenRole: true, status: "planned", plannedHeadcount: 6, plannedCost: 98000, serviceMonths: 0 },
  { ...row({ id: "cap-cx-insight", title: "Customer Insight Analysts", department: "Customer Service", country: "Singapore", managerId: "cco", hc: 0, cost: 0, responsibilities: "Turn service and sales data into growth and retention actions.", scope: "regional", unit: "coe" }), isOpenRole: true, status: "planned", plannedHeadcount: 3, plannedCost: 68000, serviceMonths: 0 },
];

function buildCapabilityOption(): Employee[] {
  const clone = baselineEmployees();
  const byId = new Map(clone.map((e) => [e.id, e]));

  // Transactional work relocates into the centre; a small part is standardised away.
  const standardised: Record<string, number> = { "fin-ap": 3, "fin-ar": 2, "hr-admin": 2, "legal-admin": 2 };
  for (const move of GBS_MOVES) {
    const target = byId.get(move.id);
    if (!target) continue;
    target.managerId = "cap-gbs-lead";
    target.status = "moved";
    target.unitKind = "gbs";
    target.responsibilities = `${target.responsibilities} — ${move.rationale}`;
    const trim = standardised[move.id] ?? 0;
    if (trim) {
      target.plannedHeadcount = Math.max(0, target.plannedHeadcount - trim);
      target.reductionLever = "duplicate";
    }
  }

  clone.push(...structuredClone(CAPABILITY_ROLES));
  return clone;
}

export function seedScenarios(): Scenario[] {
  // Every field below is a fixed constant (no dates, randomness or derived
  // numbers) and each scenario gets its own fresh objects, so opening the app
  // always reproduces the exact same demo dataset.
  const shared = () => ({ currency: "USD", createdAt: SEED_CREATED_AT, positions: {} });

  return [
    {
      ...shared(),
      id: CURRENT_STATE_ID,
      name: "Demo – Global (500 positions)",
      description:
        "Fixed demo baseline: 500 positions, 8 functions, 18 countries, 6 management layers. This dataset is locked and always reloads the same numbers; use it to explore the studio before building your own scenario.",
      employees: baselineEmployees(),
      adkarGroups: [],
      kind: "current",
      baselineId: null,
    },
    {
      ...shared(),
      id: "future-p1",
      name: "Phase 1 — Demand discipline",
      description:
        "Stop adding work that no longer earns its place: vacancy freeze, contractor exits and low-yield roles released. 15 positions out, structure untouched — this buys the room to invest in the next phases.",
      employees: buildPhase(1),
      adkarGroups: [
        {
          id: "grp-leaders",
          name: "Senior Leadership",
          scores: { awareness: 5, desire: 4, knowledge: 4, ability: 3, reinforcement: 3 },
          notes: "Aligned on the 10% target; reinforcement plan still light.",
        },
        {
          id: "grp-managers",
          name: "People Managers",
          scores: { awareness: 4, desire: 3, knowledge: 2, ability: 2, reinforcement: 2 },
          notes: "Need consultation training and lever-specific talking points.",
        },
        {
          id: "grp-impacted",
          name: "Impacted Employees",
          scores: { awareness: 2, desire: 2, knowledge: 2, ability: 2, reinforcement: 1 },
          notes: "Awareness campaign not launched in EMEA.",
        },
      ],
      kind: "future",
      phaseOrder: 1,
      phaseLabel: "Phase 1 — Demand discipline",
      baselineId: "current-state",
    },
    {
      ...shared(),
      id: "future-p2",
      name: "Phase 2 — Span, layers & duplicate roles",
      description:
        "Reshape decision-making: delayer to 5 layers with wider spans and pull duplicated finance, analytics and marketing work into single owners — plus a workforce analytics capability to keep the new shape honest.",
      employees: buildPhase(2),
      adkarGroups: [],
      kind: "future",
      phaseOrder: 2,
      phaseLabel: "Phase 2 — Span & duplicates",
      baselineId: "future-p1",
    },
    {
      ...shared(),
      id: "future-p3",
      name: "Phase 3 — AI & work redesign",
      description:
        "Redesign the work itself: automation and AI agents take the repeatable steps while people move to judgement, exception and customer work. Adds service design, AI product and data engineering capability, and lands the cumulative 10% position shift.",
      employees: buildPhase(3),
      adkarGroups: [],
      kind: "future",
      phaseOrder: 3,
      phaseLabel: "Phase 3 — AI & work redesign",
      baselineId: "future-p2",
    },
    {
      ...shared(),
      id: "future-capability",
      name: "Option — Shared service centre & digital capability",
      description:
        "A growth-and-capability option rather than a cost-out one: stand up a multi-function shared service centre, standardise the transactional work it inherits, and invest the capacity into digital product, engineering and customer insight roles. Positions stay broadly flat — the change is where capability sits, not how much of it there is.",
      employees: buildCapabilityOption(),
      adkarGroups: [
        {
          id: "cap-grp-leaders",
          name: "Function Leaders",
          scores: { awareness: 4, desire: 3, knowledge: 3, ability: 2, reinforcement: 2 },
          notes: "Need to accept service-centre delivery for work they own today.",
        },
        {
          id: "cap-grp-moving",
          name: "Teams Moving Into the Centre",
          scores: { awareness: 3, desire: 2, knowledge: 2, ability: 2, reinforcement: 2 },
          notes: "Reporting line and ways of working change; roles are retained, not removed.",
        },
        {
          id: "cap-grp-new",
          name: "New Digital Capability",
          scores: { awareness: 4, desire: 4, knowledge: 3, ability: 2, reinforcement: 2 },
          notes: "18 new roles to attract, onboard and connect to the growth agenda.",
        },
      ],
      kind: "future",
      phaseLabel: "Option — Shared services & digital",
      baselineId: "current-state",
      standalone: true,
    },
  ];
}
