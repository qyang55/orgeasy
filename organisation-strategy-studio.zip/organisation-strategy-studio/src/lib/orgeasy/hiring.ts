import type { Employee, Scenario } from "./types";
import { compareScenarios } from "./diff";
import { COUNTRY_COST_RULES } from "./country-costs";

/**
 * Hiring pipeline model.
 *
 * The reduction programme removes positions, but it also *creates* work: new roles
 * (CoE, GBS, agent-supervision, upskilled hybrid roles) that must be filled before
 * the future state can operate. This module sizes that demand and estimates how long
 * it takes to fill, using seniority, market difficulty and recruiter capacity.
 *
 * All figures are planning heuristics, not guarantees.
 */

export type SeniorityBand = "executive" | "leadership" | "manager" | "professional" | "operational";

export const SENIORITY_META: Record<
  SeniorityBand,
  { label: string; baseDays: number; offerDeclinePct: number }
> = {
  executive: { label: "Executive", baseDays: 110, offerDeclinePct: 18 },
  leadership: { label: "Senior leadership", baseDays: 85, offerDeclinePct: 15 },
  manager: { label: "Manager", baseDays: 62, offerDeclinePct: 12 },
  professional: { label: "Professional / specialist", baseDays: 48, offerDeclinePct: 10 },
  operational: { label: "Operational", baseDays: 32, offerDeclinePct: 8 },
};

/** Market friction multipliers on time-to-fill (notice periods, talent scarcity, permits). */
const MARKET_FRICTION: Record<string, number> = {
  Japan: 1.35,
  Germany: 1.3,
  Netherlands: 1.25,
  "South Korea": 1.25,
  Switzerland: 1.25,
  France: 1.2,
  Belgium: 1.2,
  Sweden: 1.2,
  "United Kingdom": 1.15,
  Ireland: 1.15,
  Spain: 1.1,
  Italy: 1.1,
  Poland: 1.1,
  Singapore: 1.15,
  "United Arab Emirates": 1.2,
  China: 1.1,
  India: 0.95,
  Philippines: 0.9,
  Vietnam: 0.95,
  Thailand: 0.95,
  Malaysia: 1.0,
  Brazil: 1.05,
  Mexico: 1.0,
  "United States": 1.0,
  Canada: 1.05,
  Australia: 1.1,
  "New Zealand": 1.1,
  "South Africa": 1.0,
};

/** Extra build time when the "role" is an AI agent or hybrid supervision design. */
const ROLE_TYPE_FACTOR = { human: 1, hybrid: 1.1, agent: 0.55 } as const;

/** Global / regional roles take longer: wider search, more stakeholders. */
const SCOPE_FACTOR = { global: 1.2, regional: 1.1, local: 1, unset: 1 } as const;

export interface HiringAssumptions {
  /** Share of new roles expected to be filled by redeployed internal talent. */
  internalFillPct: number;
  /** Requisitions one recruiter can run concurrently. */
  reqsPerRecruiter: number;
  /** Recruiters available to the programme. */
  recruiters: number;
  /** Days saved when a role is filled internally rather than externally. */
  internalDaysSaved: number;
}

export const DEFAULT_HIRING_ASSUMPTIONS: HiringAssumptions = {
  internalFillPct: 40,
  reqsPerRecruiter: 12,
  recruiters: 6,
  internalDaysSaved: 22,
};

const LEAD_WORDS = [
  "chief",
  "cxo",
  "ceo",
  "cfo",
  "coo",
  "cto",
  "chro",
  "president",
  "svp",
];

export function seniorityFor(role: Employee, directReports: number): SeniorityBand {
  const t = (role.title || "").toLowerCase();
  if (LEAD_WORDS.some((w) => t.includes(w))) return "executive";
  if (t.includes("vp") || t.includes("vice president") || t.includes("director")) return "leadership";
  if (
    directReports > 0 ||
    t.includes("head of") ||
    t.includes("manager") ||
    t.includes("lead")
  )
    return "manager";
  if (
    t.includes("operator") ||
    t.includes("technician") ||
    t.includes("assistant") ||
    t.includes("clerk") ||
    t.includes("agent")
  )
    return "operational";
  return "professional";
}

export function marketFriction(country: string) {
  return MARKET_FRICTION[country] ?? 1;
}

export interface HiringRoleRow {
  id: string;
  title: string;
  department: string;
  country: string;
  positions: number;
  seniority: SeniorityBand;
  roleType: "human" | "agent" | "hybrid";
  scope: keyof typeof SCOPE_FACTOR;
  daysToFill: number;
  isNewRole: boolean;
  noticeWeeks: number;
}

export interface HiringGroupRow {
  key: string;
  positions: number;
  avgDaysToFill: number;
  longestDays: number;
}

export interface HiringWave {
  wave: number;
  label: string;
  positions: number;
  startDay: number;
  endDay: number;
}

export interface HiringAnalysis {
  newPositions: number;
  newRoleCount: number;
  growthPositions: number;
  removedPositions: number;
  netPositions: number;
  internalFills: number;
  externalHires: number;
  extraOffersNeeded: number;
  avgDaysToFill: number;
  longestDaysToFill: number;
  programmeDays: number;
  capacityPerWave: number;
  waves: HiringWave[];
  roles: HiringRoleRow[];
  byDepartment: HiringGroupRow[];
  byCountry: HiringGroupRow[];
  bySeniority: (HiringGroupRow & { band: SeniorityBand })[];
}

function noticeWeeksFor(country: string) {
  return COUNTRY_COST_RULES.find((r) => r.country === country)?.noticeWeeks ?? 4;
}

function groupRows(roles: HiringRoleRow[], pick: (r: HiringRoleRow) => string): HiringGroupRow[] {
  const map = new Map<string, { positions: number; weighted: number; longest: number }>();
  for (const r of roles) {
    const key = pick(r) || "Unassigned";
    const cur = map.get(key) ?? { positions: 0, weighted: 0, longest: 0 };
    cur.positions += r.positions;
    cur.weighted += r.daysToFill * r.positions;
    cur.longest = Math.max(cur.longest, r.daysToFill);
    map.set(key, cur);
  }
  return [...map.entries()]
    .map(([key, v]) => ({
      key,
      positions: v.positions,
      avgDaysToFill: v.positions ? Math.round(v.weighted / v.positions) : 0,
      longestDays: v.longest,
    }))
    .sort((a, b) => b.positions - a.positions || b.avgDaysToFill - a.avgDaysToFill);
}

/**
 * Size the hiring demand created by moving from `baseline` to `target`.
 * New demand = roles that only exist in the target, plus headcount growth on roles
 * that survive the programme.
 */
export function analyseHiring(
  baseline: Scenario | null | undefined,
  target: Scenario | null | undefined,
  assumptions: HiringAssumptions = DEFAULT_HIRING_ASSUMPTIONS,
): HiringAnalysis {
  const empty: HiringAnalysis = {
    newPositions: 0,
    newRoleCount: 0,
    growthPositions: 0,
    removedPositions: 0,
    netPositions: 0,
    internalFills: 0,
    externalHires: 0,
    extraOffersNeeded: 0,
    avgDaysToFill: 0,
    longestDaysToFill: 0,
    programmeDays: 0,
    capacityPerWave: 0,
    waves: [],
    roles: [],
    byDepartment: [],
    byCountry: [],
    bySeniority: [],
  };
  if (!target) return empty;

  const reportCount = new Map<string, number>();
  for (const e of target.employees) {
    if (e.managerId) reportCount.set(e.managerId, (reportCount.get(e.managerId) ?? 0) + 1);
  }

  const demand: { role: Employee; positions: number; isNewRole: boolean }[] = [];
  let removedPositions = 0;

  if (baseline && baseline.id !== target.id) {
    const diff = compareScenarios(baseline, target);
    for (const e of diff.added) {
      const positions = Math.max(e.plannedHeadcount || e.currentHeadcount || 0, 0);
      if (positions > 0) demand.push({ role: e, positions, isNewRole: true });
    }
    for (const c of diff.changed) {
      const before = c.before.plannedHeadcount || c.before.currentHeadcount || 0;
      const after = c.after.plannedHeadcount || c.after.currentHeadcount || 0;
      if (after > before) demand.push({ role: c.after, positions: after - before, isNewRole: false });
    }
    removedPositions = diff.removed.reduce(
      (sum, e) => sum + Math.max(e.currentHeadcount || e.plannedHeadcount || 0, 0),
      0,
    );
  } else {
    for (const e of target.employees) {
      if (e.status === "planned") {
        const positions = Math.max(e.plannedHeadcount || e.currentHeadcount || 0, 0);
        if (positions > 0) demand.push({ role: e, positions, isNewRole: true });
      } else if (e.plannedHeadcount > e.currentHeadcount) {
        demand.push({ role: e, positions: e.plannedHeadcount - e.currentHeadcount, isNewRole: false });
      }
      if (e.status === "to-be-removed") {
        removedPositions += Math.max(e.currentHeadcount || e.plannedHeadcount || 0, 0);
      } else if (e.currentHeadcount > e.plannedHeadcount) {
        removedPositions += e.currentHeadcount - e.plannedHeadcount;
      }
    }
  }

  const roles: HiringRoleRow[] = demand.map(({ role, positions, isNewRole }) => {
    const seniority = seniorityFor(role, reportCount.get(role.id) ?? 0);
    const roleType = role.roleType ?? "human";
    const scope = (role.roleScope ?? "unset") as keyof typeof SCOPE_FACTOR;
    const notice = noticeWeeksFor(role.country);
    const base = SENIORITY_META[seniority].baseDays;
    const days = Math.round(
      base *
        marketFriction(role.country) *
        ROLE_TYPE_FACTOR[roleType] *
        SCOPE_FACTOR[scope] +
        (roleType === "agent" ? 0 : notice * 7 * 0.35),
    );
    return {
      id: role.id,
      title: role.title || role.name || "Untitled role",
      department: role.department || "Unassigned",
      country: role.country || "Unassigned",
      positions,
      seniority,
      roleType,
      scope,
      daysToFill: days,
      isNewRole,
      noticeWeeks: notice,
    };
  });

  const newPositions = roles.reduce((s, r) => s + r.positions, 0);
  const newRoleCount = roles.filter((r) => r.isNewRole).length;
  const growthPositions = roles.filter((r) => !r.isNewRole).reduce((s, r) => s + r.positions, 0);
  const internalFills = Math.round((newPositions * assumptions.internalFillPct) / 100);
  const externalHires = newPositions - internalFills;

  const weightedDays = roles.reduce((s, r) => {
    const internalShare = assumptions.internalFillPct / 100;
    const blended =
      r.daysToFill * (1 - internalShare) +
      Math.max(r.daysToFill - assumptions.internalDaysSaved, 14) * internalShare;
    return s + blended * r.positions;
  }, 0);
  const avgDaysToFill = newPositions ? Math.round(weightedDays / newPositions) : 0;
  const longestDaysToFill = roles.reduce((m, r) => Math.max(m, r.daysToFill), 0);

  const extraOffersNeeded = Math.round(
    roles.reduce(
      (s, r) =>
        s + (r.positions * SENIORITY_META[r.seniority].offerDeclinePct) / 100,
      0,
    ),
  );

  const capacityPerWave = Math.max(assumptions.recruiters * assumptions.reqsPerRecruiter, 1);
  const waveCount = Math.max(Math.ceil(newPositions / capacityPerWave), newPositions ? 1 : 0);
  const waves: HiringWave[] = [];
  // Fill the hardest, longest-lead roles first so critical capability lands early.
  const ordered = [...roles].sort((a, b) => b.daysToFill - a.daysToFill);
  let cursor = 0;
  let remainingInWave = capacityPerWave;
  let wave = 1;
  let wavePositions = 0;
  let waveLongest = 0;
  const flushWave = () => {
    if (!wavePositions) return;
    const start = cursor;
    waves.push({
      wave,
      label: `Wave ${wave}`,
      positions: wavePositions,
      startDay: start,
      endDay: start + waveLongest,
    });
    cursor = start + waveLongest;
    wave += 1;
    wavePositions = 0;
    waveLongest = 0;
    remainingInWave = capacityPerWave;
  };
  for (const r of ordered) {
    let left = r.positions;
    while (left > 0) {
      const take = Math.min(left, remainingInWave);
      wavePositions += take;
      waveLongest = Math.max(waveLongest, r.daysToFill);
      remainingInWave -= take;
      left -= take;
      if (remainingInWave === 0) flushWave();
    }
  }
  flushWave();

  return {
    newPositions,
    newRoleCount,
    growthPositions,
    removedPositions,
    netPositions: newPositions - removedPositions,
    internalFills,
    externalHires,
    extraOffersNeeded,
    avgDaysToFill,
    longestDaysToFill,
    programmeDays: waves.length ? waves[waves.length - 1]!.endDay : 0,
    capacityPerWave,
    waves: waves.slice(0, Math.max(waveCount, waves.length)),
    roles: roles.sort((a, b) => b.positions - a.positions || b.daysToFill - a.daysToFill),
    byDepartment: groupRows(roles, (r) => r.department),
    byCountry: groupRows(roles, (r) => r.country),
    bySeniority: (["executive", "leadership", "manager", "professional", "operational"] as SeniorityBand[])
      .map((band) => {
        const rows = groupRows(
          roles.filter((r) => r.seniority === band),
          () => SENIORITY_META[band].label,
        );
        const row = rows[0] ?? { key: SENIORITY_META[band].label, positions: 0, avgDaysToFill: 0, longestDays: 0 };
        return { ...row, band };
      })
      .filter((r) => r.positions > 0),
  };
}

export function formatDays(days: number) {
  if (!days) return "—";
  if (days < 60) return `${days} days`;
  const months = days / 30.4;
  return `${months.toFixed(1)} months`;
}