/** PowerPoint + PDF export for an Automation Opportunity analysis. */
import type PptxGenJSType from "pptxgenjs";
import {
  BAND_META,
  computeTotals,
  type RoleAutomationAnalysis,
  FLAG_META,
} from "./automation";
import { formatMoney } from "./impact";
import { EXPORT_NOTICES, NOT_LEGAL_ADVICE_SHORT } from "./notices";
import { BRAND_NAVY, LOGO_COVER, LOGO_MARK, logoData, logoDataUrl } from "./brand";

const NAVY = BRAND_NAVY;
const BLUE = "2563EB";
const INK = "1E293B";
const MUTED = "64748B";
const LIGHT = "F1F5F9";
const WHITE = "FFFFFF";
const HEAD = "Georgia";
const BODY = "Calibri";

function safeName(text: string) {
  return text.replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "") || "role";
}

export async function generateAutomationDeck(analysis: RoleAutomationAnalysis) {
  const PptxGenJS = (await import("pptxgenjs")).default;
  const pptx = new PptxGenJS();
  pptx.layout = "LAYOUT_16x9";
  pptx.author = "Organisation Strategy Studio";
  pptx.title = `${analysis.roleTitle} — Automation Opportunity Analysis`;
  const logo = await logoData();

  const totals = computeTotals(analysis);
  const cur = analysis.currency || "USD";
  const dateLabel = new Date(analysis.createdAt).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const addLight = (title: string, kicker?: string) => {
    const s = pptx.addSlide();
    s.background = { color: WHITE };
    s.addShape("rect", { x: 0, y: 0, w: 0.22, h: 5.63, fill: { color: BLUE } });
    if (logo) {
      s.addImage({
        data: logo,
        x: LOGO_MARK.x,
        y: LOGO_MARK.y,
        w: LOGO_MARK.size,
        h: LOGO_MARK.size,
      });
    }
    if (kicker) {
      s.addText(kicker.toUpperCase(), {
        x: 0.6,
        y: 0.35,
        w: 8.8,
        h: 0.3,
        fontFace: BODY,
        fontSize: 13,
        color: BLUE,
        bold: true,
        charSpacing: 2,
      });
    }
    s.addText(title, {
      x: 0.6,
      y: kicker ? 0.66 : 0.5,
      w: 8.8,
      h: 0.75,
      fontFace: HEAD,
      fontSize: 34,
      bold: true,
      color: NAVY,
    });
    return s;
  };
  const footnote = (slide: PptxGenJSType.Slide, text = NOT_LEGAL_ADVICE_SHORT) => {
    slide.addText(text, {
      x: 0.6,
      y: 5.06,
      w: 8.8,
      h: 0.4,
      fontFace: BODY,
      fontSize: 9,
      italic: true,
      color: MUTED,
    });
  };

  // 1 — Title
  const title = pptx.addSlide();
  title.background = { color: NAVY };
  title.addShape("rect", { x: 0, y: 4.9, w: 10, h: 0.73, fill: { color: BLUE } });
  if (logo) {
    title.addImage({
      data: logo,
      x: LOGO_COVER.x,
      y: LOGO_COVER.y,
      w: LOGO_COVER.size,
      h: LOGO_COVER.size,
    });
  }
  title.addText("Automation Opportunity Analysis", {
    x: 0.8,
    y: 1.4,
    w: 8.4,
    h: 0.4,
    fontFace: BODY,
    fontSize: 17,
    color: LIGHT,
    charSpacing: 3,
  });
  title.addText(analysis.roleTitle || "Role", {
    x: 0.8,
    y: 1.9,
    w: 8.4,
    h: 1.1,
    fontFace: HEAD,
    fontSize: 40,
    bold: true,
    color: WHITE,
  });
  title.addText(
    `${analysis.department || "All functions"} · ${dateLabel} · Freeing people from repetitive work`,
    { x: 0.8, y: 3.1, w: 8.4, h: 0.4, fontFace: BODY, fontSize: 14, color: LIGHT },
  );
  title.addText("Organisation Strategy Studio · Workforce planning", {
    x: 0.8,
    y: 5.02,
    w: 8.4,
    h: 0.5,
    fontFace: BODY,
    fontSize: 12,
    color: WHITE,
    bold: true,
  });

  // 2 — Headline
  const head = addLight("Where this role's time can go back", "Headline");
  head.addShape("ellipse", {
    x: 0.65,
    y: 1.7,
    w: 2.3,
    h: 2.3,
    fill: { color: LIGHT },
    line: { color: BLUE, width: 6 },
  });
  head.addText(`${analysis.overallScore}%`, {
    x: 0.65,
    y: 2.45,
    w: 2.3,
    h: 0.8,
    align: "center",
    fontFace: HEAD,
    fontSize: 40,
    bold: true,
    color: NAVY,
  });
  head.addText("automatable or AI-assisted", {
    x: 0.65,
    y: 4.05,
    w: 2.3,
    h: 0.3,
    align: "center",
    fontFace: BODY,
    fontSize: 11,
    color: MUTED,
  });
  const cards: [string, string][] = [
    [`${totals.hoursPerWeek}h`, "Hours returned each week"],
    [`${totals.hoursPerYear}h`, "Hours returned each year"],
    [formatMoney(totals.annualSaving, cur), "Indicative annual value"],
    [`${totals.quickWins}`, "Quick-win tasks identified"],
  ];
  cards.forEach(([value, label], i) => {
    const x = 3.35 + (i % 2) * 3.15;
    const y = 1.7 + Math.floor(i / 2) * 1.25;
    head.addShape("rect", { x, y, w: 2.95, h: 1.05, fill: { color: LIGHT } });
    head.addText(value, {
      x: x + 0.15,
      y: y + 0.1,
      w: 2.65,
      h: 0.5,
      fontFace: HEAD,
      fontSize: 22,
      bold: true,
      color: BLUE,
    });
    head.addText(label, {
      x: x + 0.15,
      y: y + 0.62,
      w: 2.65,
      h: 0.3,
      fontFace: BODY,
      fontSize: 10.5,
      color: MUTED,
    });
  });
  head.addText(analysis.summary || "", {
    x: 3.35,
    y: 4.3,
    w: 6.1,
    h: 0.7,
    fontFace: BODY,
    fontSize: 11,
    color: INK,
  });
  footnote(head);

  // 3 — Task breakdown (paged)
  const rows = [...analysis.tasks].sort((a, b) => b.score - a.score);
  const pageSize = 8;
  for (let page = 0; page < Math.max(1, Math.ceil(rows.length / pageSize)); page++) {
    const slice = rows.slice(page * pageSize, page * pageSize + pageSize);
    const slide = addLight(
      page === 0 ? "Task-by-task breakdown" : "Task-by-task breakdown (continued)",
      "Detail",
    );
    slide.addTable(
      [
        [
          { text: "Task", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Potential", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Suggested approach", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
          { text: "Hrs/wk saved", options: { bold: true, color: WHITE, fill: { color: NAVY } } },
        ],
        ...slice.map((t) => [
          { text: t.task, options: { color: INK } },
          {
            text: BAND_META[t.band].label,
            options: { color: BAND_META[t.band].hex, bold: true },
          },
          { text: t.approach, options: { color: MUTED } },
          { text: `${t.hoursSavedPerWeek}`, options: { color: INK, align: "right" as const } },
        ]),
      ],
      {
        x: 0.6,
        y: 1.6,
        w: 8.8,
        colW: [3.5, 1.6, 2.7, 1.0],
        fontFace: BODY,
        fontSize: 10,
        border: { type: "solid", color: "E2E8F0", pt: 1 },
        valign: "middle",
      },
    );
    slide.addNotes(
      slice
        .map(
          (t) =>
            `${t.task} — ${BAND_META[t.band].label} (${t.score}%). Why: ${t.reason} Approach: ${t.approach}. ${t.hoursPerWeek}h/wk today, ${t.hoursSavedPerWeek}h/wk returned.${t.overridden ? " [Adjusted by reviewer]" : ""}`,
        )
        .join("\n"),
    );
    footnote(slide);
  }

  // 4 — Keep human
  const human = analysis.tasks.filter((t) => t.band === "human" || t.band === "partial");
  const humanSlide = addLight("What stays with people", "Human value");
  humanSlide.addText(
    "These activities depend on judgement, relationships and accountability. Automation should protect the time available for them.",
    { x: 0.6, y: 1.5, w: 8.8, h: 0.5, fontFace: BODY, fontSize: 12, color: MUTED },
  );
  humanSlide.addText(
    (human.length
      ? human.slice(0, 9).map((t) => `${t.task} — ${t.reason}`)
      : ["No human-led tasks were identified. Review the task list with the role holder."]
    ).map((text) => ({ text, options: { bullet: true, breakLine: true } })),
    { x: 0.6, y: 2.1, w: 8.8, h: 2.7, fontFace: BODY, fontSize: 11.5, color: INK },
  );
  footnote(humanSlide);

  // 5 — Next actions
  const actions = addLight("Recommended next actions", "Decisions");
  actions.addText(
    (analysis.nextActions.length
      ? analysis.nextActions
      : ["Validate the task list with the role holder and their manager."]
    ).map((text) => ({ text, options: { bullet: { type: "number" }, breakLine: true } })),
    { x: 0.6, y: 1.6, w: 8.8, h: 2.2, fontFace: BODY, fontSize: 13.5, color: INK },
  );
  actions.addShape("rect", { x: 0.6, y: 3.95, w: 8.8, h: 0.95, fill: { color: LIGHT } });
  actions.addText(
    `Role flag: ${FLAG_META[analysis.flag].label}   ·   Time reinvested: ${totals.fteEquivalent} FTE-equivalent per week   ·   Analysis source: ${analysis.source === "ai" ? "AI-assisted, reviewed by user" : "rule-based estimate"}`,
    { x: 0.8, y: 4.15, w: 8.4, h: 0.6, fontFace: BODY, fontSize: 11, color: INK },
  );
  footnote(actions);

  // 6 — Notices
  const notices = addLight("Important notices & disclaimer", "Governance");
  notices.addText(
    EXPORT_NOTICES.map((n) => ({
      text: `${n.title}: ${n.body}`,
      options: { bullet: true, breakLine: true },
    })),
    { x: 0.6, y: 1.5, w: 8.8, h: 3.6, fontFace: BODY, fontSize: 8.5, color: INK },
  );
  notices.addText(
    "Automation assessments are indicative planning estimates, not commitments, and must not be used as the sole basis for role or headcount decisions.",
    { x: 0.6, y: 5.06, w: 8.8, h: 0.4, fontFace: BODY, fontSize: 9, italic: true, color: MUTED },
  );

  await pptx.writeFile({
    fileName: `${safeName(analysis.roleTitle)}-automation-analysis.pptx`,
  });
}

export async function generateAutomationPdf(analysis: RoleAutomationAnalysis) {
  const { jsPDF } = await import("jspdf");
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const totals = computeTotals(analysis);
  const cur = analysis.currency || "USD";
  const margin = 48;
  const width = doc.internal.pageSize.getWidth() - margin * 2;
  let y = margin;

  const line = (
    text: string,
    size = 10,
    style: "normal" | "bold" | "italic" = "normal",
    color = "#1E293B",
  ) => {
    doc.setFont("helvetica", style);
    doc.setFontSize(size);
    doc.setTextColor(color);
    const lines = doc.splitTextToSize(text, width);
    for (const l of lines) {
      if (y > doc.internal.pageSize.getHeight() - margin) {
        doc.addPage();
        y = margin;
      }
      doc.text(l, margin, y);
      y += size * 1.35;
    }
  };

  doc.setFillColor(`#${BRAND_NAVY}`);
  doc.rect(0, 0, doc.internal.pageSize.getWidth(), 96, "F");
  const logoPng = await logoDataUrl();
  if (logoPng) {
    doc.addImage(logoPng, "PNG", doc.internal.pageSize.getWidth() - margin - 52, 22, 52, 52);
  }
  doc.setTextColor("#FFFFFF");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(20);
  doc.text("Automation Opportunity Analysis", margin, 46);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  doc.text(
    `${analysis.roleTitle || "Role"}${analysis.department ? ` · ${analysis.department}` : ""} · ${new Date(analysis.createdAt).toLocaleDateString()}`,
    margin,
    70,
  );
  y = 132;

  line(`${analysis.overallScore}% of this role can be automated or AI-assisted`, 15, "bold");
  y += 4;
  line(analysis.summary, 10.5);
  y += 8;
  line(
    `Hours returned: ${totals.hoursPerWeek}/week · ${totals.hoursPerMonth}/month · ${totals.hoursPerYear}/year   |   Indicative annual value: ${formatMoney(totals.annualSaving, cur)} (at ${formatMoney(analysis.hourlyCost, cur)}/hour)   |   ${totals.fteEquivalent} FTE-equivalent`,
    10,
  );
  y += 12;

  line("Task-by-task breakdown", 13, "bold");
  y += 4;
  for (const t of [...analysis.tasks].sort((a, b) => b.score - a.score)) {
    line(`${t.task}  —  ${BAND_META[t.band].label} (${t.score}%)`, 10.5, "bold");
    line(`Why: ${t.reason}`, 9.5, "normal", "#475569");
    line(
      `Approach: ${t.approach} · ${t.hoursPerWeek}h/wk today → ${t.hoursSavedPerWeek}h/wk returned${t.overridden ? " (adjusted by reviewer)" : ""}`,
      9.5,
      "italic",
      "#475569",
    );
    y += 6;
  }

  y += 6;
  line("Recommended next actions", 13, "bold");
  analysis.nextActions.forEach((a, i) => line(`${i + 1}. ${a}`, 10.5));
  y += 6;
  line(`Role flag: ${FLAG_META[analysis.flag].label}`, 10, "italic", "#475569");

  y += 14;
  line("Important notices & disclaimer", 12, "bold");
  for (const n of EXPORT_NOTICES) line(`${n.title}: ${n.body}`, 8.5, "normal", "#475569");
  line(
    "Automation assessments are indicative planning estimates, not commitments, and must not be used as the sole basis for role or headcount decisions.",
    8.5,
    "italic",
    "#475569",
  );

  doc.save(`${safeName(analysis.roleTitle)}-automation-analysis.pdf`);
}