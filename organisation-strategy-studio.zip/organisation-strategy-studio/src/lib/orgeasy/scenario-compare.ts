import type { Scenario, ReductionLever } from "./types";
import { LEVER_META, REDUCTION_LEVERS } from "./types";
import { isCurrentState, phaseTitle } from "./phases";
import { analyseSpans } from "./span";
import { effectiveRules, separationSummary } from "./country-costs";

export interface CompareLever {
  lever: ReductionLever;
  label: string;
  short: string;
  hex: string;
  positions: number;
}

/** One column of the side-by-side comparison. */
export interface CompareColumn {
  id: string;
  name: string;
  title: string;
  isCurrent: boolean;
  currency: string;
  /** Positions in this scenario (current headcount for the baseline, planned otherwise). */
  positions: number;
  /** Annual people cost at this scenario's own state. */
  annualCost: number;
  /** Positions removed / added relative to this scenario's own current-state columns. */
  rolesRemoved: number;
  rolesAdded: number;
  /** One-off separation cost range for the exits inside this scenario. */
  separationExits: number;
  separationLow: number;
  separationMid: number;
  separationHigh: number;
  highRiskMarkets: number;
  collectiveMarkets: number;
  /** Structure signals. */
  layers: number;
  avgSpan: number;
  managerRatio: number;
  managerCount: number;
  narrowSpans: number;
  wideSpans: number;
  /** Levers that produced the reductions in this scenario, biggest first. */
  levers: CompareLever[];
  countries: number;
  departments: number;
}

function sum(list: number[]) {
  return list.reduce((a, b) => a + b, 0);
}

/** Builds the metric column for a single scenario, priced on its own rules. */
export function buildCompareColumn(scenario: Scenario): CompareColumn {
  const isCurrent = isCurrentState(scenario);
  const positions = sum(
    scenario.employees.map((e) => (isCurrent ? e.currentHeadcount : e.plannedHeadcount)),
  );
  const annualCost = sum(
    scenario.employees.map((e) =>
      isCurrent ? e.currentCost * e.currentHeadcount : e.plannedCost * e.plannedHeadcount,
    ),
  );

  let rolesRemoved = 0;
  let rolesAdded = 0;
  const leverPositions: Record<ReductionLever, number> = {
    headcount: 0,
    span: 0,
    duplicate: 0,
    automation: 0,
    agent: 0,
  };
  if (!isCurrent) {
    for (const e of scenario.employees) {
      const cut = e.currentHeadcount - e.plannedHeadcount;
      if (cut > 0) {
        rolesRemoved += cut;
        leverPositions[e.reductionLever ?? "headcount"] += cut;
      }
      if (e.currentHeadcount === 0 && e.plannedHeadcount > 0) rolesAdded += e.plannedHeadcount;
    }
  }

  const sep = isCurrent
    ? null
    : separationSummary(scenario.employees, effectiveRules(scenario));
  const spans = analyseSpans(scenario);

  return {
    id: scenario.id,
    name: scenario.name,
    title: phaseTitle(scenario),
    isCurrent,
    currency: scenario.currency ?? "USD",
    positions,
    annualCost,
    rolesRemoved,
    rolesAdded,
    separationExits: sep?.exits ?? 0,
    separationLow: sep?.low ?? 0,
    separationMid: sep?.mid ?? 0,
    separationHigh: sep?.high ?? 0,
    highRiskMarkets: sep?.highRiskCountries.filter((c) => c.exits > 0).length ?? 0,
    collectiveMarkets: sep?.collectiveMarkets.length ?? 0,
    layers: spans.maxLayer,
    avgSpan: spans.avgSpan,
    managerRatio: spans.managerRatio,
    managerCount: spans.managerCount,
    narrowSpans: spans.narrow.length,
    wideSpans: spans.wide.length,
    levers: REDUCTION_LEVERS.map((lever) => ({
      lever,
      ...LEVER_META[lever],
      positions: leverPositions[lever],
    }))
      .filter((l) => l.positions > 0)
      .sort((a, b) => b.positions - a.positions),
    countries: new Set(scenario.employees.map((e) => e.country).filter(Boolean)).size,
    departments: new Set(scenario.employees.map((e) => e.department).filter(Boolean)).size,
  };
}

export type MetricFormat = "number" | "money" | "pct" | "decimal";
/** Which direction of movement reads as a better outcome for the programme. */
export type MetricGoal = "lower" | "higher" | "none";

export interface CompareMetric {
  key: string;
  label: string;
  hint?: string;
  format: MetricFormat;
  goal: MetricGoal;
  /** Metrics that only exist for future scenarios show a dash on the baseline. */
  futureOnly?: boolean;
  value: (c: CompareColumn) => number;
}

export interface CompareMetricGroup {
  title: string;
  metrics: CompareMetric[];
}

export const COMPARE_GROUPS: CompareMetricGroup[] = [
  {
    title: "Size and cost",
    metrics: [
      {
        key: "positions",
        label: "Positions",
        hint: "Total funded positions in this state",
        format: "number",
        goal: "none",
        value: (c) => c.positions,
      },
      {
        key: "annualCost",
        label: "Annual people cost",
        hint: "Run-rate salary cost at this state",
        format: "money",
        goal: "lower",
        value: (c) => c.annualCost,
      },
      {
        key: "rolesRemoved",
        label: "Positions removed",
        format: "number",
        goal: "none",
        futureOnly: true,
        value: (c) => c.rolesRemoved,
      },
      {
        key: "rolesAdded",
        label: "New capability roles",
        format: "number",
        goal: "higher",
        futureOnly: true,
        value: (c) => c.rolesAdded,
      },
    ],
  },
  {
    title: "One-off transition cost",
    metrics: [
      {
        key: "separationMid",
        label: "Separation cost (mid case)",
        hint: "Notice, severance, legal fees, outplacement and tribunal exposure",
        format: "money",
        goal: "lower",
        futureOnly: true,
        value: (c) => c.separationMid,
      },
      {
        key: "separationExits",
        label: "Exits priced",
        format: "number",
        goal: "lower",
        futureOnly: true,
        value: (c) => c.separationExits,
      },
      {
        key: "highRiskMarkets",
        label: "High consultation-risk markets",
        format: "number",
        goal: "lower",
        futureOnly: true,
        value: (c) => c.highRiskMarkets,
      },
      {
        key: "collectiveMarkets",
        label: "Collective process triggered",
        hint: "Markets over the collective consultation threshold",
        format: "number",
        goal: "lower",
        futureOnly: true,
        value: (c) => c.collectiveMarkets,
      },
    ],
  },
  {
    title: "Shape: layers and spans",
    metrics: [
      {
        key: "layers",
        label: "Management layers",
        format: "number",
        goal: "lower",
        value: (c) => c.layers,
      },
      {
        key: "avgSpan",
        label: "Average span of control",
        hint: "Direct reports per manager",
        format: "decimal",
        goal: "higher",
        value: (c) => c.avgSpan,
      },
      {
        key: "managerRatio",
        label: "Manager ratio",
        hint: "Share of positions holding direct reports",
        format: "pct",
        goal: "lower",
        value: (c) => c.managerRatio,
      },
      {
        key: "narrowSpans",
        label: "Managers below benchmark span",
        format: "number",
        goal: "lower",
        value: (c) => c.narrowSpans,
      },
    ],
  },
];

export function formatMetric(value: number, format: MetricFormat, currency: string) {
  if (format === "money") {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency,
      maximumFractionDigits: 0,
    }).format(Math.round(value));
  }
  if (format === "pct") return `${(value * 100).toFixed(1)}%`;
  if (format === "decimal") return value.toFixed(1);
  return Math.round(value).toLocaleString();
}

/** Plain-text version of the side-by-side table for meeting notes. */
export function compareToText(columns: CompareColumn[]) {
  const currency = columns[0]?.currency ?? "USD";
  const lines = [
    "Scenario comparison",
    columns.map((c) => c.title).join(" | "),
    "",
  ];
  for (const group of COMPARE_GROUPS) {
    lines.push(group.title.toUpperCase());
    for (const metric of group.metrics) {
      const cells = columns.map((c) =>
        metric.futureOnly && c.isCurrent ? "—" : formatMetric(metric.value(c), metric.format, currency),
      );
      lines.push(`  ${metric.label}: ${cells.join(" | ")}`);
    }
    lines.push("");
  }
  lines.push("MAIN LEVERS");
  for (const c of columns) {
    lines.push(
      `  ${c.title}: ${
        c.levers.length
          ? c.levers.map((l) => `${l.label} (${l.positions})`).join(", ")
          : "no reduction levers applied"
      }`,
    );
  }
  return lines.join("\n");
}
