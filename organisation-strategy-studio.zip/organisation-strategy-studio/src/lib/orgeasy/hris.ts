import type { Employee, EmploymentType } from "./types";
import { parseCsv } from "./csv";
import { uid } from "./store";

export type HrisId = "workday" | "sap_successfactors" | "sap_hcm" | "oracle_hcm";

export interface HrisSystem {
  id: HrisId;
  name: string;
  vendor: string;
  blurb: string;
  /** How the customer produces the extract we ingest. */
  howTo: string[];
  /** Credentials a live API connection would need. */
  credentials: string[];
  /** Column aliases we auto-detect, per Organisation Strategy Studio field. */
  aliases: Partial<Record<keyof Employee, string[]>>;
  sample: string;
}

export const HRIS_SYSTEMS: HrisSystem[] = [
  {
    id: "workday",
    name: "Workday HCM",
    vendor: "Workday",
    blurb: "Worker, position and organisation data from Workday Reports-as-a-Service or RaaS CSV.",
    howTo: [
      "In Workday, run the “Worker Details” or a custom Advanced report with worker, position, supervisory org and cost fields.",
      "Share the report as Reports-as-a-Service and export it as CSV.",
      "Upload the CSV here — column names are matched automatically.",
    ],
    credentials: [
      "Workday tenant name (e.g. acme_prod)",
      "REST/RaaS endpoint URL",
      "Integration System User client ID & secret (OAuth)",
    ],
    aliases: {
      name: ["worker", "legal name", "preferred name", "employee name", "worker name"],
      title: ["business title", "job profile", "position title", "job title"],
      department: ["supervisory organization", "cost center", "organization", "department"],
      country: ["location country", "country", "work location country", "location"],
      managerId: ["manager employee id", "manager id", "supervisor employee id", "manages"],
      currentCost: ["total base pay", "annual salary", "base pay annualized", "compensation"],
      employmentType: ["worker type", "employee type", "time type"],
      serviceMonths: ["length of service in months", "months of service", "continuous service"],
      id: ["employee id", "worker id", "employee_id"],
    },
    sample:
      "Employee ID,Worker,Business Title,Supervisory Organization,Location Country,Manager Employee ID,Total Base Pay,Worker Type,Length of Service in Months\n" +
      "W-1001,Amara Osei,Chief Executive Officer,Executive,United Kingdom,,410000,Employee,142\n" +
      "W-1002,Diego Salas,VP Engineering,Technology,United States,W-1001,295000,Employee,71",
  },
  {
    id: "sap_successfactors",
    name: "SAP SuccessFactors",
    vendor: "SAP",
    blurb: "Employee Central OData extract (EmpJob, EmpEmployment, PerPerson) or ad-hoc report CSV.",
    howTo: [
      "Build an Ad Hoc Report on Employee Central with person, job, department, location and pay fields.",
      "Export the report as CSV (or pull the same fields from the OData API).",
      "Upload it here — Organisation Strategy Studio maps SuccessFactors column names on its own.",
    ],
    credentials: [
      "SuccessFactors API server URL (e.g. api4.successfactors.com)",
      "Company ID",
      "OAuth client ID + X.509 private key (or API user credentials)",
    ],
    aliases: {
      name: ["display name", "full name", "employee", "person name"],
      title: ["job title", "position title", "job code description", "jobtitle"],
      department: ["department", "division", "business unit", "cost center"],
      country: ["country/region", "country", "location country", "legal entity country"],
      managerId: ["manager user id", "supervisor", "manager", "manager id"],
      currentCost: ["annualized salary", "pay rate annual", "compa base salary", "total target cash"],
      employmentType: ["employment type", "employee class", "assignment type"],
      serviceMonths: ["service months", "seniority in months", "tenure months"],
      id: ["user id", "person id external", "employee id"],
    },
    sample:
      "User ID,Display Name,Job Title,Department,Country/Region,Manager User ID,Annualized Salary,Employment Type,Service Months\n" +
      "10001,Amara Osei,Chief Executive Officer,Executive,United Kingdom,,410000,Full Time,142\n" +
      "10002,Diego Salas,VP Engineering,Technology,United States,10001,295000,Full Time,71",
  },
  {
    id: "sap_hcm",
    name: "SAP HCM / ECC (PA)",
    vendor: "SAP",
    blurb: "Personnel Administration infotype extract (0001 org assignment, 0002, 0008 basic pay).",
    howTo: [
      "Run transaction PA20/S_AHR_61016362 or an SQVI query across infotypes 0001, 0002 and 0008.",
      "Export the ALV grid to spreadsheet and save as CSV.",
      "Upload the CSV — Personnel Number becomes the role identifier.",
    ],
    credentials: [
      "SAP system ID + client number",
      "RFC/OData service endpoint",
      "Technical user with HR read authorisation",
    ],
    aliases: {
      name: ["employee name", "name of employee or applicant", "complete name"],
      title: ["position text", "job text", "position", "job"],
      department: ["organizational unit", "org unit text", "cost center", "personnel area"],
      country: ["country key", "country of company code", "country"],
      managerId: ["manager personnel number", "chief position holder", "reports to"],
      currentCost: ["annual salary", "annual amount", "basic pay annual", "wage type amount"],
      employmentType: ["employee group", "employee subgroup", "work contract"],
      serviceMonths: ["service months", "seniority months"],
      id: ["personnel number", "pernr", "employee number"],
    },
    sample:
      "Personnel Number,Employee Name,Position Text,Organizational Unit,Country Key,Manager Personnel Number,Annual Salary,Employee Group,Service Months\n" +
      "00010001,Amara Osei,Chief Executive Officer,Executive,GB,,410000,Active,142\n" +
      "00010002,Diego Salas,VP Engineering,Technology,US,00010001,295000,Active,71",
  },
  {
    id: "oracle_hcm",
    name: "Oracle Fusion HCM",
    vendor: "Oracle",
    blurb: "HCM Extracts or BI Publisher worker/assignment report from Oracle Fusion Cloud HCM.",
    howTo: [
      "Create an HCM Extract (or BI Publisher report) over Worker and Assignment with department, location and salary.",
      "Deliver it as CSV to a WebCenter/SFTP destination, or download it from Reports & Analytics.",
      "Upload the CSV here.",
    ],
    credentials: [
      "Fusion pod URL (e.g. https://acme.fa.us2.oraclecloud.com)",
      "Integration user with HCM REST role",
      "OAuth client credentials or basic auth secret",
    ],
    aliases: {
      name: ["person name", "display name", "full name", "worker"],
      title: ["job name", "assignment name", "job title", "position name"],
      department: ["department name", "department", "business unit", "organization"],
      country: ["location country", "country", "work location", "legal employer country"],
      managerId: ["manager person number", "line manager", "manager", "supervisor person number"],
      currentCost: ["annual salary amount", "salary amount", "annualized salary", "base salary"],
      employmentType: ["assignment category", "worker type", "system person type"],
      serviceMonths: ["length of service months", "service months"],
      id: ["person number", "assignment number", "worker number"],
    },
    sample:
      "Person Number,Person Name,Job Name,Department Name,Location Country,Manager Person Number,Annual Salary Amount,Assignment Category,Length of Service Months\n" +
      "P0001,Amara Osei,Chief Executive Officer,Executive,United Kingdom,,410000,Full-time regular,142\n" +
      "P0002,Diego Salas,VP Engineering,Technology,United States,P0001,295000,Full-time regular,71",
  },
];

export function getSystem(id: HrisId) {
  return HRIS_SYSTEMS.find((s) => s.id === id)!;
}

export type FieldKey =
  | "id"
  | "name"
  | "title"
  | "department"
  | "country"
  | "managerId"
  | "currentCost"
  | "employmentType"
  | "serviceMonths";

export const MAPPABLE_FIELDS: { key: FieldKey; label: string; required?: boolean }[] = [
  { key: "id", label: "Role / employee ID" },
  { key: "name", label: "Employee name" },
  { key: "title", label: "Job title", required: true },
  { key: "department", label: "Department" },
  { key: "country", label: "Country" },
  { key: "managerId", label: "Manager ID" },
  { key: "currentCost", label: "Annual cost" },
  { key: "employmentType", label: "Employment type" },
  { key: "serviceMonths", label: "Service (months)" },
];

const COUNTRY_CODES: Record<string, string> = {
  GB: "United Kingdom",
  UK: "United Kingdom",
  US: "United States",
  USA: "United States",
  DE: "Germany",
  FR: "France",
  NL: "Netherlands",
  ES: "Spain",
  IT: "Italy",
  SE: "Sweden",
  PL: "Poland",
  IE: "Ireland",
  IN: "India",
  SG: "Singapore",
  AU: "Australia",
  CA: "Canada",
  BR: "Brazil",
  MX: "Mexico",
  JP: "Japan",
  CN: "China",
  ZA: "South Africa",
  AE: "United Arab Emirates",
};

function normalizeCountry(raw: string) {
  const v = raw.trim();
  if (!v) return "United States";
  return COUNTRY_CODES[v.toUpperCase()] ?? v;
}

function normalizeEmploymentType(raw: string): EmploymentType {
  const v = raw.toLowerCase();
  if (/part/.test(v)) return "Part-time";
  if (/contract|contingent|agency/.test(v)) return "Contract";
  if (/fixed|temp/.test(v)) return "Fixed-term";
  if (/intern|apprentice|student/.test(v)) return "Intern";
  if (/vacan|open|to be hired/.test(v)) return "Open Role";
  return "Full-time";
}

export interface ParsedExtract {
  headers: string[];
  rows: string[][];
}

export function parseExtract(text: string): ParsedExtract {
  const rows = parseCsv(text);
  const headers = (rows[0] ?? []).map((h) => h.trim());
  return { headers, rows: rows.slice(1) };
}

const NORMALIZE = (value: string) =>
  value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();

const FILLER = new Set(["of", "in", "the", "no", "nbr", "number", "num", "code", "text", "desc", "description"]);
const tokenise = (value: string) => NORMALIZE(value).split(" ").filter((t) => t && !FILLER.has(t));

const MANAGER_WORDS = /\b(manager|managers|supervisor|reports to|chief position|line manager)\b/;

/** Generic aliases applied on top of the vendor list so unusual headers still land. */
const GENERIC_ALIASES: Record<FieldKey, string[]> = {
  id: ["id", "employee id", "worker id", "person number", "personnel number", "position id"],
  name: ["name", "employee name", "worker name", "incumbent"],
  title: ["title", "job title", "role", "position title", "job profile"],
  department: ["department", "function", "organization", "org unit", "cost center", "business unit"],
  country: ["country", "location", "market", "geography"],
  managerId: ["manager id", "manager", "supervisor id", "reports to", "manager worker id"],
  currentCost: ["salary", "annual cost", "base pay", "compensation", "total cost", "fully loaded cost"],
  employmentType: ["employment type", "worker type", "contract type", "employee class"],
  serviceMonths: ["service months", "length of service", "tenure", "seniority"],
};

/** How well a file header matches one alias. 0 = no match. */
function aliasScore(header: string, alias: string) {
  const h = NORMALIZE(header);
  const a = NORMALIZE(alias);
  if (!h || !a) return 0;
  if (h === a) return 100;
  if (h.includes(a)) return 88 - Math.min(h.length - a.length, 20);
  if (a.includes(h)) return 70 - Math.min(a.length - h.length, 20);
  const ht = new Set(tokenise(header));
  const at = tokenise(alias);
  if (!at.length || !ht.size) return 0;
  const hit = at.filter((t) => ht.has(t)).length;
  if (!hit) return 0;
  return Math.round((hit / at.length) * 55);
}

/**
 * Best-guess mapping of file headers onto Organisation Strategy Studio fields.
 * Vendor aliases score first, generic aliases catch the rest, and each column is
 * claimed by only one field so "Worker ID" and "Manager Worker ID" never collide.
 */
export function autoMap(headers: string[], system: HrisSystem): Record<FieldKey, string> {
  const mapping = {} as Record<FieldKey, string>;
  for (const { key } of MAPPABLE_FIELDS) mapping[key] = "";

  const candidates: { field: FieldKey; header: string; score: number }[] = [];
  for (const { key } of MAPPABLE_FIELDS) {
    const aliases = [
      ...((system.aliases[key as keyof Employee] ?? []) as string[]),
      ...GENERIC_ALIASES[key],
      key,
      key.replace(/([A-Z])/g, " $1"),
    ];
    for (const header of headers) {
      const isManagerHeader = MANAGER_WORDS.test(NORMALIZE(header));
      // A manager column can only be the manager field, and vice versa.
      if (key === "managerId" && !isManagerHeader) continue;
      if (key !== "managerId" && isManagerHeader) continue;
      const score = Math.max(...aliases.map((a) => aliasScore(header, a)), 0);
      if (score >= 40) candidates.push({ field: key, header, score });
    }
  }

  candidates.sort((a, b) => b.score - a.score);
  const takenHeaders = new Set<string>();
  for (const c of candidates) {
    if (mapping[c.field] || takenHeaders.has(c.header)) continue;
    mapping[c.field] = c.header;
    takenHeaders.add(c.header);
  }
  return mapping;
}

/** Detect which HRIS an extract most likely came from, by header overlap. */
export function detectSystem(headers: string[]): HrisSystem {
  const lower = headers.map((h) => h.trim().toLowerCase());
  let best = HRIS_SYSTEMS[0]!;
  let bestScore = -1;
  for (const system of HRIS_SYSTEMS) {
    const all = Object.values(system.aliases).flat() as string[];
    const score = all.filter((a) => lower.some((h) => h === a || h.includes(a))).length;
    if (score > bestScore) {
      bestScore = score;
      best = system;
    }
  }
  return best;
}

export interface ImportResult {
  employees: Employee[];
  warnings: string[];
  skipped: number;
}

export function extractToEmployees(
  extract: ParsedExtract,
  mapping: Record<FieldKey, string>,
  options: { asFutureState?: boolean } = {},
): ImportResult {
  const warnings: string[] = [];
  if (!mapping.title) warnings.push("No job title column mapped — roles will be labelled Untitled.");

  const col = (field: FieldKey) => extract.headers.indexOf(mapping[field] ?? "");
  const num = (v: string) => {
    const n = Number(String(v ?? "").replace(/[^0-9.-]/g, ""));
    return Number.isFinite(n) ? n : 0;
  };
  const cell = (row: string[], field: FieldKey) => {
    const i = col(field);
    return i >= 0 ? (row[i] ?? "").trim() : "";
  };

  const externalToId = new Map<string, string>();
  let skipped = 0;

  const staged = extract.rows
    .filter((row) => row.some((c) => c.trim() !== ""))
    .map((row) => {
      const external = cell(row, "id");
      const id = uid();
      if (external) externalToId.set(external, id);
      return { row, id, external };
    });

  const employees: Employee[] = [];
  for (const { row, id } of staged) {
    const title = cell(row, "title");
    const name = cell(row, "name");
    if (!title && !name) {
      skipped += 1;
      continue;
    }
    const cost = num(cell(row, "currentCost"));
    employees.push({
      id,
      name,
      isOpenRole: name === "",
      title: title || "Untitled role",
      department: cell(row, "department"),
      country: normalizeCountry(cell(row, "country")),
      responsibilities: "",
      currentHeadcount: options.asFutureState ? 0 : 1,
      plannedHeadcount: 1,
      employmentType: normalizeEmploymentType(cell(row, "employmentType")),
      managerId: cell(row, "managerId") || null,
      status: options.asFutureState ? "planned" : "current",
      currentCost: options.asFutureState ? 0 : cost,
      plannedCost: cost,
      serviceMonths: num(cell(row, "serviceMonths")),
    });
  }

  // Resolve manager references from source IDs to internal IDs.
  let unresolved = 0;
  for (const e of employees) {
    if (!e.managerId) continue;
    const resolved = externalToId.get(e.managerId);
    if (resolved && resolved !== e.id) e.managerId = resolved;
    else {
      e.managerId = null;
      unresolved += 1;
    }
  }
  if (unresolved) warnings.push(`${unresolved} manager reference(s) could not be matched — those roles sit at the top level.`);
  if (skipped) warnings.push(`${skipped} row(s) skipped: no name or title.`);

  return { employees, warnings, skipped };
}
