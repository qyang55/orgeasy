import type { Employee } from "./types";

export type LayoutKind =
  | "vertical"
  | "horizontal"
  | "radial"
  | "mindmap"
  | "compact"
  | "expanded"
  | "department";

export const LAYOUT_OPTIONS: { value: LayoutKind; label: string }[] = [
  { value: "vertical", label: "Vertical Tree" },
  { value: "horizontal", label: "Horizontal Tree" },
  { value: "mindmap", label: "Mind Map / Capability" },
  { value: "radial", label: "Radial Rings" },
  { value: "compact", label: "Compact" },
  { value: "expanded", label: "Expanded" },
  { value: "department", label: "Department Grouped" },
];

/** Layouts that draw straight spokes rather than orthogonal tree elbows. */
export const RADIAL_LAYOUTS: LayoutKind[] = ["radial", "mindmap"];

export interface TreeNode {
  employee: Employee;
  children: TreeNode[];
  depth: number;
}

export function buildForest(employees: Employee[]): TreeNode[] {
  const byId = new Map(employees.map((e) => [e.id, e]));
  const nodes = new Map<string, TreeNode>(
    employees.map((e) => [e.id, { employee: e, children: [], depth: 0 }]),
  );
  const roots: TreeNode[] = [];
  for (const e of employees) {
    const node = nodes.get(e.id)!;
    const parent = e.managerId && byId.has(e.managerId) ? nodes.get(e.managerId) : undefined;
    if (parent && parent !== node) parent.children.push(node);
    else roots.push(node);
  }
  const setDepth = (n: TreeNode, d: number) => {
    n.depth = d;
    n.children.forEach((c) => setDepth(c, d + 1));
  };
  roots.forEach((r) => setDepth(r, 0));
  return roots;
}

export interface Positioned {
  id: string;
  x: number;
  y: number;
}

const SIZES: Record<LayoutKind, { w: number; h: number; gapX: number; gapY: number }> = {
  // Cards are deliberately large: at the default "readable size" zoom a role
  // title should be comfortable to read without leaning into the screen.
  vertical: { w: 328, h: 150, gapX: 56, gapY: 118 },
  horizontal: { w: 336, h: 150, gapX: 170, gapY: 46 },
  radial: { w: 312, h: 144, gapX: 56, gapY: 116 },
  mindmap: { w: 300, h: 136, gapX: 60, gapY: 108 },
  compact: { w: 252, h: 112, gapX: 30, gapY: 76 },
  expanded: { w: 396, h: 196, gapX: 84, gapY: 186 },
  department: { w: 328, h: 150, gapX: 56, gapY: 118 },
};

export function nodeSize(kind: LayoutKind) {
  return SIZES[kind];
}

/**
 * Ids that should start collapsed so only the top `depth + 1` layers are
 * expanded (default: top three layers). Keeps big charts readable on load.
 */
export function collapseBelowDepth(employees: Employee[], depth = 2): Set<string> {
  const collapsed = new Set<string>();
  const walk = (n: TreeNode) => {
    if (n.depth >= depth && n.children.length) collapsed.add(n.employee.id);
    n.children.forEach(walk);
  };
  buildForest(employees).forEach(walk);
  return collapsed;
}

export function computeLayout(
  employees: Employee[],
  kind: LayoutKind,
  collapsed: Set<string>,
): { positions: Positioned[]; visible: Set<string>; forest: TreeNode[] } {
  const forest = buildForest(employees);
  const { w, h, gapX, gapY } = SIZES[kind];
  const positions: Positioned[] = [];
  const visible = new Set<string>();

  if (kind === "department") {
    const groups = new Map<string, Employee[]>();
    for (const e of employees) {
      const key = e.department || "Unassigned";
      groups.set(key, [...(groups.get(key) ?? []), e]);
    }
    let x = 0;
    for (const [, list] of [...groups.entries()].sort((a, b) => a[0].localeCompare(b[0]))) {
      list.forEach((e, i) => {
        positions.push({ id: e.id, x, y: i * (h + 24) + 60 });
        visible.add(e.id);
      });
      x += w + gapX * 2;
    }
    return { positions, visible, forest };
  }

  if (kind === "mindmap") {
    // Capability mind map: the top of the house sits in the centre, each
    // function claims an angular wedge and its teams/roles fan outwards, so
    // the picture reads as a capability map rather than a reporting ladder.
    const visibleChildren = (n: TreeNode) => (collapsed.has(n.employee.id) ? [] : n.children);

    const leaves = new Map<string, number>();
    const countLeaves = (n: TreeNode): number => {
      const kids = visibleChildren(n);
      const total = kids.length ? kids.reduce((a, c) => a + countLeaves(c), 0) : 1;
      leaves.set(n.employee.id, total);
      return total;
    };
    forest.forEach(countLeaves);

    // Ring radii grow enough to fit every card sitting on that ring.
    const perDepth = new Map<number, number>();
    const tally = (n: TreeNode, d: number) => {
      perDepth.set(d, (perDepth.get(d) ?? 0) + 1);
      visibleChildren(n).forEach((c) => tally(c, d + 1));
    };
    const offset = forest.length > 1 ? 1 : 0;
    forest.forEach((r) => tally(r, offset));
    const step = h + gapY + 40;
    const radii: number[] = [0];
    const maxDepth = Math.max(0, ...[...perDepth.keys()]);
    for (let d = 1; d <= maxDepth; d += 1) {
      const need = ((perDepth.get(d) ?? 1) * (w + gapX)) / (Math.PI * 2);
      radii[d] = Math.max((radii[d - 1] ?? 0) + step, need);
    }

    const place = (n: TreeNode, d: number, a0: number, a1: number) => {
      const angle = (a0 + a1) / 2;
      const radius = radii[d] ?? d * step;
      positions.push({
        id: n.employee.id,
        x: Math.cos(angle) * radius - w / 2,
        y: Math.sin(angle) * radius - h / 2,
      });
      visible.add(n.employee.id);
      const kids = visibleChildren(n);
      if (!kids.length) return;
      const total = kids.reduce((a, c) => a + (leaves.get(c.employee.id) ?? 1), 0) || 1;
      // A leaf-weighted wedge keeps dense functions from squashing small ones.
      const spread = d === 0 ? Math.PI * 2 : a1 - a0;
      let cursorAngle = d === 0 ? -Math.PI / 2 : a0;
      for (const kid of kids) {
        const share = ((leaves.get(kid.employee.id) ?? 1) / total) * spread;
        place(kid, d + 1, cursorAngle, cursorAngle + share);
        cursorAngle += share;
      }
    };

    if (forest.length === 1) {
      place(forest[0]!, 0, -Math.PI / 2, Math.PI * 1.5);
    } else {
      const total = forest.reduce((a, r) => a + (leaves.get(r.employee.id) ?? 1), 0) || 1;
      let cursorAngle = -Math.PI / 2;
      for (const root of forest) {
        const share = ((leaves.get(root.employee.id) ?? 1) / total) * Math.PI * 2;
        place(root, 1, cursorAngle, cursorAngle + share);
        cursorAngle += share;
      }
    }
    return { positions, visible, forest };
  }

  if (kind === "radial") {
    const levels = new Map<number, TreeNode[]>();
    const walk = (n: TreeNode) => {
      levels.set(n.depth, [...(levels.get(n.depth) ?? []), n]);
      if (!collapsed.has(n.employee.id)) n.children.forEach(walk);
    };
    forest.forEach(walk);
    for (const [depth, list] of levels) {
      const radius = depth * 300;
      list.forEach((n, i) => {
        const angle = (i / Math.max(list.length, 1)) * Math.PI * 2 - Math.PI / 2;
        positions.push({
          id: n.employee.id,
          x: depth === 0 ? 0 : Math.cos(angle) * radius,
          y: depth === 0 ? i * 200 : Math.sin(angle) * radius,
        });
        visible.add(n.employee.id);
      });
    }
    return { positions, visible, forest };
  }

  const horizontal = kind === "horizontal";
  let cursor = 0;

  const place = (n: TreeNode): number => {
    visible.add(n.employee.id);
    const isCollapsed = collapsed.has(n.employee.id);
    const kids = isCollapsed ? [] : n.children;
    let center: number;
    if (!kids.length) {
      center = cursor;
      cursor += horizontal ? h + gapY : w + gapX;
    } else {
      const centers = kids.map(place);
      center = (centers[0]! + centers[centers.length - 1]!) / 2;
    }
    if (horizontal) positions.push({ id: n.employee.id, x: n.depth * (w + gapX), y: center });
    else positions.push({ id: n.employee.id, x: center, y: n.depth * (h + gapY) });
    return center;
  };

  forest.forEach((root) => {
    place(root);
    cursor += horizontal ? gapY * 2 : gapX * 2;
  });

  return { positions, visible, forest };
}