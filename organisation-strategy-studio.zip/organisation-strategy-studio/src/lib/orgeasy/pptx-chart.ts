import type PptxGenJSType from "pptxgenjs";
import type { Employee, Scenario } from "./types";
import { STATUS_META } from "./types";
import { computeLayout, nodeSize } from "./layout";

/**
 * Draws an org chart as native PowerPoint shapes (rounded boxes + connector
 * lines) instead of a flat image, so the exported deck stays fully editable:
 * every box can be moved, recoloured and retyped in PowerPoint.
 */

export interface ChartShapeBox {
  x: number;
  y: number;
  w: number;
  h: number;
}

const INK = "1E293B";
const MUTED = "64748B";
const CARD = "FFFFFF";
const LINE = "94A3B8";
const BODY = "Calibri";

export function addEditableChart(
  slide: PptxGenJSType.Slide,
  scenario: Scenario,
  box: ChartShapeBox,
): boolean {
  const { w: nw, h: nh } = nodeSize("vertical");
  const { positions } = computeLayout(scenario.employees, "vertical", new Set());
  if (!positions.length) return false;

  const byId = new Map(positions.map((p) => [p.id, p]));
  const employees = new Map(scenario.employees.map((e) => [e.id, e]));
  const minX = Math.min(...positions.map((p) => p.x));
  const minY = Math.min(...positions.map((p) => p.y));
  const contentW = Math.max(...positions.map((p) => p.x)) - minX + nw;
  const contentH = Math.max(...positions.map((p) => p.y)) - minY + nh;

  // Uniform scale so the whole tree fits the slide area.
  const scale = Math.min(box.w / contentW, box.h / contentH);
  const offsetX = box.x + (box.w - contentW * scale) / 2;
  const offsetY = box.y + (box.h - contentH * scale) / 2;
  const sx = (x: number) => offsetX + (x - minX) * scale;
  const sy = (y: number) => offsetY + (y - minY) * scale;
  const cardW = nw * scale;
  const cardH = nh * scale;

  const hLine = (x1: number, x2: number, y: number, dash: boolean) => {
    const left = Math.min(x1, x2);
    slide.addShape("line", {
      x: left,
      y,
      w: Math.abs(x2 - x1),
      h: 0,
      line: { color: LINE, width: 1, dashType: dash ? "dash" : "solid" },
    });
  };
  const vLine = (x: number, y1: number, y2: number, dash: boolean) => {
    const top = Math.min(y1, y2);
    slide.addShape("line", {
      x,
      y: top,
      w: 0,
      h: Math.abs(y2 - y1),
      line: { color: LINE, width: 1, dashType: dash ? "dash" : "solid" },
    });
  };

  /** Three-segment elbow from a manager box down to a report box. */
  const connect = (manager: string, child: string, dash: boolean) => {
    const mp = byId.get(manager);
    const cp = byId.get(child);
    if (!mp || !cp) return;
    const mx = sx(mp.x) + cardW / 2;
    const my = sy(mp.y) + cardH;
    const cx = sx(cp.x) + cardW / 2;
    const cy = sy(cp.y);
    if (cy <= my) {
      hLine(mx, cx, (my + cy) / 2, dash);
      return;
    }
    const mid = (my + cy) / 2;
    vLine(mx, my, mid, dash);
    if (Math.abs(cx - mx) > 0.01) hLine(mx, cx, mid, dash);
    vLine(cx, mid, cy, dash);
  };

  // Connectors first so boxes sit on top of the lines.
  for (const employee of scenario.employees) {
    if (employee.managerId && employees.has(employee.managerId))
      connect(employee.managerId, employee.id, false);
    for (const dotted of employee.dottedManagerIds ?? [])
      if (employees.has(dotted)) connect(dotted, employee.id, true);
  }

  for (const pos of positions) {
    const employee = employees.get(pos.id);
    if (!employee) continue;
    const x = sx(pos.x);
    const y = sy(pos.y);
    const accent = STATUS_META[employee.status]?.hex ?? MUTED;
    slide.addShape("roundRect", {
      x,
      y,
      w: cardW,
      h: cardH,
      rectRadius: 0.05,
      fill: { color: CARD },
      line: { color: accent, width: 1.25 },
      shadow: { type: "outer", blur: 6, offset: 1, angle: 90, color: "94A3B8", opacity: 0.3 },
    });
    slide.addShape("rect", { x, y, w: cardW, h: Math.min(0.06, cardH * 0.12), fill: { color: accent } });
    slide.addText(
      [
        {
          text: employee.name || "Open role",
          options: { fontSize: 9, bold: true, color: INK, breakLine: true },
        },
        { text: employee.title || "—", options: { fontSize: 8, color: MUTED, breakLine: true } },
        { text: metaLine(employee), options: { fontSize: 7, color: accent } },
      ],
      {
        x: x + 0.06,
        y: y + 0.08,
        w: cardW - 0.12,
        h: cardH - 0.14,
        fontFace: BODY,
        valign: "top",
        margin: 0,
        shrinkText: true,
      },
    );
  }
  return true;
}

function metaLine(employee: Employee) {
  const parts = [
    employee.department,
    employee.country,
    `${employee.plannedHeadcount || employee.currentHeadcount || 0} pos`,
  ].filter(Boolean);
  return parts.join(" · ");
}
