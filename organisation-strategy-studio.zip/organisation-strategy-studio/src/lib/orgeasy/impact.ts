import type { Employee, Scenario } from "./types";
import { agentMonthlyDefault, splitPlannedCost } from "./agents";
import {
  computeCostModel,
  costAssumptions,
  type CostAssumptions,
  type CostModelSummary,
} from "./cost-model";
import {
  COUNTRY_COST_RULES,
  exitCostForRole,
  exitCount,
  resolveCountries,
  ruleFor,
  separationSummary,
  type ConsultationRisk,
  type CountryCostRule,
  type SeparationSummary,
} from "./country-costs";

export interface ImpactSummary {
  currentHeadcount: number;
  plannedHeadcount: number;
  headcountDelta: number;
  currentCost: number;
  plannedCost: number;
  costDelta: number;
  /** Planned cost split into people cost and agent running cost. */
  plannedHumanCost: number;
  plannedAgentCost: number;
  plannedHumanHeadcount: number;
  agentPositions: number;
  hybridPositions: number;
  newRoles: Employee[];
  removedRoles: Employee[];
  movedRoles: Employee[];
  unchanged: number;
  byDepartment: {
    department: string;
    currentHeadcount: number;
    plannedHeadcount: number;
    currentCost: number;
    plannedCost: number;
    plannedHumanCost: number;
    plannedAgentCost: number;
  }[];
  byCountry: {
    country: string;
    currentHeadcount: number;
    plannedHeadcount: number;
    currentCost: number;
    plannedCost: number;
    removed: number;
    illustrativeSeverance: number;
    /** One-off separation cost range for this market. */
    separationLow: number;
    separationHigh: number;
    separationMid: number;
    noticeCost: number;
    severanceCost: number;
    risk: ConsultationRisk;
    riskNote: string;
  }[];
  /** One-off separation cost totals and per-country detail. */
  separation: SeparationSummary;
  /** Fully loaded cost model split into fixed, variable and total. */
  costModel: CostModelSummary;
}

export function computeImpact(
  scenario: Scenario | null | undefined,
  agentMonthly: number = agentMonthlyDefault(),
  rules: CountryCostRule[] = COUNTRY_COST_RULES,
  assumptions: CostAssumptions = costAssumptions(),
): ImpactSummary {
  const employees = scenario?.employees ?? [];
  const countries = resolveCountries(employees);
  const sum = (fn: (e: Employee) => number) => employees.reduce((a, e) => a + fn(e), 0);

  const currentHeadcount = sum((e) => e.currentHeadcount);
  const plannedHeadcount = sum((e) => e.plannedHeadcount);
  const currentCost = sum((e) => e.currentCost * e.currentHeadcount);
  const split = splitPlannedCost(employees, agentMonthly);
  const plannedCost = split.humanCost + split.agentCost;

  const deptMap = new Map<string, ImpactSummary["byDepartment"][number]>();
  const countryMap = new Map<string, ImpactSummary["byCountry"][number]>();

  for (const e of employees) {
    const dept = e.department || "Unassigned";
    const d = deptMap.get(dept) ?? {
      department: dept,
      currentHeadcount: 0,
      plannedHeadcount: 0,
      currentCost: 0,
      plannedCost: 0,
      plannedHumanCost: 0,
      plannedAgentCost: 0,
    };
    d.currentHeadcount += e.currentHeadcount;
    d.plannedHeadcount += e.plannedHeadcount;
    d.currentCost += e.currentCost * e.currentHeadcount;
    const deptSplit = splitPlannedCost([e], agentMonthly);
    d.plannedHumanCost += deptSplit.humanCost;
    d.plannedAgentCost += deptSplit.agentCost;
    d.plannedCost += deptSplit.humanCost + deptSplit.agentCost;
    deptMap.set(dept, d);

    const country = countries.get(e.id) ?? "Unspecified";
    const rule = ruleFor(country, rules);
    const c = countryMap.get(country) ?? {
      country,
      currentHeadcount: 0,
      plannedHeadcount: 0,
      currentCost: 0,
      plannedCost: 0,
      removed: 0,
      illustrativeSeverance: 0,
      separationLow: 0,
      separationHigh: 0,
      separationMid: 0,
      noticeCost: 0,
      severanceCost: 0,
      risk: rule.risk,
      riskNote: rule.riskNote,
    };
    c.currentHeadcount += e.currentHeadcount;
    c.plannedHeadcount += e.plannedHeadcount;
    c.currentCost += e.currentCost * e.currentHeadcount;
    c.plannedCost += e.plannedCost * e.plannedHeadcount;
    const exits = exitCount(e);
    if (exits > 0) {
      const cost = exitCostForRole(e, rule, exits);
      c.removed += exits;
      c.noticeCost += cost.noticeCost;
      c.severanceCost += cost.severanceCost;
      c.separationLow += cost.low;
      c.separationHigh += cost.high;
      c.separationMid += cost.mid;
      c.illustrativeSeverance += cost.mid;
    }
    countryMap.set(country, c);
  }

  return {
    currentHeadcount,
    plannedHeadcount,
    headcountDelta: plannedHeadcount - currentHeadcount,
    currentCost,
    plannedCost,
    costDelta: plannedCost - currentCost,
    plannedHumanCost: split.humanCost,
    plannedAgentCost: split.agentCost,
    plannedHumanHeadcount: split.humanHeadcount,
    agentPositions: split.agentRoles,
    hybridPositions: split.hybridRoles,
    newRoles: employees.filter((e) => e.status === "planned"),
    removedRoles: employees.filter((e) => e.status === "to-be-removed"),
    movedRoles: employees.filter((e) => e.status === "moved"),
    unchanged: employees.filter((e) => e.status === "current").length,
    byDepartment: [...deptMap.values()].sort((a, b) => b.currentCost - a.currentCost),
    byCountry: [...countryMap.values()].sort((a, b) => b.currentHeadcount - a.currentHeadcount),
    separation: separationSummary(employees, rules),
    costModel: computeCostModel(employees, assumptions, agentMonthly),
  };
}

export function formatMoney(value: number, currency = "USD") {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    maximumFractionDigits: 0,
  }).format(value || 0);
}

export function formatDelta(value: number) {
  return `${value > 0 ? "+" : ""}${value.toLocaleString()}`;
}