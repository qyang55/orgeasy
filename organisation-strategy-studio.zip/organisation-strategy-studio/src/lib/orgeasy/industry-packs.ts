/**
 * Industry Operating Model Packs.
 *
 * A pack is a curated role library plus a reporting skeleton for one industry.
 * The Automotive pack reuses the nine core automotive functions from the
 * operating-model blueprint and adds the typical supporting functions, then
 * scales the whole structure to a realistic position count for the chosen
 * company size and region. Packs generate ready-to-edit scenarios, and users
 * can save their own editable variants.
 */
import type { Employee, ReductionLever, RoleType, Scenario } from "./types";
import {
  COMPANY_SIZES,
  REGIONS,
  FUNCTION_LABELS,
  FUNCTION_KEYS,
  generateOperatingModel,
  modelToEmployees,
  AGENT_PREFIX,
  type CompanySize,
  type FunctionKey,
  type RegionFocus,
} from "./operating-model";
import { hasConsent } from "./consent";

export { COMPANY_SIZES, REGIONS };
export type { CompanySize, RegionFocus };

/** Pure human structure, or human roles paired with AI agents. */
export type PackVariant = "human" | "hybrid";

export const PACK_VARIANTS: { value: PackVariant; label: string; blurb: string }[] = [
  {
    value: "human",
    label: "Pure human",
    blurb: "Classic structure — every role delivered by a person.",
  },
  {
    value: "hybrid",
    label: "Human + AI Agent",
    blurb: "Agents paired to the roles they support, eligible roles set to hybrid delivery.",
  },
];

/** Target total positions per company size (mid-size lands in the 400–600 band). */
export const SIZE_TARGET: Record<CompanySize, number> = {
  startup: 180,
  midsize: 500,
  enterprise: 1100,
};

export const SIZE_BAND: Record<CompanySize, string> = {
  startup: "150–250 positions",
  midsize: "400–600 positions",
  enterprise: "900–1,300 positions",
};

/**
 * Plain-language explanation of what each company size means and how it changes
 * the generated structure. Shown on the Industry packs page so users understand
 * why the chart looks different when they switch size.
 */
export interface SizeDetail {
  /** Total employees the operating model is designed for. */
  employees: string;
  /** Management layers from CEO to front line. */
  layers: string;
  /** Typical average span of control. */
  span: string;
  /** What structurally changes at this size. */
  changes: string[];
}

export const SIZE_DETAIL: Record<CompanySize, SizeDetail> = {
  startup: {
    employees: "~150–250 employees",
    layers: "3–4 layers",
    span: "Average span 6–8",
    changes: [
      "Single leadership layer: founders and function heads carry delivery work themselves.",
      "Support functions are shared — HR, finance and IT generalists instead of centres of expertise.",
      "One market focus, no regional layer, no shared service centre.",
    ],
  },
  midsize: {
    employees: "~400–600 employees",
    layers: "4–5 layers",
    span: "Average span 7–9",
    changes: [
      "Function heads gain dedicated leads, so specialists no longer report to the top team.",
      "Commercial functions split by channel (retail, fleet, aftersales) rather than one sales team.",
      "First shared-service pockets appear: payroll, order-to-cash, IT support.",
    ],
  },
  enterprise: {
    employees: "~900–1,300 employees in the generated entity (operating models designed for 20,000+ group employees)",
    layers: "5–7 layers",
    span: "Average span 8–11",
    changes: [
      "Adds a regional management layer between global function heads and market delivery.",
      "Centres of expertise (COE) and global business services (GBS) are broken out as their own structures.",
      "Roles carry global / regional / local scope, so duplication between HQ and markets becomes visible.",
      "Plant, quality and supply chain functions scale into multi-site structures with their own leadership.",
      "Governance load rises: legal, compliance, JV and partner management roles are generated explicitly.",
    ],
  },
};

/**
 * Benchmarks for international markets where production runs through joint
 * ventures or contract assembly rather than wholly owned plants. Used to sanity
 * check generated structures in JV-heavy markets.
 */
export interface JvBenchmark {
  market: string;
  model: string;
  /** Share of volume produced through JV / partner plants. */
  jvShare: string;
  /** Indicative org consequence. */
  orgNote: string;
  /** Benchmark ratios to compare against. */
  metrics: { label: string; value: string }[];
}

export const JV_BENCHMARKS: JvBenchmark[] = [
  {
    market: "China",
    model: "50:50 OEM–local JV manufacturing, NEV joint programmes",
    jvShare: "70–95% of local volume",
    orgNote:
      "Manufacturing, quality and much of purchasing sit inside the JV entity. The wholly owned side stays commercial: brand, NEV product planning, JV governance and technical liaison.",
    metrics: [
      { label: "Own-entity share of total headcount", value: "15–25%" },
      { label: "JV governance & liaison roles", value: "1 per 250–400 JV employees" },
      { label: "Layers to JV board", value: "3–4" },
      { label: "Duplication risk (HQ vs JV functions)", value: "High — engineering, quality, HR" },
    ],
  },
  {
    market: "ASEAN (Thailand, Indonesia, Malaysia, Vietnam)",
    model: "CKD/CBU assembly by JV or contract assembler, distributor-led sales",
    jvShare: "50–85% of local volume",
    orgNote:
      "Assembly and localisation engineering are partner-run. The OEM entity keeps supply planning, homologation, dealer development and aftersales parts.",
    metrics: [
      { label: "Own-entity share of total headcount", value: "20–35%" },
      { label: "Supply & localisation roles per assembly site", value: "8–14" },
      { label: "Average span in distributor-led commercial", value: "9–12" },
      { label: "Regional layer", value: "Shared across 3–6 markets" },
    ],
  },
  {
    market: "India",
    model: "Majority-owned JV or technical licence with local partner",
    jvShare: "40–70% of local volume",
    orgNote:
      "Frugal engineering and sourcing are the JV's advantage; the OEM entity carries product line P&L, quality assurance and export programme management.",
    metrics: [
      { label: "Own-entity share of total headcount", value: "30–45%" },
      { label: "Sourcing / localisation engineers per plant", value: "12–20" },
      { label: "Layers CEO to plant shop floor", value: "5–6" },
      { label: "Aftersales roles per 100k vehicles in operation", value: "4–7" },
    ],
  },
  {
    market: "Middle East & Africa",
    model: "National distributor JV, low-volume SKD assembly",
    jvShare: "60–90% of local volume",
    orgNote:
      "Almost all delivery capacity sits with distributor partners. The OEM keeps a lean market office focused on brand, network standards and partner performance.",
    metrics: [
      { label: "Own-entity share of total headcount", value: "5–15%" },
      { label: "Market office size", value: "25–60 positions" },
      { label: "Partner performance managers", value: "1 per 2–4 markets" },
      { label: "Layers in market office", value: "2–3" },
    ],
  },
];

/* ------------------------------------------------------- supporting functions */

interface SupportRoleSeed {
  key: string;
  title: string;
  /** 1 = function head, 2 = lead, 3 = specialist / delivery. */
  level: 1 | 2 | 3;
  reportsTo: string | null;
  base: number;
  responsibilities: string;
  /** Role is a sensible candidate for agent or hybrid delivery. */
  agentEligible?: boolean;
}

export interface SupportFunctionSeed {
  key: string;
  label: string;
  mission: string;
  roles: SupportRoleSeed[];
}

const AUTOMOTIVE_SUPPORT: SupportFunctionSeed[] = [
  {
    key: "supply-chain",
    label: "Supply Chain & Logistics",
    mission:
      "Land vehicles and parts in market on time and at planned cost, from inbound supplier flow to dealer delivery.",
    roles: [
      {
        key: "sc-head",
        title: "Supply Chain Director",
        level: 1,
        reportsTo: null,
        base: 1,
        responsibilities: "Owns supply, distribution and parts availability across markets.",
      },
      {
        key: "sc-planning",
        title: "Demand & Supply Planning Manager",
        level: 2,
        reportsTo: "sc-head",
        base: 2,
        responsibilities: "Runs the sales & operations planning cycle and allocation by market.",
      },
      {
        key: "sc-planner",
        title: "Supply Planner",
        level: 3,
        reportsTo: "sc-planning",
        base: 6,
        responsibilities: "Builds model-mix plans, manages constraint lists and order banks.",
        agentEligible: true,
      },
      {
        key: "sc-logistics",
        title: "Inbound Logistics Manager",
        level: 2,
        reportsTo: "sc-head",
        base: 1,
        responsibilities: "Manages carriers, customs and inbound cost per unit.",
      },
      {
        key: "sc-logistics-spec",
        title: "Logistics Coordinator",
        level: 3,
        reportsTo: "sc-logistics",
        base: 8,
        responsibilities: "Books freight, clears shipments and resolves transit exceptions.",
        agentEligible: true,
      },
      {
        key: "sc-vld",
        title: "Vehicle Distribution Manager",
        level: 2,
        reportsTo: "sc-head",
        base: 1,
        responsibilities: "Owns compound stock, PDI throughput and dealer delivery lead time.",
      },
      {
        key: "sc-vld-spec",
        title: "Vehicle Logistics Specialist",
        level: 3,
        reportsTo: "sc-vld",
        base: 7,
        responsibilities: "Sequences deliveries, tracks in-transit units and damage claims.",
        agentEligible: true,
      },
      {
        key: "sc-parts",
        title: "Parts & Accessories Supply Manager",
        level: 2,
        reportsTo: "sc-head",
        base: 1,
        responsibilities: "Owns parts fill rate, warehouse stock health and back-order recovery.",
      },
      {
        key: "sc-parts-spec",
        title: "Parts Planner",
        level: 3,
        reportsTo: "sc-parts",
        base: 6,
        responsibilities: "Forecasts parts demand and manages replenishment parameters.",
        agentEligible: true,
      },
    ],
  },
  {
    key: "operations",
    label: "Manufacturing & Operations",
    mission:
      "Build and prepare vehicles to quality, cost and takt, and keep plant and PDI operations safe and stable.",
    roles: [
      {
        key: "ops-head",
        title: "Operations Director",
        level: 1,
        reportsTo: null,
        base: 1,
        responsibilities: "Owns plant and PDI performance: safety, quality, delivery and cost.",
      },
      {
        key: "ops-prod",
        title: "Production Manager",
        level: 2,
        reportsTo: "ops-head",
        base: 2,
        responsibilities: "Runs assembly and PDI lines to takt and manning plan.",
      },
      {
        key: "ops-sup",
        title: "Line Supervisor",
        level: 3,
        reportsTo: "ops-prod",
        base: 10,
        responsibilities: "Leads a shift team, manages manning, andon response and 5S.",
      },
      {
        key: "ops-quality",
        title: "Quality Manager",
        level: 2,
        reportsTo: "ops-head",
        base: 1,
        responsibilities: "Owns first-time-through quality, audits and warranty root cause.",
      },
      {
        key: "ops-quality-eng",
        title: "Quality Engineer",
        level: 3,
        reportsTo: "ops-quality",
        base: 7,
        responsibilities: "Runs defect analysis, supplier quality escalations and containment.",
        agentEligible: true,
      },
      {
        key: "ops-maint",
        title: "Maintenance & Engineering Manager",
        level: 2,
        reportsTo: "ops-head",
        base: 1,
        responsibilities: "Owns equipment availability, preventive maintenance and capex projects.",
      },
      {
        key: "ops-maint-tech",
        title: "Maintenance Technician",
        level: 3,
        reportsTo: "ops-maint",
        base: 9,
        responsibilities: "Delivers planned maintenance and breakdown recovery on the line.",
      },
      {
        key: "ops-hse",
        title: "HSE & Sustainability Manager",
        level: 2,
        reportsTo: "ops-head",
        base: 1,
        responsibilities: "Owns safety, environmental compliance and CO2 reporting for operations.",
      },
    ],
  },
  {
    key: "technology",
    label: "Technology & Digital",
    mission:
      "Run the dealer, connected-vehicle and enterprise platforms, and deliver the data foundation the operating model depends on.",
    roles: [
      {
        key: "it-head",
        title: "IT & Digital Director",
        level: 1,
        reportsTo: null,
        base: 1,
        responsibilities: "Owns the technology roadmap, spend and platform reliability.",
      },
      {
        key: "it-apps",
        title: "Enterprise Applications Manager",
        level: 2,
        reportsTo: "it-head",
        base: 1,
        responsibilities: "Owns ERP, CRM and DMS integration across markets.",
      },
      {
        key: "it-apps-eng",
        title: "Application Specialist",
        level: 3,
        reportsTo: "it-apps",
        base: 8,
        responsibilities: "Configures and supports core commercial and aftersales systems.",
        agentEligible: true,
      },
      {
        key: "it-data",
        title: "Data & Analytics Lead",
        level: 2,
        reportsTo: "it-head",
        base: 1,
        responsibilities: "Owns the data platform, governance and reporting standards.",
      },
      {
        key: "it-data-eng",
        title: "Data Engineer / Analyst",
        level: 3,
        reportsTo: "it-data",
        base: 7,
        responsibilities: "Builds pipelines and decision dashboards for commercial and aftersales.",
        agentEligible: true,
      },
      {
        key: "it-connected",
        title: "Connected Vehicle Platform Manager",
        level: 2,
        reportsTo: "it-head",
        base: 1,
        responsibilities: "Owns telematics, OTA and in-car service platforms.",
      },
      {
        key: "it-sec",
        title: "Cybersecurity Manager",
        level: 2,
        reportsTo: "it-head",
        base: 1,
        responsibilities: "Owns security posture, product cyber compliance and incident response.",
      },
      {
        key: "it-support",
        title: "IT Service Desk Analyst",
        level: 3,
        reportsTo: "it-head",
        base: 8,
        responsibilities: "Handles user requests, incidents and device lifecycle.",
        agentEligible: true,
      },
    ],
  },
  {
    key: "procurement-legal",
    label: "Procurement, Legal & Compliance",
    mission:
      "Secure supply commercially and keep the market compliant with homologation, competition and data rules.",
    roles: [
      {
        key: "pl-head",
        title: "Procurement & Legal Director",
        level: 1,
        reportsTo: null,
        base: 1,
        responsibilities: "Owns third-party spend, contracts and regulatory compliance.",
      },
      {
        key: "pl-cat",
        title: "Category Manager",
        level: 2,
        reportsTo: "pl-head",
        base: 2,
        responsibilities: "Runs sourcing strategy and supplier negotiation by category.",
      },
      {
        key: "pl-buyer",
        title: "Buyer",
        level: 3,
        reportsTo: "pl-cat",
        base: 6,
        responsibilities: "Runs tenders, purchase orders and supplier onboarding.",
        agentEligible: true,
      },
      {
        key: "pl-counsel",
        title: "Legal Counsel",
        level: 2,
        reportsTo: "pl-head",
        base: 2,
        responsibilities: "Advises on dealer agreements, agency model and consumer law.",
      },
      {
        key: "pl-compliance",
        title: "Compliance & Homologation Specialist",
        level: 3,
        reportsTo: "pl-head",
        base: 4,
        responsibilities: "Manages type approval, recall documentation and data-privacy controls.",
        agentEligible: true,
      },
    ],
  },
];

/* ------------------------------------------------------------------- packs */

export interface IndustryPack {
  id: string;
  industry: string;
  label: string;
  description: string;
  /** Core functions taken from the operating-model blueprint. */
  coreFunctions: FunctionKey[];
  /** Supporting function keys from the pack's support library. */
  supportFunctions: string[];
  /** Default generation options. */
  defaults: { size: CompanySize; region: RegionFocus; variant: PackVariant };
  /** True for user-saved variants. */
  custom?: boolean;
  createdAt?: string;
}

export const AUTOMOTIVE_PACK: IndustryPack = {
  id: "automotive",
  industry: "Automotive",
  label: "Automotive Operating Model Pack",
  description:
    "Nine core automotive functions — HR, Finance, Product Marketing, Portfolio & Planning, Marketing, Sales, Service Sales, Zone Management and Commercial Fleet — plus supply chain, operations, technology and procurement/legal support functions.",
  coreFunctions: [...FUNCTION_KEYS],
  supportFunctions: AUTOMOTIVE_SUPPORT.map((f) => f.key),
  defaults: { size: "midsize", region: "global", variant: "hybrid" },
};

export const BUILT_IN_PACKS: IndustryPack[] = [AUTOMOTIVE_PACK];

export function supportLibrary(): SupportFunctionSeed[] {
  return AUTOMOTIVE_SUPPORT;
}

export function functionLabel(key: string) {
  return (
    FUNCTION_LABELS[key as FunctionKey] ??
    AUTOMOTIVE_SUPPORT.find((f) => f.key === key)?.label ??
    key
  );
}

/* ------------------------------------------------------ saved custom packs */

const PACK_KEY = "orgeasy.industrypacks.v1";
const listeners = new Set<() => void>();
let customPacks: IndustryPack[] | null = null;

function readCustom(): IndustryPack[] {
  if (customPacks) return customPacks;
  customPacks = [];
  if (typeof localStorage !== "undefined") {
    try {
      const raw = localStorage.getItem(PACK_KEY);
      if (raw) customPacks = JSON.parse(raw) as IndustryPack[];
    } catch {
      customPacks = [];
    }
  }
  return customPacks;
}

function writeCustom(next: IndustryPack[]) {
  customPacks = next;
  if (typeof localStorage !== "undefined" && hasConsent("workspace")) {
    try {
      localStorage.setItem(PACK_KEY, JSON.stringify(next));
    } catch {
      /* storage full */
    }
  }
  listeners.forEach((fn) => fn());
}

export function listCustomPacks() {
  return readCustom();
}

export function subscribePacks(fn: () => void) {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

export function saveCustomPack(pack: IndustryPack) {
  const existing = readCustom();
  writeCustom(
    existing.some((p) => p.id === pack.id)
      ? existing.map((p) => (p.id === pack.id ? pack : p))
      : [...existing, pack],
  );
}

export function deleteCustomPack(id: string) {
  writeCustom(readCustom().filter((p) => p.id !== id));
}

/* -------------------------------------------------------------- generation */

export interface PackGenerateOptions {
  size: CompanySize;
  region: RegionFocus;
  variant: PackVariant;
  /** Optional override for the total position count. */
  targetPositions?: number | undefined;
}

/** Indicative annual cost per position by layer, before the regional factor. */
const LEVEL_COST: Record<1 | 2 | 3, number> = { 1: 245000, 2: 155000, 3: 92000 };

const REGION_COST_FACTOR: Record<RegionFocus, number> = {
  global: 1,
  asean: 0.55,
  europe: 1.05,
  "north-america": 1.12,
  china: 0.7,
};

function levelOf(e: Employee, rootId: string): 1 | 2 | 3 {
  if (e.id === rootId) return 1;
  if (!e.managerId || e.managerId === rootId) return 1;
  return e.title.match(/manager|lead|head|director/i) ? 2 : 3;
}

function supportEmployees(
  pack: IndustryPack,
  opts: PackGenerateOptions,
  rootId: string,
  country: string,
): Employee[] {
  const out: Employee[] = [];
  for (const fn of AUTOMOTIVE_SUPPORT.filter((f) => pack.supportFunctions.includes(f.key))) {
    for (const role of fn.roles) {
      out.push({
        id: `${fn.key}:${role.key}`,
        name: "",
        isOpenRole: true,
        title: role.title,
        department: fn.label,
        country,
        responsibilities: `${role.responsibilities}\nFunction mission: ${fn.mission}`,
        currentHeadcount: role.base,
        plannedHeadcount: role.base,
        employmentType: "Full-time",
        managerId: role.reportsTo ? `${fn.key}:${role.reportsTo}` : rootId,
        status: "current",
        currentCost: 0,
        plannedCost: 0,
        serviceMonths: 36,
        unitKind: fn.key === "operations" ? "line" : "gbs",
        roleScope: role.level === 1 ? "global" : "regional",
        roleType: opts.variant === "hybrid" && role.agentEligible ? "hybrid" : "human",
        ...(opts.variant === "hybrid" && role.agentEligible
          ? { reductionLever: "agent" as ReductionLever }
          : {}),
      });
    }
  }
  return out;
}

/**
 * Scales specialist headcount so the whole structure lands on the target
 * position count for the chosen company size, then prices every position.
 */
function scaleAndPrice(employees: Employee[], opts: PackGenerateOptions, rootId: string) {
  const target = Math.max(20, Math.round(opts.targetPositions ?? SIZE_TARGET[opts.size]));
  const isAgentNode = (e: Employee) => e.title.startsWith(AGENT_PREFIX);
  const specialists = employees.filter((e) => !isAgentNode(e) && levelOf(e, rootId) === 3);
  const fixed = employees
    .filter((e) => !isAgentNode(e) && levelOf(e, rootId) !== 3)
    .reduce((a, e) => a + Math.max(1, e.plannedHeadcount), 0);
  const variable = specialists.reduce((a, e) => a + Math.max(1, e.plannedHeadcount), 0) || 1;
  const factor = Math.max(0.35, (target - fixed) / variable);

  for (const e of specialists) {
    e.plannedHeadcount = Math.max(1, Math.round(Math.max(1, e.plannedHeadcount) * factor));
  }

  // Correct the rounding drift on the largest specialist teams.
  const total = () =>
    employees.filter((e) => !isAgentNode(e)).reduce((a, e) => a + e.plannedHeadcount, 0);
  const ordered = [...specialists].sort((a, b) => b.plannedHeadcount - a.plannedHeadcount);
  let guard = 0;
  while (total() !== target && ordered.length && guard < 5000) {
    guard += 1;
    const diff = target - total();
    const role = ordered[guard % ordered.length]!;
    if (diff > 0) role.plannedHeadcount += 1;
    else if (role.plannedHeadcount > 1) role.plannedHeadcount -= 1;
    else continue;
  }

  const costFactor = REGION_COST_FACTOR[opts.region];
  for (const e of employees) {
    if (isAgentNode(e)) {
      e.currentHeadcount = 0;
      e.plannedHeadcount = 0;
      e.currentCost = 0;
      e.plannedCost = 0;
      e.roleType = "agent" as RoleType;
      e.reductionLever = "agent" as ReductionLever;
      continue;
    }
    const cost = Math.round(LEVEL_COST[levelOf(e, rootId)] * costFactor);
    e.currentCost = cost;
    e.plannedCost = cost;
    e.currentHeadcount = e.plannedHeadcount;
    e.status = "current";
    e.serviceMonths = e.serviceMonths || 36;
    if (!e.roleType) e.roleType = "human";
  }
}

export interface GeneratedPack {
  employees: Employee[];
  name: string;
  description: string;
  positions: number;
  agents: number;
  functions: number;
}

/** Builds the full role population for a pack as an editable current-state org. */
export function generatePackScenario(
  pack: IndustryPack,
  opts: PackGenerateOptions,
): GeneratedPack {
  const region = REGIONS.find((r) => r.value === opts.region);
  const country = region?.country ?? "United States";
  const model = generateOperatingModel({
    size: opts.size,
    region: opts.region,
    includeAgents: opts.variant === "hybrid",
    functions: pack.coreFunctions,
  });
  const core = modelToEmployees(model).map<Employee>((e) => ({
    ...e,
    status: "current",
    currentHeadcount: e.plannedHeadcount,
    roleType: e.title.startsWith(AGENT_PREFIX) ? "agent" : "human",
  }));
  const rootId = core[0]?.id ?? "aom-root";
  const employees = [...core, ...supportEmployees(pack, opts, rootId, country)];

  // In the hybrid variant, roles paired with an agent are hybrid-delivered.
  if (opts.variant === "hybrid") {
    const paired = new Set(
      employees.filter((e) => e.title.startsWith(AGENT_PREFIX)).map((e) => e.managerId),
    );
    for (const e of employees) {
      if (paired.has(e.id) && !e.title.startsWith(AGENT_PREFIX)) {
        e.roleType = "hybrid";
        e.reductionLever = "agent";
      }
    }
  }

  scaleAndPrice(employees, opts, rootId);

  const sizeLabel = COMPANY_SIZES.find((s) => s.value === opts.size)?.label ?? opts.size;
  const variantLabel = PACK_VARIANTS.find((v) => v.value === opts.variant)?.label ?? opts.variant;
  const positions = employees.reduce((a, e) => a + e.plannedHeadcount, 0);
  const agents = employees.filter((e) => e.title.startsWith(AGENT_PREFIX)).length;
  const functions = new Set(employees.map((e) => e.department)).size;

  return {
    employees,
    name: `${pack.industry} — ${sizeLabel} · ${region?.label ?? opts.region}`,
    description: `${pack.label} · ${variantLabel} variant · ${positions.toLocaleString()} positions across ${functions} functions${
      agents ? ` with ${agents} AI agents` : ""
    }. Generated structure — edit freely, then apply transformation levers.`,
    positions,
    agents,
    functions,
  };
}

/** Position count a pack would generate, without building the scenario. */
export function estimatePositions(opts: PackGenerateOptions) {
  return Math.round(opts.targetPositions ?? SIZE_TARGET[opts.size]);
}

export function packScenarioMeta(currency = "USD"): Partial<Scenario> {
  return { kind: "current", currency };
}