/**
 * Leadership narrative deck: a short, clean 5–7 slide story for a decision
 * meeting. The detailed multi-section pack lives in `pptx.ts` — this file
 * deliberately trades tables and raw numbers for the "so what".
 */
import type PptxGenJSType from "pptxgenjs";
import type { Scenario } from "./types";
import { DISCLAIMER } from "./types";
import { formatMoney } from "./impact";
import type { ImpactSummary } from "./impact";
import type { ProgrammeSummary } from "./levers";
import type { ChangePlan } from "./change-plan";
import { buildDecisionSummary, type DecisionSummary } from "./decision-summary";
import { analyseSpans } from "./span";
import { addEditableChart } from "./pptx-chart";
import { BRAND_NAVY, LOGO_COVER, LOGO_MARK, logoData } from "./brand";
import { NOT_LEGAL_ADVICE_SHORT } from "./notices";

const NAVY = BRAND_NAVY;
const BLUE = "2563EB";
const INK = "1E293B";
const MUTED = "64748B";
const LIGHT = "F1F5F9";
const WHITE = "FFFFFF";
const RED = "DC2626";
const AMBER = "B45309";
const GREEN = "047857";
const HEAD = "Georgia";
const BODY = "Calibri";

export interface ExecDeckOptions {
  programme: ProgrammeSummary;
  impact: ImpactSummary;
  plan: ChangePlan;
  baselineName?: string | null;
  /** Pre-rendered chart images (used when editable shapes are off). */
  currentChartPng?: string | null;
  futureChartPng?: string | null;
  editableCharts?: boolean;
  currentChartScenario?: Scenario | null;
  /** Alternative options the meeting should see alongside this one. */
  options?: { name: string; positions: number; costDelta: number; note?: string }[];
  /** Attributed on the cover when the workspace is signed in. */
  preparedBy?: string | null;
  fileName?: string;
}

const money = (v: number, cur: string) => formatMoney(v, cur);

/** Short money for metric tiles, so long totals never wrap. */
function compactMoney(v: number, cur: string) {
  const sign = v < 0 ? "-" : "";
  const a = Math.abs(v);
  const sym = formatMoney(0, cur).replace(/[\d.,\s]/g, "") || "";
  if (a >= 1_000_000_000) return `${sign}${sym}${(a / 1_000_000_000).toFixed(1)}bn`;
  if (a >= 1_000_000) return `${sign}${sym}${(a / 1_000_000).toFixed(1)}m`;
  if (a >= 1_000) return `${sign}${sym}${Math.round(a / 1_000)}k`;
  return `${sign}${sym}${Math.round(a)}`;
}

export async function generateExecutiveDeck(scenario: Scenario, opts: ExecDeckOptions) {
  const PptxGenJS = (await import("pptxgenjs")).default;
  const pptx = new PptxGenJS();
  pptx.layout = "LAYOUT_16x9";
  pptx.author = "Organisation Strategy Studio";
  pptx.title = `${scenario.name} — Leadership decision pack`;
  const logo = await logoData();
  const cur = scenario.currency;
  const summary: DecisionSummary = buildDecisionSummary(
    scenario,
    opts.programme,
    opts.impact,
    opts.plan,
  );
  const n = summary.numbers;
  const dateLabel = new Date().toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const light = (title: string, kicker: string) => {
    const s = pptx.addSlide();
    s.background = { color: WHITE };
    s.addShape("rect", { x: 0, y: 0, w: 0.22, h: 5.63, fill: { color: BLUE } });
    if (logo) {
      s.addImage({ data: logo, x: LOGO_MARK.x, y: LOGO_MARK.y, w: LOGO_MARK.size, h: LOGO_MARK.size });
    }
    s.addText(kicker.toUpperCase(), {
      x: 0.6, y: 0.34, w: 8.5, h: 0.3,
      fontFace: BODY, fontSize: 13, bold: true, color: BLUE, charSpacing: 2,
    });
    s.addText(title, {
      x: 0.6, y: 0.64, w: 8.5, h: 0.78,
      fontFace: HEAD, fontSize: title.length > 34 ? 28 : 34, bold: true, color: NAVY,
      shrinkText: true, valign: "middle",
    });
    return s;
  };

  const foot = (s: PptxGenJSType.Slide, text = NOT_LEGAL_ADVICE_SHORT) => {
    s.addText(text, {
      x: 0.6, y: 5.1, w: 8.8, h: 0.35, fontFace: BODY, fontSize: 10, italic: true, color: MUTED,
    });
  };

  /** Big "so what" line under the title. */
  const soWhat = (s: PptxGenJSType.Slide, text: string) => {
    s.addShape("rect", { x: 0.6, y: 1.5, w: 8.8, h: 0.62, fill: { color: LIGHT } });
    s.addText(text, {
      x: 0.78, y: 1.55, w: 8.45, h: 0.52, fontFace: BODY, fontSize: 15, bold: true, color: NAVY,
      valign: "middle",
    });
  };

  const tiles = (
    s: PptxGenJSType.Slide,
    items: { label: string; value: string; note?: string; color?: string }[],
    y = 2.35,
  ) => {
    const w = 8.8 / items.length;
    items.forEach((t, i) => {
      const x = 0.6 + i * w;
      s.addShape("rect", { x: x + 0.05, y, w: w - 0.18, h: 1.5, fill: { color: LIGHT } });
      s.addText(t.value, {
        x: x + 0.2, y: y + 0.14, w: w - 0.45, h: 0.6,
        fontFace: HEAD, fontSize: 24, bold: true, color: t.color ?? NAVY, shrinkText: true,
      });
      s.addText(t.label, {
        x: x + 0.2, y: y + 0.76, w: w - 0.45, h: 0.3, fontFace: BODY, fontSize: 12, color: MUTED,
      });
      if (t.note) {
        s.addText(t.note, {
          x: x + 0.2, y: y + 1.04, w: w - 0.45, h: 0.36, fontFace: BODY, fontSize: 10.5, color: INK,
        });
      }
    });
  };

  const bullets = (
    s: PptxGenJSType.Slide,
    lines: string[],
    box: { x: number; y: number; w: number; h: number },
    size = 15,
  ) => {
    s.addText(
      lines.map((text) => ({
        text,
        options: { bullet: true, fontFace: BODY, fontSize: size, color: INK, paraSpaceAfter: 10 },
      })),
      box,
    );
  };

  const drawChart = (
    s: PptxGenJSType.Slide,
    png: string | null | undefined,
    source: Scenario | null | undefined,
    box: { x: number; y: number; w: number; h: number },
  ) => {
    if (opts.editableCharts && source && addEditableChart(s, source, box)) return true;
    if (!png) return false;
    s.addImage({ data: png, ...box, sizing: { type: "contain", w: box.w, h: box.h } });
    return true;
  };

  /* 1 — Title & context ------------------------------------------------- */
  const title = pptx.addSlide();
  title.background = { color: NAVY };
  if (logo) {
    title.addImage({ data: logo, x: LOGO_COVER.x, y: LOGO_COVER.y, w: LOGO_COVER.size, h: LOGO_COVER.size });
  }
  title.addShape("rect", { x: 0, y: 4.92, w: 10, h: 0.71, fill: { color: BLUE } });
  title.addText("ORGANISATION DESIGN — DECISION PACK", {
    x: 0.8, y: 1.35, w: 8.4, h: 0.4, fontFace: BODY, fontSize: 16, color: LIGHT, charSpacing: 3,
  });
  title.addText(scenario.name, {
    x: 0.8, y: 1.8, w: 8.4, h: 1.2, fontFace: HEAD, fontSize: 42, bold: true, color: WHITE,
  });
  title.addText(
    `${n.baselinePositions.toLocaleString()} positions today → ${n.futurePositions.toLocaleString()} in this option · ${money(n.annualSaving, cur)} annual people cost released · ${money(n.oneOffCost, cur)} one-off · ${n.countries} markets involved`,
    { x: 0.8, y: 3.05, w: 8.4, h: 0.7, fontFace: BODY, fontSize: 15, color: LIGHT },
  );
  title.addText(
    `${dateLabel}${summary.baselineName ? ` · compared with ${summary.baselineName}` : ""}${opts.preparedBy ? ` · Prepared by ${opts.preparedBy}` : ""} · Decision asked for: ${summary.nextStep.title.toLowerCase()}`,
    { x: 0.8, y: 3.85, w: 8.4, h: 0.6, fontFace: BODY, fontSize: 13, color: WHITE },
  );
  title.addText("Illustrative modelling — not legal, financial or employment advice", {
    x: 0.8, y: 5.02, w: 8.4, h: 0.4, fontFace: BODY, fontSize: 11.5, color: WHITE,
  });

  /* 2 — Current state snapshot ------------------------------------------ */
  const span = analyseSpans(opts.currentChartScenario ?? scenario);
  const cs = light("Where we are today", "Current state snapshot");
  soWhat(
    cs,
    `${n.baselinePositions.toLocaleString()} positions, ${span.maxLayer} management layers and an average span of ${span.avgSpan.toFixed(1)} — the shape, not the headcount, is the constraint.`,
  );
  tiles(cs, [
    { label: "Positions today", value: n.baselinePositions.toLocaleString() },
    { label: "Annual people cost", value: compactMoney(opts.programme.baselineCost, cur) },
    { label: "Management layers", value: String(span.maxLayer) },
    { label: "Average span", value: span.avgSpan.toFixed(1) },
  ]);
  bullets(
    cs,
    [
      `Work spans ${opts.impact.byDepartment.length} functions and ${opts.impact.byCountry.length} markets, so any change is a multi-country decision.`,
      span.avgSpan < 5
        ? "Narrow spans indicate supervision-heavy layers rather than delivery capacity."
        : span.avgSpan <= 9
          ? "Spans are broadly in the 5–9 range; the opportunity sits in duplication and work design more than in supervision."
          : `An average span of ${span.avgSpan.toFixed(1)} means several managers carry very large teams — support and role clarity matter as much as structure here.`,
      `Largest functions: ${opts.impact.byDepartment
        .slice()
        .sort((a, b) => b.currentHeadcount - a.currentHeadcount)
        .slice(0, 3)
        .map((d) => `${d.department} (${d.currentHeadcount.toLocaleString()})`)
        .join(", ")}.`,
    ],
    { x: 0.75, y: 3.95, w: 8.55, h: 1.05 },
    13.5,
  );
  foot(cs);

  /* 3 — Proposed future organisation ----------------------------------- */
  const fut = light("The organisation we are proposing", "Proposed future");
  soWhat(fut, summary.whatIsChanging[0] ?? "This option is structurally identical to today.");
  // A 500-node tree is illegible at slide size: only show the chart when the
  // structure is small enough to read.
  const chartReadable = scenario.employees.length <= 45;
  const hasChart = chartReadable
    ? drawChart(
        fut,
        opts.futureChartPng,
        opts.editableCharts ? scenario : null,
        { x: 5.0, y: 2.3, w: 4.4, h: 2.35 },
      )
    : false;
  const futureLines = Array.from(
    new Set([
      ...summary.whatIsChanging.slice(1),
      ...(n.rolesAdded
        ? [`${n.rolesAdded} new capability roles are part of the design, not an afterthought.`]
        : []),
    ]),
  ).slice(0, 3);
  bullets(
    fut,
    futureLines,
    { x: 0.75, y: 2.35, w: hasChart ? 4.05 : 8.55, h: 2.15 },
    hasChart ? 12.5 : 14.5,
  );
  if (!chartReadable) {
    fut.addText(
      "Full structure charts stay in the studio — this pack carries the shape of the decision, not the whole tree.",
      { x: 0.75, y: 4.5, w: 8.55, h: 0.32, fontFace: BODY, fontSize: 11.5, italic: true, color: MUTED },
    );
  }
  if (opts.options?.length) {
    fut.addText(
      `Options on the table: ${opts.options
        .map((o) => `${o.name} (${o.positions.toLocaleString()} positions, ${o.costDelta <= 0 ? "−" : "+"}${compactMoney(Math.abs(o.costDelta), cur)})`)
        .join(" · ")}`,
      { x: 0.75, y: 4.82, w: 8.55, h: 0.3, fontFace: BODY, fontSize: 11, color: MUTED },
    );
  }
  foot(fut);

  /* 4 — Phased path (only when there is more than one phase) ------------ */
  if (opts.programme.phases.length > 1) {
    const road = light("How we would get there", "Sequence");
    soWhat(
      road,
      `${opts.programme.phases.length} phases, each with its own gate — nothing beyond phase 1 is committed today.`,
    );
    const ph = opts.programme.phases.slice(0, 4);
    const w = 8.8 / ph.length;
    ph.forEach((p, i) => {
      const x = 0.6 + i * w;
      road.addShape("rect", { x: x + 0.05, y: 2.35, w: w - 0.18, h: 2.1, fill: { color: LIGHT } });
      road.addShape("rect", { x: x + 0.05, y: 2.35, w: w - 0.18, h: 0.09, fill: { color: BLUE } });
      road.addText(`Phase ${i + 1}`, {
        x: x + 0.2, y: 2.55, w: w - 0.45, h: 0.28, fontFace: BODY, fontSize: 11, bold: true, color: BLUE,
      });
      road.addText((p.name || p.title).replace(/^Phase\s*\d+\s*[—-]\s*/i, ""), {
        x: x + 0.2, y: 2.84, w: w - 0.45, h: 0.62, fontFace: HEAD, fontSize: 15, bold: true, color: NAVY,
        shrinkText: true,
      });
      road.addText(
        `${p.headcount.toLocaleString()} positions\n${p.stepReduction >= 0 ? "−" : "+"}${Math.abs(p.stepReduction)} vs prior phase\n${compactMoney(p.costSaving, cur)} annual effect`,
        { x: x + 0.2, y: 3.5, w: w - 0.45, h: 0.85, fontFace: BODY, fontSize: 11.5, color: INK },
      );
    });
    road.addText(
      "Each phase is re-modelled before it starts; consultation calendars and hiring lead times drive the dates.",
      { x: 0.75, y: 4.6, w: 8.55, h: 0.4, fontFace: BODY, fontSize: 12.5, color: MUTED },
    );
    foot(road);
  }

  /* 5 — Key trade-offs -------------------------------------------------- */
  const to = light("What we gain and what we give up", "Key trade-offs");
  soWhat(to, `Four dimensions leadership is being asked to balance, not one cost number.`);
  summary.tradeOffs.slice(0, 4).forEach((t, i) => {
    const x = 0.6 + (i % 2) * 4.45;
    const y = 2.3 + Math.floor(i / 2) * 1.42;
    to.addShape("rect", { x, y, w: 4.25, h: 1.3, fill: { color: LIGHT } });
    to.addShape("rect", { x, y, w: 0.08, h: 1.3, fill: { color: BLUE } });
    to.addText(`${t.label} — ${t.headline}`, {
      x: x + 0.2, y: y + 0.1, w: 3.95, h: 0.38, fontFace: BODY, fontSize: 12.5, bold: true, color: NAVY,
    });
    to.addText(
      [
        { text: "Gain: ", options: { bold: true, color: GREEN } },
        { text: t.gain, options: { color: INK } },
      ],
      { x: x + 0.2, y: y + 0.48, w: 3.95, h: 0.38, fontFace: BODY, fontSize: 10.5 },
    );
    to.addText(
      [
        { text: "Give: ", options: { bold: true, color: AMBER } },
        { text: t.give, options: { color: INK } },
      ],
      { x: x + 0.2, y: y + 0.86, w: 3.95, h: 0.38, fontFace: BODY, fontSize: 10.5 },
    );
  });
  foot(to);

  /* 6 — Multi-country & consultation risk ------------------------------- */
  const risk = light("Risks to plan for", "Multi-country & consultation");
  const highRisk = opts.programme.highRiskMarkets;
  const collective = opts.programme.separationByCountry.filter((c) => c.collectiveTriggered);
  soWhat(
    risk,
    highRisk.length || collective.length
      ? `${n.exits.toLocaleString()} exits across ${n.countries} markets — ${highRisk.length} high-risk and ${collective.length} triggering collective consultation set the critical path.`
      : `${n.countries} markets involved and no collective consultation thresholds crossed on today's numbers.`,
  );
  const rows = summary.risks.slice(0, 3);
  rows.forEach((r, i) => {
    const y = 2.32 + i * 0.68;
    const colour = r.severity === "high" ? RED : r.severity === "medium" ? AMBER : GREEN;
    risk.addShape("rect", { x: 0.6, y, w: 8.8, h: 0.6, fill: { color: LIGHT } });
    risk.addShape("rect", { x: 0.6, y, w: 0.08, h: 0.6, fill: { color: colour } });
    risk.addText(r.title, {
      x: 0.82, y: y + 0.05, w: 8.4, h: 0.26, fontFace: BODY, fontSize: 12.5, bold: true, color: colour,
    });
    risk.addText(r.detail, {
      x: 0.82, y: y + 0.29, w: 8.4, h: 0.28, fontFace: BODY, fontSize: 10.5, color: INK,
    });
  });
  risk.addText(
    `Transition cost range across the programme: ${compactMoney(n.oneOffLow, cur)} – ${compactMoney(n.oneOffHigh, cur)} depending on consultation outcomes. Local counsel validates timelines before any date is announced.`,
    { x: 0.75, y: 4.45, w: 8.55, h: 0.5, fontFace: BODY, fontSize: 11.5, color: MUTED },
  );
  foot(risk, DISCLAIMER);

  /* 7 — Recommendation & next steps ------------------------------------ */
  const rec = light("What we are asking for", "Recommendation & next steps");
  rec.addShape("rect", { x: 0.6, y: 1.5, w: 8.8, h: 1.12, fill: { color: NAVY } });
  rec.addText(summary.nextStep.title, {
    x: 0.8, y: 1.6, w: 8.4, h: 0.38, fontFace: HEAD, fontSize: 19, bold: true, color: WHITE,
  });
  rec.addText(summary.nextStep.detail, {
    x: 0.8, y: 2.0, w: 8.4, h: 0.5, fontFace: BODY, fontSize: 11.5, color: LIGHT, shrinkText: true,
  });
  const pilotArea = opts.plan.groups[0]?.name;
  bullets(
    rec,
    [
      `Pilot first: run phase 1 in ${pilotArea ?? "one function"} as a contained pilot, then re-model before the next gate.`,
      `Confirm the decision principles: protect delivery, keep spans in the 5–9 range, and reinvest in ${n.rolesAdded ? `${n.rolesAdded} new capability roles` : "priority capability"}.`,
      ...(summary.nextStep.detail.toLowerCase().includes("counsel")
        ? []
        : [
            highRisk.length
              ? `Commission local counsel in ${highRisk.slice(0, 3).map((c) => c.country).join(", ")} to validate consultation timelines and cost.`
              : "Re-check consultation thresholds in every market before dates are communicated.",
          ]),
      "Agree the communication sequence: leaders first, then affected teams, then the wider organisation.",
      "Return to this forum at the phase 1 gate with actuals against the model.",
    ],
    { x: 0.75, y: 2.82, w: 8.55, h: 1.9 },
    13,
  );
  foot(rec, DISCLAIMER);

  const name = (opts.fileName ?? `${scenario.name}-leadership-pack`).replace(/[^a-z0-9-]+/gi, "-");
  await pptx.writeFile({ fileName: `${name}.pptx` });
}
