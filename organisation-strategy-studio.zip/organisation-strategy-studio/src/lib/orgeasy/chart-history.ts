import { useCallback, useRef, useState } from "react";

/** One reversible org chart edit (card resize or reporting-line change). */
export interface ChartHistoryEntry {
  /** Short human label, e.g. "card resize" or "reporting line". */
  label: string;
  /** Re-applies the edit. */
  redo: () => void;
  /** Reverts the edit. */
  undo: () => void;
}

const LIMIT = 50;

/**
 * Lightweight undo/redo stack for chart edits. Entries carry their own
 * apply/revert closures so callers stay in control of how state is written.
 * Stacks live in refs (mutations are side-effectful, so they must not run
 * inside a state updater) with a counter to drive re-renders.
 */
export function useChartHistory() {
  const past = useRef<ChartHistoryEntry[]>([]);
  const future = useRef<ChartHistoryEntry[]>([]);
  const [, bump] = useState(0);
  // Guards against recording the writes performed by undo/redo themselves.
  const replaying = useRef(false);
  const sync = useCallback(() => bump((n) => n + 1), []);

  const push = useCallback(
    (entry: ChartHistoryEntry) => {
      if (replaying.current) return;
      past.current = [...past.current, entry].slice(-LIMIT);
      future.current = [];
      sync();
    },
    [sync],
  );

  const run = useCallback((fn: () => void) => {
    replaying.current = true;
    try {
      fn();
    } finally {
      replaying.current = false;
    }
  }, []);

  const undo = useCallback(() => {
    const entry = past.current[past.current.length - 1];
    if (!entry) return null;
    past.current = past.current.slice(0, -1);
    future.current = [entry, ...future.current].slice(0, LIMIT);
    run(entry.undo);
    sync();
    return entry.label;
  }, [run, sync]);

  const redo = useCallback(() => {
    const entry = future.current[0];
    if (!entry) return null;
    future.current = future.current.slice(1);
    past.current = [...past.current, entry].slice(-LIMIT);
    run(entry.redo);
    sync();
    return entry.label;
  }, [run, sync]);

  const reset = useCallback(() => {
    past.current = [];
    future.current = [];
    sync();
  }, [sync]);

  return {
    push,
    undo,
    redo,
    reset,
    canUndo: past.current.length > 0,
    canRedo: future.current.length > 0,
    nextUndoLabel: past.current[past.current.length - 1]?.label ?? null,
    nextRedoLabel: future.current[0]?.label ?? null,
  };
}
