import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { AdkarGroup, Employee, Scenario, Workspace } from "./types";
import type { OperatingModel } from "./operating-model";
import { seedScenarios, baselineEmployees, CURRENT_STATE_ID, SEED_CREATED_AT } from "./seed";
import { nextPhaseOrder, listPhases, currentStateScenario } from "./phases";
import { hasConsent, subscribeConsent } from "./consent";
import { SCALE_LIMITS } from "./scale";
import { loadVersions, saveVersion, shouldAutoSnapshot } from "./versions";
import {
  findScenarioSnapshot,
  saveScenarioSnapshot,
  type ScenarioSnapshot,
} from "./scenario-snapshots";
import {
  logEvent,
  ROLE_META,
  roleCan,
  type ActivityKind,
  type Permission,
  type WorkspaceRole,
} from "./roles";
import { toast } from "sonner";


// v3: fixed, deterministic 500-position demo baseline.
const STORAGE_KEY = "orgeasy.workspace.v3";
const LEGACY_KEYS = ["orgeasy.workspace.v2", "orgeasy.workspace"];
export const POP_OUT_HANDOFF_KEY = "orgeasy.workspace.popout-handoff.v1";
// Cross-window sync channel: keeps a popped-out canvas window in lock-step
// with the main workspace. BroadcastChannel is in-memory only, so nothing
// extra is persisted and storage consent rules are unaffected.
const SYNC_CHANNEL = "orgeasy.workspace.sync.v1";
const SYNC_REQUEST = "orgeasy.workspace.request.v1";

type WorkspaceSyncMessage =
  | { type: "request"; sender: string }
  | { type: "workspace"; sender: string; payload: string };

function parseWorkspaceSyncMessage(data: unknown): WorkspaceSyncMessage | null {
  if (data === SYNC_REQUEST) return { type: "request", sender: "legacy" };
  if (typeof data !== "string") return null;
  try {
    const parsed = JSON.parse(data) as unknown;
    if (!parsed || typeof parsed !== "object") return null;
    const record = parsed as Record<string, unknown>;
    if (record["type"] === "request" && typeof record["sender"] === "string") {
      return { type: "request", sender: record["sender"] };
    }
    if (
      record["type"] === "workspace" &&
      typeof record["sender"] === "string" &&
      typeof record["payload"] === "string"
    ) {
      return { type: "workspace", sender: record["sender"], payload: record["payload"] };
    }
    // Backwards compatibility with older open windows that posted the raw
    // workspace JSON string.
    if (Array.isArray(record["scenarios"])) {
      return { type: "workspace", sender: "legacy", payload: data };
    }
  } catch {
    /* ignore malformed sync payloads */
  }
  return null;
}


function uid() {
  return Math.random().toString(36).slice(2, 10);
}

function defaultWorkspace(): Workspace {
  const scenarios = seedScenarios();
  return {
    account: null,
    scenarios,
    activeScenarioId: scenarios[0]?.id ?? null,
    operatingModels: [],
    role: "admin",
    activity: [],
  };
}

/**
 * Restores the fixed demo dataset on every page load: the default
 * "Demo – Global (500 positions)" baseline and its seeded demo phases always
 * hold the exact same roster, headcount, costs and countries, so a refresh
 * discards experimental edits to the demo org chart. Chart layout (positions /
 * node sizes) the user arranged is preserved, and scenarios the user created or
 * imported themselves are left untouched.
 */
function withFixedBaseline(w: Workspace): Workspace {
  const seeded = seedScenarios();
  const base = seeded.find((s) => s.id === CURRENT_STATE_ID);
  if (!base) return w;
  const seedById = new Map(seeded.map((s) => [s.id, s]));

  const scenarios = w.scenarios.map((s) => {
    const fresh = seedById.get(s.id);
    if (!fresh) return s;
    return {
      ...fresh,
      employees:
        s.id === CURRENT_STATE_ID ? baselineEmployees() : structuredClone(fresh.employees),
      positions: s.positions ?? {},
      ...(s.nodeSizes ? { nodeSizes: s.nodeSizes } : {}),
      createdAt: SEED_CREATED_AT,
    };
  });

  // Re-add any seeded demo scenario the stored workspace no longer has.
  const present = new Set(scenarios.map((s) => s.id));
  const restored = seeded.filter((s) => !present.has(s.id));

  return {
    ...w,
    scenarios: restored.length ? [...restored, ...scenarios] : scenarios,
    activeScenarioId: w.activeScenarioId ?? CURRENT_STATE_ID,
  };
}

export type ScenarioMeta = Partial<
  Pick<Scenario, "kind" | "phaseOrder" | "phaseLabel" | "baselineId" | "description" | "currency">
>;

interface StoreValue {
  hydrated: boolean;
  workspace: Workspace;
  scenario: Scenario | null;
  /** Current user's workspace role (defaults to Admin for legacy workspaces). */
  role: WorkspaceRole;
  /** Permission check for UI gating: `can("exportPacks")`. */
  can: (permission: Permission) => boolean;
  /** Admin-only: change the workspace role. */
  setRole: (role: WorkspaceRole) => void;
  /** Appends an executive-readable entry to the workspace activity trail. */
  recordActivity: (kind: ActivityKind, message: string, scenarioName?: string) => void;
  /** Admin-only: clears the activity trail (the clear itself is logged). */
  clearActivity: () => void;
  setActiveScenario: (id: string) => void;
  createScenario: (name: string, cloneFromId?: string, meta?: ScenarioMeta) => void;
  /** Creates a scenario pre-populated with generated roles (industry packs). */
  createScenarioWithEmployees: (
    name: string,
    employees: Employee[],
    meta?: ScenarioMeta,
  ) => string;
  addNextPhase: () => void;
  reorderPhases: (orderedIds: string[]) => void;
  renameScenario: (id: string, name: string, description: string) => void;
  deleteScenario: (id: string) => void;
  updateScenario: (patch: Partial<Scenario>) => void;
  upsertEmployee: (employee: Employee) => void;
  addEmployee: () => Employee;
  removeEmployee: (id: string) => void;
  replaceEmployees: (employees: Employee[]) => void;
  /**
   * Applies a roster change to a specific scenario (not necessarily the active
   * one) — used to route manual chart edits into future phases and to
   * propagate a change across later phases.
   */
  mutateScenarioEmployees: (scenarioId: string, updater: (employees: Employee[]) => Employee[]) => void;
  /**
   * Restores the seeded roster for the active scenario. By default node
   * positions/sizes and manually drawn reporting lines are preserved.
   * Returns false when the active scenario has no seeded source.
   */
  resetChartData: (opts?: { keepLayout?: boolean; keepLinks?: boolean }) => boolean;
  /** Clears saved node positions and card sizes for the active scenario only. */
  resetChartLayout: () => void;

  setPosition: (id: string, pos: { x: number; y: number }) => void;
  setNodeSize: (id: string, size: { w: number; h: number } | null) => void;
  upsertAdkarGroup: (group: AdkarGroup) => void;
  removeAdkarGroup: (id: string) => void;
  saveOperatingModel: (model: OperatingModel) => void;
  removeOperatingModel: (id: string) => void;
  /** Saves a restore point of the whole workspace. */
  saveVersion: (label?: string) => void;
  /** Replaces the workspace with a stored version (after snapshotting today's state). */
  restoreVersion: (id: string) => boolean;
  /**
   * Saves a snapshot of one scenario (defaults to the active one) so imports,
   * bulk edits and resets can be rolled back scenario-by-scenario.
   */
  snapshotScenario: (options?: {
    reason?: ScenarioSnapshot["reason"];
    label?: string;
    scenarioId?: string;
  }) => ScenarioSnapshot | null;
  /** Restores a single scenario from a snapshot, snapshotting the current state first. */
  restoreScenarioSnapshot: (id: string) => boolean;

  signIn: (email: string) => void;
  signOut: () => void;
  resetDemoData: () => void;
}

const StoreContext = createContext<StoreValue | null>(null);

export function emptyEmployee(): Employee {
  return {
    id: uid(),
    name: "",
    isOpenRole: true,
    title: "New Role",
    department: "",
    country: "United States",
    responsibilities: "",
    currentHeadcount: 0,
    plannedHeadcount: 1,
    employmentType: "Full-time",
    managerId: null,
    status: "planned",
    currentCost: 0,
    plannedCost: 0,
    serviceMonths: 0,
  };
}

export function OrgEasyProvider({ children }: { children: ReactNode }) {
  const [workspace, setWorkspace] = useState<Workspace>(() => defaultWorkspace());
  const [hydrated, setHydrated] = useState(false);
  const [consentTick, setConsentTick] = useState(0);
  // Refs for the cross-window sync channel (pop-out canvas). `lastPayloadRef`
  // holds the last serialised workspace we sent or applied, which breaks
  // broadcast echo loops between the two windows.
  const channelRef = useRef<BroadcastChannel | null>(null);
  const lastPayloadRef = useRef<string | null>(null);
  const instanceIdRef = useRef(uid());
  const workspaceRef = useRef(workspace);
  const hydratedRef = useRef(hydrated);
  const receivedSyncRef = useRef(false);

  workspaceRef.current = workspace;
  hydratedRef.current = hydrated;

  useEffect(() => subscribeConsent(() => setConsentTick((n) => n + 1)), []);

  // Receive workspace updates broadcast from another window (e.g. edits made
  // inside the popped-out canvas) and adopt them.
  useEffect(() => {
    if (typeof BroadcastChannel === "undefined") return;
    const ch = new BroadcastChannel(SYNC_CHANNEL);
    channelRef.current = ch;
    const postWorkspace = () => {
      if (!hydratedRef.current) return;
      try {
        const payload = JSON.stringify(workspaceRef.current);
        ch.postMessage(
          JSON.stringify({ type: "workspace", sender: instanceIdRef.current, payload }),
        );
      } catch {
        /* payload too large to clone for the channel — skip sync */
      }
    };
    ch.onmessage = (event: MessageEvent<unknown>) => {
      const message = parseWorkspaceSyncMessage(event.data);
      if (!message || message.sender === instanceIdRef.current) return;
      if (message.type === "request") {
        postWorkspace();
        return;
      }
      const payload = message.payload;
      if (payload === lastPayloadRef.current) return;
      try {
        const parsed = JSON.parse(payload) as Workspace;
        if (!parsed?.scenarios?.length) return;
        receivedSyncRef.current = true;
        lastPayloadRef.current = payload;
        // Do not re-apply the fixed demo reset to live sync messages: the pop-out
        // canvas must mirror in-session edits exactly, then normal page reloads
        // can still restore the locked demo dataset through storage hydration.
        setWorkspace(parsed);
      } catch {
        /* ignore malformed workspace payloads */
      }
    };
    try {
      ch.postMessage(JSON.stringify({ type: "request", sender: instanceIdRef.current }));
    } catch {
      /* ignore unavailable channel */
    }
    return () => {
      channelRef.current = null;
      ch.close();
    };
  }, []);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      // Without workspace consent we keep work in sessionStorage instead, so a
      // reload inside the same tab never loses a generated pack or import.
      const session = window.sessionStorage.getItem(STORAGE_KEY);
      // A popped-out canvas is a separate window. Give it the opener's exact
      // live workspace before storage hydration runs, otherwise a consented
      // localStorage snapshot can briefly replace unsaved in-session edits.
      const handoff =
        window.location.pathname === "/canvas-popout"
          ? window.sessionStorage.getItem(POP_OUT_HANDOFF_KEY)
          : null;
      const source = handoff ?? raw ?? session;
      if (source) {
        const parsed = JSON.parse(source) as Workspace;
        if (parsed?.scenarios?.length) {
          if (handoff) {
            receivedSyncRef.current = true;
            lastPayloadRef.current = source;
            setWorkspace(parsed);
          } else {
            setWorkspace(withFixedBaseline(parsed));
          }
        }
      }
      window.sessionStorage.removeItem(POP_OUT_HANDOFF_KEY);
      for (const key of LEGACY_KEYS) {
        window.localStorage.removeItem(key);
        window.sessionStorage.removeItem(key);
      }
    } catch {
      /* ignore corrupt storage */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    // Workspace records are personal data: long-term (localStorage) persistence
    // needs explicit consent. Without it we fall back to tab-scoped
    // sessionStorage so the current session's work survives a reload and is
    // discarded when the tab closes.
    const persistent = hasConsent("workspace");
    const store = persistent ? window.localStorage : window.sessionStorage;
    try {
      (persistent ? window.sessionStorage : window.localStorage).removeItem(STORAGE_KEY);
    } catch {
      /* ignore */
    }
    // Enterprise-scale workspaces can hold hundreds of thousands of rows, so we
    // debounce serialisation (keeps typing/dragging smooth) and skip writes that
    // would exceed the browser storage budget.
    const timer = window.setTimeout(() => {
      try {
        const payload = JSON.stringify(workspace);
        // Keep any other open window (pop-out canvas) in sync. Skip payloads
        // we just adopted from the other window so the two never echo. A newly
        // opened pop-out with an opener waits for the main window's first
        // response before it broadcasts, preventing its empty sessionStorage
        // fallback from overwriting the live workspace.
        const awaitingInitialPopoutSync =
          window.location.pathname === "/canvas-popout" &&
          Boolean(window.opener && !window.opener.closed) &&
          !receivedSyncRef.current;
        if (payload !== lastPayloadRef.current) {
          lastPayloadRef.current = payload;
          if (!awaitingInitialPopoutSync) {
            try {
              channelRef.current?.postMessage(
                JSON.stringify({ type: "workspace", sender: instanceIdRef.current, payload }),
              );
            } catch {
              /* payload too large to clone for the channel — skip sync */
            }
          }
        }
        if (payload.length > SCALE_LIMITS.persistBytes) {
          store.removeItem(STORAGE_KEY);
          return;
        }
        store.setItem(STORAGE_KEY, payload);
      } catch {
        /* storage full — the workspace stays in memory for this session */
      }
    }, 600);
    return () => window.clearTimeout(timer);
  }, [workspace, hydrated, consentTick]);

  // Automatic restore points: once the workspace has settled, capture a snapshot
  // (rate-limited) so a bad pack regeneration or cost edit can be rolled back.
  useEffect(() => {
    if (!hydrated) return;
    const timer = window.setTimeout(() => {
      if (shouldAutoSnapshot()) saveVersion(workspace, { reason: "auto" });
    }, 4000);
    return () => window.clearTimeout(timer);
  }, [workspace, hydrated]);

  const scenario = useMemo(
    () => workspace.scenarios.find((s) => s.id === workspace.activeScenarioId) ?? null,
    [workspace],
  );

  const patchActive = useCallback((fn: (s: Scenario) => Scenario) => {
    setWorkspace((w) => ({
      ...w,
      scenarios: w.scenarios.map((s) =>
        s.id === w.activeScenarioId ? { ...fn(s), updatedAt: new Date().toISOString() } : s,
      ),
    }));
  }, []);

  // RBAC: every mutating action checks the current workspace role before
  // applying, so read-only (Viewer) sessions are enforced centrally rather
  // than per screen.
  const role: WorkspaceRole = workspace.role ?? "admin";
  const guard = (permission: Permission, action: string): boolean => {
    if (roleCan(role, permission)) return true;
    toast.error(`${ROLE_META[role].label}s can't ${action}`, {
      description:
        "Your workspace role doesn't include this action. An Admin can change roles on the Workspace access page.",
    });
    return false;
  };
  const log = (w: Workspace, kind: ActivityKind, message: string, scenarioName?: string) =>
    logEvent(w.activity, w.account?.email ?? "Guest session", kind, message, scenarioName);

  const value: StoreValue = useMemo(
    () => ({
      hydrated,
      workspace,
      scenario,
      role,
      can: (permission) => roleCan(role, permission),
      setRole: (next) => {
        if (!guard("manageRoles", "change workspace roles")) return;
        setWorkspace((w) => ({
          ...w,
          role: next,
          activity: log(w, "access", `Workspace role changed to ${ROLE_META[next].label}`),
        }));
        toast.success(`Workspace role set to ${ROLE_META[next].label}`, {
          description: ROLE_META[next].tagline,
        });
      },
      recordActivity: (kind, message, scenarioName) =>
        setWorkspace((w) => ({
          ...w,
          activity: log(w, kind, message, scenarioName ?? w.scenarios.find((s) => s.id === w.activeScenarioId)?.name),
        })),
      clearActivity: () => {
        if (!guard("resetData", "clear the activity log")) return;
        setWorkspace((w) => ({
          ...w,
          activity: log({ ...w, activity: [] }, "access", "Cleared the activity log"),
        }));
      },
      setActiveScenario: (id) => setWorkspace((w) => ({ ...w, activeScenarioId: id })),
      createScenario: (name, cloneFromId, meta) => {
        if (!guard("manageScenarios", "create scenarios")) return;
        setWorkspace((w) => {
          const source = w.scenarios.find((s) => s.id === cloneFromId);
          const next: Scenario = source
            ? {
                ...structuredClone(source),
                id: uid(),
                name,
                createdAt: new Date().toISOString(),
                kind: "future",
                phaseOrder: nextPhaseOrder(w.scenarios),
                phaseLabel: "",
                baselineId: cloneFromId ?? null,
                ...meta,
              }
            : {
                id: uid(),
                name,
                description: "",
                currency: "USD",
                createdAt: new Date().toISOString(),
                employees: [],
                adkarGroups: [],
                positions: {},
                kind: "future",
                phaseOrder: nextPhaseOrder(w.scenarios),
                phaseLabel: "",
                baselineId: null,
                ...meta,
              };
          return {
            ...w,
            scenarios: [...w.scenarios, next],
            activeScenarioId: next.id,
            activity: log(w, "scenario", `Created scenario “${name}”`, name),
          };
        });
      },
      createScenarioWithEmployees: (name, employees, meta) => {
        if (!guard("manageScenarios", "create scenarios")) return "";
        const id = uid();
        setWorkspace((w) => {
          const next: Scenario = {
            id,
            name,
            description: "",
            currency: "USD",
            createdAt: new Date().toISOString(),
            employees: structuredClone(employees),
            adkarGroups: [],
            positions: {},
            kind: "current",
            phaseOrder: 0,
            phaseLabel: "",
            baselineId: null,
            ...meta,
          };
          return {
            ...w,
            scenarios: [...w.scenarios, next],
            activeScenarioId: next.id,
            activity: log(w, "scenario", `Created scenario “${name}” from a generated model`, name),
          };
        });
        return id;
      },
      addNextPhase: () => {
        if (!guard("manageScenarios", "add phases")) return;
        setWorkspace((w) => {
          const phases = listPhases(w.scenarios);
          const source = phases[phases.length - 1] ?? currentStateScenario(w.scenarios);
          const order = nextPhaseOrder(w.scenarios);
          const next: Scenario = {
            ...(source
              ? structuredClone(source)
              : {
                  description: "",
                  currency: "USD",
                  employees: [],
                  adkarGroups: [],
                  positions: {},
                }),
            id: uid(),
            name: `Future State — Phase ${order}`,
            description: source
              ? `Builds on “${source.name}”.`
              : "New phase of the target organisation.",
            createdAt: new Date().toISOString(),
            kind: "future",
            phaseOrder: order,
            phaseLabel: `Phase ${order}`,
            baselineId: source?.id ?? null,
          } as Scenario;
          return {
            ...w,
            scenarios: [...w.scenarios, next],
            activeScenarioId: next.id,
            activity: log(w, "scenario", `Added ${next.phaseLabel || "a new phase"} — “${next.name}”`, next.name),
          };
        });
      },
      renameScenario: (id, name, description) => {
        if (!guard("manageScenarios", "rename scenarios")) return;
        setWorkspace((w) => ({
          ...w,
          scenarios: w.scenarios.map((s) =>
            s.id === id ? { ...s, name, description, updatedAt: new Date().toISOString() } : s,
          ),
          activity: log(w, "scenario", `Renamed a scenario to “${name}”`, name),
        }));
      },
      reorderPhases: (orderedIds) => {
        if (!guard("manageScenarios", "reorder phases")) return;
        setWorkspace((w) => {
          const phases = listPhases(w.scenarios);
          // Keep only known phase ids, then append any phase the caller omitted.
          const ordered = [
            ...orderedIds.filter((id) => phases.some((p) => p.id === id)),
            ...phases.filter((p) => !orderedIds.includes(p.id)).map((p) => p.id),
          ];
          const rank = new Map(ordered.map((id, index) => [id, index + 1]));
          const scenarios = w.scenarios.map((s) => {
            const order = rank.get(s.id);
            if (!order) return s;
            const label = s.phaseLabel?.trim();
            const autoLabel = !label || /^phase\s*\d+$/i.test(label);
            return { ...s, phaseOrder: order, phaseLabel: autoLabel ? `Phase ${order}` : label };
          });
          // Drop explicit baselines that now point at a later phase so the
          // automatic "previous phase" resolution stays correct.
          return {
            ...w,
            scenarios: scenarios.map((s) => {
              const order = rank.get(s.id);
              const baseOrder = s.baselineId ? rank.get(s.baselineId) : undefined;
              if (order && baseOrder && baseOrder >= order) return { ...s, baselineId: null };
              return s;
            }),
          };
        });
      },
      deleteScenario: (id) => {
        if (!guard("deleteScenarios", "delete scenarios")) return;
        setWorkspace((w) => {
          const target = w.scenarios.find((s) => s.id === id);
          const scenarios = w.scenarios.filter((s) => s.id !== id);
          return {
            ...w,
            scenarios,
            activeScenarioId:
              w.activeScenarioId === id ? (scenarios[0]?.id ?? null) : w.activeScenarioId,
            activity: log(w, "scenario", `Deleted scenario “${target?.name ?? id}”`),
          };
        });
      },
      updateScenario: (patch) => {
        if (!guard("editStructure", "change scenario settings")) return;
        patchActive((s) => ({ ...s, ...patch }));
      },
      upsertEmployee: (employee) => {
        if (!guard("editStructure", "edit roles")) return;
        patchActive((s) => ({
          ...s,
          employees: s.employees.some((e) => e.id === employee.id)
            ? s.employees.map((e) => (e.id === employee.id ? employee : e))
            : [...s.employees, employee],
        }));
      },
      addEmployee: () => {
        const employee = emptyEmployee();
        if (!guard("editStructure", "add roles")) return employee;
        patchActive((s) => ({ ...s, employees: [...s.employees, employee] }));
        return employee;
      },
      removeEmployee: (id) => {
        if (!guard("editStructure", "remove roles")) return;
        const removed = scenario?.employees.find((e) => e.id === id);
        patchActive((s) => ({
          ...s,
          employees: s.employees
            .filter((e) => e.id !== id)
            .map((e) => (e.managerId === id ? { ...e, managerId: null } : e))
            .map((e) =>
              (e.dottedManagerIds ?? []).includes(id)
                ? { ...e, dottedManagerIds: e.dottedManagerIds!.filter((m) => m !== id) }
                : e,
            ),
        }));
        if (removed)
          setWorkspace((w) => ({
            ...w,
            activity: log(
              w,
              "structure",
              `Removed role “${removed.title || removed.name || "Untitled role"}”`,
              scenario?.name,
            ),
          }));
      },
      replaceEmployees: (employees) => {
        if (!guard("editStructure", "replace the roster")) return;
        patchActive((s) => ({ ...s, employees }));
        setWorkspace((w) => ({
          ...w,
          activity: log(
            w,
            "structure",
            `Roster updated — ${employees.length.toLocaleString()} roles`,
            scenario?.name,
          ),
        }));
      },
      mutateScenarioEmployees: (scenarioId, updater) => {
        if (!guard("editStructure", "change the structure")) return;
        setWorkspace((w) => ({
          ...w,
          scenarios: w.scenarios.map((s) =>
            s.id === scenarioId
              ? { ...s, employees: updater(s.employees), updatedAt: new Date().toISOString() }
              : s,
          ),
          activity: log(
            w,
            "structure",
            "Edited the structure (reporting lines or roles)",
            w.scenarios.find((s) => s.id === scenarioId)?.name,
          ),
        }));
      },
      resetChartData: (opts) => {
        if (!guard("editStructure", "reset chart data")) return false;
        const keepLayout = opts?.keepLayout ?? true;
        const keepLinks = opts?.keepLinks ?? true;
        const fresh = seedScenarios().find((s) => s.id === scenario?.id);
        if (!fresh) return false;
        // A reset is destructive: keep a scenario snapshot so it can be undone.
        if (scenario) saveScenarioSnapshot(scenario, { reason: "pre-reset", label: "Before reset" });

        patchActive((s) => {
          const base =
            s.id === CURRENT_STATE_ID ? baselineEmployees() : structuredClone(fresh.employees);
          const previous = new Map(s.employees.map((e) => [e.id, e]));
          const employees = base.map((e) => {
            const prev = keepLinks ? previous.get(e.id) : undefined;
            if (!prev) return e;
            return {
              ...e,
              managerId: prev.managerId,
              ...(prev.dottedManagerIds ? { dottedManagerIds: [...prev.dottedManagerIds] } : {}),
            };
          });
          return {
            ...s,
            employees,
            positions: keepLayout ? (s.positions ?? {}) : {},
            ...(keepLayout ? (s.nodeSizes ? { nodeSizes: s.nodeSizes } : {}) : { nodeSizes: {} }),
          };
        });
        setWorkspace((w) => ({
          ...w,
          activity: log(w, "structure", "Reset chart data to the seeded roster", scenario?.name),
        }));
        return true;
      },
      resetChartLayout: () => {
        if (!guard("editStructure", "reset the chart layout")) return;
        patchActive((s) => ({ ...s, positions: {}, nodeSizes: {} }));
      },

      setPosition: (id, pos) =>
        patchActive((s) => ({ ...s, positions: { ...s.positions, [id]: pos } })),
      setNodeSize: (id, size) =>
        patchActive((s) => {
          const next = { ...(s.nodeSizes ?? {}) };
          if (size) next[id] = size;
          else delete next[id];
          return { ...s, nodeSizes: next };
        }),
      upsertAdkarGroup: (group) => {
        if (!guard("editStructure", "edit ADKAR groups")) return;
        patchActive((s) => ({
          ...s,
          adkarGroups: s.adkarGroups.some((g) => g.id === group.id)
            ? s.adkarGroups.map((g) => (g.id === group.id ? group : g))
            : [...s.adkarGroups, group],
        }));
      },
      removeAdkarGroup: (id) => {
        if (!guard("editStructure", "remove ADKAR groups")) return;
        patchActive((s) => ({ ...s, adkarGroups: s.adkarGroups.filter((g) => g.id !== id) }));
      },
      saveOperatingModel: (model) => {
        if (!guard("manageScenarios", "save operating models")) return;
        setWorkspace((w) => {
          const existing = w.operatingModels ?? [];
          return {
            ...w,
            operatingModels: existing.some((m) => m.id === model.id)
              ? existing.map((m) => (m.id === model.id ? model : m))
              : [...existing, model],
          };
        });
      },
      removeOperatingModel: (id) => {
        if (!guard("manageScenarios", "remove operating models")) return;
        setWorkspace((w) => ({
          ...w,
          operatingModels: (w.operatingModels ?? []).filter((m) => m.id !== id),
        }));
      },
      saveVersion: (label) => {
        saveVersion(workspace, {
          reason: "manual",
          ...(label ? { label } : {}),
          ...(typeof window !== "undefined" ? { origin: window.location.pathname } : {}),
        });
        setWorkspace((w) => ({
          ...w,
          activity: log(w, "version", `Saved a workspace restore point${label ? ` — “${label}”` : ""}`),
        }));
      },
      restoreVersion: (id) => {
        if (!guard("resetData", "restore workspace versions")) return false;
        const version = loadVersions().find((v) => v.id === id);
        if (!version) return false;
        // Snapshot the pre-restore state so restoring is itself undoable.
        saveVersion(workspace, { reason: "pre-restore", label: "Before restore" });
        const restored = structuredClone(version.workspace);
        setWorkspace((w) => ({
          ...restored,
          // Roles and the audit trail survive a restore: restoring data must
          // never silently hand back elevated access or erase the record.
          role: w.role ?? "admin",
          activity: log(w, "version", `Restored the workspace to “${version.label || version.id}”`),
        }));
        return true;
      },
      snapshotScenario: (options) => {
        const target = options?.scenarioId
          ? (workspace.scenarios.find((s) => s.id === options.scenarioId) ?? null)
          : scenario;
        if (!target) return null;
        return saveScenarioSnapshot(target, {
          ...(options?.reason ? { reason: options.reason } : {}),
          ...(options?.label ? { label: options.label } : {}),
        });
      },
      restoreScenarioSnapshot: (id) => {
        if (!guard("manageScenarios", "restore scenario snapshots")) return false;
        const snapshot = findScenarioSnapshot(id);
        if (!snapshot) return false;
        const current = workspace.scenarios.find((s) => s.id === snapshot.scenarioId);
        // Snapshot the live scenario first so a restore is itself reversible.
        if (current)
          saveScenarioSnapshot(current, { reason: "pre-restore", label: "Before restore" });
        setWorkspace((w) => {
          const restored: Scenario = {
            ...structuredClone(snapshot.scenario),
            updatedAt: new Date().toISOString(),
          };
          const exists = w.scenarios.some((s) => s.id === restored.id);
          return {
            ...w,
            scenarios: exists
              ? w.scenarios.map((s) => (s.id === restored.id ? restored : s))
              : // The scenario was deleted since the snapshot: bring it back.
                [...w.scenarios, restored],
            activeScenarioId: restored.id,
            activity: log(
              w,
              "version",
              `Restored “${restored.name}” from a snapshot${snapshot.label ? ` — ${snapshot.label}` : ""}`,
              restored.name,
            ),
          };
        });
        return true;
      },

      signIn: (email) =>
        setWorkspace((w) => ({
          ...w,
          account: { email, signedInAt: new Date().toISOString() },
          activity: log({ ...w, account: { email, signedInAt: new Date().toISOString() } }, "access", `Signed in as ${email}`),
        })),
      signOut: () =>
        setWorkspace((w) => ({
          ...w,
          account: null,
          activity: log(w, "access", `Signed out${w.account?.email ? ` (${w.account.email})` : ""}`),
        })),
      resetDemoData: () => {
        if (!guard("resetData", "reset the workspace")) return;
        try {
          window.localStorage.removeItem(STORAGE_KEY);
          window.sessionStorage.removeItem(STORAGE_KEY);
        } catch {
          /* ignore */
        }
        const fresh = defaultWorkspace();
        setWorkspace({
          ...fresh,
          activity: log(fresh, "access", "Workspace reset to demo data"),
        });
      },
    }),
    [hydrated, workspace, scenario, patchActive],
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useOrgEasy() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useOrgEasy must be used inside OrgEasyProvider");
  return ctx;
}

export { uid };
