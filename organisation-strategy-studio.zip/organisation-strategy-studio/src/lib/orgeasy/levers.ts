import type { ReductionLever, Scenario, Workspace } from "./types";
import { REDUCTION_LEVERS, LEVER_META } from "./types";
import { currentStateFor, phasesFor, phaseTitle } from "./phases";
import { TARGET_REDUCTION_PCT } from "./seed";
import {
  effectiveRules,
  exitCount,
  exitCostForRole,
  resolveCountries,
  ruleFor,
  separationSummary,
  type CountrySeparation,
} from "./country-costs";

export interface LeverContribution {
  lever: ReductionLever;
  label: string;
  short: string;
  hex: string;
  description: string;
  positions: number;
  cost: number;
}

export interface PhaseProgress {
  id: string;
  name: string;
  title: string;
  headcount: number;
  cumulativeReduction: number;
  stepReduction: number;
  cost: number;
  costSaving: number;
  byLever: Record<ReductionLever, number>;
  /** Incremental one-off separation cost created by this phase alone. */
  separationExits: number;
  separationLow: number;
  separationMid: number;
  separationHigh: number;
  /** Largest markets by incremental separation cost in this phase. */
  separationTopCountries: string[];
}

export interface ProgrammeSummary {
  baselineHeadcount: number;
  baselineCost: number;
  finalHeadcount: number;
  finalCost: number;
  targetPct: number;
  targetReduction: number;
  achievedReduction: number;
  achievedPct: number;
  grossRemovals: number;
  rolesAdded: number;
  costSaving: number;
  levers: LeverContribution[];
  phases: PhaseProgress[];
  currency: string;
  /** Illustrative one-off separation cost across every phase of the programme. */
  separationExits: number;
  separationLow: number;
  separationMid: number;
  separationHigh: number;
  separationByCountry: CountrySeparation[];
  highRiskMarkets: CountrySeparation[];
}

function headcountOf(s: Scenario, planned: boolean) {
  return s.employees.reduce((a, e) => a + (planned ? e.plannedHeadcount : e.currentHeadcount), 0);
}

function costOf(s: Scenario, planned: boolean) {
  return s.employees.reduce(
    (a, e) => a + (planned ? e.plannedCost * e.plannedHeadcount : e.currentCost * e.currentHeadcount),
    0,
  );
}

function emptyByLever(): Record<ReductionLever, number> {
  return { headcount: 0, span: 0, duplicate: 0, automation: 0, agent: 0 };
}

/**
 * Rolls the whole phase chain up into a single reduction programme view,
 * attributing every removed position to its transformation lever.
 */
export function computeProgramme(
  workspace: Workspace,
  /** Anchor scenario — the programme is rolled up around its own baseline. */
  anchor?: import("./types").Scenario | null,
): ProgrammeSummary {
  const scenarios = workspace.scenarios;
  const current =
    anchor && anchor.kind === "current" ? anchor : currentStateFor(scenarios, anchor ?? null);
  const phases = phasesFor(scenarios, current);
  const last = phases[phases.length - 1] ?? current;
  const currency = current?.currency ?? "USD";

  const baselineHeadcount = current ? headcountOf(current, false) : 0;
  const baselineCost = current ? costOf(current, false) : 0;
  const finalHeadcount = last ? headcountOf(last, true) : baselineHeadcount;
  const finalCost = last ? costOf(last, true) : baselineCost;

  const leverPositions = emptyByLever();
  const leverCost = emptyByLever();
  let grossRemovals = 0;
  let rolesAdded = 0;

  if (last) {
    for (const e of last.employees) {
      const cut = e.currentHeadcount - e.plannedHeadcount;
      if (cut > 0) {
        grossRemovals += cut;
        const lever: ReductionLever = e.reductionLever ?? "headcount";
        leverPositions[lever] += cut;
        leverCost[lever] += cut * e.currentCost;
      }
      if (e.currentHeadcount === 0 && e.plannedHeadcount > 0) rolesAdded += e.plannedHeadcount;
    }
  }

  // One-off separation cost: each phase is a cumulative snapshot of the same
  // baseline, so summing phases would count the same exit two or three times.
  // Price the end state once — baseline positions missing from the final phase
  // still count as exits — which keeps this equal to Impact simulation.
  const endStateEmployees = last
    ? (() => {
        const seen = new Set(last.employees.map((e) => e.id));
        const merged = [...last.employees];
        for (const b of current?.employees ?? []) {
          if (!seen.has(b.id)) merged.push({ ...b, plannedHeadcount: 0, status: "to-be-removed" });
        }
        return merged;
      })()
    : [];
  const endRules = effectiveRules(last ?? null);
  const separationByCountry = [...separationSummary(endStateEmployees, endRules).byCountry].sort(
    (a, b) => b.mid - a.mid,
  );

  // Per-role end-state exit cost, so the phase split is a true breakdown of the
  // same total rather than a second, separately priced calculation.
  const endCountries = resolveCountries(endStateEmployees);
  const roleExit = new Map<
    string,
    { country: string; exits: number; low: number; mid: number; high: number }
  >();
  for (const e of endStateEmployees) {
    const exits = exitCount(e);
    if (exits <= 0) continue;
    const country = endCountries.get(e.id) ?? "Unspecified";
    const cost = exitCostForRole(e, ruleFor(country, endRules), exits);
    roleExit.set(e.id, { country, exits, low: cost.low, mid: cost.mid, high: cost.high });
  }
  /** Exits of a role already attributed to an earlier phase. */
  const allocated = new Map<string, number>();

  const phaseProgress: PhaseProgress[] = [];
  let previous = baselineHeadcount;
  for (const phase of phases) {
    const hc = headcountOf(phase, true);
    const byLever = emptyByLever();
    for (const e of phase.employees) {
      const cut = e.currentHeadcount - e.plannedHeadcount;
      if (cut > 0) byLever[e.reductionLever ?? "headcount"] += cut;
    }
    // Exits visible in this cumulative snapshot, minus everything already
    // attributed to earlier phases, priced pro-rata on the end-state cost.
    const seenInPhase = new Set(phase.employees.map((e) => e.id));
    const snapshotExits = new Map<string, number>();
    for (const e of phase.employees) {
      const total = roleExit.get(e.id);
      if (!total) continue;
      snapshotExits.set(e.id, Math.min(total.exits, exitCount(e)));
    }
    for (const b of current?.employees ?? []) {
      if (seenInPhase.has(b.id)) continue;
      const total = roleExit.get(b.id);
      if (total) snapshotExits.set(b.id, total.exits);
    }
    let stepExits = 0;
    let stepLow = 0;
    let stepMid = 0;
    let stepHigh = 0;
    const byCountry = new Map<string, number>();
    for (const [id, cum] of snapshotExits) {
      const total = roleExit.get(id);
      if (!total) continue;
      const step = Math.max(0, Math.min(total.exits, cum) - (allocated.get(id) ?? 0));
      if (step <= 0) continue;
      allocated.set(id, (allocated.get(id) ?? 0) + step);
      const share = step / total.exits;
      stepExits += step;
      stepLow += total.low * share;
      stepMid += total.mid * share;
      stepHigh += total.high * share;
      byCountry.set(total.country, (byCountry.get(total.country) ?? 0) + total.mid * share);
    }
    const topCountries = [...byCountry.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([country]) => country);
    phaseProgress.push({
      id: phase.id,
      name: phase.name,
      title: phaseTitle(phase),
      headcount: hc,
      cumulativeReduction: baselineHeadcount - hc,
      stepReduction: previous - hc,
      cost: costOf(phase, true),
      costSaving: baselineCost - costOf(phase, true),
      byLever,
      separationExits: stepExits,
      separationLow: stepLow,
      separationMid: stepMid,
      separationHigh: stepHigh,
      separationTopCountries: topCountries,
    });
    previous = hc;
  }

  // Any exit that only shows up in the merged end state (never visible in a
  // phase snapshot) lands on the final phase, so the split always reconciles
  // to the total one-off cost.
  const lastProgress = phaseProgress[phaseProgress.length - 1];
  if (lastProgress) {
    for (const [id, total] of roleExit) {
      const rest = total.exits - (allocated.get(id) ?? 0);
      if (rest <= 0) continue;
      const share = rest / total.exits;
      lastProgress.separationExits += rest;
      lastProgress.separationLow += total.low * share;
      lastProgress.separationMid += total.mid * share;
      lastProgress.separationHigh += total.high * share;
      allocated.set(id, total.exits);
    }
  }

  // Country-level collective consultation costs sit outside per-role pricing, so
  // spread them across phases in proportion to their exit cost. This keeps the
  // phase split reconciling exactly to the programme total.
  {
    const totals = separationByCountry.reduce(
      (a, c) => ({ low: a.low + c.low, mid: a.mid + c.mid, high: a.high + c.high }),
      { low: 0, mid: 0, high: 0 },
    );
    const sums = phaseProgress.reduce(
      (a, p) => ({
        low: a.low + p.separationLow,
        mid: a.mid + p.separationMid,
        high: a.high + p.separationHigh,
      }),
      { low: 0, mid: 0, high: 0 },
    );
    for (const p of phaseProgress) {
      if (sums.low > 0) p.separationLow *= totals.low / sums.low;
      if (sums.mid > 0) p.separationMid *= totals.mid / sums.mid;
      if (sums.high > 0) p.separationHigh *= totals.high / sums.high;
    }
  }

  const achievedReduction = baselineHeadcount - finalHeadcount;

  return {
    baselineHeadcount,
    baselineCost,
    finalHeadcount,
    finalCost,
    targetPct: TARGET_REDUCTION_PCT,
    targetReduction: Math.round(baselineHeadcount * TARGET_REDUCTION_PCT),
    achievedReduction,
    achievedPct: baselineHeadcount ? achievedReduction / baselineHeadcount : 0,
    grossRemovals,
    rolesAdded,
    costSaving: baselineCost - finalCost,
    currency,
    levers: REDUCTION_LEVERS.map((lever) => ({
      lever,
      ...LEVER_META[lever],
      positions: leverPositions[lever],
      cost: leverCost[lever],
    })),
    phases: phaseProgress,
    separationExits: separationByCountry.reduce((a, c) => a + c.exits, 0),
    separationLow: separationByCountry.reduce((a, c) => a + c.low, 0),
    separationMid: separationByCountry.reduce((a, c) => a + c.mid, 0),
    separationHigh: separationByCountry.reduce((a, c) => a + c.high, 0),
    separationByCountry,
    highRiskMarkets: separationByCountry.filter((c) => c.rule.risk === "High" && c.exits > 0),
  };
}
