/**
 * Automotive Operating Model Autogenerator.
 *
 * Produces a complete Human + AI Agent operating model for nine automotive
 * functions. Content is curated, deterministic and scaled by company size and
 * region so leadership always sees a credible, presentation-ready structure.
 */
import type { Employee } from "./types";

export type CompanySize = "startup" | "midsize" | "enterprise";
export type RegionFocus = "global" | "asean" | "europe" | "north-america" | "china";

export const COMPANY_SIZES: { value: CompanySize; label: string; blurb: string }[] = [
  { value: "startup", label: "Startup / Challenger", blurb: "Lean team, one layer of leadership" },
  { value: "midsize", label: "Mid-size", blurb: "National importer, dealer group or fleet operator" },
  { value: "enterprise", label: "Large Enterprise", blurb: "OEM or multi-market distributor" },
];

export const REGIONS: { value: RegionFocus; label: string; note: string; country: string }[] = [
  { value: "global", label: "Global", note: "Global HQ standards with regional adaptation", country: "United States" },
  { value: "asean", label: "ASEAN", note: "Distributor-led markets, high two-wheeler and pickup mix", country: "Singapore" },
  { value: "europe", label: "Europe", note: "Works councils, CO2 compliance and agency sales models", country: "Germany" },
  { value: "north-america", label: "North America", note: "Franchise dealer law, large truck and SUV mix", country: "United States" },
  { value: "china", label: "China", note: "NEV-first, direct-to-consumer and rapid model cycles", country: "China" },
];

export type FunctionKey =
  | "hr"
  | "finance"
  | "product-marketing"
  | "portfolio-planning"
  | "marketing"
  | "sales"
  | "service-sales"
  | "zone-manager"
  | "commercial-fleet";

export type Autonomy = "human-in-the-loop" | "supervised" | "autonomous";

export const AUTONOMY_META: Record<Autonomy, { label: string; hint: string }> = {
  "human-in-the-loop": { label: "Human-in-the-loop", hint: "Agent proposes, a named human approves" },
  supervised: { label: "Supervised autonomy", hint: "Agent acts inside guardrails, humans review exceptions" },
  autonomous: { label: "Fully autonomous", hint: "Agent runs end-to-end, humans audit outcomes" },
};

export type RaciMode = "human" | "agent" | "hybrid";

export const RACI_META: Record<RaciMode, { label: string; className: string }> = {
  human: { label: "Human-owned", className: "bg-secondary text-secondary-foreground" },
  agent: { label: "Agent-owned", className: "bg-info/15 text-info" },
  hybrid: { label: "Hybrid", className: "bg-warning/20 text-warning-foreground" },
};

export interface HumanRole {
  id: string;
  title: string;
  /** 1 = function head, 2 = lead, 3 = specialist. */
  level: 1 | 2 | 3;
  reportsTo: string | null;
  responsibilities: string[];
  kpis: string[];
  collaboration: string[];
  headcount: number;
}

export interface AgentRole {
  id: string;
  name: string;
  purpose: string;
  owns: string[];
  autonomy: Autonomy;
  dataSources: string[];
  triggers: string[];
  pairedRoleId: string;
}

export interface RaciRow {
  task: string;
  mode: RaciMode;
  human: string;
  agent: string;
}

export interface FunctionModel {
  key: FunctionKey;
  label: string;
  mission: string;
  humanRoles: HumanRole[];
  agents: AgentRole[];
  raci: RaciRow[];
  fteImpact: { low: number; high: number; note: string };
}

export interface OperatingModel {
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  size: CompanySize;
  region: RegionFocus;
  includeAgents: boolean;
  functions: FunctionModel[];
}

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

/* ------------------------------------------------------------------ blueprint */

interface RoleSeed {
  key: string;
  title: string;
  level: 1 | 2 | 3;
  reportsTo: string | null;
  responsibilities: string[];
  kpis: string[];
  collaboration: string[];
  /** Base headcount for a mid-size organisation. */
  base: number;
  /** Dropped for startup-sized organisations. */
  enterpriseOnly?: boolean;
}

interface AgentSeed {
  name: string;
  purpose: string;
  owns: string[];
  autonomy: Autonomy;
  dataSources: string[];
  triggers: string[];
  pairedRole: string;
}

interface FunctionSeed {
  key: FunctionKey;
  label: string;
  mission: string;
  roles: RoleSeed[];
  agents: AgentSeed[];
  raci: RaciRow[];
  fte: { low: number; high: number; note: string };
}

const BLUEPRINT: FunctionSeed[] = [
  {
    key: "hr",
    label: "HR",
    mission:
      "Secure the technical and commercial talent the model-year plan depends on, and run a change-ready workforce across plants, NSCs and the dealer network.",
    roles: [
      {
        key: "hr-head",
        title: "HR Director",
        level: 1,
        reportsTo: null,
        responsibilities: [
          "Own the people plan behind the model-year and electrification roadmap",
          "Chair works council / employee representative consultation",
          "Govern reward, mobility and succession for commercial leadership",
        ],
        kpis: ["Critical role vacancy rate", "Regretted attrition %", "Time-to-productivity (days)"],
        collaboration: ["Finance on labour budget", "Zone Manager on field capability", "Service Sales on technician pipeline"],
        base: 1,
      },
      {
        key: "hr-tap",
        title: "Talent Acquisition Lead",
        level: 2,
        reportsTo: "hr-head",
        responsibilities: [
          "Hire EV, software and aftersales technical talent",
          "Run dealer-network recruitment standards and employer brand",
        ],
        kpis: ["Time-to-fill (days)", "Offer acceptance %", "Cost per hire"],
        collaboration: ["Sales on field vacancies", "Service Sales on technician demand"],
        base: 2,
      },
      {
        key: "hr-bp",
        title: "HR Business Partner",
        level: 2,
        reportsTo: "hr-head",
        responsibilities: [
          "Partner commercial and aftersales leadership on structure and performance",
          "Manage restructuring, consultation and redeployment casework",
        ],
        kpis: ["Manager NPS", "Case cycle time", "Internal fill rate %"],
        collaboration: ["All functions on org design", "Finance on FTE control"],
        base: 2,
      },
      {
        key: "hr-ld",
        title: "Learning & Capability Manager",
        level: 3,
        reportsTo: "hr-head",
        responsibilities: [
          "Certify EV high-voltage, diagnostics and agency-sales capability",
          "Run dealer academy curriculum and certification tracking",
        ],
        kpis: ["Certification coverage %", "Training hours per FTE", "Skill gap closure rate"],
        collaboration: ["Service Sales on technician certification", "Product Marketing on launch training"],
        base: 1,
      },
      {
        key: "hr-ops",
        title: "People Operations & Reward Analyst",
        level: 3,
        reportsTo: "hr-head",
        responsibilities: [
          "Run payroll interfaces, HRIS data quality and workforce reporting",
          "Benchmark sales incentive and technician pay structures",
        ],
        kpis: ["HRIS data accuracy %", "Payroll error rate", "Pay competitiveness index"],
        collaboration: ["Finance on labour cost", "Sales on incentive design"],
        base: 1,
        enterpriseOnly: true,
      },
    ],
    agents: [
      {
        name: "Talent Matching Agent",
        purpose: "Match internal and external candidates to open technical and commercial roles by skill adjacency.",
        owns: ["Requisition screening", "Internal redeployment shortlists", "Interview scheduling"],
        autonomy: "human-in-the-loop",
        dataSources: ["HRIS role and skill records", "ATS pipeline", "Dealer certification registry"],
        triggers: ["New requisition approved", "Role marked at-risk", "Certification expiry within 90 days"],
        pairedRole: "hr-tap",
      },
      {
        name: "Workforce Demand Agent",
        purpose: "Translate volume, model-year and aftersales plans into rolling headcount and skill demand.",
        owns: ["Rolling 18-month headcount forecast", "Technician capacity gap alerts"],
        autonomy: "supervised",
        dataSources: ["Volume plan", "Workshop hours booked", "Attrition history"],
        triggers: ["Monthly plan refresh", "Volume variance beyond ±5%"],
        pairedRole: "hr-bp",
      },
      {
        name: "Capability Coach Agent",
        purpose: "Assign and track learning paths for EV, diagnostics and agency-model selling.",
        owns: ["Personalised curricula", "Certification renewal nudges", "Launch-readiness scoring"],
        autonomy: "autonomous",
        dataSources: ["LMS records", "Certification registry", "Launch calendar"],
        triggers: ["New model launch confirmed", "Certification lapse", "Onboarding day 1"],
        pairedRole: "hr-ld",
      },
      {
        name: "Policy & Compliance Agent",
        purpose: "Draft policy answers and flag consultation obligations by market before actions are taken.",
        owns: ["Tier-1 policy Q&A", "Consultation checklist generation"],
        autonomy: "human-in-the-loop",
        dataSources: ["Policy library", "Country obligation register", "Case history"],
        triggers: ["Employee query raised", "Restructuring scenario created"],
        pairedRole: "hr-bp",
      },
    ],
    raci: [
      { task: "Workforce plan and headcount forecast", mode: "hybrid", human: "HR Business Partner signs off", agent: "Workforce Demand Agent models scenarios" },
      { task: "Candidate sourcing and screening", mode: "agent", human: "TA Lead reviews shortlist", agent: "Talent Matching Agent" },
      { task: "Consultation and separation decisions", mode: "human", human: "HR Director with counsel", agent: "Drafts checklists only" },
      { task: "Certification tracking and renewals", mode: "agent", human: "L&D Manager audits", agent: "Capability Coach Agent" },
      { task: "Reward benchmarking", mode: "hybrid", human: "Reward Analyst validates", agent: "Policy & Compliance Agent surfaces market data" },
    ],
    fte: { low: 1, high: 2, note: "Screening, scheduling and certification admin absorbed by agents." },
  },
  {
    key: "finance",
    label: "Finance",
    mission:
      "Protect margin per unit across vehicle, parts and finance revenue, and give the business a single trusted view of variable marketing spend and dealer profitability.",
    roles: [
      {
        key: "fin-head",
        title: "Finance Director",
        level: 1,
        reportsTo: null,
        responsibilities: [
          "Own P&L, gross margin per unit and variable marketing expense (VME) governance",
          "Approve incentive envelopes and dealer support programmes",
        ],
        kpis: ["Gross margin per unit", "VME as % of revenue", "Working capital days"],
        collaboration: ["Sales on incentive spend", "Portfolio on model-year business cases"],
        base: 1,
      },
      {
        key: "fin-fpa",
        title: "FP&A Manager",
        level: 2,
        reportsTo: "fin-head",
        responsibilities: [
          "Run the rolling forecast by model line, channel and market",
          "Build business cases for launches, facelifts and network investment",
        ],
        kpis: ["Forecast accuracy %", "Cycle time to close", "Business case hit rate"],
        collaboration: ["Portfolio & Planning on volume", "Marketing on spend phasing"],
        base: 2,
      },
      {
        key: "fin-pricing",
        title: "Pricing & Incentives Controller",
        level: 2,
        reportsTo: "fin-head",
        responsibilities: [
          "Set transaction price guardrails and residual value assumptions",
          "Control programme spend, stock ageing support and campaign payback",
        ],
        kpis: ["Net transaction price vs target", "Incentive per unit", "Stock ageing > 90 days %"],
        collaboration: ["Sales on deal desk", "Fleet on tender pricing"],
        base: 1,
      },
      {
        key: "fin-dealer",
        title: "Dealer Finance & Credit Analyst",
        level: 3,
        reportsTo: "fin-head",
        responsibilities: [
          "Monitor dealer composite profitability, floorplan and credit exposure",
          "Run margin and bonus settlement for the network",
        ],
        kpis: ["Dealer return on sales %", "Overdue receivables", "Bonus settlement accuracy"],
        collaboration: ["Zone Manager on dealer health", "Service Sales on parts margin"],
        base: 2,
      },
      {
        key: "fin-control",
        title: "Controlling & Reporting Analyst",
        level: 3,
        reportsTo: "fin-head",
        responsibilities: ["Close, consolidation and statutory reporting", "Cost centre control and audit support"],
        kpis: ["Days to close", "Audit findings", "Accrual accuracy"],
        collaboration: ["All functions on cost centres"],
        base: 2,
        enterpriseOnly: true,
      },
    ],
    agents: [
      {
        name: "Pricing Agent",
        purpose: "Recommend transaction price and incentive levels by model, trim, market and stock age.",
        owns: ["Price guardrail proposals", "Incentive scenario simulation", "Payback tracking"],
        autonomy: "human-in-the-loop",
        dataSources: ["Order bank", "Competitor price feeds", "Stock ageing", "Residual value curves"],
        triggers: ["Weekly pricing committee", "Stock age crosses 60 days", "Competitor price move"],
        pairedRole: "fin-pricing",
      },
      {
        name: "Margin Watch Agent",
        purpose: "Detect margin leakage across deals, programmes and parts pricing before month-end.",
        owns: ["Deal-level anomaly detection", "VME overspend alerts"],
        autonomy: "supervised",
        dataSources: ["Deal desk records", "VME ledger", "Dealer claims"],
        triggers: ["Daily deal file load", "Claim submitted above threshold"],
        pairedRole: "fin-head",
      },
      {
        name: "Forecast Copilot Agent",
        purpose: "Generate the rolling forecast narrative and variance bridge from source systems.",
        owns: ["Variance bridges", "Draft commentary", "Scenario sensitivity packs"],
        autonomy: "human-in-the-loop",
        dataSources: ["ERP actuals", "Volume plan", "FX and commodity feeds"],
        triggers: ["Month-end close complete", "Plan revision published"],
        pairedRole: "fin-fpa",
      },
      {
        name: "Dealer Credit Agent",
        purpose: "Score dealer financial health and flag floorplan or receivable risk early.",
        owns: ["Credit scoring", "Exposure alerts", "Composite benchmarking"],
        autonomy: "supervised",
        dataSources: ["Dealer composites", "Floorplan balances", "Payment history"],
        triggers: ["Composite submission", "Payment overdue 15 days"],
        pairedRole: "fin-dealer",
      },
    ],
    raci: [
      { task: "Price and incentive decisions", mode: "hybrid", human: "Pricing Controller approves", agent: "Pricing Agent proposes and simulates" },
      { task: "Month-end close and statutory reporting", mode: "human", human: "Controlling Analyst", agent: "Prepares draft variance bridges" },
      { task: "Deal-level margin anomaly detection", mode: "agent", human: "Finance Director on exceptions", agent: "Margin Watch Agent" },
      { task: "Dealer credit exposure monitoring", mode: "agent", human: "Dealer Finance Analyst acts on alerts", agent: "Dealer Credit Agent" },
      { task: "Launch business case", mode: "hybrid", human: "FP&A Manager owns assumptions", agent: "Forecast Copilot Agent builds sensitivities" },
    ],
    fte: { low: 2, high: 3, note: "Reporting pack assembly, reconciliation and claim checking largely automated." },
  },
  {
    key: "product-marketing",
    label: "Product Marketing",
    mission:
      "Define the product story, trim ladder and pricing position that make each model-year competitive in its segment.",
    roles: [
      {
        key: "pm-head",
        title: "Head of Product Marketing",
        level: 1,
        reportsTo: null,
        responsibilities: [
          "Own segment positioning, trim ladder and equipment strategy",
          "Sign off launch pricing corridors and competitive response",
        ],
        kpis: ["Segment share %", "Mix of high-trim sales", "Launch order intake vs plan"],
        collaboration: ["Portfolio & Planning on model-year content", "Marketing on campaign proposition"],
        base: 1,
      },
      {
        key: "pm-manager",
        title: "Product Manager (Model Line)",
        level: 2,
        reportsTo: "pm-head",
        responsibilities: [
          "Own the model line from pre-launch to run-out",
          "Define option packs, specification and market-specific content",
        ],
        kpis: ["Option take rate %", "Price realisation vs competitor", "Run-out stock clearance"],
        collaboration: ["Sales on order guides", "Finance on margin per trim"],
        base: 3,
      },
      {
        key: "pm-intel",
        title: "Competitive Intelligence Analyst",
        level: 3,
        reportsTo: "pm-head",
        responsibilities: ["Track competitor launches, pricing and specification moves", "Maintain the benchmark library"],
        kpis: ["Insight lead time (days)", "Benchmark coverage %", "Win/loss clarity"],
        collaboration: ["Marketing on messaging", "Finance on price position"],
        base: 1,
      },
      {
        key: "pm-launch",
        title: "Launch & Content Manager",
        level: 3,
        reportsTo: "pm-head",
        responsibilities: ["Produce launch playbooks, product training and retail collateral", "Coordinate press and dealer readiness"],
        kpis: ["Launch readiness score", "Dealer product test pass rate", "Time to collateral"],
        collaboration: ["HR L&D on training", "Zone Manager on dealer rollout"],
        base: 1,
        enterpriseOnly: true,
      },
    ],
    agents: [
      {
        name: "Competitive Radar Agent",
        purpose: "Continuously monitor competitor specification, pricing and offer moves across priority segments.",
        owns: ["Daily competitor digest", "Spec-vs-spec comparisons", "Alert on price moves"],
        autonomy: "autonomous",
        dataSources: ["Public price lists", "Configurator scrapes", "Registration data"],
        triggers: ["Competitor price list update", "New model announcement"],
        pairedRole: "pm-intel",
      },
      {
        name: "Trim & Take-Rate Agent",
        purpose: "Optimise the trim ladder and option packaging using live take-rate and margin data.",
        owns: ["Take-rate analytics", "Pack simulation", "Cannibalisation warnings"],
        autonomy: "human-in-the-loop",
        dataSources: ["Order bank", "Configurator sessions", "Margin per option"],
        triggers: ["Model-year content freeze", "Monthly take-rate review"],
        pairedRole: "pm-manager",
      },
      {
        name: "Launch Content Agent",
        purpose: "Generate first-draft product collateral, order guides and dealer training content per market.",
        owns: ["Draft copy and order guides", "Localised feature sheets", "FAQ generation"],
        autonomy: "human-in-the-loop",
        dataSources: ["Homologated specification", "Brand tone guide", "Prior launch assets"],
        triggers: ["Specification freeze", "Launch T-minus milestones"],
        pairedRole: "pm-launch",
      },
    ],
    raci: [
      { task: "Positioning and trim ladder decisions", mode: "human", human: "Head of Product Marketing", agent: "Supplies take-rate evidence" },
      { task: "Competitor monitoring", mode: "agent", human: "Intelligence Analyst curates", agent: "Competitive Radar Agent" },
      { task: "Option packaging optimisation", mode: "hybrid", human: "Product Manager decides", agent: "Trim & Take-Rate Agent simulates" },
      { task: "Launch collateral production", mode: "hybrid", human: "Launch Manager edits and approves", agent: "Launch Content Agent drafts" },
    ],
    fte: { low: 1, high: 2, note: "Benchmark maintenance and first-draft collateral shift to agents." },
  },
  {
    key: "portfolio-planning",
    label: "Portfolio & Planning",
    mission:
      "Balance model-year volume, mix and capacity so the right vehicles arrive in the right market at the right time.",
    roles: [
      {
        key: "pp-head",
        title: "Head of Portfolio & Planning",
        level: 1,
        reportsTo: null,
        responsibilities: [
          "Own the multi-year model plan, lifecycle and powertrain transition",
          "Chair the sales & operations planning (S&OP) cycle",
        ],
        kpis: ["Plan attainment %", "Days of stock cover", "Mix vs plan variance"],
        collaboration: ["Finance on business cases", "Sales on demand", "Product Marketing on content"],
        base: 1,
      },
      {
        key: "pp-demand",
        title: "Demand Planning Manager",
        level: 2,
        reportsTo: "pp-head",
        responsibilities: ["Build consensus demand by model, trim and market", "Own the order bank and pipeline conversion view"],
        kpis: ["Forecast bias", "Order-to-delivery days", "Pipeline conversion %"],
        collaboration: ["Sales and Zone teams on retail signals"],
        base: 2,
      },
      {
        key: "pp-supply",
        title: "Supply & Allocation Manager",
        level: 2,
        reportsTo: "pp-head",
        responsibilities: ["Allocate build slots and stock across markets and dealers", "Manage constraint and expedite decisions"],
        kpis: ["Allocation fill rate", "Ageing stock %", "Expedite cost"],
        collaboration: ["Zone Manager on dealer allocation", "Finance on stock funding"],
        base: 2,
      },
      {
        key: "pp-lifecycle",
        title: "Lifecycle & Run-out Analyst",
        level: 3,
        reportsTo: "pp-head",
        responsibilities: ["Plan model-year changeovers and run-out actions", "Track residual value and price positioning over life"],
        kpis: ["Run-out stock at changeover", "Residual value index", "Changeover slippage (weeks)"],
        collaboration: ["Finance on RV assumptions", "Marketing on run-out campaigns"],
        base: 1,
        enterpriseOnly: true,
      },
    ],
    agents: [
      {
        name: "Demand Sensing Agent",
        purpose: "Sense near-term demand shifts from configurator, lead, order and registration signals.",
        owns: ["Weekly demand signal refresh", "Bias correction", "Early warning on mix shifts"],
        autonomy: "supervised",
        dataSources: ["Configurator sessions", "Lead and test-drive data", "Registrations", "Order bank"],
        triggers: ["Weekly S&OP prep", "Signal deviation beyond threshold"],
        pairedRole: "pp-demand",
      },
      {
        name: "Allocation Optimiser Agent",
        purpose: "Propose build-slot and stock allocation that maximises turn rate and dealer fill.",
        owns: ["Allocation proposals", "Constraint trade-off options", "Ageing-stock rebalancing"],
        autonomy: "human-in-the-loop",
        dataSources: ["Build slots", "Dealer stock and sell-through", "Logistics lead times"],
        triggers: ["Allocation cycle open", "Constraint notification from plant"],
        pairedRole: "pp-supply",
      },
      {
        name: "Model-Year Planning Agent",
        purpose: "Simulate model-year changeover timing, content and run-out risk.",
        owns: ["Changeover scenario packs", "Run-out risk scoring"],
        autonomy: "human-in-the-loop",
        dataSources: ["Lifecycle calendar", "Stock ageing", "Historic changeover performance"],
        triggers: ["Model-year gateway review", "Run-out stock above target"],
        pairedRole: "pp-lifecycle",
      },
    ],
    raci: [
      { task: "Consensus demand plan", mode: "hybrid", human: "Demand Planning Manager owns consensus", agent: "Demand Sensing Agent produces the baseline" },
      { task: "Build slot and stock allocation", mode: "hybrid", human: "Supply Manager approves", agent: "Allocation Optimiser Agent proposes" },
      { task: "Multi-year portfolio decisions", mode: "human", human: "Head of Portfolio & Planning", agent: "Provides scenario evidence" },
      { task: "Ageing stock rebalancing", mode: "agent", human: "Supply Manager on exceptions", agent: "Allocation Optimiser Agent" },
    ],
    fte: { low: 2, high: 3, note: "Signal consolidation and allocation modelling no longer done in spreadsheets." },
  },
  {
    key: "marketing",
    label: "Marketing",
    mission:
      "Generate qualified demand at the lowest cost per sale and keep brand health strong across the funnel and the dealer network.",
    roles: [
      {
        key: "mkt-head",
        title: "Marketing Director",
        level: 1,
        reportsTo: null,
        responsibilities: ["Own brand, demand generation and media investment", "Govern national and dealer co-op marketing"],
        kpis: ["Cost per qualified lead", "Brand consideration %", "Marketing-sourced order share"],
        collaboration: ["Sales on lead quality", "Finance on VME"],
        base: 1,
      },
      {
        key: "mkt-campaign",
        title: "Campaign & Media Manager",
        level: 2,
        reportsTo: "mkt-head",
        responsibilities: ["Plan and buy always-on and launch media", "Run offer campaigns by model and market"],
        kpis: ["ROAS", "Cost per test drive", "Reach vs target audience"],
        collaboration: ["Product Marketing on proposition", "Zone Manager on local activation"],
        base: 2,
      },
      {
        key: "mkt-crm",
        title: "CRM & Lifecycle Manager",
        level: 2,
        reportsTo: "mkt-head",
        responsibilities: ["Own owner lifecycle, retention and service-lead nurture", "Manage consent, preference and data quality"],
        kpis: ["Owner retention %", "Service lead conversion", "Consent coverage %"],
        collaboration: ["Service Sales on aftersales offers", "HR on privacy training"],
        base: 1,
      },
      {
        key: "mkt-digital",
        title: "Digital & Content Specialist",
        level: 3,
        reportsTo: "mkt-head",
        responsibilities: ["Run website, configurator and social content", "Optimise digital retail journey"],
        kpis: ["Configurator completion %", "Digital lead volume", "Page performance"],
        collaboration: ["Sales on digital handover"],
        base: 2,
      },
      {
        key: "mkt-insight",
        title: "Marketing Insight Analyst",
        level: 3,
        reportsTo: "mkt-head",
        responsibilities: ["Measure campaign attribution and brand tracking", "Maintain the marketing performance dashboard"],
        kpis: ["Attribution coverage %", "Insight turnaround (days)"],
        collaboration: ["Finance on payback"],
        base: 1,
        enterpriseOnly: true,
      },
    ],
    agents: [
      {
        name: "Campaign Optimisation Agent",
        purpose: "Reallocate media spend across channels and markets against live cost-per-lead performance.",
        owns: ["Budget shifts inside guardrails", "Creative fatigue detection", "Channel mix recommendations"],
        autonomy: "supervised",
        dataSources: ["Media platform APIs", "Lead system", "Order bank"],
        triggers: ["Daily performance load", "CPL above threshold"],
        pairedRole: "mkt-campaign",
      },
      {
        name: "Lead Scoring Agent",
        purpose: "Score and route leads to the right dealer and follow-up path by purchase intent.",
        owns: ["Intent scoring", "Routing rules", "Stale lead escalation"],
        autonomy: "autonomous",
        dataSources: ["CRM", "Configurator behaviour", "Test-drive bookings"],
        triggers: ["Lead created", "No dealer contact within 2 hours"],
        pairedRole: "mkt-crm",
      },
      {
        name: "Content Studio Agent",
        purpose: "Produce localised campaign, social and dealer co-op assets from brand-approved templates.",
        owns: ["First-draft copy and variants", "Localisation", "Compliance pre-check"],
        autonomy: "human-in-the-loop",
        dataSources: ["Brand guidelines", "Product feature sheets", "Historic asset performance"],
        triggers: ["Campaign brief approved", "Dealer co-op request"],
        pairedRole: "mkt-digital",
      },
      {
        name: "Owner Lifecycle Agent",
        purpose: "Trigger retention, service and repurchase journeys at the right point of vehicle life.",
        owns: ["Journey triggers", "Offer selection", "Churn risk flags"],
        autonomy: "supervised",
        dataSources: ["Ownership records", "Service history", "Contract end dates"],
        triggers: ["Service due", "Finance contract 6 months from end"],
        pairedRole: "mkt-crm",
      },
    ],
    raci: [
      { task: "Brand strategy and annual plan", mode: "human", human: "Marketing Director", agent: "Provides performance evidence" },
      { task: "Daily media optimisation", mode: "agent", human: "Campaign Manager sets guardrails", agent: "Campaign Optimisation Agent" },
      { task: "Lead qualification and routing", mode: "agent", human: "CRM Manager audits sample", agent: "Lead Scoring Agent" },
      { task: "Creative production", mode: "hybrid", human: "Digital Specialist approves", agent: "Content Studio Agent drafts" },
      { task: "Owner retention journeys", mode: "hybrid", human: "CRM Manager owns policy", agent: "Owner Lifecycle Agent executes" },
    ],
    fte: { low: 2, high: 4, note: "Asset production, reporting and manual campaign tuning largely agent-run." },
  },
  {
    key: "sales",
    label: "Sales",
    mission:
      "Convert demand into profitable retail and corporate orders through the dealer network and digital retail channels.",
    roles: [
      {
        key: "sal-head",
        title: "Sales Director",
        level: 1,
        reportsTo: null,
        responsibilities: ["Own retail volume, mix and margin targets", "Set network sales standards and incentive design"],
        kpis: ["Retail volume vs target", "Margin per unit", "Market share %"],
        collaboration: ["Finance on incentives", "Portfolio on supply", "Zone on execution"],
        base: 1,
      },
      {
        key: "sal-ops",
        title: "Sales Operations Manager",
        level: 2,
        reportsTo: "sal-head",
        responsibilities: ["Run order-to-delivery, deal desk and CRM discipline", "Administer targets, bonuses and reporting"],
        kpis: ["Order-to-delivery days", "CRM compliance %", "Bonus accuracy"],
        collaboration: ["Finance on settlement", "Planning on allocation"],
        base: 2,
      },
      {
        key: "sal-digital",
        title: "Digital Retail Manager",
        level: 2,
        reportsTo: "sal-head",
        responsibilities: ["Own online sales journey, agency-model execution and handover to dealers"],
        kpis: ["Online-initiated order share", "Lead-to-order %", "Handover satisfaction"],
        collaboration: ["Marketing on lead flow", "Zone on dealer adoption"],
        base: 1,
      },
      {
        key: "sal-network",
        title: "Network Development Manager",
        level: 3,
        reportsTo: "sal-head",
        responsibilities: ["Plan network coverage, standards and dealer investment", "Manage dealer contracts and openings"],
        kpis: ["Coverage of sales opportunity %", "Standards compliance", "Network ROS"],
        collaboration: ["Zone Manager on performance", "Finance on viability"],
        base: 1,
        enterpriseOnly: true,
      },
    ],
    agents: [
      {
        name: "Deal Desk Agent",
        purpose: "Check deal structure, discount and finance mix against margin guardrails in real time.",
        owns: ["Deal validation", "Approval routing", "Discount leakage flags"],
        autonomy: "supervised",
        dataSources: ["CRM deals", "Price guardrails", "Finance product rates"],
        triggers: ["Deal submitted", "Discount above threshold"],
        pairedRole: "sal-ops",
      },
      {
        name: "Conversion Coach Agent",
        purpose: "Guide dealer sales consultants on next best action for every open opportunity.",
        owns: ["Next-best-action prompts", "Follow-up cadence", "Stalled deal alerts"],
        autonomy: "autonomous",
        dataSources: ["CRM activity", "Test-drive records", "Stock availability"],
        triggers: ["Lead assigned", "No activity for 48 hours"],
        pairedRole: "sal-digital",
      },
      {
        name: "Order Bank Agent",
        purpose: "Keep the order bank clean and customers informed through to delivery.",
        owns: ["Delivery date updates", "Order exception triage", "Customer status messaging"],
        autonomy: "supervised",
        dataSources: ["Order management system", "Logistics tracking", "Dealer PDI status"],
        triggers: ["ETA change", "Order stuck beyond SLA"],
        pairedRole: "sal-ops",
      },
    ],
    raci: [
      { task: "Target setting and incentive design", mode: "human", human: "Sales Director", agent: "Models payout scenarios" },
      { task: "Deal approval within guardrails", mode: "agent", human: "Sales Ops on exceptions", agent: "Deal Desk Agent" },
      { task: "Customer negotiation and close", mode: "human", human: "Dealer sales consultant", agent: "Conversion Coach Agent prompts" },
      { task: "Order status communication", mode: "agent", human: "Sales Ops audits", agent: "Order Bank Agent" },
    ],
    fte: { low: 2, high: 3, note: "Deal admin, order chasing and status reporting move to agents; selling stays human." },
  },
  {
    key: "service-sales",
    label: "Service Sales",
    mission:
      "Grow aftersales revenue and retention through workshop capacity, parts availability and proactive owner contact.",
    roles: [
      {
        key: "svc-head",
        title: "Aftersales / Service Sales Manager",
        level: 1,
        reportsTo: null,
        responsibilities: ["Own service revenue, parts margin and retention", "Set workshop and parts standards for the network"],
        kpis: ["Aftersales penetration %", "Service retention rate", "Parts gross margin"],
        collaboration: ["Zone Manager on dealer performance", "Marketing on owner campaigns"],
        base: 1,
      },
      {
        key: "svc-parts",
        title: "Parts & Accessories Manager",
        level: 2,
        reportsTo: "svc-head",
        responsibilities: ["Own parts pricing, availability and accessory attachment", "Manage stock at central and dealer level"],
        kpis: ["First-pick availability %", "Accessory attachment rate", "Obsolescence %"],
        collaboration: ["Finance on margin", "Planning on logistics"],
        base: 2,
      },
      {
        key: "svc-contracts",
        title: "Service Contracts & Warranty Lead",
        level: 2,
        reportsTo: "svc-head",
        responsibilities: ["Design service plans and extended warranty products", "Govern warranty claim quality"],
        kpis: ["Service plan penetration %", "Warranty cost per unit", "Claim rejection rate"],
        collaboration: ["Finance on provisions", "Zone on dealer claim quality"],
        base: 1,
      },
      {
        key: "svc-cx",
        title: "Customer Experience Specialist",
        level: 3,
        reportsTo: "svc-head",
        responsibilities: ["Run service CX programme, complaints and NPS follow-up"],
        kpis: ["Service NPS", "Complaint resolution days", "Fixed-first-visit %"],
        collaboration: ["Marketing on lifecycle comms"],
        base: 2,
      },
    ],
    agents: [
      {
        name: "Service Capacity Agent",
        purpose: "Balance workshop bookings, technician skills and bay capacity across the network.",
        owns: ["Slot optimisation", "Overbooking prevention", "Technician skill matching"],
        autonomy: "supervised",
        dataSources: ["Dealer management system bookings", "Technician certifications", "Job time standards"],
        triggers: ["Booking request", "Capacity utilisation above 90%"],
        pairedRole: "svc-head",
      },
      {
        name: "Parts Availability Agent",
        purpose: "Forecast parts demand and prevent vehicle-off-road (VOR) situations.",
        owns: ["Replenishment proposals", "VOR escalation", "Obsolescence flags"],
        autonomy: "supervised",
        dataSources: ["Parc data", "Job history", "Supplier lead times", "Dealer stock"],
        triggers: ["Stock below reorder point", "VOR raised"],
        pairedRole: "svc-parts",
      },
      {
        name: "Warranty Integrity Agent",
        purpose: "Pre-check warranty claims and detect anomalous repair patterns.",
        owns: ["Claim pre-validation", "Pattern detection", "Coaching flags for dealers"],
        autonomy: "human-in-the-loop",
        dataSources: ["Claim submissions", "Job cards", "Technical bulletins"],
        triggers: ["Claim submitted", "Repeat repair detected"],
        pairedRole: "svc-contracts",
      },
      {
        name: "Service Retention Agent",
        purpose: "Bring owners back for scheduled and lapsed service with tailored offers.",
        owns: ["Recall and service due outreach", "Lapsed owner win-back", "Booking confirmation"],
        autonomy: "autonomous",
        dataSources: ["Service history", "Telematics where consented", "Parc and warranty status"],
        triggers: ["Service interval reached", "12 months since last visit"],
        pairedRole: "svc-cx",
      },
    ],
    raci: [
      { task: "Workshop scheduling", mode: "agent", human: "Service manager handles exceptions", agent: "Service Capacity Agent" },
      { task: "Parts replenishment", mode: "hybrid", human: "Parts Manager approves value orders", agent: "Parts Availability Agent proposes" },
      { task: "Warranty claim approval", mode: "hybrid", human: "Warranty Lead decides", agent: "Warranty Integrity Agent pre-checks" },
      { task: "Customer complaint resolution", mode: "human", human: "CX Specialist", agent: "Summarises history and drafts response" },
      { task: "Service reminder outreach", mode: "agent", human: "CX Specialist owns tone rules", agent: "Service Retention Agent" },
    ],
    fte: { low: 2, high: 4, note: "Booking admin, reminder calling and claim pre-checking absorbed by agents." },
  },
  {
    key: "zone-manager",
    label: "Zone Manager",
    mission:
      "Drive dealer performance in the field: coverage, standards, profitability and execution of national programmes.",
    roles: [
      {
        key: "zon-head",
        title: "National Field Operations Manager",
        level: 1,
        reportsTo: null,
        responsibilities: ["Own zone structure, coverage and field cadence", "Escalate underperforming dealers and remedial plans"],
        kpis: ["Zone target attainment %", "Dealer standards compliance", "Field visit coverage"],
        collaboration: ["Sales and Service Sales on programmes", "Finance on dealer health"],
        base: 1,
      },
      {
        key: "zon-sales",
        title: "Zone Manager — Sales",
        level: 2,
        reportsTo: "zon-head",
        responsibilities: ["Coach dealer principals and sales managers in the zone", "Land national campaigns and stock actions locally"],
        kpis: ["Zone retail volume vs target", "Stock turn", "Dealer sales process score"],
        collaboration: ["Sales Ops on allocation", "Marketing on local activation"],
        base: 4,
      },
      {
        key: "zon-service",
        title: "Zone Manager — Aftersales",
        level: 2,
        reportsTo: "zon-head",
        responsibilities: ["Improve workshop throughput, retention and parts performance in the zone"],
        kpis: ["Aftersales penetration %", "Workshop utilisation", "Service NPS"],
        collaboration: ["Service Sales on standards", "HR on technician capability"],
        base: 3,
      },
      {
        key: "zon-analyst",
        title: "Field Performance Analyst",
        level: 3,
        reportsTo: "zon-head",
        responsibilities: ["Produce dealer scorecards and visit packs", "Track remedial action plans"],
        kpis: ["Scorecard timeliness", "Action plan closure rate"],
        collaboration: ["Finance on composites"],
        base: 1,
        enterpriseOnly: true,
      },
    ],
    agents: [
      {
        name: "Dealer Performance Agent",
        purpose: "Score every dealer weekly across sales, aftersales, stock and CX, and explain the gap.",
        owns: ["Scorecards", "Gap diagnosis", "Peer benchmarking"],
        autonomy: "autonomous",
        dataSources: ["DMS feeds", "Composites", "CRM", "CX surveys"],
        triggers: ["Weekly data load", "Metric drops two quartiles"],
        pairedRole: "zon-analyst",
      },
      {
        name: "Visit Planner Agent",
        purpose: "Prioritise field visits by value at risk and build the visit pack automatically.",
        owns: ["Visit prioritisation", "Agenda and pack generation", "Follow-up action logging"],
        autonomy: "human-in-the-loop",
        dataSources: ["Dealer scorecards", "Zone travel constraints", "Open action plans"],
        triggers: ["Monthly planning cycle", "Dealer flagged red"],
        pairedRole: "zon-sales",
      },
      {
        name: "Zone Coverage Agent",
        purpose: "Model zone boundaries and coverage against registration opportunity.",
        owns: ["Coverage gap maps", "Zone rebalancing options"],
        autonomy: "human-in-the-loop",
        dataSources: ["Registration data by postcode", "Dealer locations", "Travel times"],
        triggers: ["Annual network review", "Dealer opening or closure"],
        pairedRole: "zon-head",
      },
    ],
    raci: [
      { task: "Dealer scorecard production", mode: "agent", human: "Field Analyst validates", agent: "Dealer Performance Agent" },
      { task: "Dealer coaching and relationship", mode: "human", human: "Zone Manager", agent: "Supplies diagnosis and talking points" },
      { task: "Visit planning and packs", mode: "hybrid", human: "Zone Manager confirms route", agent: "Visit Planner Agent prepares" },
      { task: "Zone boundary changes", mode: "human", human: "National Field Operations Manager", agent: "Zone Coverage Agent models options" },
    ],
    fte: { low: 1, high: 3, note: "Scorecard and visit-pack preparation removed from field and analyst workload." },
  },
  {
    key: "commercial-fleet",
    label: "Commercial Fleet Manager",
    mission:
      "Win and retain corporate, leasing and rental business with strong total-cost-of-ownership and uptime performance.",
    roles: [
      {
        key: "flt-head",
        title: "Commercial Fleet Director",
        level: 1,
        reportsTo: null,
        responsibilities: ["Own fleet volume, channel mix and residual value discipline", "Sign off major tenders and framework agreements"],
        kpis: ["Fleet volume vs target", "Fleet margin per unit", "Residual value performance"],
        collaboration: ["Finance on tender pricing", "Service Sales on uptime commitments"],
        base: 1,
      },
      {
        key: "flt-key",
        title: "Key Account Manager (Corporate / Leasing)",
        level: 2,
        reportsTo: "flt-head",
        responsibilities: ["Own named leasing, rental and corporate accounts", "Negotiate framework terms and renewal cycles"],
        kpis: ["Account retention %", "Share of customer fleet", "Order pipeline value"],
        collaboration: ["Sales on delivery", "Fleet ops on service levels"],
        base: 3,
      },
      {
        key: "flt-tender",
        title: "Fleet Tender & Pricing Analyst",
        level: 2,
        reportsTo: "flt-head",
        responsibilities: ["Model TCO, residual and maintenance assumptions for bids", "Prepare tender documentation"],
        kpis: ["Tender win rate %", "TCO accuracy vs actual", "Bid turnaround days"],
        collaboration: ["Finance on RV", "Service Sales on maintenance cost"],
        base: 1,
      },
      {
        key: "flt-ops",
        title: "Fleet Operations & Uptime Manager",
        level: 3,
        reportsTo: "flt-head",
        responsibilities: ["Manage delivery logistics, upfits and uptime commitments", "Run fleet service level reporting"],
        kpis: ["Fleet uptime %", "On-time delivery %", "SLA breaches"],
        collaboration: ["Service Sales on priority workshop slots"],
        base: 2,
      },
    ],
    agents: [
      {
        name: "Fleet Utilisation Agent",
        purpose: "Monitor customer fleet utilisation and recommend right-sizing and replacement cycles.",
        owns: ["Utilisation analytics", "Replacement cycle proposals", "Upsell signals"],
        autonomy: "supervised",
        dataSources: ["Telematics (with consent)", "Contract mileage", "Service history"],
        triggers: ["Monthly utilisation refresh", "Mileage variance beyond contract"],
        pairedRole: "flt-ops",
      },
      {
        name: "TCO & Tender Agent",
        purpose: "Build total-cost-of-ownership models and draft tender responses at speed.",
        owns: ["TCO modelling", "Bid document drafting", "Win/loss analysis"],
        autonomy: "human-in-the-loop",
        dataSources: ["Residual value curves", "Maintenance cost history", "Fuel/energy price feeds"],
        triggers: ["Tender received", "Framework renewal 90 days out"],
        pairedRole: "flt-tender",
      },
      {
        name: "Uptime Guardian Agent",
        purpose: "Predict downtime risk and pre-book priority workshop capacity for fleet vehicles.",
        owns: ["Downtime risk scoring", "Priority slot booking", "SLA breach alerts"],
        autonomy: "supervised",
        dataSources: ["Fault codes", "Service intervals", "Workshop capacity"],
        triggers: ["Fault code raised", "SLA at risk"],
        pairedRole: "flt-ops",
      },
      {
        name: "Account Intelligence Agent",
        purpose: "Track corporate account signals and prepare renewal and growth plays.",
        owns: ["Account briefings", "Churn risk scoring", "Renewal reminders"],
        autonomy: "autonomous",
        dataSources: ["CRM", "Contract end dates", "Public company news"],
        triggers: ["Contract 6 months from end", "Account activity drop"],
        pairedRole: "flt-key",
      },
    ],
    raci: [
      { task: "Tender pricing decision", mode: "human", human: "Fleet Director with Finance", agent: "TCO & Tender Agent models options" },
      { task: "Bid document preparation", mode: "hybrid", human: "Tender Analyst finalises", agent: "TCO & Tender Agent drafts" },
      { task: "Account relationship and negotiation", mode: "human", human: "Key Account Manager", agent: "Account Intelligence Agent briefs" },
      { task: "Fleet uptime management", mode: "agent", human: "Fleet Ops Manager on escalations", agent: "Uptime Guardian Agent" },
      { task: "Fleet right-sizing advice", mode: "hybrid", human: "Key Account Manager presents", agent: "Fleet Utilisation Agent analyses" },
    ],
    fte: { low: 1, high: 2, note: "Bid preparation and utilisation reporting shift to agents; negotiation stays human." },
  },
];

export const FUNCTION_KEYS = BLUEPRINT.map((f) => f.key);
export const FUNCTION_LABELS: Record<FunctionKey, string> = Object.fromEntries(
  BLUEPRINT.map((f) => [f.key, f.label]),
) as Record<FunctionKey, string>;

/* ------------------------------------------------------------------ generation */

const SIZE_FACTOR: Record<CompanySize, number> = { startup: 0.4, midsize: 1, enterprise: 1.8 };

function scaleHeadcount(base: number, size: CompanySize) {
  return Math.max(1, Math.round(base * SIZE_FACTOR[size]));
}

function regionalCollaboration(region: RegionFocus): string | null {
  switch (region) {
    case "asean":
      return "Distributor and importer partners on market execution";
    case "europe":
      return "Works council and CO2 / agency-model compliance";
    case "north-america":
      return "Franchise dealer council and state regulatory requirements";
    case "china":
      return "NEV mandate reporting and direct-to-consumer channel";
    default:
      return null;
  }
}

export function generateFunctionModel(
  seed: FunctionSeed,
  size: CompanySize,
  region: RegionFocus,
  includeAgents: boolean,
): FunctionModel {
  const extra = regionalCollaboration(region);
  const roles = seed.roles
    .filter((r) => !(r.enterpriseOnly && size === "startup"))
    .map<HumanRole>((r) => ({
      id: `${seed.key}:${r.key}`,
      title: size === "startup" && r.level === 1 ? `${r.title} (player-coach)` : r.title,
      level: r.level,
      reportsTo: r.reportsTo ? `${seed.key}:${r.reportsTo}` : null,
      responsibilities: r.responsibilities,
      kpis: r.kpis,
      collaboration: extra && r.level === 1 ? [...r.collaboration, extra] : r.collaboration,
      headcount: scaleHeadcount(r.base, size),
    }));
  const roleIds = new Set(roles.map((r) => r.id));
  const headId = roles[0]?.id ?? "";

  const agents = includeAgents
    ? seed.agents.map<AgentRole>((a) => {
        const paired = `${seed.key}:${a.pairedRole}`;
        return {
          id: `${seed.key}:agent:${a.name.toLowerCase().replace(/[^a-z]+/g, "-")}`,
          name: a.name,
          purpose: a.purpose,
          owns: a.owns,
          autonomy: a.autonomy,
          dataSources: a.dataSources,
          triggers: a.triggers,
          pairedRoleId: roleIds.has(paired) ? paired : headId,
        };
      })
    : [];

  const factor = size === "startup" ? 0.5 : size === "enterprise" ? 1.6 : 1;
  return {
    key: seed.key,
    label: seed.label,
    mission: seed.mission,
    humanRoles: roles,
    agents,
    raci: includeAgents ? seed.raci : seed.raci.filter((r) => r.mode === "human"),
    fteImpact: includeAgents
      ? {
          low: Math.max(0, Math.round(seed.fte.low * factor)),
          high: Math.max(1, Math.round(seed.fte.high * factor)),
          note: seed.fte.note,
        }
      : { low: 0, high: 0, note: "No agents included in this model." },
  };
}

export interface GenerateOptions {
  size: CompanySize;
  region: RegionFocus;
  includeAgents: boolean;
  name?: string;
  functions?: FunctionKey[];
}

export function generateOperatingModel(opts: GenerateOptions): OperatingModel {
  const keys = opts.functions?.length ? opts.functions : FUNCTION_KEYS;
  const now = new Date().toISOString();
  const sizeLabel = COMPANY_SIZES.find((s) => s.value === opts.size)?.label ?? opts.size;
  const regionLabel = REGIONS.find((r) => r.value === opts.region)?.label ?? opts.region;
  return {
    id: uid(),
    name: opts.name ?? `Automotive Operating Model — ${sizeLabel} · ${regionLabel}`,
    createdAt: now,
    updatedAt: now,
    size: opts.size,
    region: opts.region,
    includeAgents: opts.includeAgents,
    functions: BLUEPRINT.filter((f) => keys.includes(f.key)).map((f) =>
      generateFunctionModel(f, opts.size, opts.region, opts.includeAgents),
    ),
  };
}

/** Rebuilds a single function in place, leaving user edits to other functions intact. */
export function regenerateFunction(model: OperatingModel, key: FunctionKey): OperatingModel {
  const seed = BLUEPRINT.find((f) => f.key === key);
  if (!seed) return model;
  const next = generateFunctionModel(seed, model.size, model.region, model.includeAgents);
  return {
    ...model,
    updatedAt: new Date().toISOString(),
    functions: model.functions.map((f) => (f.key === key ? next : f)),
  };
}

/* ------------------------------------------------------------------ rollups */

export interface ModelTotals {
  functions: number;
  humanRoles: number;
  headcount: number;
  agents: number;
  fteLow: number;
  fteHigh: number;
  agentOwned: number;
  hybrid: number;
  humanOnly: number;
}

export function modelTotals(model: OperatingModel): ModelTotals {
  const raci = model.functions.flatMap((f) => f.raci);
  return {
    functions: model.functions.length,
    humanRoles: model.functions.reduce((s, f) => s + f.humanRoles.length, 0),
    headcount: model.functions.reduce(
      (s, f) => s + f.humanRoles.reduce((n, r) => n + r.headcount, 0),
      0,
    ),
    agents: model.functions.reduce((s, f) => s + f.agents.length, 0),
    fteLow: model.functions.reduce((s, f) => s + f.fteImpact.low, 0),
    fteHigh: model.functions.reduce((s, f) => s + f.fteImpact.high, 0),
    agentOwned: raci.filter((r) => r.mode === "agent").length,
    hybrid: raci.filter((r) => r.mode === "hybrid").length,
    humanOnly: raci.filter((r) => r.mode === "human").length,
  };
}

/* ------------------------------------------------------------------ org chart */

function employee(partial: Partial<Employee> & { id: string; title: string }): Employee {
  return {
    name: "",
    isOpenRole: true,
    department: "",
    country: "United States",
    responsibilities: "",
    currentHeadcount: 0,
    plannedHeadcount: 1,
    employmentType: "Full-time",
    managerId: null,
    status: "planned",
    currentCost: 0,
    plannedCost: 0,
    serviceMonths: 0,
    ...partial,
  } as Employee;
}

export const AGENT_PREFIX = "AI Agent · ";

/**
 * Converts a generated model into Organisation Strategy Studio employees: a COO root, one branch per
 * function, and AI Agents attached to the human role they support.
 */
export function modelToEmployees(model: OperatingModel): Employee[] {
  const country = REGIONS.find((r) => r.value === model.region)?.country ?? "United States";
  const rootId = "aom-root";
  const out: Employee[] = [
    employee({
      id: rootId,
      title: "Chief Operating Officer",
      department: "Executive",
      country,
      responsibilities: "Owns the automotive operating model across commercial, aftersales and support functions.",
      unitKind: "line",
      roleScope: model.region === "global" ? "global" : "regional",
    }),
  ];

  for (const fn of model.functions) {
    for (const role of fn.humanRoles) {
      out.push(
        employee({
          id: role.id,
          title: role.title,
          department: fn.label,
          country,
          managerId: role.reportsTo ?? rootId,
          plannedHeadcount: role.headcount,
          responsibilities: [
            role.responsibilities.map((r) => `• ${r}`).join("\n"),
            `KPIs: ${role.kpis.join(", ")}`,
          ].join("\n"),
          unitKind: fn.key === "zone-manager" || fn.key === "commercial-fleet" ? "line" : "coe",
          roleScope: role.level === 1 ? (model.region === "global" ? "global" : "regional") : "local",
        }),
      );
    }
    for (const agent of fn.agents) {
      out.push(
        employee({
          id: agent.id,
          title: `${AGENT_PREFIX}${agent.name}`,
          name: "AI Agent",
          department: fn.label,
          country,
          managerId: agent.pairedRoleId,
          employmentType: "Open Role",
          plannedHeadcount: 0,
          status: "planned",
          unitKind: "gbs",
          roleScope: "global",
          responsibilities: [
            agent.purpose,
            `Owns: ${agent.owns.join(", ")}`,
            `Autonomy: ${AUTONOMY_META[agent.autonomy].label}`,
            `Data: ${agent.dataSources.join(", ")}`,
            `Triggers: ${agent.triggers.join(", ")}`,
          ].join("\n"),
        }),
      );
    }
  }
  return out;
}

export { uid as modelUid };
export type { FunctionSeed };
export { BLUEPRINT as OPERATING_MODEL_BLUEPRINT };
