import { DISCLAIMER } from "./types";

export interface Notice {
  title: string;
  body: string;
}

/** Short one-liner used as a slide/page footer. */
export const NOT_LEGAL_ADVICE_SHORT =
  "Not legal, financial or employment advice — obtain qualified local counsel before acting.";

/** Full qualifier set applied to every exported artefact. */
export const EXPORT_NOTICES: Notice[] = [
  {
    title: "Not legal advice",
    body: DISCLAIMER,
  },
  {
    title: "Illustrative modelling only",
    body: "Headcount, cost, severance and timeline figures are indicative estimates produced from data entered into Organisation Strategy Studio. They are not payroll, accounting or statutory calculations and must be validated with Finance, Reward and local employment counsel before use in any decision, filing or employee communication.",
  },
  {
    title: "Country considerations are high level",
    body: "Country notice, severance and consultation content is general awareness material, is not maintained as a legal register, and may not reflect current statute, case law, collective agreements or works council obligations in the relevant jurisdiction.",
  },
  {
    title: "Confidential — personal data",
    body: "This document may contain personal data about identifiable individuals and is strictly confidential. Restrict distribution to those with a documented business need, keep access controlled, apply your organisation's retention schedule, and delete copies once the purpose is complete. Where required, run a data protection impact assessment and inform works councils or employee representatives before wider circulation.",
  },
  {
    title: "Lawful basis & data minimisation",
    body: "Scenario data is processed under your organisation's own lawful basis (typically legitimate interests or legal obligation) as data controller. Only use the minimum personal data needed for the restructuring purpose, and honour employee information and access rights under applicable data protection law (including GDPR, UK GDPR and equivalent regimes).",
  },
  {
    title: "AI-assisted content",
    body: "Any copilot-generated or template communication text is a draft only. Review for accuracy, tone, discrimination risk and jurisdictional requirements, and obtain HR and legal sign-off before it is issued to employees or external parties.",
  },
];

/** Plain-text block for .txt / .md exports. */
export function noticesToText(heading = "Important notices"): string {
  const rule = "-".repeat(66);
  return [
    rule,
    heading.toUpperCase(),
    rule,
    ...EXPORT_NOTICES.map((n) => `${n.title}: ${n.body}`),
    rule,
    "",
  ].join("\n");
}

/** Prefixes a downloadable communication artefact with the notices block. */
export function withNotices(body: string, heading?: string): string {
  return `${noticesToText(heading)}\n${body}`;
}
