import type { Employee, Scenario } from "./types";
import { SCALE_LIMITS } from "./scale";

/** Industry-style benchmarks used to flag layer / span problems. */
export const SPAN_BENCHMARK = {
  idealSpanMin: 5,
  idealSpanMax: 9,
  narrowSpan: 3,
  wideSpan: 12,
  maxLayers: 6,
} as const;

export interface SpanRow {
  id: string;
  name: string;
  title: string;
  department: string;
  layer: number;
  directReports: number;
  totalReports: number;
  cost: number;
  verdict: "narrow" | "ideal" | "acceptable" | "wide";
}

export interface LayerRow {
  layer: number;
  managers: number;
  people: number;
  positions: number;
  cost: number;
  avgSpan: number;
  verdict: "ok" | "thin" | "deep";
}

export interface HeatCell {
  key: string;
  department: string;
  layer: number;
  positions: number;
  cost: number;
  costPerPosition: number;
  /** 0 = most efficient, 1 = most expensive. */
  intensity: number;
}

export interface DuplicateGroup {
  id: string;
  label: string;
  similarity: number;
  reason: string;
  members: Employee[];
  cost: number;
}

export interface SpanAnalysis {
  rows: SpanRow[];
  layers: LayerRow[];
  heat: HeatCell[];
  departments: string[];
  maxLayer: number;
  avgSpan: number;
  managerCount: number;
  icCount: number;
  managerRatio: number;
  narrow: SpanRow[];
  wide: SpanRow[];
  duplicates: DuplicateGroup[];
  duplicateCost: number;
  flags: { id: string; severity: "high" | "medium" | "low"; title: string; detail: string }[];
}

const STOP = new Set([
  "the","and","of","for","to","a","an","with","in","on","at","by","or","as","senior","junior",
  "lead","head","manager","director","specialist","officer","associate","assistant","global",
  "regional","local","group","team","chief","vp","svp","evp","i","ii","iii",
]);

function tokens(text: string) {
  return new Set(
    (text || "")
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, " ")
      .split(/\s+/)
      .filter((t) => t.length > 2 && !STOP.has(t)),
  );
}

function jaccard(a: Set<string>, b: Set<string>) {
  if (!a.size || !b.size) return 0;
  let inter = 0;
  for (const t of a) if (b.has(t)) inter += 1;
  return inter / (a.size + b.size - inter);
}

function positions(e: Employee) {
  return Math.max(e.plannedHeadcount || e.currentHeadcount || 0, 0);
}

function annualCost(e: Employee) {
  const rate = e.plannedCost || e.currentCost || 0;
  return rate * Math.max(positions(e), 1);
}

export function analyseSpans(scenario: Scenario | null | undefined): SpanAnalysis {
  const employees = (scenario?.employees ?? []).filter((e) => e.status !== "to-be-removed");
  const byId = new Map(employees.map((e) => [e.id, e]));
  const children = new Map<string, Employee[]>();
  for (const e of employees) {
    const mid = e.managerId && byId.has(e.managerId) ? e.managerId : "__root";
    children.set(mid, [...(children.get(mid) ?? []), e]);
  }

  const layerOf = new Map<string, number>();
  const walk = (id: string, layer: number, guard: Set<string>) => {
    for (const child of children.get(id) ?? []) {
      if (guard.has(child.id)) continue;
      guard.add(child.id);
      layerOf.set(child.id, layer);
      walk(child.id, layer + 1, guard);
    }
  };
  walk("__root", 1, new Set());
  for (const e of employees) if (!layerOf.has(e.id)) layerOf.set(e.id, 1);

  // Single memoised post-order pass: keeps total-report roll-ups linear even on
  // hundreds of thousands of rows.
  const subtree = new Map<string, number>();
  const rollUp = (id: string, guard: Set<string>): number => {
    const cached = subtree.get(id);
    if (cached !== undefined) return cached;
    if (guard.has(id)) return 0;
    guard.add(id);
    let total = 0;
    for (const c of children.get(id) ?? []) {
      total += (positions(c) || 1) + rollUp(c.id, guard);
    }
    subtree.set(id, total);
    return total;
  };
  for (const e of employees) rollUp(e.id, new Set());
  const totalReports = (id: string) => subtree.get(id) ?? 0;

  const rows: SpanRow[] = employees
    .map((e) => {
      const direct = (children.get(e.id) ?? []).reduce((a, c) => a + (positions(c) || 1), 0);
      const verdict: SpanRow["verdict"] =
        direct === 0
          ? "ideal"
          : direct < SPAN_BENCHMARK.narrowSpan
            ? "narrow"
            : direct <= SPAN_BENCHMARK.idealSpanMax
              ? "ideal"
              : direct < SPAN_BENCHMARK.wideSpan
                ? "acceptable"
                : "wide";
      return {
        id: e.id,
        name: e.name || "Open role",
        title: e.title || "—",
        department: e.department || "Unassigned",
        layer: layerOf.get(e.id) ?? 1,
        directReports: direct,
        totalReports: totalReports(e.id),
        cost: annualCost(e),
        verdict,
      };
    })
    .sort((a, b) => a.layer - b.layer || b.directReports - a.directReports);

  const managers = rows.filter((r) => r.directReports > 0);
  const maxLayer = rows.reduce((m, r) => Math.max(m, r.layer), 0);

  const layerMap = new Map<number, LayerRow>();
  for (const r of rows) {
    const row = layerMap.get(r.layer) ?? {
      layer: r.layer,
      managers: 0,
      people: 0,
      positions: 0,
      cost: 0,
      avgSpan: 0,
      verdict: "ok" as LayerRow["verdict"],
    };
    row.people += 1;
    row.positions += positions(byId.get(r.id)!) || 1;
    row.cost += r.cost;
    if (r.directReports > 0) {
      row.managers += 1;
      row.avgSpan += r.directReports;
    }
    layerMap.set(r.layer, row);
  }
  const layers = [...layerMap.values()]
    .map((l) => {
      const avgSpan = l.managers ? l.avgSpan / l.managers : 0;
      const verdict: LayerRow["verdict"] =
        l.layer > SPAN_BENCHMARK.maxLayers
          ? "deep"
          : l.managers && avgSpan < SPAN_BENCHMARK.narrowSpan
            ? "thin"
            : "ok";
      return { ...l, avgSpan, verdict };
    })
    .sort((a, b) => a.layer - b.layer);

  // Cost heat map: department x layer, coloured by cost per position.
  const cellMap = new Map<string, HeatCell>();
  for (const r of rows) {
    const key = `${r.department}__${r.layer}`;
    const pos = positions(byId.get(r.id)!) || 1;
    const cell = cellMap.get(key) ?? {
      key,
      department: r.department,
      layer: r.layer,
      positions: 0,
      cost: 0,
      costPerPosition: 0,
      intensity: 0,
    };
    cell.positions += pos;
    cell.cost += r.cost;
    cellMap.set(key, cell);
  }
  const heat = [...cellMap.values()].map((c) => ({
    ...c,
    costPerPosition: c.positions ? c.cost / c.positions : 0,
  }));
  const rates = heat.map((c) => c.costPerPosition).filter((v) => v > 0);
  const lo = rates.length ? Math.min(...rates) : 0;
  const hi = rates.length ? Math.max(...rates) : 0;
  for (const c of heat) {
    c.intensity = hi > lo ? (c.costPerPosition - lo) / (hi - lo) : c.costPerPosition > 0 ? 0.5 : 0;
  }

  // Duplicate / overlapping role detection.
  const duplicates: DuplicateGroup[] = [];
  const used = new Set<string>();
  // At enterprise scale a full pairwise scan is quadratic, so we look at the
  // most expensive roles and compare only within each department bucket.
  const scanPool =
    employees.length > SCALE_LIMITS.duplicateScan
      ? [...employees].sort((a, b) => annualCost(b) - annualCost(a)).slice(0, SCALE_LIMITS.duplicateScan)
      : employees;
  const buckets = new Map<string, Employee[]>();
  for (const e of scanPool) {
    const key = e.department || "Unassigned";
    buckets.set(key, [...(buckets.get(key) ?? []), e]);
  }
  for (const bucket of buckets.values()) {
  const profiles = bucket.map((e) => ({
    e,
    title: tokens(e.title),
    resp: tokens(`${e.title} ${e.responsibilities}`),
  }));
  for (let i = 0; i < profiles.length; i += 1) {
    const a = profiles[i]!;
    if (used.has(a.e.id)) continue;
    const members = [a.e];
    let best = 0;
    let reason = "";
    for (let j = i + 1; j < profiles.length; j += 1) {
      const b = profiles[j]!;
      if (used.has(b.e.id)) continue;
      const sameTitle =
        a.e.title && b.e.title && a.e.title.trim().toLowerCase() === b.e.title.trim().toLowerCase();
      const titleSim = jaccard(a.title, b.title);
      const respSim = jaccard(a.resp, b.resp);
      const score = sameTitle ? 1 : Math.max(titleSim, respSim * 0.95);
      if (score >= 0.6) {
        members.push(b.e);
        used.add(b.e.id);
        if (score > best) {
          best = score;
          reason = sameTitle
            ? "Identical role title in more than one place in the structure"
            : titleSim >= respSim
              ? "Highly similar role titles"
              : "Overlapping responsibility wording";
        }
      }
    }
    if (members.length > 1) {
      used.add(a.e.id);
      duplicates.push({
        id: a.e.id,
        label: a.e.title || a.e.name || "Untitled role",
        similarity: best,
        reason,
        members,
        cost: members.reduce((s, m) => s + annualCost(m), 0),
      });
    }
  }
  }
  duplicates.sort((x, y) => y.cost - x.cost);

  const narrow = managers.filter((m) => m.verdict === "narrow");
  const wide = managers.filter((m) => m.verdict === "wide");
  const avgSpan = managers.length
    ? managers.reduce((s, m) => s + m.directReports, 0) / managers.length
    : 0;
  const icCount = rows.length - managers.length;

  const flags: SpanAnalysis["flags"] = [];
  if (maxLayer > SPAN_BENCHMARK.maxLayers)
    flags.push({
      id: "layers",
      severity: "high",
      title: `${maxLayer} management layers vs benchmark of ${SPAN_BENCHMARK.maxLayers}`,
      detail: "Deep hierarchies slow decisions. Consider merging adjacent layers.",
    });
  if (narrow.length)
    flags.push({
      id: "narrow",
      severity: "high",
      title: `${narrow.length} manager${narrow.length === 1 ? "" : "s"} with fewer than ${SPAN_BENCHMARK.narrowSpan} reports`,
      detail: "Narrow spans usually signal an unnecessary layer or a player-coach role.",
    });
  if (wide.length)
    flags.push({
      id: "wide",
      severity: "medium",
      title: `${wide.length} manager${wide.length === 1 ? "" : "s"} with ${SPAN_BENCHMARK.wideSpan}+ reports`,
      detail: "Overloaded spans risk weak coaching and slow escalation.",
    });
  if (duplicates.length)
    flags.push({
      id: "duplicates",
      severity: "medium",
      title: `${duplicates.length} potential duplicate role cluster${duplicates.length === 1 ? "" : "s"}`,
      detail: "Similar titles or responsibilities appear in more than one part of the org.",
    });
  const ratio = managers.length && icCount ? icCount / managers.length : 0;
  if (ratio && ratio < 4)
    flags.push({
      id: "ratio",
      severity: "low",
      title: `Manager-to-IC ratio is 1:${ratio.toFixed(1)}`,
      detail: "Healthy organisations typically sit between 1:5 and 1:9.",
    });

  return {
    rows,
    layers,
    heat,
    departments: [...new Set(heat.map((c) => c.department))].sort(),
    maxLayer,
    avgSpan,
    managerCount: managers.length,
    icCount,
    managerRatio: ratio,
    narrow,
    wide,
    duplicates,
    duplicateCost: duplicates.reduce((s, d) => s + d.cost - d.cost / d.members.length, 0),
    flags,
  };
}
