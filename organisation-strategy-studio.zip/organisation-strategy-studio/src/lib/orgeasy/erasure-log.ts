/**
 * Erasure audit log.
 *
 * Deliberately kept OUTSIDE the workspace record so it survives the wipe it
 * documents. Entries contain no personal data — only counts, key names and
 * timestamps — so they are safe to retain as evidence that an erasure request
 * was actioned.
 */
export const ERASURE_LOG_KEY = "orgeasy.erasure-log.v1";
const MAX_ENTRIES = 20;

export interface ErasureEntry {
  id: string;
  at: string;
  reason: string;
  removed: {
    scenarios: number;
    roles: number;
    namedPeople: number;
    photos: number;
    adkarGroups: number;
    savedViews: number;
  };
  keysCleared: string[];
  keysRemaining: string[];
}

export function readErasureLog(): ErasureEntry[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(ERASURE_LOG_KEY);
    const parsed = raw ? (JSON.parse(raw) as ErasureEntry[]) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function recordErasure(entry: Omit<ErasureEntry, "id" | "at">): ErasureEntry[] {
  const next: ErasureEntry[] = [
    {
      ...entry,
      id: `er_${Date.now().toString(36)}`,
      at: new Date().toISOString(),
    },
    ...readErasureLog(),
  ].slice(0, MAX_ENTRIES);
  try {
    window.localStorage.setItem(ERASURE_LOG_KEY, JSON.stringify(next));
  } catch {
    /* storage unavailable — the log stays in memory for this session only */
  }
  window.dispatchEvent(new CustomEvent<ErasureEntry[]>("orgeasy:erasure-log", { detail: next }));
  return next;
}

export function clearErasureLog(): ErasureEntry[] {
  try {
    window.localStorage.removeItem(ERASURE_LOG_KEY);
  } catch {
    /* ignore */
  }
  window.dispatchEvent(new CustomEvent<ErasureEntry[]>("orgeasy:erasure-log", { detail: [] }));
  return [];
}

export function subscribeErasureLog(fn: (entries: ErasureEntry[]) => void) {
  if (typeof window === "undefined") return () => {};
  const handler = (event: Event) => fn((event as CustomEvent<ErasureEntry[]>).detail);
  window.addEventListener("orgeasy:erasure-log", handler);
  return () => window.removeEventListener("orgeasy:erasure-log", handler);
}

export function erasureLogToText(entries: ErasureEntry[]): string {
  if (!entries.length) return "Organisation Strategy Studio erasure log — no erasures recorded in this browser.\n";
  return [
    "Organisation Strategy Studio — local data erasure log",
    "Counts only; contains no personal data.",
    "",
    ...entries.map((e) =>
      [
        `Erased at: ${new Date(e.at).toISOString()} (local: ${new Date(e.at).toLocaleString()})`,
        `Trigger: ${e.reason}`,
        `Scenarios: ${e.removed.scenarios} · Role records: ${e.removed.roles} · Named individuals: ${e.removed.namedPeople} · Photos: ${e.removed.photos} · ADKAR groups: ${e.removed.adkarGroups} · Saved views: ${e.removed.savedViews}`,
        `Storage keys cleared: ${e.keysCleared.join(", ") || "none"}`,
        `Storage keys intentionally retained: ${e.keysRemaining.join(", ") || "none"}`,
        "",
      ].join("\n"),
    ),
  ].join("\n");
}
