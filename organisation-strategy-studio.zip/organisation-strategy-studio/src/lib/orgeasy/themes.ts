import type { Employee } from "./types";
import { LEVER_META, ROLE_TYPE_META, SCOPE_META, STATUS_META, UNIT_META } from "./types";

export type ColorBy =
  | "status"
  | "department"
  | "country"
  | "level"
  | "scope"
  | "unit"
  | "roleType"
  | "lever"
  | "cost"
  | "positions"
  | "span"
  | "tenure";

/** Numeric attributes are painted with a continuous ramp instead of a palette. */
export type Measure = "cost" | "positions" | "span" | "tenure";

export const MEASURE_META: Record<Measure, { label: string; unit: string; format: (v: number) => string }> = {
  cost: {
    label: "Annual cost of the position",
    unit: "cost",
    format: (v) => (v >= 1000 ? `${Math.round(v / 1000)}k` : Math.round(v).toString()),
  },
  positions: { label: "Positions held (FTE)", unit: "FTE", format: (v) => v.toFixed(0) },
  span: { label: "Direct reports", unit: "reports", format: (v) => v.toFixed(0) },
  tenure: { label: "Length of service", unit: "years", format: (v) => `${(v / 12).toFixed(1)}y` },
};

export interface ChartTheme {
  id: string;
  label: string;
  /** Accent palette used when colouring by department / country / level. */
  swatches: string[];
  /** Default connector colour. */
  edge: string;
  /** Background dot colour. */
  dot: string;
  /** Canvas backdrop (CSS background value). */
  canvas: string;
  /** Card surface (CSS background value). */
  surface: string;
  /** Card border colour. */
  border: string;
  /** Primary text colour on the card. */
  text: string;
  /** Muted text colour on the card. */
  muted: string;
  /** Soft chip background on the card. */
  chip: string;
}

export const CHART_THEMES: ChartTheme[] = [
  {
    id: "clay",
    label: "Natural Clay",
    swatches: ["#B4703C", "#6F8F5E", "#2F7A78", "#C08A2E", "#8A6A4F", "#4F7CA3", "#B4534A", "#7C7466"],
    edge: "#c9bda9",
    dot: "#ded4c2",
    canvas:
      "radial-gradient(circle at 18% 0%, #F7EFE2 0%, transparent 55%), radial-gradient(circle at 85% 100%, #F1EDE1 0%, transparent 52%), #FBF7F0",
    surface: "#FFFFFF",
    border: "rgba(120,101,79,0.28)",
    text: "#2C241C",
    muted: "#7A6B5A",
    chip: "rgba(180,112,60,0.12)",
  },
  {

    id: "obsidian",
    label: "Ocean Teal",
    swatches: ["#5E9E9E", "#22D3EE", "#34D399", "#FBBF24", "#9BCFCF", "#60A5FA", "#F87171", "#94A3B8"],
    edge: "#3A5F5F",
    dot: "#1C3333",
    canvas:
      "radial-gradient(circle at 18% 0%, #0F2E2E 0%, transparent 55%), radial-gradient(circle at 85% 100%, #0D2626 0%, transparent 52%), #081A1A",
    surface: "#0F2626",
    border: "rgba(255,255,255,0.09)",
    text: "#E7F0F0",
    muted: "#9BBDBD",
    chip: "rgba(94,158,158,0.14)",
  },
  {
    id: "enterprise",
    label: "Cool Enterprise",
    swatches: ["#2563EB", "#1E3A5F", "#0891B2", "#7C3AED", "#059669", "#D97706", "#DB2777", "#475569"],
    edge: "#a4b3c6",
    dot: "#c3cfdd",
    canvas:
      "radial-gradient(circle at 20% 0%, oklch(0.95 0.03 255) 0%, transparent 55%), radial-gradient(circle at 85% 100%, oklch(0.95 0.02 240) 0%, transparent 50%), #F8FAFC",
    surface: "#FFFFFF",
    border: "rgba(148,163,184,0.45)",
    text: "#0F172A",
    muted: "#64748B",
    chip: "rgba(148,163,184,0.16)",
  },
  {
    id: "midnight",
    label: "Midnight",
    swatches: ["#60A5FA", "#22D3EE", "#A78BFA", "#34D399", "#FBBF24", "#F472B6", "#F87171", "#94A3B8"],
    edge: "#3f5170",
    dot: "#2b3a52",
    canvas:
      "radial-gradient(circle at 18% 0%, #1c2b47 0%, transparent 55%), radial-gradient(circle at 85% 100%, #172036 0%, transparent 52%), #0B1120",
    surface: "#131D30",
    border: "rgba(99,126,166,0.35)",
    text: "#E9EFF9",
    muted: "#93A4BD",
    chip: "rgba(148,178,219,0.14)",
  },
  {
    id: "graphite",
    label: "Graphite Mono",
    swatches: ["#111827", "#334155", "#4B5563", "#6B7280", "#94A3B8", "#1E3A5F", "#1F2937", "#52525B"],
    edge: "#b6bec9",
    dot: "#d5dae1",
    canvas: "linear-gradient(180deg, #FAFAFA 0%, #F1F2F4 100%)",
    surface: "#FFFFFF",
    border: "rgba(120,128,140,0.35)",
    text: "#18181B",
    muted: "#71717A",
    chip: "rgba(113,113,122,0.13)",
  },
  {
    id: "sunset",
    label: "Warm Sunset",
    swatches: ["#EA580C", "#DB2777", "#F59E0B", "#E11D48", "#7C3AED", "#0891B2", "#65A30D", "#9A3412"],
    edge: "#e3b39b",
    dot: "#eccdbc",
    canvas:
      "radial-gradient(circle at 15% 0%, #FFE9D8 0%, transparent 55%), radial-gradient(circle at 88% 100%, #FFE1EC 0%, transparent 50%), #FFF9F5",
    surface: "#FFFFFF",
    border: "rgba(214,155,124,0.38)",
    text: "#3B1F14",
    muted: "#8A6A5A",
    chip: "rgba(217,119,6,0.12)",
  },
  {
    id: "forest",
    label: "Evergreen",
    swatches: ["#047857", "#0D9488", "#4D7C0F", "#0369A1", "#A16207", "#7C3AED", "#BE123C", "#334155"],
    edge: "#9dc3b4",
    dot: "#bcd9cd",
    canvas:
      "radial-gradient(circle at 20% 0%, #DFF2E8 0%, transparent 55%), radial-gradient(circle at 85% 100%, #E4F0DC 0%, transparent 50%), #F6FBF8",
    surface: "#FFFFFF",
    border: "rgba(120,168,146,0.4)",
    text: "#0C2A20",
    muted: "#5C7B70",
    chip: "rgba(4,120,87,0.11)",
  },
  {
    id: "violet",
    label: "Violet Studio",
    swatches: ["#7C3AED", "#4F46E5", "#C026D3", "#0EA5E9", "#14B8A6", "#F59E0B", "#EF4444", "#64748B"],
    edge: "#bdb0e6",
    dot: "#d3caf0",
    canvas:
      "radial-gradient(circle at 18% 0%, #EDE9FE 0%, transparent 55%), radial-gradient(circle at 86% 100%, #FAE8FF 0%, transparent 50%), #FBFAFF",
    surface: "#FFFFFF",
    border: "rgba(160,140,220,0.4)",
    text: "#241546",
    muted: "#6E639B",
    chip: "rgba(124,58,237,0.12)",
  },
];

export const COLOR_BY_OPTIONS: { value: ColorBy; label: string; group: "Category" | "Measure" }[] = [
  { value: "status", label: "Colour by status", group: "Category" },
  { value: "department", label: "Colour by department", group: "Category" },
  { value: "country", label: "Colour by country", group: "Category" },
  { value: "level", label: "Colour by org level", group: "Category" },
  { value: "scope", label: "Colour by role scope", group: "Category" },
  { value: "unit", label: "Colour by CoE / GBS", group: "Category" },
  { value: "roleType", label: "Colour by human / AI agent", group: "Category" },
  { value: "lever", label: "Colour by reduction lever", group: "Category" },
  { value: "cost", label: "Heat by annual cost", group: "Measure" },
  { value: "positions", label: "Heat by positions (FTE)", group: "Measure" },
  { value: "span", label: "Heat by direct reports", group: "Measure" },
  { value: "tenure", label: "Heat by length of service", group: "Measure" },
];

export function isMeasure(colorBy: ColorBy): colorBy is Measure {
  return colorBy === "cost" || colorBy === "positions" || colorBy === "span" || colorBy === "tenure";
}

/** Low → high ramp used for every measure encoding. */
export const MEASURE_RAMP = ["#1D4ED8", "#0891B2", "#16A34A", "#D97706", "#DC2626"] as const;

function mix(a: string, b: string, t: number) {
  const parse = (hex: string) => [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16));
  const [ar, ag, ab] = parse(a) as [number, number, number];
  const [br, bg, bb] = parse(b) as [number, number, number];
  const to = (v: number) => Math.round(v).toString(16).padStart(2, "0");
  return `#${to(ar + (br - ar) * t)}${to(ag + (bg - ag) * t)}${to(ab + (bb - ab) * t)}`;
}

/** Colour for a normalised 0–1 position on the measure ramp. */
export function rampColor(t: number) {
  const clamped = Math.max(0, Math.min(1, Number.isFinite(t) ? t : 0));
  const scaled = clamped * (MEASURE_RAMP.length - 1);
  const index = Math.min(Math.floor(scaled), MEASURE_RAMP.length - 2);
  return mix(MEASURE_RAMP[index]!, MEASURE_RAMP[index + 1]!, scaled - index);
}

export interface EncodeContext {
  levels: Map<string, number>;
  spans: Map<string, number>;
  ranges: Record<Measure, { lo: number; hi: number }>;
}

function rawMeasure(e: Employee, measure: Measure, ctx: EncodeContext): number {
  if (measure === "cost") {
    const rate = e.plannedCost || e.currentCost || 0;
    return rate * Math.max(e.plannedHeadcount || e.currentHeadcount || 1, 1);
  }
  if (measure === "positions") return Math.max(e.plannedHeadcount || e.currentHeadcount || 0, 0);
  if (measure === "span") return ctx.spans.get(e.id) ?? 0;
  return e.serviceMonths || 0;
}

/** Pre-computes spans, levels and min/max bounds so every card shares one scale. */
export function buildEncodeContext(employees: Employee[]): EncodeContext {
  const spans = new Map<string, number>();
  for (const e of employees) {
    if (e.managerId) spans.set(e.managerId, (spans.get(e.managerId) ?? 0) + 1);
  }
  const ctx: EncodeContext = {
    levels: levelMap(employees),
    spans,
    ranges: {
      cost: { lo: 0, hi: 0 },
      positions: { lo: 0, hi: 0 },
      span: { lo: 0, hi: 0 },
      tenure: { lo: 0, hi: 0 },
    },
  };
  for (const measure of Object.keys(ctx.ranges) as Measure[]) {
    const values = employees.map((e) => rawMeasure(e, measure, ctx)).filter((v) => Number.isFinite(v));
    ctx.ranges[measure] = {
      lo: values.length ? Math.min(...values) : 0,
      hi: values.length ? Math.max(...values) : 0,
    };
  }
  return ctx;
}

/** Value and 0–1 ramp position of a role on a measure. */
export function measureValue(e: Employee, measure: Measure, ctx: EncodeContext) {
  const value = rawMeasure(e, measure, ctx);
  const { lo, hi } = ctx.ranges[measure];
  return { value, t: hi > lo ? (value - lo) / (hi - lo) : value > 0 ? 0.5 : 0 };
}

export function getTheme(id: string) {
  return CHART_THEMES.find((t) => t.id === id) ?? CHART_THEMES[0]!;
}

function hash(value: string) {
  let h = 0;
  for (let i = 0; i < value.length; i++) h = (h * 31 + value.charCodeAt(i)) | 0;
  return Math.abs(h);
}

/** Depth of each employee in the reporting tree (0 = top). */
export function levelMap(employees: Employee[]) {
  const byId = new Map(employees.map((e) => [e.id, e]));
  const depth = new Map<string, number>();
  const resolve = (id: string, guard = 0): number => {
    if (depth.has(id)) return depth.get(id)!;
    const e = byId.get(id);
    if (!e || !e.managerId || guard > 40) return 0;
    const d = resolve(e.managerId, guard + 1) + 1;
    depth.set(id, d);
    return d;
  };
  for (const e of employees) depth.set(e.id, resolve(e.id));
  return depth;
}

export function accentFor(
  employee: Employee,
  colorBy: ColorBy,
  theme: ChartTheme,
  levels?: Map<string, number>,
  encode?: EncodeContext,
) {
  if (colorBy === "status") return `#${STATUS_META[employee.status].hex}`;
  if (colorBy === "scope") return `#${SCOPE_META[employee.roleScope ?? "unset"].hex}`;
  if (colorBy === "unit") return `#${UNIT_META[employee.unitKind ?? "line"].hex}`;
  if (colorBy === "roleType") return `#${ROLE_TYPE_META[employee.roleType ?? "human"].hex}`;
  if (colorBy === "lever")
    return employee.reductionLever
      ? `#${LEVER_META[employee.reductionLever].hex}`
      : theme.muted;
  if (isMeasure(colorBy)) {
    if (!encode) return theme.muted;
    return rampColor(measureValue(employee, colorBy, encode).t);
  }
  const palette = theme.swatches;
  if (colorBy === "level") {
    const d = levels?.get(employee.id) ?? 0;
    return palette[d % palette.length]!;
  }
  const key = (colorBy === "department" ? employee.department : employee.country) || "—";
  return palette[hash(key) % palette.length]!;
}
