/**
 * Shared Organisation Strategy Studio brand assets for generated documents.
 *
 * pptxgenjs and jsPDF both need the logo as base64 data (a path/URL reference
 * does not survive PowerPoint or PDF embedding), so the badge is fetched once
 * and cached for the session.
 */
import logoUrl from "@/assets/orgeasy-logo.png";

/** Brand ink used on light document surfaces. */
export const BRAND_INDIGO = "3B82F6";
/** Deep navy used on cover slides / PDF headers. */
export const BRAND_NAVY = "1E3A5F";

/** Square badge size (inches) and margins used on every deck cover. */
export const LOGO_COVER = { size: 0.8, x: 0.8, y: 0.5 } as const;
/** Smaller mark used on interior slide corners. */
export const LOGO_MARK = { size: 0.34, x: 9.06, y: 0.3 } as const;

let cached: string | null | undefined;

/** Returns the logo as a `image/png;base64,...` string, or null if unavailable. */
export async function logoData(): Promise<string | null> {
  if (cached !== undefined) return cached;
  try {
    const res = await fetch(logoUrl);
    if (!res.ok) throw new Error(`logo ${res.status}`);
    const buf = new Uint8Array(await res.arrayBuffer());
    let binary = "";
    for (let i = 0; i < buf.length; i += 8192) {
      binary += String.fromCharCode(...buf.subarray(i, i + 8192));
    }
    cached = `image/png;base64,${btoa(binary)}`;
  } catch {
    cached = null;
  }
  return cached;
}

/** Data URL form, for jsPDF `addImage`. */
export async function logoDataUrl(): Promise<string | null> {
  const data = await logoData();
  return data ? `data:${data}` : null;
}