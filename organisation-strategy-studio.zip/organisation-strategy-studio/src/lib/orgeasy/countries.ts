export interface CountryGuidance {
  country: string;
  region: string;
  /** Illustrative statutory severance: weeks of pay per completed year of service. */
  severanceWeeksPerYear: number;
  /** Illustrative statutory notice, in weeks. */
  noticeWeeks: number;
  capNote: string;
  considerations: string[];
}

export const COUNTRY_GUIDANCE: CountryGuidance[] = [
  {
    country: "Thailand",
    region: "APAC",
    severanceWeeksPerYear: 4.3,
    noticeWeeks: 4,
    capNote: "Statutory severance is banded by service length and capped at roughly 400 days of pay.",
    considerations: [
      "Severance is banded by length of service rather than purely pro-rata.",
      "Notice generally aligns with one pay period; pay in lieu is common.",
      "Unfair-dismissal claims can be filed with the Labour Court.",
    ],
  },
  {
    country: "Australia",
    region: "APAC",
    severanceWeeksPerYear: 2,
    noticeWeeks: 4,
    capNote: "National Employment Standards redundancy pay is banded and caps around 16 weeks.",
    considerations: [
      "Genuine redundancy test applies, including redeployment consideration.",
      "Consultation obligations under modern awards and enterprise agreements.",
      "Small business employers may be exempt from redundancy pay.",
    ],
  },
  {
    country: "South Africa",
    region: "EMEA",
    severanceWeeksPerYear: 1,
    noticeWeeks: 4,
    capNote: "Minimum one week per completed year; enhanced packages are common practice.",
    considerations: [
      "Section 189 / 189A consultation process is mandatory for operational requirements.",
      "Selection criteria must be fair and objective.",
      "CCMA facilitation may be required for large-scale retrenchments.",
    ],
  },
  {
    country: "UAE",
    region: "EMEA",
    severanceWeeksPerYear: 3,
    noticeWeeks: 4,
    capNote: "End-of-service gratuity of roughly 21-30 days pay per year, capped around two years' pay.",
    considerations: [
      "End-of-service gratuity applies after one year of service.",
      "Visa cancellation and repatriation logistics must be planned.",
      "Free zone rules (e.g. DIFC, ADGM) can differ from mainland law.",
    ],
  },
  {
    country: "Vietnam",
    region: "APAC",
    severanceWeeksPerYear: 2.2,
    noticeWeeks: 6,
    capNote: "Job-loss allowance is typically half a month per year, with a two-month minimum.",
    considerations: [
      "A formal labour usage plan and union consultation are usually required.",
      "Notice periods vary by contract type.",
      "Unemployment insurance offsets part of the employer obligation.",
    ],
  },
  {
    country: "Philippines",
    region: "APAC",
    severanceWeeksPerYear: 4.3,
    noticeWeeks: 4,
    capNote: "Redundancy separation pay is typically one month per year of service.",
    considerations: [
      "30-day written notice to both employee and DOLE is required.",
      "Redundancy must be shown to be in good faith with fair criteria.",
      "Quitclaim documentation is standard practice.",
    ],
  },
  {
    country: "United States",
    region: "Americas",
    severanceWeeksPerYear: 2,
    noticeWeeks: 0,
    capNote: "No federal statutory severance; amounts follow policy or negotiated packages.",
    considerations: [
      "WARN Act (and state mini-WARN) notice may apply to larger reductions.",
      "OWBPA requirements apply to releases for employees aged 40+.",
      "Adverse-impact analysis on protected classes is strongly advised.",
    ],
  },
  {
    country: "Germany",
    region: "EMEA",
    severanceWeeksPerYear: 2.2,
    noticeWeeks: 4,
    capNote: "Customary settlement is around 0.5 month per year of service.",
    considerations: [
      "Works council consultation and possible reconciliation of interests.",
      "Social selection criteria (Sozialauswahl) apply where dismissal protection exists.",
      "Mass dismissal notification to the employment agency may be required.",
    ],
  },
  {
    country: "United Kingdom",
    region: "EMEA",
    severanceWeeksPerYear: 1,
    noticeWeeks: 4,
    capNote: "Statutory redundancy pay is age-banded with a capped weekly amount.",
    considerations: [
      "Collective consultation thresholds at 20+ and 100+ proposed redundancies.",
      "Fair selection pool and individual consultation required.",
      "Two years' continuous service needed for statutory redundancy pay.",
    ],
  },
  {
    country: "France",
    region: "EMEA",
    severanceWeeksPerYear: 1.1,
    noticeWeeks: 8,
    capNote: "Legal indemnity is roughly 1/4 month per year for the first 10 years, then 1/3.",
    considerations: [
      "Economic dismissal requires documented economic justification.",
      "PSE (job-safeguard plan) obligations for larger reductions.",
      "CSE consultation and redeployment search obligations apply.",
    ],
  },
  {
    country: "China",
    region: "APAC",
    severanceWeeksPerYear: 2.2,
    noticeWeeks: 4,
    capNote: "One month per year, with monthly pay capped at 3x local average wage.",
    considerations: [
      "Mutual separation agreements are the common practical route.",
      "Mass layoffs require plan reporting to the labour bureau.",
      "Social insurance and housing fund transfers must be handled.",
    ],
  },
  {
    country: "South Korea",
    region: "APAC",
    severanceWeeksPerYear: 4.3,
    noticeWeeks: 4,
    capNote: "Statutory retirement allowance of about 30 days pay per year of service.",
    considerations: [
      "Managerial dismissal requires urgent business necessity and fair criteria.",
      "60 days of consultation with the labour union or employee representatives.",
      "Severance may sit in a retirement pension scheme.",
    ],
  },
  {
    country: "Japan",
    region: "APAC",
    severanceWeeksPerYear: 4.3,
    noticeWeeks: 4.3,
    capNote: "No statutory severance formula; packages follow policy and negotiated practice.",
    considerations: [
      "Dismissal must satisfy the four-factor test for economic redundancy.",
      "Voluntary retirement programmes are the common practice.",
      "30 days notice or pay in lieu is required.",
    ],
  },
  {
    country: "Taiwan",
    region: "APAC",
    severanceWeeksPerYear: 2.2,
    noticeWeeks: 4,
    capNote: "Half a month per year under the new pension scheme, capped at six months.",
    considerations: [
      "Mass redundancy notification and plan filing obligations.",
      "Notice length scales with length of service.",
      "Paid leave for job seeking during the notice period.",
    ],
  },
  {
    country: "Malaysia",
    region: "APAC",
    severanceWeeksPerYear: 2.5,
    noticeWeeks: 4,
    capNote: "Termination benefits of 10-20 days wages per year for covered employees.",
    considerations: [
      "PK form notification to the Labour Department before retrenchment.",
      "Last-in-first-out expectations unless justified otherwise.",
      "Local vs foreign worker sequencing guidance applies.",
    ],
  },
  {
    country: "Singapore",
    region: "APAC",
    severanceWeeksPerYear: 2,
    noticeWeeks: 4,
    capNote: "No statutory severance; norm is 2 weeks to 1 month per year of service.",
    considerations: [
      "Tripartite Advisory on managing excess manpower should be followed.",
      "Mandatory retrenchment notification to MOM for larger employers.",
      "Fair consideration framework applies to workforce composition.",
    ],
  },
  {
    country: "Netherlands",
    region: "EMEA",
    severanceWeeksPerYear: 1.4,
    noticeWeeks: 4,
    capNote: "Transition payment of about 1/3 month per year of service.",
    considerations: [
      "UWV permission or court route required for dismissal.",
      "Reflection period on settlement agreements.",
      "Works council consultation for collective changes.",
    ],
  },
  {
    country: "Belgium",
    region: "EMEA",
    severanceWeeksPerYear: 3,
    noticeWeeks: 6,
    capNote: "Notice periods scale steeply with seniority; pay in lieu is common.",
    considerations: [
      "Renault Act procedure for collective dismissals.",
      "Outplacement obligations for eligible employees.",
      "Motivation of dismissal may be requested by the employee.",
    ],
  },
  {
    country: "Spain",
    region: "EMEA",
    severanceWeeksPerYear: 2.9,
    noticeWeeks: 2,
    capNote: "Objective dismissal: 20 days pay per year, capped at 12 months.",
    considerations: [
      "ERE collective dismissal procedure above statutory thresholds.",
      "Consultation period with worker representatives.",
      "Unfair dismissal exposure rises to 33 days per year.",
    ],
  },
  {
    country: "Turkey",
    region: "EMEA",
    severanceWeeksPerYear: 4.3,
    noticeWeeks: 4,
    capNote: "30 days pay per year, subject to a statutory ceiling per year of service.",
    considerations: [
      "One year minimum service for severance entitlement.",
      "Notice pay is separate from severance.",
      "Reinstatement claims possible where job security provisions apply.",
    ],
  },
  {
    country: "Italy",
    region: "EMEA",
    severanceWeeksPerYear: 3.2,
    noticeWeeks: 4,
    capNote: "TFR accrues at roughly one month's pay per year of service.",
    considerations: [
      "Collective dismissal procedure with union notification.",
      "TFR is an accrued entitlement payable on any exit.",
      "National collective agreements (CCNL) may add obligations.",
    ],
  },
  {
    country: "New Zealand",
    region: "APAC",
    severanceWeeksPerYear: 0,
    noticeWeeks: 4,
    capNote: "No statutory redundancy compensation; contract and policy govern.",
    considerations: [
      "Good-faith consultation obligations are substantive, not procedural only.",
      "Genuine business rationale must be documented.",
      "Redeployment must be considered before termination.",
    ],
  },
];

export const SUPPORTED_COUNTRIES = COUNTRY_GUIDANCE.map((c) => c.country);

export function getGuidance(country: string): CountryGuidance | undefined {
  return COUNTRY_GUIDANCE.find((c) => c.country === country);
}

/** Illustrative only. Weeks-per-year heuristic on annual cost. */
export function illustrativeSeverance(annualCost: number, serviceMonths: number, country: string) {
  const g = getGuidance(country);
  if (!g) return { severance: 0, notice: 0, total: 0, years: 0 };
  const years = Math.max(0, serviceMonths / 12);
  const weekly = annualCost / 52;
  const severance = Math.round(weekly * g.severanceWeeksPerYear * years);
  const notice = Math.round(weekly * g.noticeWeeks);
  return { severance, notice, total: severance + notice, years };
}