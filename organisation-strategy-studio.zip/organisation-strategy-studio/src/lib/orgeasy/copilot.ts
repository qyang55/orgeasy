import type { Scenario } from "./types";
import { computeImpact, formatMoney } from "./impact";

export interface CopilotBrief {
  asset: string;
  audience: string;
  tone: string;
  language: string;
  length: string;
  channel: string;
  senderName: string;
  senderTitle: string;
  mustInclude: string;
  guardrails: string;
  facts: string;
  reference?: string;
  previousDraft?: string;
  revisionRequest?: string;
}

export const ASSET_PRESETS: {
  id: string;
  label: string;
  asset: string;
  audience: string;
  channel: string;
  hint: string;
  referenceTemplateId?: string;
}[] = [
  {
    id: "leadership",
    label: "Leadership announcement",
    asset: "Company-wide leadership announcement email",
    audience: "All employees",
    channel: "Email",
    hint: "Sets the narrative: why now, what changes, what happens next.",
    referenceTemplateId: "leadership",
  },
  {
    id: "manager",
    label: "Manager talking points",
    asset: "Manager briefing pack with talking points and objection handling",
    audience: "People managers",
    channel: "Briefing document",
    hint: "What managers say, what they must not say, and how to escalate.",
    referenceTemplateId: "manager",
  },
  {
    id: "faq",
    label: "Employee FAQ",
    asset: "Employee FAQ covering process, selection, support and timing",
    audience: "All employees",
    channel: "Intranet page",
    hint: "Answers the questions people actually ask, without over-promising.",
    referenceTemplateId: "faq",
  },
  {
    id: "personal",
    label: "1:1 impacted conversation",
    asset: "Script for a one-to-one conversation with an impacted colleague",
    audience: "Impacted colleague (delivered by their manager)",
    channel: "In person / video call",
    hint: "Opening words, pauses, and how to close with next steps.",
    referenceTemplateId: "personal",
  },
  {
    id: "retained",
    label: "Retained team message",
    asset: "Message to colleagues who are not directly impacted",
    audience: "Retained teams",
    channel: "Team meeting note",
    hint: "Addresses survivor anxiety and re-anchors on the work ahead.",
  },
  {
    id: "works-council",
    label: "Works council / union note",
    asset: "Information and consultation opening note for a works council or union",
    audience: "Employee representatives",
    channel: "Formal letter",
    hint: "Neutral, process-first framing that does not pre-empt consultation.",
  },
  {
    id: "adkar",
    label: "ADKAR intervention plan",
    asset: "ADKAR-based change communication plan with interventions per barrier point",
    audience: "Change and OD team",
    channel: "Working document",
    hint: "Maps the weakest ADKAR dimension per stakeholder group to actions.",
  },
  {
    id: "town-hall",
    label: "Town hall Q&A prep",
    asset: "Town hall run sheet with likely hard questions and holding answers",
    audience: "Executive panel",
    channel: "Run sheet",
    hint: "Prepares leaders for the questions they would rather not get.",
  },
  {
    id: "custom",
    label: "Something else",
    asset: "",
    audience: "",
    channel: "Email",
    hint: "Describe the asset you need in your own words.",
  },
];

export const TONES = [
  "Warm and human",
  "Calm and factual",
  "Direct and decisive",
  "Formal and legalistic",
  "Empathetic and supportive",
];

export const LENGTHS = [
  "Short (under 200 words)",
  "Standard (300–450 words)",
  "Detailed (600–900 words)",
  "Comprehensive (900+ words, sectioned)",
];

export const LANGUAGES = [
  "English (international)",
  "English (US)",
  "English (UK)",
  "French",
  "German",
  "Spanish",
  "Portuguese (Brazil)",
  "Dutch",
  "Japanese",
  "Simplified Chinese",
  "Thai",
];

const ADKAR_LABELS: Record<string, string> = {
  awareness: "Awareness",
  desire: "Desire",
  knowledge: "Knowledge",
  ability: "Ability",
  reinforcement: "Reinforcement",
};

export function buildScenarioFacts(scenario: Scenario | null | undefined): string {
  if (!scenario) return "No scenario is loaded. Use placeholders for every number.";
  const impact = computeImpact(scenario);
  const cur = scenario.currency ?? "USD";
  const lines: string[] = [];

  lines.push(`Scenario name: ${scenario.name}`);
  lines.push(
    `Headcount: ${impact.currentHeadcount.toLocaleString()} current positions to ${impact.plannedHeadcount.toLocaleString()} planned positions (delta ${impact.headcountDelta >= 0 ? "+" : ""}${impact.headcountDelta}).`,
  );
  lines.push(
    `Annualised fully loaded people cost: ${formatMoney(impact.currentCost, cur)} to ${formatMoney(impact.plannedCost, cur)} (change ${formatMoney(impact.costDelta, cur)}${impact.costDelta < 0 ? `, a reduction of ${formatMoney(-impact.costDelta, cur)}` : ""}).`,
  );
  lines.push(
    `Role movements: ${impact.newRoles.length} new, ${impact.removedRoles.length} proposed for removal, ${impact.movedRoles.length} changing reporting line, ${impact.unchanged} unchanged.`,
  );

  const depts = impact.byDepartment
    .filter((d) => d.plannedHeadcount !== d.currentHeadcount)
    .slice(0, 12)
    .map((d) => `${d.department}: ${d.currentHeadcount} to ${d.plannedHeadcount}`);
  if (depts.length) lines.push(`Departments with headcount change — ${depts.join("; ")}.`);

  const countries = impact.byCountry
    .filter((c) => c.removed > 0 || c.plannedHeadcount !== c.currentHeadcount)
    .slice(0, 22)
    .map(
      (c) =>
        `${c.country}: ${c.currentHeadcount} to ${c.plannedHeadcount}${c.removed ? `, ${c.removed} role(s) proposed for removal` : ""}`,
    );
  if (countries.length) lines.push(`Countries in scope — ${countries.join("; ")}.`);

  const removedTitles = impact.removedRoles
    .slice(0, 15)
    .map((e) => `${e.title}${e.department ? ` (${e.department})` : ""}`);
  if (removedTitles.length)
    lines.push(`Example roles proposed for removal: ${removedTitles.join(", ")}.`);

  const newTitles = impact.newRoles
    .slice(0, 15)
    .map((e) => `${e.title}${e.department ? ` (${e.department})` : ""}`);
  if (newTitles.length) lines.push(`Example new roles being created: ${newTitles.join(", ")}.`);

  const adkar = scenario.adkarGroups ?? [];
  if (adkar.length) {
    const summary = adkar.slice(0, 10).map((g) => {
      const entries = Object.entries(g.scores ?? {});
      const weakest = entries.sort((a, b) => Number(a[1]) - Number(b[1]))[0];
      const scores = entries
        .map(([k, v]) => `${ADKAR_LABELS[k] ?? k} ${v}/5`)
        .join(", ");
      return `${g.name}: ${scores}${weakest ? ` — weakest barrier: ${ADKAR_LABELS[weakest[0]] ?? weakest[0]}` : ""}`;
    });
    lines.push(`ADKAR readiness by stakeholder group — ${summary.join("; ")}.`);
  }

  return lines.join("\n");
}