/**
 * Portfolio analysis across many job descriptions: rollups, phase
 * recommendations and a proposed future-state structure.
 *
 * Framing stays on planning: the outputs describe where work can move to
 * technology and how roles can be reshaped, never individual people.
 */
import { BAND_META, computeTotals, type AutomatabilityBand, type RoleAutomationAnalysis } from "./automation";
import type { Employee, EmployeeStatus } from "./types";

export interface PortfolioTotals {
  roles: number;
  tasks: number;
  averageScore: number;
  hoursPerWeek: number;
  hoursPerYear: number;
  annualSaving: number;
  fteEquivalent: number;
  quickWins: number;
  humanTasks: number;
  currency: string;
}

export function portfolioTotals(analyses: RoleAutomationAnalysis[]): PortfolioTotals {
  const rows = analyses.map((a) => ({ a, t: computeTotals(a) }));
  const hoursPerWeek = round1(rows.reduce((s, r) => s + r.t.hoursPerWeek, 0));
  const scored = rows.filter((r) => r.a.tasks.length);
  return {
    roles: analyses.length,
    tasks: analyses.reduce((s, a) => s + a.tasks.length, 0),
    averageScore: scored.length
      ? Math.round(scored.reduce((s, r) => s + r.a.overallScore, 0) / scored.length)
      : 0,
    hoursPerWeek,
    hoursPerYear: Math.round(hoursPerWeek * 46),
    annualSaving: rows.reduce((s, r) => s + r.t.annualSaving, 0),
    fteEquivalent: Math.round((hoursPerWeek / 38) * 100) / 100,
    quickWins: rows.reduce((s, r) => s + r.t.quickWins, 0),
    humanTasks: rows.reduce((s, r) => s + r.t.humanTasks, 0),
    currency: analyses[0]?.currency ?? "USD",
  };
}

function round1(n: number) {
  return Math.round(n * 10) / 10;
}

export interface DepartmentRollup {
  department: string;
  roles: number;
  averageScore: number;
  hoursPerWeek: number;
  annualSaving: number;
  fteEquivalent: number;
  analyses: RoleAutomationAnalysis[];
}

export function departmentRollups(analyses: RoleAutomationAnalysis[]): DepartmentRollup[] {
  const map = new Map<string, RoleAutomationAnalysis[]>();
  for (const a of analyses) {
    const key = a.department.trim() || "Unassigned";
    map.set(key, [...(map.get(key) ?? []), a]);
  }
  return [...map.entries()]
    .map(([department, list]) => {
      const hoursPerWeek = round1(
        list.reduce((s, a) => s + computeTotals(a).hoursPerWeek, 0),
      );
      return {
        department,
        roles: list.length,
        averageScore: Math.round(list.reduce((s, a) => s + a.overallScore, 0) / list.length),
        hoursPerWeek,
        annualSaving: list.reduce((s, a) => s + computeTotals(a).annualSaving, 0),
        fteEquivalent: Math.round((hoursPerWeek / 38) * 100) / 100,
        analyses: [...list].sort((a, b) => b.overallScore - a.overallScore),
      };
    })
    .sort((a, b) => b.hoursPerWeek - a.hoursPerWeek);
}

export function bandDistribution(analyses: RoleAutomationAnalysis[]) {
  const counts: Record<AutomatabilityBand, number> = { full: 0, high: 0, partial: 0, human: 0 };
  let total = 0;
  for (const a of analyses) {
    for (const t of a.tasks) {
      counts[t.band] += 1;
      total += 1;
    }
  }
  return { counts, total };
}

export interface PortfolioTaskRow {
  analysis: RoleAutomationAnalysis;
  taskId: string;
  task: string;
  band: AutomatabilityBand;
  score: number;
  approach: string;
  hoursSavedPerWeek: number;
}

export function allTaskRows(analyses: RoleAutomationAnalysis[]): PortfolioTaskRow[] {
  return analyses
    .flatMap((analysis) =>
      analysis.tasks.map((t) => ({
        analysis,
        taskId: t.id,
        task: t.task,
        band: t.band,
        score: t.score,
        approach: t.approach,
        hoursSavedPerWeek: t.hoursSavedPerWeek,
      })),
    )
    .sort((a, b) => b.hoursSavedPerWeek - a.hoursSavedPerWeek || b.score - a.score);
}

export interface ChangePhase {
  order: number;
  name: string;
  window: string;
  focus: string;
  hoursPerWeek: number;
  annualSaving: number;
  roles: string[];
  items: PortfolioTaskRow[];
  actions: string[];
}

/**
 * Sequences the portfolio into three delivery phases: proven quick wins first,
 * assisted work next, then the structural changes that need consultation.
 */
export function recommendPhases(analyses: RoleAutomationAnalysis[]): ChangePhase[] {
  const rows = allTaskRows(analyses);
  const currency = analyses[0]?.currency ?? "USD";
  const rate = (r: PortfolioTaskRow) => r.analysis.hourlyCost || 0;

  const build = (
    order: number,
    name: string,
    window: string,
    focus: string,
    items: PortfolioTaskRow[],
    actions: string[],
  ): ChangePhase => {
    const hoursPerWeek = round1(items.reduce((s, r) => s + r.hoursSavedPerWeek, 0));
    return {
      order,
      name,
      window,
      focus,
      hoursPerWeek,
      annualSaving: Math.round(items.reduce((s, r) => s + r.hoursSavedPerWeek * 46 * rate(r), 0)),
      roles: [...new Set(items.map((r) => r.analysis.roleTitle))].slice(0, 12),
      items: items.slice(0, 40),
      actions,
    };
  };

  const phase1 = rows.filter((r) => r.band === "full");
  const phase2 = rows.filter((r) => r.band === "high");
  const phase3 = rows.filter((r) => r.band === "partial");

  const heavyDepartments = departmentRollups(analyses)
    .filter((d) => d.fteEquivalent >= 0.5)
    .slice(0, 3)
    .map((d) => d.department);

  void currency;

  return [
    build(
      1,
      "Prove it — rule-based wins",
      "0–3 months",
      "Automate the high-volume, rule-based steps where the input format is already stable.",
      phase1,
      [
        "Confirm task volumes and weekly hours with each role holder before building.",
        "Pilot two or three automations end to end and measure hours returned over four weeks.",
        "Agree up front what the freed hours are reinvested in.",
      ],
    ),
    build(
      2,
      "Assist — AI in the flow of work",
      "3–9 months",
      "Introduce AI assistants and integrations for drafting, summarising and moving data, with human review.",
      phase2,
      [
        "Stand up review and quality checks so a person signs off every AI output.",
        "Train affected role holders on the new tools before go-live (ADKAR: knowledge and ability).",
        "Refresh job descriptions to reflect the reviewer, not the producer, of routine output.",
      ],
    ),
    build(
      3,
      "Reshape — role and structure design",
      "9–18 months",
      heavyDepartments.length
        ? `Redesign roles and spans where capacity has shifted, starting with ${heavyDepartments.join(", ")}.`
        : "Redesign roles and spans of control where capacity has meaningfully shifted.",
      phase3,
      [
        "Model the future structure and validate spans of control with department leads.",
        "Take local legal and consultation advice before any role or headcount change.",
        "Publish redeployment and upskilling routes alongside any structural announcement.",
      ],
    ),
  ];
}

/* ------------------------------------------------------- future-state build */

function baseEmployee(partial: Partial<Employee> & { id: string; title: string }): Employee {
  return {
    name: "",
    isOpenRole: true,
    department: "",
    country: "United States",
    responsibilities: "",
    currentHeadcount: 0,
    plannedHeadcount: 1,
    employmentType: "Full-time",
    managerId: null,
    status: "planned",
    currentCost: 0,
    plannedCost: 0,
    serviceMonths: 0,
    ...partial,
  };
}

function statusForScore(score: number): EmployeeStatus {
  if (score >= 85) return "to-be-removed";
  if (score >= 65) return "moved";
  return "planned";
}

/** Suggested shape of the role after automation, used as the node subtitle. */
export function futureRoleTitle(analysis: RoleAutomationAnalysis) {
  if (analysis.overallScore >= 85) return `${analysis.roleTitle} (automated / redesign)`;
  if (analysis.overallScore >= 65) return `${analysis.roleTitle} (AI-assisted)`;
  return analysis.roleTitle;
}

export interface FutureStateDraft {
  employees: Employee[];
  notes: string[];
}

/**
 * Builds a proposed future-state org structure from the analysed JDs:
 * one node per role, grouped under a department lead, with automation status
 * and post-automation cost applied.
 */
export function buildFutureState(
  analyses: RoleAutomationAnalysis[],
  options: { rootTitle?: string } = {},
): FutureStateDraft {
  const employees: Employee[] = [];
  const notes: string[] = [];
  if (!analyses.length) return { employees, notes };

  const rootId = "root-exec";
  employees.push(
    baseEmployee({
      id: rootId,
      title: options.rootTitle ?? "Executive Team",
      department: "Leadership",
      responsibilities: "Owns the automation and role-redesign programme.",
      plannedHeadcount: 1,
      status: "current",
    }),
  );

  for (const group of departmentRollups(analyses)) {
    const leadId = `lead-${slug(group.department)}`;
    employees.push(
      baseEmployee({
        id: leadId,
        title: `${group.department} Lead`,
        department: group.department,
        managerId: rootId,
        responsibilities: `Owns ${group.roles} analysed role${group.roles === 1 ? "" : "s"}; ${group.hoursPerWeek}h/week of routine work moving to technology.`,
        status: "current",
      }),
    );
    notes.push(
      `${group.department}: ${group.roles} roles, ${group.hoursPerWeek}h/week returned (~${group.fteEquivalent} FTE of capacity).`,
    );

    for (const analysis of group.analyses) {
      const totals = computeTotals(analysis);
      const annualCost = Math.round((analysis.hourlyCost || 0) * 1800);
      employees.push(
        baseEmployee({
          id: `role-${analysis.id}`,
          title: futureRoleTitle(analysis),
          department: group.department,
          managerId: leadId,
          responsibilities:
            `${analysis.overallScore}% automatable. ${totals.hoursPerWeek}h/week returned. ` +
            (analysis.summary || ""),
          status: statusForScore(analysis.overallScore),
          currentCost: annualCost,
          plannedCost: Math.max(
            0,
            Math.round(annualCost * (1 - Math.min(0.6, analysis.overallScore / 200))),
          ),
          plannedHeadcount: 1,
          currentHeadcount: 1,
        }),
      );
    }
  }

  return { employees, notes };
}

function slug(text: string) {
  return text.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "dept";
}

export function bandLabel(band: AutomatabilityBand) {
  return BAND_META[band].label;
}
