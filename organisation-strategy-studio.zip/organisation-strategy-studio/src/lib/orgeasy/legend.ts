import type { Scenario } from "./types";
import {
  LEVER_META,
  ORG_UNIT_KINDS,
  REDUCTION_LEVERS,
  ROLE_SCOPES,
  ROLE_TYPES,
  ROLE_TYPE_META,
  SCOPE_META,
  STATUS_META,
  UNIT_META,
} from "./types";
import {
  MEASURE_META,
  MEASURE_RAMP,
  buildEncodeContext,
  getTheme,
  isMeasure,
  type ChartTheme,
  type ColorBy,
} from "./themes";

/** Which legend sections the user wants shown on the chart and in exports. */
export interface LegendConfig {
  show: boolean;
  status: boolean;
  employmentType: boolean;
  openRole: boolean;
  roleScope: boolean;
  unitKind: boolean;
  dottedLine: boolean;
}

export const DEFAULT_LEGEND: LegendConfig = {
  show: true,
  status: true,
  employmentType: true,
  openRole: true,
  roleScope: true,
  unitKind: true,
  dottedLine: true,
};

export const LEGEND_STORAGE_KEY = "orgeasy.chart.legend";

export function loadLegendConfig(): LegendConfig {
  if (typeof localStorage === "undefined") return DEFAULT_LEGEND;
  try {
    const raw = localStorage.getItem(LEGEND_STORAGE_KEY);
    return raw ? { ...DEFAULT_LEGEND, ...(JSON.parse(raw) as Partial<LegendConfig>) } : DEFAULT_LEGEND;
  } catch {
    return DEFAULT_LEGEND;
  }
}

export function saveLegendConfig(config: LegendConfig) {
  if (typeof localStorage === "undefined") return;
  localStorage.setItem(LEGEND_STORAGE_KEY, JSON.stringify(config));
}

export interface LegendItem {
  label: string;
  color: string;
  /** Rendered as a hollow ring instead of a filled dot (used for open roles). */
  hollow?: boolean;
}

export interface LegendSection {
  title: string;
  items: LegendItem[];
}

function hash(value: string) {
  let h = 0;
  for (let i = 0; i < value.length; i++) h = (h * 31 + value.charCodeAt(i)) | 0;
  return Math.abs(h);
}

/** Builds the legend sections for a scenario, based only on values actually present. */
export function buildLegend(
  scenario: Scenario | null,
  config: LegendConfig = DEFAULT_LEGEND,
  theme: ChartTheme = getTheme("enterprise"),
  colorBy: ColorBy = "status",
): LegendSection[] {
  if (!scenario || !config.show) return [];
  const sections: LegendSection[] = [];
  const employees = scenario.employees;

  // The active encoding always leads the legend so the reader knows what colour means.
  if (isMeasure(colorBy)) {
    const ctx = buildEncodeContext(employees);
    const { lo, hi } = ctx.ranges[colorBy];
    const meta = MEASURE_META[colorBy];
    sections.push({
      title: `Colour = ${meta.label}`,
      items: MEASURE_RAMP.map((hex, i) => {
        const t = i / (MEASURE_RAMP.length - 1);
        return { label: meta.format(lo + (hi - lo) * t), color: hex };
      }),
    });
  } else if (colorBy === "roleType") {
    sections.push({
      title: "Colour = delivery by human or AI agent",
      items: ROLE_TYPES.filter((k) => employees.some((e) => (e.roleType ?? "human") === k)).map((k) => ({
        label: `${ROLE_TYPE_META[k].label} (${employees.filter((e) => (e.roleType ?? "human") === k).length})`,
        color: `#${ROLE_TYPE_META[k].hex}`,
      })),
    });
  } else if (colorBy === "lever") {
    sections.push({
      title: "Colour = reduction lever",
      items: [
        ...REDUCTION_LEVERS.filter((k) => employees.some((e) => e.reductionLever === k)).map((k) => ({
          label: `${LEVER_META[k].label} (${employees.filter((e) => e.reductionLever === k).length})`,
          color: `#${LEVER_META[k].hex}`,
        })),
        { label: "No lever applied", color: theme.muted, hollow: true },
      ],
    });
  }

  if (config.status) {
    const used = (Object.keys(STATUS_META) as (keyof typeof STATUS_META)[]).filter((k) =>
      employees.some((e) => e.status === k),
    );
    const keys = used.length ? used : (Object.keys(STATUS_META) as (keyof typeof STATUS_META)[]);
    sections.push({
      title: "Status",
      items: keys.map((k) => {
        const count = employees.filter((e) => e.status === k).length;
        return {
          label: `${STATUS_META[k].label}${count ? ` (${count})` : ""}`,
          color: `#${STATUS_META[k].hex}`,
        };
      }),
    });
  }

  if (config.employmentType) {
    const types = Array.from(new Set(employees.map((e) => e.employmentType))).sort();
    if (types.length) {
      sections.push({
        title: "Employment type",
        items: types.map((t) => ({
          label: `${t} (${employees.filter((e) => e.employmentType === t).length})`,
          color: theme.swatches[hash(t) % theme.swatches.length]!,
        })),
      });
    }
  }

  if (config.openRole) {
    const open = employees.filter((e) => e.isOpenRole || !e.name.trim()).length;
    sections.push({
      title: "Open roles",
      items: [
        { label: `Unfilled / open role (${open})`, color: theme.muted, hollow: true },
        { label: `Named incumbent (${employees.length - open})`, color: theme.text },
      ],
    });
  }

  if (config.roleScope) {
    const used = ROLE_SCOPES.filter(
      (k) => k !== "unset" && employees.some((e) => (e.roleScope ?? "unset") === k),
    );
    if (used.length) {
      sections.push({
        title: "Role scope",
        items: used.map((k) => ({
          label: `${SCOPE_META[k].label} (${employees.filter((e) => (e.roleScope ?? "unset") === k).length})`,
          color: `#${SCOPE_META[k].hex}`,
        })),
      });
    }
  }

  if (config.unitKind) {
    const used = ORG_UNIT_KINDS.filter(
      (k) => k !== "line" && employees.some((e) => (e.unitKind ?? "line") === k),
    );
    if (used.length) {
      sections.push({
        title: "Delivery model",
        items: used.map((k) => ({
          label: `${UNIT_META[k].label} (${employees.filter((e) => (e.unitKind ?? "line") === k).length})`,
          color: `#${UNIT_META[k].hex}`,
        })),
      });
    }
  }

  if (config.dottedLine) {
    const dotted = employees.filter((e) => (e.dottedManagerIds ?? []).length).length;
    if (dotted) {
      sections.push({
        title: "Reporting lines",
        items: [
          { label: `Solid line — direct manager`, color: theme.text },
          { label: `Dotted line — matrix / functional (${dotted})`, color: theme.muted, hollow: true },
        ],
      });
    }
  }

  return sections;
}

/** Flat text lines for the PDF summary. */
export function legendToLines(sections: LegendSection[]): string[] {
  return sections.map((s) => `${s.title}: ${s.items.map((i) => i.label).join(" · ")}`);
}

export interface LegendDrawOptions {
  x: number;
  y: number;
  maxWidth: number;
  textColor?: string;
  mutedColor?: string;
  surface?: string;
  border?: string;
}

/** Measures then draws the legend onto a 2D canvas. Returns the height consumed. */
export function drawLegend(
  ctx: CanvasRenderingContext2D,
  sections: LegendSection[],
  opts: LegendDrawOptions,
): number {
  if (!sections.length) return 0;
  const pad = 14;
  const rowGap = 22;
  const titleGap = 18;
  const text = opts.textColor ?? "#0f172a";
  const muted = opts.mutedColor ?? "#64748b";

  // --- measure
  ctx.font = "600 12px Helvetica, Arial, sans-serif";
  const layout = sections.map((section) => {
    ctx.font = "12px Helvetica, Arial, sans-serif";
    const rows: LegendItem[][] = [[]];
    let width = 0;
    const inner = opts.maxWidth - pad * 2;
    for (const item of section.items) {
      const w = 16 + ctx.measureText(item.label).width + 18;
      if (width + w > inner && rows[rows.length - 1]!.length) {
        rows.push([]);
        width = 0;
      }
      rows[rows.length - 1]!.push(item);
      width += w;
    }
    return { section, rows };
  });
  const height =
    pad * 2 + layout.reduce((sum, l) => sum + titleGap + l.rows.length * rowGap, 0) - 4;

  // --- draw
  if (opts.surface) {
    ctx.fillStyle = opts.surface;
    ctx.beginPath();
    ctx.rect(opts.x, opts.y, opts.maxWidth, height);
    ctx.fill();
  }
  if (opts.border) {
    ctx.strokeStyle = opts.border;
    ctx.lineWidth = 1;
    ctx.strokeRect(opts.x + 0.5, opts.y + 0.5, opts.maxWidth - 1, height - 1);
  }

  let cursorY = opts.y + pad + 10;
  for (const { section, rows } of layout) {
    ctx.fillStyle = muted;
    ctx.font = "600 11px Helvetica, Arial, sans-serif";
    ctx.fillText(section.title.toUpperCase(), opts.x + pad, cursorY);
    cursorY += titleGap;
    for (const row of rows) {
      let cursorX = opts.x + pad;
      for (const item of row) {
        ctx.beginPath();
        ctx.arc(cursorX + 5, cursorY - 4, 5, 0, Math.PI * 2);
        if (item.hollow) {
          ctx.strokeStyle = item.color;
          ctx.lineWidth = 2;
          ctx.stroke();
        } else {
          ctx.fillStyle = item.color;
          ctx.fill();
        }
        ctx.fillStyle = text;
        ctx.font = "12px Helvetica, Arial, sans-serif";
        ctx.fillText(item.label, cursorX + 16, cursorY);
        cursorX += 16 + ctx.measureText(item.label).width + 18;
      }
      cursorY += rowGap;
    }
  }
  return height;
}
