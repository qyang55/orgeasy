/**
 * Full cost model per role.
 *
 * Every position is priced from a base salary and split into:
 *  - FIXED    committed recurring cost — base salary + employer contributions
 *             (social security, statutory funds) + benefits (medical, pension,
 *             allowances)
 *  - VARIABLE consumption / performance cost — bonus and incentive pay plus AI
 *             agent running cost (licences, tokens, orchestration)
 *  - TOTAL    fixed + variable
 *
 * Assumptions are illustrative planning defaults, editable per workspace and
 * overridable per role. They are not payroll or actuarial figures.
 */
import { useSyncExternalStore } from "react";
import { hasConsent } from "./consent";
import { agentAnnualCost, agentMonthlyDefault, HYBRID_AGENT_SHARE, roleTypeOf } from "./agents";
import { COUNTRY_COST_RULES, resolveCountries } from "./country-costs";
import type { Employee } from "./types";

/* ------------------------------------------------------------- assumptions */

export interface CostAssumptions {
  /** Employer social-security / statutory contributions, % of base salary. */
  employerContributionPct: number;
  /** Benefits: medical, pension top-up, allowances, % of base salary. */
  benefitsPct: number;
  /** Bonus and incentive pay at target, % of base salary. */
  variablePayPct: number;
  /** Use region-specific employer contribution rates instead of one global rate. */
  useRegionalRates: boolean;
}

export const DEFAULT_COST_ASSUMPTIONS: CostAssumptions = {
  employerContributionPct: 18,
  benefitsPct: 12,
  variablePayPct: 10,
  useRegionalRates: true,
};

/** Illustrative employer contribution rates (% of base) by region. */
export const REGION_EMPLOYER_RATES: Record<string, number> = {
  EMEA: 24,
  Europe: 26,
  APAC: 15,
  Americas: 17,
  LATAM: 28,
};

const KEY = "orgeasy.costmodel.v1";
let assumptions: CostAssumptions = { ...DEFAULT_COST_ASSUMPTIONS };
let loaded = false;
const listeners = new Set<() => void>();

export function costAssumptions(): CostAssumptions {
  if (!loaded) {
    loaded = true;
    if (typeof localStorage !== "undefined") {
      try {
        const raw = localStorage.getItem(KEY);
        if (raw) assumptions = { ...DEFAULT_COST_ASSUMPTIONS, ...JSON.parse(raw) };
      } catch {
        /* ignore malformed state */
      }
    }
  }
  return assumptions;
}

export function setCostAssumptions(patch: Partial<CostAssumptions>) {
  assumptions = { ...costAssumptions(), ...patch };
  if (typeof localStorage !== "undefined" && hasConsent("workspace")) {
    try {
      localStorage.setItem(KEY, JSON.stringify(assumptions));
    } catch {
      /* storage full */
    }
  }
  listeners.forEach((fn) => fn());
}

export function subscribeCostAssumptions(fn: () => void) {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

/** Live subscription to the workspace cost assumptions. */
export function useCostAssumptions() {
  return useSyncExternalStore(
    subscribeCostAssumptions,
    () => costAssumptions(),
    () => DEFAULT_COST_ASSUMPTIONS,
  );
}

const REGION_BY_COUNTRY = new Map(COUNTRY_COST_RULES.map((r) => [r.country, r.region]));

/** Employer contribution rate (% of base) applied to a role. */
export function employerRateFor(country: string, a: CostAssumptions = costAssumptions()) {
  if (!a.useRegionalRates) return a.employerContributionPct;
  const region = REGION_BY_COUNTRY.get(country);
  const rate = region ? REGION_EMPLOYER_RATES[region] : undefined;
  return rate ?? a.employerContributionPct;
}

/* ---------------------------------------------------------------- per role */

export interface RoleCost {
  /** Positions priced (headcount for the chosen state). */
  positions: number;
  /** Base salary per position, before any loading. */
  baseSalaryPerPosition: number;
  baseSalary: number;
  employerContributions: number;
  benefits: number;
  variablePay: number;
  agentCost: number;
  fixed: number;
  variable: number;
  total: number;
  /** Fully loaded cost of one position. */
  totalPerPosition: number;
}

export type CostState = "current" | "planned";

const EMPTY: RoleCost = {
  positions: 0,
  baseSalaryPerPosition: 0,
  baseSalary: 0,
  employerContributions: 0,
  benefits: 0,
  variablePay: 0,
  agentCost: 0,
  fixed: 0,
  variable: 0,
  total: 0,
  totalPerPosition: 0,
};

/**
 * Prices one role for the current or planned state, splitting the result into
 * fixed, variable and total. A hybrid role keeps a person at a reduced people
 * cost and adds a partial agent running cost; a fully agentic role carries no
 * salary at all.
 */
export function roleCost(
  e: Employee,
  state: CostState = "planned",
  a: CostAssumptions = costAssumptions(),
  agentMonthly = agentMonthlyDefault(),
  country?: string,
): RoleCost {
  const positions = state === "current" ? e.currentHeadcount : e.plannedHeadcount;
  if (positions <= 0) return { ...EMPTY };

  const type = state === "current" ? "human" : roleTypeOf(e);
  const humanShare = type === "agent" ? 0 : type === "hybrid" ? 1 - HYBRID_AGENT_SHARE : 1;
  const rawBase = state === "current" ? e.currentCost : e.plannedCost;
  const basePerPosition = Math.max(0, rawBase) * humanShare;

  const employerPct = employerRateFor(country ?? e.country, a) / 100;
  const benefitsPct = (e.benefitsPct ?? a.benefitsPct) / 100;
  const variablePct = (e.variablePayPct ?? a.variablePayPct) / 100;

  const baseSalary = basePerPosition * positions;
  const employerContributions = baseSalary * employerPct;
  const benefits = baseSalary * benefitsPct;
  const variablePay = baseSalary * variablePct;
  const agentCost = state === "current" ? 0 : agentAnnualCost(e, agentMonthly) * positions;

  const fixed = baseSalary + employerContributions + benefits;
  const variable = variablePay + agentCost;
  const total = fixed + variable;

  return {
    positions,
    baseSalaryPerPosition: Math.round(basePerPosition),
    baseSalary: Math.round(baseSalary),
    employerContributions: Math.round(employerContributions),
    benefits: Math.round(benefits),
    variablePay: Math.round(variablePay),
    agentCost: Math.round(agentCost),
    fixed: Math.round(fixed),
    variable: Math.round(variable),
    total: Math.round(total),
    totalPerPosition: Math.round(total / positions),
  };
}

/* --------------------------------------------------------------- roll-ups */

export interface CostTotals {
  positions: number;
  baseSalary: number;
  employerContributions: number;
  benefits: number;
  variablePay: number;
  agentCost: number;
  fixed: number;
  variable: number;
  total: number;
}

function emptyTotals(): CostTotals {
  return {
    positions: 0,
    baseSalary: 0,
    employerContributions: 0,
    benefits: 0,
    variablePay: 0,
    agentCost: 0,
    fixed: 0,
    variable: 0,
    total: 0,
  };
}

function add(into: CostTotals, c: RoleCost) {
  into.positions += c.positions;
  into.baseSalary += c.baseSalary;
  into.employerContributions += c.employerContributions;
  into.benefits += c.benefits;
  into.variablePay += c.variablePay;
  into.agentCost += c.agentCost;
  into.fixed += c.fixed;
  into.variable += c.variable;
  into.total += c.total;
}

export interface CostModelSummary {
  current: CostTotals;
  planned: CostTotals;
  delta: CostTotals;
  /** Fixed share of total planned cost, 0-1. */
  plannedFixedShare: number;
  currentFixedShare: number;
  /** Fully loaded cost per planned position. */
  plannedCostPerPosition: number;
  currentCostPerPosition: number;
  /** Multiple applied to base salary to reach total cost, planned state. */
  plannedLoadingFactor: number;
  byDepartment: { department: string; current: CostTotals; planned: CostTotals }[];
  byCountry: { country: string; current: CostTotals; planned: CostTotals }[];
}

const share = (part: number, whole: number) => (whole > 0 ? part / whole : 0);

/** Full fixed / variable / total cost model for a set of roles. */
export function computeCostModel(
  employees: Employee[],
  a: CostAssumptions = costAssumptions(),
  agentMonthly = agentMonthlyDefault(),
): CostModelSummary {
  const countries = resolveCountries(employees);
  const current = emptyTotals();
  const planned = emptyTotals();
  const deptMap = new Map<string, { department: string; current: CostTotals; planned: CostTotals }>();
  const countryMap = new Map<string, { country: string; current: CostTotals; planned: CostTotals }>();

  for (const e of employees) {
    const country = countries.get(e.id) ?? e.country ?? "Unspecified";
    const cur = roleCost(e, "current", a, agentMonthly, country);
    const plan = roleCost(e, "planned", a, agentMonthly, country);
    add(current, cur);
    add(planned, plan);

    const deptKey = e.department || "Unassigned";
    const d =
      deptMap.get(deptKey) ??
      { department: deptKey, current: emptyTotals(), planned: emptyTotals() };
    add(d.current, cur);
    add(d.planned, plan);
    deptMap.set(deptKey, d);

    const c =
      countryMap.get(country) ?? { country, current: emptyTotals(), planned: emptyTotals() };
    add(c.current, cur);
    add(c.planned, plan);
    countryMap.set(country, c);
  }

  const delta: CostTotals = {
    positions: planned.positions - current.positions,
    baseSalary: planned.baseSalary - current.baseSalary,
    employerContributions: planned.employerContributions - current.employerContributions,
    benefits: planned.benefits - current.benefits,
    variablePay: planned.variablePay - current.variablePay,
    agentCost: planned.agentCost - current.agentCost,
    fixed: planned.fixed - current.fixed,
    variable: planned.variable - current.variable,
    total: planned.total - current.total,
  };

  return {
    current,
    planned,
    delta,
    plannedFixedShare: share(planned.fixed, planned.total),
    currentFixedShare: share(current.fixed, current.total),
    plannedCostPerPosition: planned.positions
      ? Math.round(planned.total / planned.positions)
      : 0,
    currentCostPerPosition: current.positions
      ? Math.round(current.total / current.positions)
      : 0,
    plannedLoadingFactor: planned.baseSalary ? planned.total / planned.baseSalary : 0,
    byDepartment: [...deptMap.values()].sort((x, y) => y.current.total - x.current.total),
    byCountry: [...countryMap.values()].sort((x, y) => y.current.total - x.current.total),
  };
}

/** Line items for a single role, ready to render in a breakdown table. */
export function roleCostLines(c: RoleCost) {
  return [
    { label: "Base salary", value: c.baseSalary, kind: "fixed" as const },
    { label: "Employer contributions", value: c.employerContributions, kind: "fixed" as const },
    { label: "Benefits", value: c.benefits, kind: "fixed" as const },
    { label: "Bonus & incentives", value: c.variablePay, kind: "variable" as const },
    { label: "Agent running cost", value: c.agentCost, kind: "variable" as const },
  ].filter((l) => l.value !== 0);
}
