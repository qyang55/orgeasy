/** PowerPoint export for a generated Automotive Operating Model. */
import {
  AUTONOMY_META,
  COMPANY_SIZES,
  RACI_META,
  REGIONS,
  modelTotals,
  type OperatingModel,
} from "./operating-model";
import { EXPORT_NOTICES, NOT_LEGAL_ADVICE_SHORT } from "./notices";
import { BRAND_NAVY, LOGO_COVER, LOGO_MARK, logoData } from "./brand";

const BLUE = "2563EB";
const INK = "1E293B";
const MUTED = "64748B";
const LIGHT = "F1F5F9";
const WHITE = "FFFFFF";
const HEAD = "Georgia";
const BODY = "Calibri";

export async function generateOperatingModelDeck(model: OperatingModel) {
  const PptxGenJS = (await import("pptxgenjs")).default;
  const pptx = new PptxGenJS();
  pptx.layout = "LAYOUT_16x9";
  pptx.author = "Organisation Strategy Studio";
  pptx.title = model.name;
  const logo = await logoData();

  const totals = modelTotals(model);
  const sizeLabel = COMPANY_SIZES.find((s) => s.value === model.size)?.label ?? model.size;
  const region = REGIONS.find((r) => r.value === model.region);
  const dateLabel = new Date().toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const slide = (title: string, kicker?: string) => {
    const s = pptx.addSlide();
    s.background = { color: WHITE };
    s.addShape("rect", { x: 0, y: 0, w: 0.22, h: 5.63, fill: { color: BLUE } });
    if (logo) {
      s.addImage({ data: logo, x: LOGO_MARK.x, y: LOGO_MARK.y, w: LOGO_MARK.size, h: LOGO_MARK.size });
    }
    if (kicker) {
      s.addText(kicker.toUpperCase(), {
        x: 0.6, y: 0.32, w: 8.8, h: 0.3,
        fontFace: BODY, fontSize: 12, color: BLUE, bold: true, charSpacing: 2,
      });
    }
    s.addText(title, {
      x: 0.6, y: kicker ? 0.62 : 0.45, w: 8.8, h: 0.55,
      fontFace: HEAD, fontSize: 25, color: INK, bold: true,
    });
    s.addText(NOT_LEGAL_ADVICE_SHORT, {
      x: 0.6, y: 5.15, w: 8.8, h: 0.3, fontFace: BODY, fontSize: 8, color: MUTED,
    });
    return s;
  };

  const bullets = (items: string[], opts: { x: number; y: number; w: number; h: number; size?: number }) =>
    items.map((text) => ({
      text,
      options: {
        bullet: true,
        fontSize: opts.size ?? 11,
        color: INK,
        fontFace: BODY,
        breakLine: true,
      },
    }));

  /* --------------------------------------------------------------- cover */
  const cover = pptx.addSlide();
  cover.background = { color: BRAND_NAVY };
  if (logo) {
    cover.addImage({
      data: logo,
      x: LOGO_COVER.x,
      y: LOGO_COVER.y,
      w: LOGO_COVER.size,
      h: LOGO_COVER.size,
    });
  }
  cover.addText("Automotive Operating Model", {
    x: 0.7, y: 1.5, w: 8.6, h: 0.8, fontFace: HEAD, fontSize: 36, color: WHITE, bold: true,
  });
  cover.addText("Human + AI Agent model", {
    x: 0.7, y: 2.3, w: 8.6, h: 0.4, fontFace: BODY, fontSize: 18, color: "BFDBFE",
  });
  cover.addText(
    `${sizeLabel} · ${region?.label ?? model.region} · ${totals.functions} functions · ${totals.agents} agents · ${dateLabel}`,
    { x: 0.7, y: 2.85, w: 8.6, h: 0.4, fontFace: BODY, fontSize: 13, color: "E2E8F0" },
  );
  cover.addText(NOT_LEGAL_ADVICE_SHORT, {
    x: 0.7, y: 4.9, w: 8.6, h: 0.4, fontFace: BODY, fontSize: 9, color: "94A3B8",
  });

  /* ------------------------------------------------------------- summary */
  const s1 = slide("Operating model at a glance", "Executive summary");
  const cards: [string, string][] = [
    ["Functions", String(totals.functions)],
    ["Human roles", String(totals.humanRoles)],
    ["Planned positions", String(totals.headcount)],
    ["AI Agents", String(totals.agents)],
  ];
  cards.forEach(([label, value], i) => {
    const x = 0.6 + i * 2.22;
    s1.addShape("roundRect", {
      x, y: 1.35, w: 2, h: 1.1, fill: { color: LIGHT }, line: { color: "E2E8F0" }, rectRadius: 0.08,
    });
    s1.addText(value, { x, y: 1.45, w: 2, h: 0.55, align: "center", fontFace: HEAD, fontSize: 26, color: BLUE, bold: true });
    s1.addText(label, { x, y: 2.0, w: 2, h: 0.3, align: "center", fontFace: BODY, fontSize: 11, color: MUTED });
  });
  s1.addText(
    bullets([
      `Task ownership: ${totals.humanOnly} human-owned · ${totals.hybrid} hybrid · ${totals.agentOwned} agent-owned`,
      `Indicative efficiency: ${totals.fteLow}–${totals.fteHigh} FTE of effort can be released across the nine functions`,
      region?.note ? `Region focus: ${region.note}` : "Region focus: global standards",
      "Agents are deployed alongside named human owners; accountability stays with people.",
    ], { x: 0.6, y: 2.7, w: 8.8, h: 2.2 }),
    { x: 0.6, y: 2.7, w: 8.8, h: 2.2 },
  );

  /* ------------------------------------------------------- per function */
  for (const fn of model.functions) {
    const a = slide(`${fn.label} — human operating model`, "Human model");
    a.addText(fn.mission, { x: 0.6, y: 1.2, w: 8.8, h: 0.5, fontFace: BODY, fontSize: 11, color: MUTED, italic: true });
    a.addTable(
      [
        ["Role", "HC", "Core responsibilities", "KPIs"].map((t) => ({
          text: t,
          options: { bold: true, color: WHITE, fill: { color: BLUE }, fontFace: BODY, fontSize: 10 },
        })),
        ...fn.humanRoles.map((r) => [
          { text: r.title, options: { bold: true, fontSize: 9.5, color: INK, fontFace: BODY } },
          { text: String(r.headcount), options: { fontSize: 9.5, color: INK, fontFace: BODY, align: "center" as const } },
          { text: r.responsibilities.join("; "), options: { fontSize: 9, color: INK, fontFace: BODY } },
          { text: r.kpis.join(" · "), options: { fontSize: 9, color: MUTED, fontFace: BODY } },
        ]),
      ],
      { x: 0.6, y: 1.8, w: 8.8, colW: [2, 0.5, 3.4, 2.9], border: { type: "solid", color: "E2E8F0", pt: 0.5 } },
    );

    if (fn.agents.length) {
      const b = slide(`${fn.label} — AI Agent model`, "Agent model");
      b.addTable(
        [
          ["Agent", "Purpose & ownership", "Autonomy", "Data & triggers"].map((t) => ({
            text: t,
            options: { bold: true, color: WHITE, fill: { color: BRAND_NAVY }, fontFace: BODY, fontSize: 10 },
          })),
          ...fn.agents.map((ag) => [
            { text: ag.name, options: { bold: true, fontSize: 9.5, color: INK, fontFace: BODY } },
            { text: `${ag.purpose} Owns: ${ag.owns.join(", ")}.`, options: { fontSize: 9, color: INK, fontFace: BODY } },
            { text: AUTONOMY_META[ag.autonomy].label, options: { fontSize: 9, color: BLUE, fontFace: BODY } },
            {
              text: `Data: ${ag.dataSources.join(", ")}. Triggers: ${ag.triggers.join(", ")}.`,
              options: { fontSize: 9, color: MUTED, fontFace: BODY },
            },
          ]),
        ],
        { x: 0.6, y: 1.3, w: 8.8, colW: [1.7, 3.3, 1.2, 2.6], border: { type: "solid", color: "E2E8F0", pt: 0.5 } },
      );

      const c = slide(`${fn.label} — combined human + agent model`, "RACI view");
      c.addTable(
        [
          ["Task", "Ownership", "Human", "Agent"].map((t) => ({
            text: t,
            options: { bold: true, color: WHITE, fill: { color: BLUE }, fontFace: BODY, fontSize: 10 },
          })),
          ...fn.raci.map((r) => [
            { text: r.task, options: { fontSize: 9.5, color: INK, fontFace: BODY } },
            { text: RACI_META[r.mode].label, options: { fontSize: 9.5, bold: true, color: BLUE, fontFace: BODY } },
            { text: r.human, options: { fontSize: 9, color: INK, fontFace: BODY } },
            { text: r.agent, options: { fontSize: 9, color: MUTED, fontFace: BODY } },
          ]),
        ],
        { x: 0.6, y: 1.3, w: 8.8, colW: [2.7, 1.5, 2.3, 2.3], border: { type: "solid", color: "E2E8F0", pt: 0.5 } },
      );
      c.addText(
        `Indicative efficiency: ${fn.fteImpact.low}–${fn.fteImpact.high} FTE of effort released. ${fn.fteImpact.note}`,
        { x: 0.6, y: 4.7, w: 8.8, h: 0.4, fontFace: BODY, fontSize: 10.5, color: INK, bold: true },
      );
    }
  }

  /* ------------------------------------------------------------ roadmap */
  const road = slide("Suggested deployment sequence", "Roadmap");
  const autonomous = model.functions.flatMap((f) =>
    f.agents.filter((a) => a.autonomy === "autonomous").map((a) => `${f.label}: ${a.name}`),
  );
  const supervised = model.functions.flatMap((f) =>
    f.agents.filter((a) => a.autonomy === "supervised").map((a) => `${f.label}: ${a.name}`),
  );
  const hitl = model.functions.flatMap((f) =>
    f.agents.filter((a) => a.autonomy === "human-in-the-loop").map((a) => `${f.label}: ${a.name}`),
  );
  road.addText(
    bullets(
      [
        `Phase 1 — quick wins (0–3 months): ${autonomous.slice(0, 6).join(" · ") || "n/a"}`,
        `Phase 2 — supervised autonomy (3–9 months): ${supervised.slice(0, 6).join(" · ") || "n/a"}`,
        `Phase 3 — decision support with approval gates (9–18 months): ${hitl.slice(0, 6).join(" · ") || "n/a"}`,
        "Each phase needs data readiness, guardrail definition, capability build and works council / employee consultation where applicable.",
      ],
      { x: 0.6, y: 1.3, w: 8.8, h: 3.5, size: 11.5 },
    ),
    { x: 0.6, y: 1.3, w: 8.8, h: 3.5 },
  );

  /* ------------------------------------------------------------ notices */
  const last = slide("Important notices & disclaimer", "Governance");
  last.addText(
    EXPORT_NOTICES.map((n) => ({
      text: `${n.title}: ${n.body}`,
      options: { bullet: true, fontSize: 10, color: INK, fontFace: BODY, breakLine: true },
    })),
    { x: 0.6, y: 1.3, w: 8.7, h: 3.6 },
  );

  await pptx.writeFile({ fileName: "Strategy-Studio-Automotive-Operating-Model.pptx" });
}