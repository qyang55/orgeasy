export type ConsentCategoryId = "essential" | "workspace" | "preferences" | "analytics";

export type ConsentState = {
  version: number;
  decidedAt: string | null;
  categories: Record<ConsentCategoryId, boolean>;
};

export const CONSENT_VERSION = 1;
const KEY = "orgeasy.consent.v1";

export const CONSENT_CATEGORIES: {
  id: ConsentCategoryId;
  label: string;
  purpose: string;
  storage: string;
  required: boolean;
}[] = [
  {
    id: "essential",
    label: "Strictly necessary",
    purpose:
      "Keeps the app usable: routing, session integrity and remembering this consent choice itself.",
    storage: "localStorage: orgeasy.consent.v1 · sessionStorage: orgeasy:chunk-reloaded",
    required: true,
  },
  {
    id: "workspace",
    label: "Workspace data (employee records)",
    purpose:
      "Stores your scenarios, roles, costs, photos and ADKAR scores in this browser so work survives a refresh. Turning this off keeps your work in this browser tab only (sessionStorage) — it is discarded when the tab closes.",
    storage: "localStorage: orgeasy.workspace.v1 (tab-only sessionStorage when declined)",
    required: false,
  },
  {
    id: "preferences",
    label: "Preferences",
    purpose:
      "Remembers chart theme, layout, legend settings and saved People & Roles filter views.",
    storage: "localStorage: orgeasy.people.presets.v1",
    required: false,
  },
  {
    id: "analytics",
    label: "Analytics",
    purpose:
      "Anonymous usage measurement (pages opened, features used). Never includes employee records. Off unless you opt in; no analytics tag loads without consent.",
    storage: "Analytics provider cookies, only after opt-in",
    required: false,
  },
];

export function defaultConsent(): ConsentState {
  return {
    version: CONSENT_VERSION,
    decidedAt: null,
    categories: { essential: true, workspace: false, preferences: false, analytics: false },
  };
}

export function allConsent(granted: boolean): ConsentState {
  return {
    version: CONSENT_VERSION,
    decidedAt: new Date().toISOString(),
    categories: {
      essential: true,
      workspace: granted,
      preferences: granted,
      analytics: granted,
    },
  };
}

export function readConsent(): ConsentState {
  if (typeof window === "undefined") return defaultConsent();
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return defaultConsent();
    const parsed = JSON.parse(raw) as ConsentState;
    if (!parsed || parsed.version !== CONSENT_VERSION) return defaultConsent();
    return {
      version: CONSENT_VERSION,
      decidedAt: parsed.decidedAt ?? null,
      categories: { ...defaultConsent().categories, ...(parsed.categories ?? {}), essential: true },
    };
  } catch {
    return defaultConsent();
  }
}

export function writeConsent(state: ConsentState) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    /* storage unavailable — consent stays session-only */
  }
  window.dispatchEvent(new CustomEvent<ConsentState>("orgeasy:consent-change", { detail: state }));
}

export function subscribeConsent(fn: (state: ConsentState) => void) {
  if (typeof window === "undefined") return () => {};
  const handler = (event: Event) => fn((event as CustomEvent<ConsentState>).detail);
  window.addEventListener("orgeasy:consent-change", handler);
  return () => window.removeEventListener("orgeasy:consent-change", handler);
}

/** True when the given non-essential storage category may be written. */
export function hasConsent(id: ConsentCategoryId) {
  if (id === "essential") return true;
  return readConsent().categories[id] === true;
}
