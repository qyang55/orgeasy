import type { Scenario, ScenarioKind, Workspace } from "./types";

/** Infers the kind of a scenario when it predates the phase model. */
export function scenarioKind(s: Scenario): ScenarioKind {
  if (s.kind) return s.kind;
  return /current|baseline|as[- ]is/i.test(s.name) ? "current" : "future";
}

export function isCurrentState(s: Scenario) {
  return scenarioKind(s) === "current";
}

export function phaseOrder(s: Scenario) {
  return s.phaseOrder ?? 0;
}

/** Sequential future-state phases ordered by phase, then creation time.
 *  Standalone design options are excluded — they are alternatives, not steps. */
export function listPhases(scenarios: Scenario[]): Scenario[] {
  return scenarios
    .filter((s) => scenarioKind(s) === "future" && !s.standalone)
    .slice()
    .sort((a, b) => phaseOrder(a) - phaseOrder(b) || a.createdAt.localeCompare(b.createdAt));
}

/** Standalone future options that sit alongside the phase sequence. */
export function listOptions(scenarios: Scenario[]): Scenario[] {
  return scenarios
    .filter((s) => scenarioKind(s) === "future" && s.standalone)
    .slice()
    .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}

export function currentStateScenario(scenarios: Scenario[]): Scenario | null {
  return scenarios.find(isCurrentState) ?? null;
}

/**
 * The baseline current state for a given scenario: the most recent current-state
 * scenario created no later than it (so a freshly generated pack wins over an
 * older demo baseline), falling back to the newest current state overall.
 */
export function currentStateFor(scenarios: Scenario[], scenario: Scenario | null): Scenario | null {
  const currents = scenarios
    .filter((s) => isCurrentState(s) && s.id !== scenario?.id)
    .slice()
    .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  if (!currents.length) return null;
  if (!scenario) return currents[currents.length - 1]!;
  const earlier = currents.filter((s) => s.createdAt <= scenario.createdAt);
  return (earlier.length ? earlier[earlier.length - 1] : currents[currents.length - 1])!;
}

export function phaseTitle(s: Scenario) {
  if (s.phaseLabel?.trim()) return s.phaseLabel.trim();
  const order = phaseOrder(s);
  if (scenarioKind(s) === "current") return "Current state";
  return order ? `Phase ${order}` : "Future state";
}

/**
 * "Phase — name" label for selectors, de-duplicated when the scenario name
 * already carries the phase title (avoids "Phase 1 — X — Phase 1 — X").
 * Matches on the leading token ("Phase 2", "Option", "Current state") so a
 * name like "Phase 2 — Span, layers & duplicate roles" isn't repeated after
 * a slightly different phase label.
 */
export function scenarioLabel(s: Scenario) {
  const t = phaseTitle(s);
  const leadOf = (v: string) => v.split(" — ")[0]?.trim();
  if (s.name === t || s.name.startsWith(`${t} — `) || leadOf(s.name) === leadOf(t)) {
    return s.name;
  }
  return `${t} — ${s.name}`;
}

/**
 * Which scenario a phase should be compared against:
 * explicit baseline → previous phase → the current state.
 */
export function resolveBaseline(scenarios: Scenario[], scenario: Scenario | null): Scenario | null {
  if (!scenario) return null;
  // A current state IS the baseline — never diff it against another one.
  if (isCurrentState(scenario)) return null;
  if (scenario.baselineId) {
    const explicit = scenarios.find((s) => s.id === scenario.baselineId);
    if (explicit && explicit.id !== scenario.id) return explicit;
  }
  const phases = listPhases(scenarios);
  const index = phases.findIndex((s) => s.id === scenario.id);
  if (index > 0) return phases[index - 1]!;
  return currentStateFor(scenarios, scenario);
}

/** Next free phase number for a new future state. */
export function nextPhaseOrder(scenarios: Scenario[]) {
  return listPhases(scenarios).reduce((max, s) => Math.max(max, phaseOrder(s)), 0) + 1;
}

/**
 * Future phases that come strictly after the given one in the phase sequence.
 * Used to propagate a manual chart edit to every later phase.
 */
export function laterPhases(scenarios: Scenario[], scenarioId: string): Scenario[] {
  const from = scenarios.find((s) => s.id === scenarioId);
  if (!from || scenarioKind(from) !== "future") return [];
  const order = phaseOrder(from);
  return listPhases(scenarios).filter((p) => p.id !== scenarioId && phaseOrder(p) > order);
}

export function phaseChain(workspace: Workspace): Scenario[] {
  const current = currentStateScenario(workspace.scenarios);
  return current ? [current, ...listPhases(workspace.scenarios)] : listPhases(workspace.scenarios);
}

/**
 * Future phases that belong to the same programme as `current`: either explicitly
 * chained to it, or created after it. Without this a freshly generated pack or a
 * fresh import would be reported against the demo workspace's phases.
 */
export function phasesFor(scenarios: Scenario[], current: Scenario | null): Scenario[] {
  const phases = listPhases(scenarios);
  if (!current) return phases;
  const byId = new Map(scenarios.map((s) => [s.id, s]));
  const chainsToCurrent = (s: Scenario) => {
    const seen = new Set<string>();
    let node: Scenario | undefined = s;
    while (node && !seen.has(node.id)) {
      seen.add(node.id);
      if (node.baselineId === current.id) return true;
      node = node.baselineId ? byId.get(node.baselineId) : undefined;
    }
    return false;
  };
  const linked = phases.filter((s) => chainsToCurrent(s) || s.createdAt >= current.createdAt);
  return linked.length ? linked : [];
}
