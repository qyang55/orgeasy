import { useEffect, useState } from "react";

/**
 * Persisted boolean UI preference (panel collapsed/expanded states etc.).
 * Reads after mount to stay SSR/hydration safe.
 */
export function usePersistedFlag(key: string, fallback: boolean) {
  const storageKey = `orgeasy.ui.${key}`;
  const [value, setValue] = useState(fallback);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(storageKey);
      if (raw === "true" || raw === "false") setValue(raw === "true");
    } catch {
      /* storage unavailable */
    }
  }, [storageKey]);

  const update = (next: boolean | ((prev: boolean) => boolean)) => {
    setValue((prev) => {
      const resolved = typeof next === "function" ? (next as (p: boolean) => boolean)(prev) : next;
      try {
        localStorage.setItem(storageKey, String(resolved));
      } catch {
        /* storage unavailable */
      }
      return resolved;
    });
  };

  return [value, update] as const;
}
