import type { Employee, Scenario } from "./types";

export type DiffSide = "base" | "target";

export function effHeadcount(e: Employee, side: DiffSide) {
  return side === "base"
    ? (e.currentHeadcount || (e.status === "planned" ? 0 : e.plannedHeadcount))
    : (e.plannedHeadcount || (e.status === "to-be-removed" ? 0 : e.currentHeadcount));
}

export function effCost(e: Employee, side: DiffSide) {
  const rate = side === "base" ? e.currentCost || e.plannedCost : e.plannedCost || e.currentCost;
  return rate * effHeadcount(e, side);
}

export interface FieldChange {
  field: string;
  label: string;
  before: string;
  after: string;
}

export interface ChangedRole {
  before: Employee;
  after: Employee;
  changes: FieldChange[];
}

export interface GroupDelta {
  key: string;
  baseHeadcount: number;
  targetHeadcount: number;
  baseCost: number;
  targetCost: number;
}

export interface ScenarioDiff {
  base: { id: string; name: string };
  target: { id: string; name: string };
  currency: string;
  added: Employee[];
  removed: Employee[];
  changed: ChangedRole[];
  unchangedCount: number;
  headcount: { base: number; target: number; delta: number };
  cost: { base: number; target: number; delta: number };
  layers: { base: number; target: number };
  span: { base: number; target: number };
  byDepartment: GroupDelta[];
  byCountry: GroupDelta[];
}

function matchKey(e: Employee) {
  return `${(e.name || "").trim().toLowerCase()}|${(e.title || "").trim().toLowerCase()}`;
}

function depth(employees: Employee[]) {
  const byId = new Map(employees.map((e) => [e.id, e]));
  let max = 0;
  for (const e of employees) {
    let d = 1;
    let cursor = e.managerId;
    const seen = new Set<string>([e.id]);
    while (cursor && byId.has(cursor) && !seen.has(cursor)) {
      seen.add(cursor);
      d += 1;
      cursor = byId.get(cursor)?.managerId ?? null;
    }
    max = Math.max(max, d);
  }
  return max;
}

function avgSpan(employees: Employee[]) {
  const counts = new Map<string, number>();
  for (const e of employees) {
    if (e.managerId) counts.set(e.managerId, (counts.get(e.managerId) ?? 0) + 1);
  }
  if (!counts.size) return 0;
  return [...counts.values()].reduce((a, b) => a + b, 0) / counts.size;
}

function groupDeltas(
  base: Employee[],
  target: Employee[],
  pick: (e: Employee) => string,
): GroupDelta[] {
  const map = new Map<string, GroupDelta>();
  const touch = (key: string) =>
    map.get(key) ??
    map.set(key, { key, baseHeadcount: 0, targetHeadcount: 0, baseCost: 0, targetCost: 0 }).get(key)!;
  for (const e of base) {
    const g = touch(pick(e) || "Unspecified");
    g.baseHeadcount += effHeadcount(e, "base");
    g.baseCost += effCost(e, "base");
  }
  for (const e of target) {
    const g = touch(pick(e) || "Unspecified");
    g.targetHeadcount += effHeadcount(e, "target");
    g.targetCost += effCost(e, "target");
  }
  return [...map.values()].sort(
    (a, b) =>
      Math.abs(b.targetHeadcount - b.baseHeadcount) - Math.abs(a.targetHeadcount - a.baseHeadcount) ||
      b.targetCost - a.targetCost,
  );
}

const money = (n: number) => Math.round(n).toLocaleString();

export function compareScenarios(base: Scenario, target: Scenario): ScenarioDiff {
  const targetById = new Map(target.employees.map((e) => [e.id, e]));
  const targetByKey = new Map(target.employees.map((e) => [matchKey(e), e]));
  const usedTarget = new Set<string>();

  const nameOf = (list: Employee[], id: string | null) =>
    (id && list.find((e) => e.id === id)?.name) || (id ? "Unknown manager" : "—");

  const changed: ChangedRole[] = [];
  const removed: Employee[] = [];

  for (const before of base.employees) {
    const after =
      targetById.get(before.id) ??
      (matchKey(before) !== "|" ? targetByKey.get(matchKey(before)) : undefined);
    if (!after) {
      removed.push(before);
      continue;
    }
    usedTarget.add(after.id);
    const changes: FieldChange[] = [];
    const push = (field: string, label: string, b: string, a: string) => {
      if (b !== a) changes.push({ field, label, before: b, after: a });
    };
    push("title", "Title", before.title, after.title);
    push("department", "Department", before.department || "—", after.department || "—");
    push("country", "Country", before.country, after.country);
    push(
      "managerId",
      "Reports to",
      nameOf(base.employees, before.managerId),
      nameOf(target.employees, after.managerId),
    );
    push("employmentType", "Employment type", before.employmentType, after.employmentType);
    push("status", "Status", before.status, after.status);
    push(
      "headcount",
      "Headcount",
      String(effHeadcount(before, "base")),
      String(effHeadcount(after, "target")),
    );
    push("cost", "Annual cost", money(effCost(before, "base")), money(effCost(after, "target")));
    if (changes.length) changed.push({ before, after, changes });
  }

  const added = target.employees.filter((e) => !usedTarget.has(e.id));

  const sum = (list: Employee[], side: DiffSide, fn: (e: Employee, s: DiffSide) => number) =>
    list.reduce((a, e) => a + fn(e, side), 0);

  const baseHc = sum(base.employees, "base", effHeadcount);
  const targetHc = sum(target.employees, "target", effHeadcount);
  const baseCost = sum(base.employees, "base", effCost);
  const targetCost = sum(target.employees, "target", effCost);

  return {
    base: { id: base.id, name: base.name },
    target: { id: target.id, name: target.name },
    currency: target.currency || base.currency || "USD",
    added,
    removed,
    changed,
    unchangedCount: base.employees.length - removed.length - changed.length,
    headcount: { base: baseHc, target: targetHc, delta: targetHc - baseHc },
    cost: { base: baseCost, target: targetCost, delta: targetCost - baseCost },
    layers: { base: depth(base.employees), target: depth(target.employees) },
    span: { base: avgSpan(base.employees), target: avgSpan(target.employees) },
    byDepartment: groupDeltas(base.employees, target.employees, (e) => e.department),
    byCountry: groupDeltas(base.employees, target.employees, (e) => e.country),
  };
}

/* ------------------------------------------------------- visual diff mode */

export type DiffClass = "added" | "removed" | "moved" | "changed" | "unchanged";

export const DIFF_CLASS_META: Record<
  DiffClass,
  { label: string; hex: string; description: string }
> = {
  added: { label: "Added", hex: "16A34A", description: "New role in the future state." },
  removed: {
    label: "Removed",
    hex: "DC2626",
    description: "Role in the baseline that is not in the future state, or marked for removal.",
  },
  moved: {
    label: "Moved",
    hex: "EA580C",
    description: "Same role, different reporting line, department or country.",
  },
  changed: {
    label: "Changed",
    hex: "2563EB",
    description: "Same position, changed headcount, cost, status or title.",
  },
  unchanged: { label: "Unchanged", hex: "94A3B8", description: "Identical to the baseline." },
};

const MOVE_FIELDS = new Set(["managerId", "department", "country"]);

/**
 * Classifies every role in the target scenario for the canvas visual diff:
 * added, removed, moved, changed or unchanged.
 */
export function diffClassMap(diff: ScenarioDiff | null | undefined): Map<string, DiffClass> {
  const map = new Map<string, DiffClass>();
  if (!diff) return map;
  for (const e of diff.added) map.set(e.id, "added");
  for (const e of diff.removed) map.set(e.id, "removed");
  for (const c of diff.changed) {
    const moved = c.changes.some((ch) => MOVE_FIELDS.has(ch.field));
    map.set(c.after.id, moved ? "moved" : "changed");
  }
  return map;
}

export function diffToCsv(diff: ScenarioDiff) {
  const esc = (v: unknown) => {
    const s = String(v ?? "");
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const rows: string[][] = [
    ["change", "role", "title", "department", "country", "field", "from", "to"],
  ];
  for (const e of diff.added)
    rows.push([
      "Added",
      e.name || "Open Role",
      e.title,
      e.department,
      e.country,
      "—",
      "—",
      String(effHeadcount(e, "target")),
    ]);
  for (const e of diff.removed)
    rows.push([
      "Removed",
      e.name || "Open Role",
      e.title,
      e.department,
      e.country,
      "—",
      String(effHeadcount(e, "base")),
      "0",
    ]);
  for (const c of diff.changed)
    for (const ch of c.changes)
      rows.push([
        "Changed",
        c.after.name || c.before.name || "Open Role",
        c.after.title,
        c.after.department,
        c.after.country,
        ch.label,
        ch.before,
        ch.after,
      ]);
  return rows.map((r) => r.map(esc).join(",")).join("\n");
}

/* ---------------------------------------------------------------------------
 * Drill-down: which exact roles sit behind one delta row
 * ------------------------------------------------------------------------- */

export type DrilldownKind = "department" | "country" | "total";

export interface DrilldownScope {
  kind: DrilldownKind;
  /** Department/country name. Ignored for "total". */
  key: string;
}

export interface Drilldown {
  scope: DrilldownScope;
  label: string;
  currency: string;
  baseName: string;
  targetName: string;
  baseHeadcount: number;
  targetHeadcount: number;
  baseCost: number;
  targetCost: number;
  added: Employee[];
  removed: Employee[];
  changed: ChangedRole[];
}

export const scopeId = (s: DrilldownScope) => `${s.kind}:${s.key}`;

const scopeMatch = (e: Employee | undefined, scope: DrilldownScope) => {
  if (!e) return false;
  if (scope.kind === "total") return true;
  const value = (scope.kind === "department" ? e.department : e.country) || "Unspecified";
  return value === scope.key;
};

export function buildDrilldown(diff: ScenarioDiff, scope: DrilldownScope): Drilldown {
  const group =
    scope.kind === "total"
      ? null
      : (scope.kind === "department" ? diff.byDepartment : diff.byCountry).find(
          (g) => g.key === scope.key,
        ) ?? null;

  return {
    scope,
    label:
      scope.kind === "total"
        ? "All departments and countries"
        : `${scope.key} (${scope.kind === "department" ? "department" : "country"})`,
    currency: diff.currency,
    baseName: diff.base.name,
    targetName: diff.target.name,
    baseHeadcount: group ? group.baseHeadcount : diff.headcount.base,
    targetHeadcount: group ? group.targetHeadcount : diff.headcount.target,
    baseCost: group ? group.baseCost : diff.cost.base,
    targetCost: group ? group.targetCost : diff.cost.target,
    added: diff.added.filter((e) => scopeMatch(e, scope)),
    removed: diff.removed.filter((e) => scopeMatch(e, scope)),
    changed: diff.changed.filter((c) => scopeMatch(c.after, scope) || scopeMatch(c.before, scope)),
  };
}

/** Flat, presentation-ready note lines used in PowerPoint speaker notes and the PDF. */
export function drilldownToNotes(d: Drilldown, limitPerGroup = 12): string[] {
  const hcDelta = d.targetHeadcount - d.baseHeadcount;
  const costDelta = d.targetCost - d.baseCost;
  const lines = [
    `${d.label} — ${d.baseName} → ${d.targetName}`,
    `Positions ${d.baseHeadcount} → ${d.targetHeadcount} (${hcDelta >= 0 ? "+" : ""}${hcDelta}) · annual cost ${money(d.baseCost)} → ${money(d.targetCost)} (${costDelta <= 0 ? "−" : "+"}${money(Math.abs(costDelta))} ${d.currency})`,
    `Roles added ${d.added.length} · removed ${d.removed.length} · changed ${d.changed.length}`,
  ];
  const label = (e: Employee) =>
    `${e.name || "Open role"} — ${e.title}${e.department ? ` · ${e.department}` : ""} · ${e.country}`;
  if (d.added.length) {
    lines.push("Added:");
    for (const e of d.added.slice(0, limitPerGroup))
      lines.push(`  + ${label(e)} · ${effHeadcount(e, "target")} FTE · ${money(effCost(e, "target"))}`);
    if (d.added.length > limitPerGroup) lines.push(`  + …${d.added.length - limitPerGroup} more`);
  }
  if (d.removed.length) {
    lines.push("Removed:");
    for (const e of d.removed.slice(0, limitPerGroup))
      lines.push(`  − ${label(e)} · ${effHeadcount(e, "base")} FTE · ${money(effCost(e, "base"))}`);
    if (d.removed.length > limitPerGroup) lines.push(`  − …${d.removed.length - limitPerGroup} more`);
  }
  if (d.changed.length) {
    lines.push("Changed:");
    for (const c of d.changed.slice(0, limitPerGroup))
      lines.push(
        `  ~ ${label(c.after)} · ${c.changes.map((ch) => `${ch.label}: ${ch.before} → ${ch.after}`).join("; ")}`,
      );
    if (d.changed.length > limitPerGroup)
      lines.push(`  ~ …${d.changed.length - limitPerGroup} more`);
  }
  if (!d.added.length && !d.removed.length && !d.changed.length)
    lines.push("No role-level changes in this slice.");
  return lines;
}

/* Pinned drill-downs shared between the comparison page and the export centre. */
const PIN_KEY = "orgeasy.drilldown.pins.v1";

export function loadPinnedScopes(): DrilldownScope[] {
  if (typeof localStorage === "undefined") return [];
  try {
    const raw = JSON.parse(localStorage.getItem(PIN_KEY) ?? "[]");
    if (!Array.isArray(raw)) return [];
    return raw.filter(
      (s): s is DrilldownScope =>
        !!s && typeof s.key === "string" && ["department", "country", "total"].includes(s.kind),
    );
  } catch {
    return [];
  }
}

export function savePinnedScopes(scopes: DrilldownScope[]) {
  if (typeof localStorage === "undefined") return;
  localStorage.setItem(PIN_KEY, JSON.stringify(scopes));
}
