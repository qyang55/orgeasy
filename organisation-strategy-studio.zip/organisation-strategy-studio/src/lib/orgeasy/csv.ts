import type { Employee, EmployeeStatus, EmploymentType } from "./types";
import { uid } from "./store";

const HEADERS = [
  "id",
  "name",
  "isOpenRole",
  "title",
  "department",
  "country",
  "responsibilities",
  "currentHeadcount",
  "plannedHeadcount",
  "employmentType",
  "managerId",
  "status",
  "currentCost",
  "plannedCost",
  "serviceMonths",
  "photoUrl",
] as const;

function escape(value: unknown) {
  const s = String(value ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function employeesToCsv(employees: Employee[]) {
  const rows = employees.map((e) => HEADERS.map((h) => escape(e[h])).join(","));
  return [HEADERS.join(","), ...rows].join("\n");
}

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let quoted = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') {
        field += '"';
        i++;
      } else if (ch === '"') {
        quoted = false;
      } else field += ch;
      continue;
    }
    if (ch === '"') quoted = true;
    else if (ch === ",") {
      row.push(field);
      field = "";
    } else if (ch === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else if (ch !== "\r") field += ch;
  }
  if (field.length || row.length) {
    row.push(field);
    rows.push(row);
  }
  return rows.filter((r) => r.some((c) => c.trim() !== ""));
}

export function csvToEmployees(text: string): { employees: Employee[]; errors: string[] } {
  const rows = parseCsv(text);
  const errors: string[] = [];
  if (!rows.length) return { employees: [], errors: ["File is empty."] };
  const header = (rows[0] ?? []).map((h) => h.trim());
  const index = (name: string) => header.findIndex((h) => h.toLowerCase() === name.toLowerCase());
  if (index("title") === -1) errors.push("Missing required column: title");

  const num = (v: string, fallback = 0) => {
    const n = Number(String(v ?? "").replace(/[^0-9.-]/g, ""));
    return Number.isFinite(n) ? n : fallback;
  };
  const get = (row: string[], name: string) => (index(name) >= 0 ? (row[index(name)] ?? "") : "");

  const employees = rows.slice(1).map((row) => {
    const name = get(row, "name").trim();
    const status = (get(row, "status").trim() || "current") as EmployeeStatus;
    return {
      id: get(row, "id").trim() || uid(),
      name,
      isOpenRole: /true|yes|1/i.test(get(row, "isOpenRole")) || name === "",
      title: get(row, "title").trim() || "Untitled role",
      department: get(row, "department").trim(),
      country: get(row, "country").trim() || "United States",
      responsibilities: get(row, "responsibilities").trim(),
      currentHeadcount: num(get(row, "currentHeadcount"), 1),
      plannedHeadcount: num(get(row, "plannedHeadcount"), 1),
      employmentType: (get(row, "employmentType").trim() || "Full-time") as EmploymentType,
      managerId: get(row, "managerId").trim() || null,
      status: ["current", "planned", "to-be-removed", "moved"].includes(status) ? status : "current",
      currentCost: num(get(row, "currentCost")),
      plannedCost: num(get(row, "plannedCost")),
      serviceMonths: num(get(row, "serviceMonths")),
      photoUrl: get(row, "photoUrl").trim() || undefined,
    } satisfies Employee;
  });

  return { employees, errors };
}

export function downloadBlob(data: BlobPart, filename: string, type: string) {
  const url = URL.createObjectURL(new Blob([data], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}