export type EmployeeStatus = "current" | "planned" | "to-be-removed" | "moved";

export type EmploymentType =
  | "Full-time"
  | "Part-time"
  | "Contract"
  | "Fixed-term"
  | "Intern"
  | "Open Role";

/** Where the role sits on the global / regional / local market axis. */
export type RoleScope = "unset" | "global" | "regional" | "local";

/** Structural unit the role belongs to: normal line role, CoE, or GBS centre. */
export type OrgUnitKind = "line" | "coe" | "gbs";

/** Which transformation lever drives a planned reduction on this role. */
export type ReductionLever = "headcount" | "span" | "duplicate" | "automation" | "agent";

/** Whether the work is delivered by a person, an AI agent, or both together. */
export type RoleType = "human" | "agent" | "hybrid";

export const ROLE_TYPE_META: Record<
  RoleType,
  { label: string; short: string; hex: string; description: string }
> = {
  human: {
    label: "Human",
    short: "Human",
    hex: "475569",
    description: "Delivered by a person. Judgement, leadership and relationship work.",
  },
  agent: {
    label: "AI Agent",
    short: "Agent",
    hex: "0891B2",
    description: "Delivered end to end by an AI agent or automation, with human oversight.",
  },
  hybrid: {
    label: "Human + AI Hybrid",
    short: "Hybrid",
    hex: "7C3AED",
    description: "A person supervises and decides; an agent does the preparation and drafting.",
  },
};

export const ROLE_TYPES: RoleType[] = ["human", "agent", "hybrid"];

export const LEVER_META: Record<
  ReductionLever,
  { label: string; short: string; hex: string; description: string }
> = {
  headcount: {
    label: "Headcount reduction",
    short: "HC",
    hex: "DC2626",
    description: "Vacancy freeze, contractor exit and direct position removal.",
  },
  span: {
    label: "Span of control",
    short: "Span",
    hex: "D97706",
    description: "Delayering supervisory roles to widen spans towards 5–9 reports.",
  },
  duplicate: {
    label: "Duplicate roles",
    short: "Duplicates",
    hex: "7C3AED",
    description: "Consolidating overlapping roles across functions and regions.",
  },
  automation: {
    label: "AI & work redesign",
    short: "Redesign",
    hex: "0891B2",
    description:
      "Transactional work is redesigned out of roles — automation and AI absorb the repeatable steps so people move to judgement, exception and customer work.",
  },
  agent: {
    label: "Agent-enabled delivery",
    short: "Agent-enabled",
    hex: "2563EB",
    description:
      "Work is re-split between people and AI agents: roles become agent-run or human + agent hybrid, shifting capability rather than simply removing it.",
  },
};

export const REDUCTION_LEVERS: ReductionLever[] = [
  "headcount",
  "span",
  "duplicate",
  "automation",
  "agent",
];

export interface Employee {
  id: string;
  name: string;
  isOpenRole: boolean;
  title: string;
  department: string;
  country: string;
  responsibilities: string;
  currentHeadcount: number;
  plannedHeadcount: number;
  employmentType: EmploymentType;
  managerId: string | null;
  status: EmployeeStatus;
  currentCost: number;
  plannedCost: number;
  serviceMonths: number;
  /** Optional headshot: data URL or absolute image URL. */
  photoUrl?: string | undefined;
  /** Work email, used to match rows on re-import. */
  email?: string | undefined;
  /** Cost centre / budget code from the source system. */
  costCenter?: string | undefined;
  /** Additional dotted-line (matrix) reporting relationships. */
  dottedManagerIds?: string[] | undefined;
  /** Global / regional / local market scope of the role. */
  roleScope?: RoleScope | undefined;
  /** Line role, Centre of Excellence, or Global Business Services centre. */
  unitKind?: OrgUnitKind | undefined;
  /** Transformation lever responsible for this role's planned reduction. */
  reductionLever?: ReductionLever | undefined;
  /** Whether the role is delivered by a human, an AI agent, or a hybrid of both. */
  roleType?: RoleType | undefined;
  /** Running cost of the agent behind this role, per month, in scenario currency. */
  agentMonthlyCost?: number | undefined;
  /** Benefits loading for this role, % of base salary (overrides the workspace default). */
  benefitsPct?: number | undefined;
  /** Bonus / incentive pay at target, % of base salary (overrides the workspace default). */
  variablePayPct?: number | undefined;
}

export const SCOPE_META: Record<RoleScope, { label: string; short: string; hex: string }> = {
  unset: { label: "Not set", short: "—", hex: "94A3B8" },
  global: { label: "Global role", short: "Global", hex: "1D4ED8" },
  regional: { label: "Regional role", short: "Regional", hex: "0891B2" },
  local: { label: "Local market role", short: "Local mkt", hex: "7C3AED" },
};

export const UNIT_META: Record<OrgUnitKind, { label: string; short: string; hex: string }> = {
  line: { label: "Line / business role", short: "Line", hex: "475569" },
  coe: { label: "Centre of Excellence (CoE)", short: "CoE", hex: "059669" },
  gbs: { label: "Global Business Services (GBS)", short: "GBS", hex: "D97706" },
};

export const ROLE_SCOPES: RoleScope[] = ["unset", "global", "regional", "local"];
export const ORG_UNIT_KINDS: OrgUnitKind[] = ["line", "coe", "gbs"];

export type AdkarKey = "awareness" | "desire" | "knowledge" | "ability" | "reinforcement";

export interface AdkarGroup {
  id: string;
  name: string;
  scores: Record<AdkarKey, number>;
  notes: string;
}

export type ScenarioKind = "current" | "future";

/**
 * Scenario-level override of a Country Cost Rule. Any omitted field falls back
 * to the shared illustrative default for that market.
 */
export interface CountryCostOverride {
  region?: string;
  noticeWeeks?: number;
  severanceWeeksPerYear?: number;
  minSeveranceWeeks?: number;
  capSeveranceWeeks?: number;
  risk?: "Low" | "Medium" | "High";
  riskNote?: string;
  legalFeePerExit?: number;
  outplacementPerExit?: number;
  adminPerExit?: number;
  claimRatePct?: number;
  avgClaimMonths?: number;
  defenceCostPerClaim?: number;
  collectiveThreshold?: number;
  collectiveProcessCost?: number;
  legalNote?: string;
  formulaNote?: string;
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  currency: string;
  createdAt: string;
  /** Last time this scenario's content changed. */
  updatedAt?: string;
  employees: Employee[];
  adkarGroups: AdkarGroup[];
  positions: Record<string, { x: number; y: number }>;
  /** "current" = baseline org, "future" = a proposed target state / phase. */
  kind?: ScenarioKind;
  /** 1-based phase order for future states (Phase 1, Phase 2, ...). */
  phaseOrder?: number;
  /** Optional free-text phase label, e.g. "Phase 1 — Q3 2026". */
  phaseLabel?: string;
  /** Scenario this phase is measured against. Defaults to the previous phase. */
  baselineId?: string | null;
  /**
   * A standalone design option that sits outside the sequential phase chain:
   * still comparable and selectable, but never rolled into the programme total.
   */
  standalone?: boolean;
  /** User-resized card sizes on the org chart, keyed by employee id. */
  nodeSizes?: Record<string, { w: number; h: number }>;
  /** Per-scenario overrides of the Country Cost Rules, keyed by country name. */
  countryCostOverrides?: Record<string, CountryCostOverride>;
}

export interface Workspace {
  account: { email: string; signedInAt: string } | null;
  scenarios: Scenario[];
  activeScenarioId: string | null;
  /** Saved Automotive Operating Model autogenerator outputs. */
  operatingModels?: import("./operating-model").OperatingModel[];
  /**
   * Current user's workspace role (Admin / Editor / Viewer). Defaults to
   * "admin" for a freshly claimed local workspace; IdP-mapped roles arrive
   * with cloud sync.
   */
  role?: import("./roles").WorkspaceRole;
  /** Executive-readable activity trail, newest first (capped). */
  activity?: import("./roles").ActivityEvent[];
}

export const STATUS_META: Record<
  EmployeeStatus,
  { label: string; className: string; hex: string }
> = {
  current: { label: "Current", className: "bg-secondary text-secondary-foreground", hex: "475569" },
  planned: { label: "Planned", className: "bg-info/15 text-info", hex: "2563EB" },
  "to-be-removed": {
    label: "To Be Removed",
    className: "bg-destructive/15 text-destructive",
    hex: "DC2626",
  },
  moved: { label: "Moved", className: "bg-warning/20 text-warning-foreground", hex: "D97706" },
};

export const EMPLOYMENT_TYPES: EmploymentType[] = [
  "Full-time",
  "Part-time",
  "Contract",
  "Fixed-term",
  "Intern",
  "Open Role",
];

export const DISCLAIMER =
  "This tool provides general awareness and illustrative examples only. It is NOT legal, financial, or employment advice. Users must consult qualified local legal counsel before making any separation or restructuring decisions.";