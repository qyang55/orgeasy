import type { ChangePlan } from "./change-plan";
import type { ImpactSummary } from "./impact";
import { formatMoney } from "./impact";
import type { ProgrammeSummary } from "./levers";
import type { Scenario } from "./types";

export interface TradeOff {
  id: "structure" | "cost" | "capability" | "risk";
  label: string;
  headline: string;
  gain: string;
  give: string;
}

export interface DecisionRisk {
  id: string;
  title: string;
  detail: string;
  severity: "high" | "medium" | "low";
}

export interface DecisionSummary {
  scenarioName: string;
  baselineName: string | null;
  currency: string;
  /** Plain-language "what is changing". */
  whatIsChanging: string[];
  /** Plain-language "why". */
  drivers: string[];
  numbers: {
    baselinePositions: number;
    futurePositions: number;
    positionsRemoved: number;
    rolesAdded: number;
    reductionPct: number;
    annualSaving: number;
    oneOffCost: number;
    oneOffLow: number;
    oneOffHigh: number;
    paybackMonths: number | null;
    countries: number;
    exits: number;
  };
  tradeOffs: TradeOff[];
  risks: DecisionRisk[];
  /** One-off separation cost split by delivery phase. */
  oneOffByPhase: {
    id: string;
    title: string;
    exits: number;
    low: number;
    mid: number;
    high: number;
    share: number;
    countries: string[];
  }[];
  nextStep: { title: string; detail: string };
}

function pct(v: number) {
  return `${(v * 100).toFixed(1)}%`;
}

export function buildDecisionSummary(
  scenario: Scenario | null | undefined,
  programme: ProgrammeSummary,
  impact: ImpactSummary,
  plan: ChangePlan,
): DecisionSummary {
  const cur = programme.currency;
  const removed = programme.grossRemovals;
  const added = programme.rolesAdded;
  const net = programme.achievedReduction;
  const reductionPct = programme.achievedPct;
  const oneOff = programme.separationMid;
  const saving = programme.costSaving;
  const paybackMonths = saving > 0 ? (oneOff / saving) * 12 : null;
  const countries = programme.separationByCountry.filter((c) => c.exits > 0).length;
  const topLevers = [...programme.levers].filter((l) => l.positions > 0).sort((a, b) => b.positions - a.positions);
  const topGroups = plan.groups.slice(0, 3);
  const highRisk = programme.highRiskMarkets;
  const collective = programme.separationByCountry.filter((c) => c.collectiveTriggered);

  const whatIsChanging: string[] = [];
  whatIsChanging.push(
    `${programme.baselineHeadcount.toLocaleString()} current-state positions move to ${programme.finalHeadcount.toLocaleString()} in this option — a net change of ${net >= 0 ? "−" : "+"}${Math.abs(net).toLocaleString()} positions (${pct(Math.abs(reductionPct))}).`,
  );
  if (removed) {
    whatIsChanging.push(
      `${removed.toLocaleString()} roles come out, mainly through ${topLevers
        .slice(0, 2)
        .map((l) => `${l.label} (${l.positions} positions)`)
        .join(" and ")}.`,
    );
  }
  if (added) {
    whatIsChanging.push(
      `${added.toLocaleString()} new capability roles are created, so this is a reshape rather than a straight cut.`,
    );
  }
  if (programme.phases.length > 1) {
    whatIsChanging.push(
      `Delivery is sequenced over ${programme.phases.length} phases, starting with ${programme.phases[0]?.title}.`,
    );
  }
  if (topGroups.length) {
    whatIsChanging.push(
      `Most affected areas: ${topGroups.map((g) => `${g.name} (${g.changed} positions touched)`).join(", ")}.`,
    );
  }

  const drivers: string[] = [];
  for (const l of topLevers.slice(0, 3)) {
    drivers.push(`${l.label}: ${l.description} — ${l.positions} positions, ${formatMoney(l.cost, cur)} of annual cost.`);
  }
  if (impact.agentPositions || impact.hybridPositions) {
    drivers.push(
      `Human + AI agent operating model: ${impact.agentPositions} agent-run and ${impact.hybridPositions} hybrid positions in the future state.`,
    );
  }
  if (saving > 0) {
    drivers.push(
      `Cost discipline: ${formatMoney(saving, cur)} of annual people cost released (${formatMoney(programme.baselineCost, cur)} → ${formatMoney(programme.finalCost, cur)}).`,
    );
  }
  if (!drivers.length) drivers.push("No levers are applied yet — this option is structurally identical to the current state.");

  const tradeOffs: TradeOff[] = [
    {
      id: "structure",
      label: "Structure",
      headline: plan.spanChanges
        ? `${plan.spanChanges} managers see a change in span of control.`
        : "Reporting lines stay broadly stable; the change is in role content, not supervision.",
      gain: "Flatter reporting lines and clearer accountability where layers are removed.",
      give: "Wider spans increase manager load; some teams will need interim support.",
    },
    {
      id: "cost",
      label: "Cost",
      headline: `${formatMoney(saving, cur)} annual saving for ${formatMoney(oneOff, cur)} one-off cost.`,
      gain:
        paybackMonths !== null
          ? `Payback in roughly ${Math.round(paybackMonths)} months on the mid-case transition cost.`
          : "Cost profile is broadly neutral in this option.",
      give: `Transition cost is uncertain: ${formatMoney(programme.separationLow, cur)} – ${formatMoney(programme.separationHigh, cur)} depending on consultation outcomes.`,
    },
    {
      id: "capability",
      label: "Capability",
      headline: `${added} new roles created, ${removed} removed.`,
      gain: added
        ? "Capability is rebuilt in priority areas (digital, AI enablement, customer-facing)."
        : "Existing capability is preserved; no new roles are added.",
      give: added
        ? "New roles take time to hire; expect a capability dip while the pipeline fills."
        : "Without new roles, capability gaps created by exits stay unresolved.",
    },
    {
      id: "risk",
      label: "Risk",
      headline: `${countries} markets affected, ${highRisk.length} high consultation risk.`,
      gain: "Country-specific rules are priced in, so the plan is defensible to works councils and boards.",
      give: "Multi-country consultation extends timelines and can force sequencing changes mid-programme.",
    },
  ];

  const risks: DecisionRisk[] = [];
  for (const c of highRisk.slice(0, 4)) {
    risks.push({
      id: `risk-${c.country}`,
      title: `${c.country} — ${c.exits} exits, high consultation risk`,
      detail: `${c.rule.riskNote} Mid-case cost ${formatMoney(c.mid, cur)}, including ${formatMoney(c.legalFees, cur)} legal fees and ${formatMoney(c.tribunalRisk, cur)} expected claim exposure.`,
      severity: "high",
    });
  }
  for (const c of collective.slice(0, 3)) {
    if (risks.some((r) => r.id === `risk-${c.country}`)) continue;
    risks.push({
      id: `collective-${c.country}`,
      title: `${c.country} — collective consultation triggered`,
      detail: `${c.exits} exits exceed the ${c.rule.collectiveThreshold}-exit threshold, adding a formal process costed at ${formatMoney(c.collectiveCost, cur)}.`,
      severity: "high",
    });
  }
  if (added) {
    risks.push({
      id: "hiring",
      title: `Hiring lag on ${added} new roles`,
      detail: "Time-to-fill in tighter markets can run past the phase gate, leaving work uncovered. Check the hiring pipeline before committing dates.",
      severity: "medium",
    });
  }
  if (plan.groups.some((g) => g.severity === "critical")) {
    risks.push({
      id: "readiness",
      title: "Concentrated change fatigue",
      detail: `${plan.groups.filter((g) => g.severity === "critical").length} groups carry critical change load. Leaders in those areas need dedicated support and messaging.`,
      severity: "medium",
    });
  }
  if (programme.achievedReduction < programme.targetReduction) {
    risks.push({
      id: "gap",
      title: "Option does not yet reach the target",
      detail: `${programme.targetReduction - programme.achievedReduction} positions short of the ${pct(programme.targetPct)} target. Further levers or a revised target will be needed.`,
      severity: "medium",
    });
  }
  if (!risks.length) {
    risks.push({
      id: "none",
      title: "No high-risk markets flagged",
      detail: "Current exits sit below collective consultation thresholds in every market. Re-check after any change to the phase mix.",
      severity: "low",
    });
  }

  const nextStep = highRisk.length
    ? {
        title: "Approve the shape, then start country consultation planning",
        detail: `Confirm the option direction in principle, and commission local counsel in ${highRisk
          .slice(0, 3)
          .map((c) => c.country)
          .join(", ")} to validate timelines and cost before dates are announced.`,
      }
    : programme.achievedReduction < programme.targetReduction
      ? {
          title: "Agree whether to close the gap or revise the target",
          detail: `Decide between adding levers for the remaining ${programme.targetReduction - programme.achievedReduction} positions or endorsing a lower target, then lock the phase plan.`,
        }
      : {
          title: "Endorse the option and lock phase 1 scope",
          detail: "Approve the future-state shape, sign off the phase 1 scope and start the change and communication plan.",
        };

  const phaseMidTotal = programme.phases.reduce((a, p) => a + p.separationMid, 0);
  const oneOffByPhase = programme.phases.map((p) => ({
    id: p.id,
    title: p.title,
    exits: p.separationExits,
    low: p.separationLow,
    mid: p.separationMid,
    high: p.separationHigh,
    share: phaseMidTotal > 0 ? p.separationMid / phaseMidTotal : 0,
    countries: p.separationTopCountries,
  }));

  return {
    scenarioName: scenario?.name ?? "No scenario selected",
    baselineName: plan.baselineName,
    currency: cur,
    whatIsChanging,
    drivers,
    numbers: {
      baselinePositions: programme.baselineHeadcount,
      futurePositions: programme.finalHeadcount,
      positionsRemoved: removed,
      rolesAdded: added,
      reductionPct,
      annualSaving: saving,
      oneOffCost: oneOff,
      oneOffLow: programme.separationLow,
      oneOffHigh: programme.separationHigh,
      paybackMonths,
      countries,
      exits: programme.separationExits,
    },
    tradeOffs,
    risks,
    oneOffByPhase,
    nextStep,
  };
}

/** Plain-text version for pasting into an email or meeting note. */
export function decisionSummaryText(s: DecisionSummary): string {
  const n = s.numbers;
  const cur = s.currency;
  const lines: string[] = [];
  lines.push(`DECISION SUMMARY — ${s.scenarioName}`);
  if (s.baselineName) lines.push(`Compared with: ${s.baselineName}`);
  lines.push("");
  lines.push("WHAT IS CHANGING");
  s.whatIsChanging.forEach((t) => lines.push(`- ${t}`));
  lines.push("");
  lines.push("WHY");
  s.drivers.forEach((t) => lines.push(`- ${t}`));
  lines.push("");
  lines.push("KEY NUMBERS");
  lines.push(`- Positions: ${n.baselinePositions.toLocaleString()} → ${n.futurePositions.toLocaleString()}`);
  lines.push(`- Change: ${pct(Math.abs(n.reductionPct))} (${n.positionsRemoved} removed, ${n.rolesAdded} added)`);
  lines.push(`- Annual saving: ${formatMoney(n.annualSaving, cur)}`);
  lines.push(
    `- One-off cost: ${formatMoney(n.oneOffCost, cur)} (range ${formatMoney(n.oneOffLow, cur)} – ${formatMoney(n.oneOffHigh, cur)})`,
  );
  if (n.paybackMonths !== null) lines.push(`- Payback: ~${Math.round(n.paybackMonths)} months`);
  if (s.oneOffByPhase.length) {
    lines.push("");
    lines.push("ONE-OFF COST BY PHASE");
    s.oneOffByPhase.forEach((p) =>
      lines.push(
        `- ${p.title}: ${formatMoney(p.mid, cur)} (${p.exits} exits, ${Math.round(p.share * 100)}% of one-off cost${p.countries.length ? `, mainly ${p.countries.join(", ")}` : ""})`,
      ),
    );
  }
  lines.push("");
  lines.push("TRADE-OFFS");
  s.tradeOffs.forEach((t) => lines.push(`- ${t.label}: ${t.headline} Gain: ${t.gain} Give: ${t.give}`));
  lines.push("");
  lines.push("TOP RISKS");
  s.risks.forEach((r) => lines.push(`- [${r.severity.toUpperCase()}] ${r.title} — ${r.detail}`));
  lines.push("");
  lines.push("RECOMMENDED NEXT STEP");
  lines.push(`- ${s.nextStep.title}: ${s.nextStep.detail}`);
  lines.push("");
  lines.push("Illustrative modelling only — validate with local legal and finance advice before decisions.");
  return lines.join("\n");
}
