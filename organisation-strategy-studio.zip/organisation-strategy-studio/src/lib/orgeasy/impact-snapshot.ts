import type { Employee } from "./types";
import { formatMoney } from "./impact";

/**
 * One-line, executive-friendly impact snapshot for toasts and inline hints,
 * e.g. "412 → 385 positions (−27) · saves $2.4m a year · layers 7 → 6".
 * Deliberately reads only employee lists so it can run before a freshly
 * created scenario has landed in workspace state.
 */

const total = (
  list: Employee[],
  pick: (e: Employee) => number,
) => list.reduce((s, e) => s + Math.max(pick(e) || 0, 0), 0);

const plannedPositions = (list: Employee[]) =>
  total(list, (e) => e.plannedHeadcount || e.currentHeadcount);
const currentPositions = (list: Employee[]) =>
  total(list, (e) => e.currentHeadcount || e.plannedHeadcount);
const plannedCost = (list: Employee[]) => total(list, (e) => e.plannedCost || e.currentCost);
const currentCost = (list: Employee[]) => total(list, (e) => e.currentCost || e.plannedCost);

function layersOf(list: Employee[]) {
  const managerOf = new Map(list.map((e) => [e.id, e.managerId]));
  let max = 0;
  for (const e of list) {
    let depth = 1;
    let cursor = e.managerId;
    const seen = new Set<string>([e.id]);
    while (cursor && managerOf.has(cursor) && !seen.has(cursor)) {
      seen.add(cursor);
      depth += 1;
      cursor = managerOf.get(cursor) ?? null;
    }
    if (depth > max) max = depth;
  }
  return max;
}

/** Totals-only line when there is no baseline to compare against. */
export function sizeSnapshot(target: Employee[], currency: string): string {
  const pos = plannedPositions(target);
  const lay = layersOf(target);
  return `${pos.toLocaleString()} positions · ${formatMoney(plannedCost(target), currency)} annual people cost · ${lay} layer${lay === 1 ? "" : "s"}`;
}

/** Baseline vs target line; falls back to totals when no baseline exists. */
export function impactSnapshot(
  baseline: Employee[] | null | undefined,
  target: Employee[],
  currency: string,
): string {
  if (!baseline?.length) return sizeSnapshot(target, currency);
  const bPos = currentPositions(baseline);
  const tPos = plannedPositions(target);
  const dPos = tPos - bPos;
  const dCost = plannedCost(target) - currentCost(baseline);
  const bLay = layersOf(baseline);
  const tLay = layersOf(target);
  return [
    `${bPos.toLocaleString()} → ${tPos.toLocaleString()} positions (${
      dPos > 0 ? "+" : dPos < 0 ? "−" : "±"
    }${Math.abs(dPos).toLocaleString()})`,
    dCost === 0
      ? "annual cost flat"
      : `${dCost < 0 ? "saves" : "adds"} ${formatMoney(Math.abs(dCost), currency)} a year`,
    bLay === tLay ? `${tLay} layers (unchanged)` : `layers ${bLay} → ${tLay}`,
  ].join(" · ");
}
