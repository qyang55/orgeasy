import { useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Sparkles, Upload, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useOrgEasy } from "@/lib/orgeasy/store";
import {
  consumeNudgeArmed,
  dismissNudge,
  isDemoOnlyWorkspace,
  isNudgeDismissed,
  readGuidedDemo,
  readNudgeSession,
  subscribeGuidedDemo,
  writeNudgeSession,
} from "@/lib/orgeasy/guided-demo";

const HIDDEN_PATHS = new Set(["/welcome", "/auth", "/privacy", "/data-input", "/integrations"]);
/** Show after this much exploration: ≥2 pages and ≥75 seconds in-session. */
const MIN_ROUTES = 2;
const MIN_ELAPSED_MS = 75_000;

/**
 * Conversion prompt shown after a visitor has explored the demo for a short
 * time: "Ready for your real data?" with import + pilot request actions.
 * Dismiss permanently with the X, or snooze for the session with "Not now".
 */
export function DemoNudge() {
  const { workspace } = useOrgEasy();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(() => isNudgeDismissed());

  // Record the route visit and evaluate eligibility.
  useEffect(() => {
    if (HIDDEN_PATHS.has(pathname)) return;
    const session = readNudgeSession();
    if (!session.routes.includes(pathname)) {
      session.routes.push(pathname);
      writeNudgeSession(session);
    }
  }, [pathname]);

  useEffect(() => {
    const evaluate = () => {
      if (isNudgeDismissed()) return setVisible(false);
      if (readGuidedDemo()) return setVisible(false); // guided bar owns the screen
      const session = readNudgeSession();
      if (session.later) return setVisible(false);
      if (HIDDEN_PATHS.has(pathname)) return setVisible(false);
      if (!isDemoOnlyWorkspace(workspace.scenarios)) return setVisible(false);
      const armed = consumeNudgeArmed();
      const eligible =
        armed ||
        (session.routes.length >= MIN_ROUTES && Date.now() - session.start >= MIN_ELAPSED_MS);
      setVisible(eligible);
    };
    evaluate();
    const interval = window.setInterval(evaluate, 5_000);
    const unsubscribe = subscribeGuidedDemo(evaluate);
    return () => {
      window.clearInterval(interval);
      unsubscribe();
    };
  }, [pathname, workspace.scenarios]);

  if (!visible || dismissed) return null;

  const notNow = () => {
    const session = readNudgeSession();
    session.later = true;
    writeNudgeSession(session);
    setVisible(false);
  };

  const never = () => {
    dismissNudge();
    setDismissed(true);
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 w-[340px] rounded-2xl border border-brand/40 bg-card/95 p-5 shadow-overlay backdrop-blur">
      <button
        type="button"
        onClick={never}
        aria-label="Don't show this again"
        className="absolute right-3 top-3 rounded-md p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
      >
        <X className="size-4" />
      </button>
      <p className="inline-flex items-center gap-1.5 text-[10.5px] font-bold uppercase tracking-[0.16em] text-brand">
        <Sparkles className="size-3.5" />
        Next step
      </p>
      <h3 className="mt-2 font-display text-[17px] font-semibold tracking-tight text-foreground">
        Ready for your real data?
      </h3>
      <p className="mt-1.5 text-[12.5px] leading-relaxed text-muted-foreground">
        Import a Workday, SAP or Oracle extract — or generate another industry pack. Everything you
        explored in the demo stays saved in this browser.
      </p>
      <div className="mt-4 flex flex-col gap-2">
        <Button size="sm" asChild>
          <Link to="/data-input">
            <Upload className="size-4" />
            Start with your data
          </Link>
        </Button>
        <Button size="sm" variant="outline" asChild>
          <a href="mailto:pilot@orgeasy.app?subject=Organisation%20Strategy%20Studio%20pilot%20request&body=Hi%20—%20we%27d%20like%20to%20pilot%20Organisation%20Strategy%20Studio%20with%20our%20own%20data.">
            Request a pilot
          </a>
        </Button>
        <button
          type="button"
          onClick={notNow}
          className="mt-1 text-[11.5px] text-muted-foreground transition-colors hover:text-foreground"
        >
          Not now — keep exploring
        </button>
      </div>
    </div>
  );
}
