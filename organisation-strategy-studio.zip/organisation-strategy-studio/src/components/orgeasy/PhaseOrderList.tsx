import { useState } from "react";
import { ArrowDown, ArrowUp, GripVertical } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { listPhases, phaseTitle, resolveBaseline } from "@/lib/orgeasy/phases";
import { cn } from "@/lib/utils";

/**
 * Drag-and-drop ordering for future-state phases. Reordering renumbers
 * phaseOrder in the workspace, which every downstream view (comparison,
 * roadmap, PPT/PDF exports) reads, so exports stay in sync automatically.
 */
export function PhaseOrderList({ compact = false }: { compact?: boolean }) {
  const { workspace, reorderPhases, setActiveScenario } = useOrgEasy();
  const phases = listPhases(workspace.scenarios);
  const [dragId, setDragId] = useState<string | null>(null);
  const [overId, setOverId] = useState<string | null>(null);

  const move = (id: string, targetId: string) => {
    if (id === targetId) return;
    const ids = phases.map((p) => p.id);
    const from = ids.indexOf(id);
    const to = ids.indexOf(targetId);
    if (from < 0 || to < 0) return;
    ids.splice(to, 0, ids.splice(from, 1)[0]!);
    reorderPhases(ids);
    toast.success("Phase order updated — exports now follow the new sequence");
  };

  const shift = (id: string, delta: number) => {
    const ids = phases.map((p) => p.id);
    const from = ids.indexOf(id);
    const to = from + delta;
    if (from < 0 || to < 0 || to >= ids.length) return;
    ids.splice(to, 0, ids.splice(from, 1)[0]!);
    reorderPhases(ids);
    toast.success("Phase order updated — exports now follow the new sequence");
  };

  if (!phases.length) {
    return (
      <p className="text-[13px] text-muted-foreground">
        No future-state phases yet. Use “Add next phase” in the sidebar to start a sequence.
      </p>
    );
  }

  return (
    <div className="space-y-2">
      {phases.map((s, index) => {
        const baseline = resolveBaseline(workspace.scenarios, s);
        return (
          <div
            key={s.id}
            draggable
            onDragStart={() => setDragId(s.id)}
            onDragEnd={() => {
              setDragId(null);
              setOverId(null);
            }}
            onDragOver={(e) => {
              e.preventDefault();
              setOverId(s.id);
            }}
            onDrop={(e) => {
              e.preventDefault();
              if (dragId) move(dragId, s.id);
              setDragId(null);
              setOverId(null);
            }}
            className={cn(
              "flex items-center gap-3 rounded-md border bg-card px-3 py-2.5 transition-colors",
              dragId === s.id ? "opacity-50" : "",
              overId === s.id && dragId && dragId !== s.id
                ? "border-brand ring-1 ring-brand/40"
                : "border-border",
            )}
          >
            <GripVertical className="size-4 shrink-0 cursor-grab text-muted-foreground" />
            <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-brand text-[11px] font-semibold text-brand-foreground">
              {index + 1}
            </span>
            <button
              type="button"
              className="min-w-0 flex-1 text-left"
              onClick={() => setActiveScenario(s.id)}
            >
              <span className="block truncate text-[13px] font-medium">{phaseTitle(s)}</span>
              <span className="block truncate text-[12px] text-muted-foreground">
                {s.name}
                {!compact && baseline ? ` · compared with ${phaseTitle(baseline)}` : ""}
              </span>
            </button>
            {!compact && (
              <span className="shrink-0 text-[12px] text-muted-foreground">
                {s.employees.reduce((a, e) => a + e.plannedHeadcount, 0)} positions
              </span>
            )}
            <div className="flex shrink-0 gap-1">
              <Button
                variant="ghost"
                size="icon"
                className="size-7"
                aria-label={`Move ${phaseTitle(s)} earlier`}
                disabled={index === 0}
                onClick={() => shift(s.id, -1)}
              >
                <ArrowUp className="size-3.5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="size-7"
                aria-label={`Move ${phaseTitle(s)} later`}
                disabled={index === phases.length - 1}
                onClick={() => shift(s.id, 1)}
              >
                <ArrowDown className="size-3.5" />
              </Button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
