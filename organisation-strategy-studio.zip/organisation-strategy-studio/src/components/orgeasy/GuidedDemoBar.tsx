import { useEffect, useState } from "react";
import { useNavigate, useRouterState } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Compass, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useOrgEasy } from "@/lib/orgeasy/store";
import {
  GUIDED_DEMO_STEPS,
  armNudge,
  ensureAutomotiveDemo,
  exitGuidedDemo,
  readGuidedDemo,
  setGuidedDemoStep,
  subscribeGuidedDemo,
  type GuidedDemoState,
} from "@/lib/orgeasy/guided-demo";
import { cn } from "@/lib/utils";

const HIDDEN_PATHS = new Set(["/welcome", "/auth"]);

/**
 * Bottom bar that walks a first-time visitor through the pre-built demo
 * scenarios. Rendered once at the root so it persists across navigation.
 */
export function GuidedDemoBar() {
  const { workspace, setActiveScenario, createScenarioWithEmployees } = useOrgEasy();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [state, setState] = useState<GuidedDemoState | null>(null);

  useEffect(() => {
    setState(readGuidedDemo());
    return subscribeGuidedDemo(() => setState(readGuidedDemo()));
  }, []);

  if (!state || HIDDEN_PATHS.has(pathname)) return null;

  const stepIndex = Math.min(state.step, GUIDED_DEMO_STEPS.length - 1);
  const step = GUIDED_DEMO_STEPS[stepIndex];
  if (!step) return null;
  const isLast = stepIndex === GUIDED_DEMO_STEPS.length - 1;

  const applyStep = (index: number) => {
    const target = GUIDED_DEMO_STEPS[index];
    if (!target) return;
    setGuidedDemoStep(index);
    if (target.scenarioId === "automotive") {
      const id = ensureAutomotiveDemo(workspace.scenarios, createScenarioWithEmployees);
      setActiveScenario(id);
    } else {
      setActiveScenario(target.scenarioId);
    }
    void navigate({ to: target.route });
  };

  const finish = () => {
    exitGuidedDemo();
    armNudge();
    window.dispatchEvent(new Event("oss:guided-demo"));
    toast.success("Demo complete", {
      description: "Everything you saw is editable — or bring your own data when you're ready.",
    });
  };

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-4 z-50 flex justify-center px-4">
      <div className="pointer-events-auto flex w-full max-w-2xl items-center gap-4 rounded-2xl border border-brand/40 bg-card/95 p-4 shadow-overlay backdrop-blur">
        <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-brand/15 text-brand">
          <Compass className="size-5" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[10.5px] font-bold uppercase tracking-[0.16em] text-brand">
            Guided demo · Step {stepIndex + 1} of {GUIDED_DEMO_STEPS.length}
          </p>
          <p className="mt-0.5 truncate text-[14px] font-semibold text-foreground">{step.title}</p>
          <p className="mt-0.5 line-clamp-2 text-[12px] leading-snug text-muted-foreground">
            {step.blurb}
          </p>
          <div className="mt-2 flex gap-1.5">
            {GUIDED_DEMO_STEPS.map((s, i) => (
              <button
                key={s.title}
                type="button"
                aria-label={`Go to demo step ${i + 1}: ${s.title}`}
                onClick={() => applyStep(i)}
                className={cn(
                  "h-1.5 rounded-full transition-all",
                  i === stepIndex ? "w-6 bg-brand" : "w-3 bg-border hover:bg-brand/50",
                )}
              />
            ))}
          </div>
        </div>
        <div className="flex shrink-0 flex-col items-end gap-2">
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={stepIndex === 0}
              onClick={() => applyStep(stepIndex - 1)}
            >
              <ArrowLeft className="size-4" />
              Back
            </Button>
            {isLast ? (
              <Button size="sm" onClick={finish}>
                Finish demo
              </Button>
            ) : (
              <Button size="sm" onClick={() => applyStep(stepIndex + 1)}>
                Next
                <ArrowRight className="size-4" />
              </Button>
            )}
          </div>
          <button
            type="button"
            onClick={() => exitGuidedDemo()}
            className="inline-flex items-center gap-1 text-[11px] text-muted-foreground transition-colors hover:text-foreground"
          >
            <X className="size-3" /> Exit demo
          </button>
        </div>
      </div>
    </div>
  );
}
