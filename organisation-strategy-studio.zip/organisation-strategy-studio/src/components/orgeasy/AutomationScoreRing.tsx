import { bandFromScore, BAND_META } from "@/lib/orgeasy/automation";

/** Big progress ring for the overall automation score. */
export function AutomationScoreRing({
  score,
  size = 168,
  label = "automatable or AI-assisted",
}: {
  score: number;
  size?: number;
  label?: string;
}) {
  const stroke = Math.round(size * 0.085);
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const clamped = Math.max(0, Math.min(100, Math.round(score)));
  const color = BAND_META[bandFromScore(clamped)].ringHex;

  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90" role="img" aria-label={`${clamped}% ${label}`}>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          strokeWidth={stroke}
          className="stroke-muted"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          strokeWidth={stroke}
          stroke={color}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={circumference * (1 - clamped / 100)}
          style={{ transition: "stroke-dashoffset 900ms cubic-bezier(0.22,1,0.36,1)" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        <span
          className="font-semibold leading-none tracking-tight"
          style={{ fontSize: size * 0.28, color }}
        >
          {clamped}%
        </span>
        <span
          className="mt-1 px-3 text-[10.5px] font-medium leading-tight text-muted-foreground"
          style={{ maxWidth: size }}
        >
          {label}
        </span>
      </div>
    </div>
  );
}