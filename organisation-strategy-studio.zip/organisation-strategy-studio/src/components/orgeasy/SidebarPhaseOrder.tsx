import { useState } from "react";
import { ChevronDown, GripVertical } from "lucide-react";
import { toast } from "sonner";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { listPhases, phaseTitle } from "@/lib/orgeasy/phases";
import { cn } from "@/lib/utils";

/**
 * Compact drag-and-drop phase reordering inside the sidebar scenario switcher.
 * Writes through reorderPhases, so comparisons and exports follow the new order.
 */
export function SidebarPhaseOrder() {
  const { workspace, scenario, reorderPhases, setActiveScenario } = useOrgEasy();
  const phases = listPhases(workspace.scenarios);
  const [open, setOpen] = useState(false);
  const [dragId, setDragId] = useState<string | null>(null);
  const [overId, setOverId] = useState<string | null>(null);

  if (phases.length < 2) return null;

  const move = (id: string, targetId: string) => {
    if (id === targetId) return;
    const ids = phases.map((p) => p.id);
    const from = ids.indexOf(id);
    const to = ids.indexOf(targetId);
    if (from < 0 || to < 0) return;
    ids.splice(to, 0, ids.splice(from, 1)[0]!);
    reorderPhases(ids);
    toast.success("Phase order updated — exports now follow the new sequence");
  };

  return (
    <div className="mt-2">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="flex w-full items-center justify-between gap-2 rounded-md px-1.5 py-1 text-[10.5px] font-semibold uppercase tracking-wide text-sidebar-foreground/80 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
      >
        <span className="flex items-center gap-1.5">
          <GripVertical className="size-3.5" />
          Reorder phases
        </span>
        <ChevronDown className={cn("size-3.5 transition-transform", open && "rotate-180")} />
      </button>
      {open ? (
        <div className="mt-1.5 space-y-1">
          <p className="px-1.5 text-[10px] leading-snug text-sidebar-foreground/60">
            Drag a phase to change the timeline order.
          </p>
          {phases.map((s, index) => (
            <div
              key={s.id}
              draggable
              onDragStart={() => setDragId(s.id)}
              onDragEnd={() => {
                setDragId(null);
                setOverId(null);
              }}
              onDragOver={(e) => {
                e.preventDefault();
                setOverId(s.id);
              }}
              onDrop={(e) => {
                e.preventDefault();
                if (dragId) move(dragId, s.id);
                setDragId(null);
                setOverId(null);
              }}
              className={cn(
                "flex cursor-grab items-center gap-2 rounded-md border px-2 py-1.5 transition-colors",
                dragId === s.id ? "opacity-50" : "",
                overId === s.id && dragId && dragId !== s.id
                  ? "border-brand bg-sidebar-accent"
                  : "border-white/10 bg-sidebar-accent/40",
                scenario?.id === s.id && "ring-1 ring-inset ring-brand/60",
              )}
            >
              <GripVertical className="size-3.5 shrink-0 text-sidebar-foreground/60" />
              <span className="flex size-4 shrink-0 items-center justify-center rounded-full bg-brand text-[9px] font-bold text-brand-foreground">
                {index + 1}
              </span>
              <button
                type="button"
                onClick={() => setActiveScenario(s.id)}
                className="min-w-0 flex-1 text-left"
                title={`Switch to ${s.name}`}
              >
                <span className="block truncate text-[11.5px] font-medium text-sidebar-accent-foreground">
                  {phaseTitle(s)}
                </span>
                <span className="block truncate text-[10px] text-sidebar-foreground/70">
                  {s.name}
                </span>
              </button>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}
