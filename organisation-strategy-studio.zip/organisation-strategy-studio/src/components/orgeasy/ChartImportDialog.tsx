import { useCallback, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  FileSpreadsheet,
  FileUp,
  Loader2,
  RefreshCcw,
  Upload,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import {
  fileToRows,
  mapHeaders,
  mergeImport,
  rowsToEmployees,
  type ImportField,
  type SheetImportResult,
} from "@/lib/orgeasy/chart-import";
import { analyseDataHealth } from "@/lib/orgeasy/data-health";
import { analyseSpans } from "@/lib/orgeasy/span";
import { downloadBlob, employeesToCsv } from "@/lib/orgeasy/csv";
import { useOrgEasy } from "@/lib/orgeasy/store";
import type { Scenario } from "@/lib/orgeasy/types";
import { toast } from "sonner";

/**
 * Self-contained import trigger + dialog. With no props it renders its own
 * "Import" button and writes straight into the active scenario; hosts that
 * already manage dialog state can drive it via the optional props instead.
 */
interface ChartImportDialogProps {
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  scenarioName?: string;
  onCommit?: (result: SheetImportResult, mode: "replace" | "merge") => void;
}

const FIELD_LABELS: Record<ImportField, string> = {
  id: "Employee ID",
  name: "Name",
  title: "Title",
  manager: "Manager (name)",
  managerId: "Manager ID / email",
  department: "Department",
  country: "Country / location",
  photoUrl: "Photo URL",
  email: "Email",
  headcount: "Headcount",
  status: "Status",
  costCenter: "Cost centre",
  employmentType: "Employment type",
  cost: "Cost / salary",
  responsibilities: "Responsibilities",
};

const MAPPING_FIELDS = Object.keys(FIELD_LABELS) as ImportField[];

export function ChartImportDialog({
  open: openProp,
  onOpenChange: onOpenChangeProp,
  scenarioName: scenarioNameProp,
  onCommit: onCommitProp,
}: ChartImportDialogProps = {}) {
  const { scenario, replaceEmployees, can, recordActivity } = useOrgEasy();
  const [internalOpen, setInternalOpen] = useState(false);
  const controlled = openProp !== undefined;
  const open = openProp ?? internalOpen;
  const scenarioName = scenarioNameProp ?? scenario?.name ?? "this scenario";
  const [result, setResult] = useState<SheetImportResult | null>(null);
  const [rows, setRows] = useState<string[][] | null>(null);
  const [overrides, setOverrides] = useState<Partial<Record<ImportField, number | null>>>({});
  const [fileName, setFileName] = useState("");
  const [busy, setBusy] = useState(false);
  const [stage, setStage] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const reset = () => {
    setResult(null);
    setRows(null);
    setOverrides({});
    setFileName("");
    setBusy(false);
    setStage("");
  };

  const handleOpenChange = (next: boolean) => {
    if (controlled) onOpenChangeProp?.(next);
    else setInternalOpen(next);
    if (!next) reset();
  };

  const readFile = useCallback(async (file: File | undefined | null) => {
    if (!file) return;
    setBusy(true);
    setStage("Reading file…");
    try {
      const rawRows = await fileToRows(file);
      if (!rawRows.length) {
        setResult({
          employees: [],
          errors: [
            /\.(xlsx|xlsm|xlsb|xls)$/i.test(file.name)
              ? "That workbook has no sheets."
              : "The file needs a header row and at least one data row.",
          ],
          warnings: [],
          detected: {},
          stats: { rows: 0, roots: 0, linked: 0, unlinked: 0, vacant: 0 },
        });
        setRows(null);
        setFileName(file.name);
        return;
      }
      setStage("Mapping columns…");
      await new Promise((r) => setTimeout(r, 30)); // let the UI paint the stage
      const parsed = rowsToEmployees(rawRows);
      setStage("Building hierarchy…");
      await new Promise((r) => setTimeout(r, 30));
      setRows(rawRows);
      setOverrides({});
      setResult(parsed);
      setFileName(file.name);
    } catch {
      setResult({
        employees: [],
        errors: ["Could not read that file. Export it as CSV or .xlsx and try again."],
        warnings: [],
        detected: {},
        stats: { rows: 0, roots: 0, linked: 0, unlinked: 0, vacant: 0 },
      });
      setRows(null);
      setFileName(file.name);
    } finally {
      setBusy(false);
      setStage("");
    }
  }, []);

  /** Re-run the parse with a user-adjusted column mapping. */
  const remap = (field: ImportField, value: string) => {
    const next = { ...overrides, [field]: value === "" ? null : Number(value) };
    setOverrides(next);
    if (rows) setResult(rowsToEmployees(rows, next));
  };

  const autoMap = useMemo(
    () =>
      rows && rows.length ? mapHeaders((rows[0] ?? []).map((h) => String(h ?? "").trim())) : {},
    [rows],
  );
  const headers = useMemo(
    () => (rows?.[0] ?? []).map((h, i) => String(h ?? "").trim() || `Column ${i + 1}`),
    [rows],
  );

  const quality = useMemo(() => {
    if (!result || !result.employees.length) return null;
    const stub = { employees: result.employees } as unknown as Scenario;
    const health = analyseDataHealth(stub);
    const spans = analyseSpans(stub);
    const positions = result.employees.reduce(
      (s, e) => s + Math.max(e.plannedHeadcount || e.currentHeadcount || 1, 0),
      0,
    );
    const gaps = health.completeness
      .filter((c) => c.filled < c.total)
      .map((c) => `${c.label} ${c.filled}/${c.total}`);
    return { health, layers: spans.maxLayer, positions, gaps };
  }, [result]);

  const commit = (mode: "replace" | "merge") => {
    if (!result || !result.employees.length) return;
    if (onCommitProp) {
      onCommitProp(result, mode);
    } else if (scenario) {
      replaceEmployees(
        mode === "replace"
          ? result.employees
          : mergeImport(scenario.employees, result.employees).employees,
      );
    }
    recordActivity(
      "structure",
      `${mode === "replace" ? "Imported" : "Merged"} ${result.stats.rows} roles from ${fileName || "a file"}`,
      scenarioName,
    );
    toast.success(
      mode === "replace"
        ? `Imported ${result.stats.rows} roles into “${scenarioName}”`
        : `Merged ${result.stats.rows} roles into “${scenarioName}”`,
      {
        description: quality
          ? `Data quality ${quality.health.score}/100 (${quality.health.band.label}) — the Data health check page has the full breakdown.`
          : undefined,
      },
    );
    handleOpenChange(false);
  };

  return (
    <>
      {!controlled && (
        <Button
          variant="outline"
          size="sm"
          onClick={() => handleOpenChange(true)}
          disabled={!can("importData")}
          title={
            can("importData")
              ? "Import roles from a CSV or Excel file"
              : "Your workspace role can't import data"
          }
        >
          <Upload className="mr-1.5 size-4" /> Import
        </Button>
      )}
      <Dialog open={open} onOpenChange={handleOpenChange}>
        <DialogContent className="max-h-[85vh] max-w-[min(56rem,94vw)] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Import chart from CSV or Excel</DialogTitle>
            <DialogDescription>
              Upload a .csv, .tsv or .xlsx export from any HR system. Column names are
              auto-detected, the mapping is editable, and you&apos;ll see a data quality summary
              before anything is written to “{scenarioName}”.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* Dropzone */}
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                void readFile(e.dataTransfer.files?.[0]);
              }}
              className={cn(
                "flex w-full flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed px-6 py-8 text-center transition-colors",
                result
                  ? "border-border bg-secondary/30"
                  : "border-brand/40 bg-brand/5 hover:border-brand hover:bg-brand/10",
              )}
            >
              {busy ? (
                <>
                  <Loader2 className="size-6 animate-spin text-brand" />
                  <p className="text-[13px] font-medium">{stage || "Reading file…"}</p>
                  <p className="text-[11.5px] text-muted-foreground">{fileName}</p>
                </>
              ) : (
                <>
                  <FileUp className="size-6 text-brand" />
                  <p className="text-[13px] font-medium">
                    {fileName
                      ? "Drop another file or click to replace"
                      : "Drop a file or click to browse"}
                  </p>
                  <p className="text-[11.5px] text-muted-foreground">
                    CSV, TSV or Excel — first row should be column names
                  </p>
                </>
              )}
              <input
                ref={inputRef}
                type="file"
                accept=".csv,.tsv,.txt,.xlsx,.xls,.xlsm,.xlsb"
                className="hidden"
                onChange={(e) => {
                  void readFile(e.target.files?.[0]);
                  e.target.value = "";
                }}
              />
            </button>

            {result && (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-[12px] text-muted-foreground">
                  <FileSpreadsheet className="size-4" />
                  <span className="font-medium text-foreground">{fileName}</span>
                  <button
                    type="button"
                    onClick={reset}
                    className="ml-auto inline-flex items-center gap-1 text-[11px] hover:text-foreground"
                  >
                    <RefreshCcw className="size-3" /> Start over
                  </button>
                </div>

                {/* Editable column mapping */}
                {rows && headers.length > 0 && (
                  <div className="rounded-lg border border-border bg-card p-3">
                    <p className="text-[12px] font-semibold">Column mapping</p>
                    <p className="mt-0.5 text-[11px] text-muted-foreground">
                      Auto-detected from your headers — adjust any field and the preview updates
                      instantly.
                    </p>
                    <div className="mt-2.5 grid grid-cols-1 gap-x-4 gap-y-1.5 sm:grid-cols-2 lg:grid-cols-3">
                      {MAPPING_FIELDS.map((field) => {
                        const effective =
                          field in overrides ? overrides[field] : autoMap[field];
                        return (
                          <label
                            key={field}
                            className="flex items-center justify-between gap-2 text-[11px]"
                          >
                            <span className="shrink-0 text-muted-foreground">
                              {FIELD_LABELS[field]}
                            </span>
                            <select
                              value={
                                effective === null || effective === undefined
                                  ? ""
                                  : String(effective)
                              }
                              onChange={(e) => remap(field, e.target.value)}
                              className={cn(
                                "h-7 w-32 truncate rounded-md border border-border bg-background px-1.5 text-[11px]",
                                (effective === null || effective === undefined) &&
                                  "text-muted-foreground/70",
                              )}
                            >
                              <option value="">Not mapped</option>
                              {headers.map((h, i) => (
                                <option key={`${i}-${h}`} value={i}>
                                  {h}
                                </option>
                              ))}
                            </select>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Import stats */}
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
                  {[
                    { label: "Roles", value: result.stats.rows },
                    { label: "Linked", value: result.stats.linked },
                    { label: "Top level", value: result.stats.roots },
                    { label: "Vacant", value: result.stats.vacant },
                    { label: "Unlinked", value: result.stats.unlinked },
                  ].map((s) => (
                    <div
                      key={s.label}
                      className="rounded-lg border border-border bg-card px-3 py-2 text-center"
                    >
                      <p className="text-[16px] font-bold">{s.value}</p>
                      <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
                        {s.label}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Data quality summary */}
                {quality && (
                  <div className="rounded-lg border border-border bg-card p-3">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-[12px] font-semibold">Data quality summary</p>
                      <span
                        className={cn(
                          "rounded-full px-2 py-0.5 text-[10px] font-semibold",
                          quality.health.score >= 80
                            ? "bg-success/10 text-success"
                            : quality.health.score >= 60
                              ? "bg-warning/10 text-warning"
                              : "bg-danger/10 text-danger",
                        )}
                      >
                        {quality.health.score}/100 · {quality.health.band.label}
                      </span>
                    </div>
                    <p className="mt-1.5 text-[11.5px] leading-relaxed text-muted-foreground">
                      {quality.positions.toLocaleString()} positions across {quality.layers} layers
                      · {quality.health.criticalCount} critical · {quality.health.warningCount}{" "}
                      warnings
                    </p>
                    <p className="mt-1 text-[11.5px] leading-relaxed text-muted-foreground">
                      {quality.gaps.length
                        ? `Missing values — ${quality.gaps.join(" · ")}. You can still import; the Data health check will guide the fixes.`
                        : "All key fields are populated — this file is modelling-ready."}
                    </p>
                  </div>
                )}

                {result.warnings.length > 0 && (
                  <ul className="space-y-1.5">
                    {result.warnings.map((w, i) => (
                      <li
                        key={i}
                        className="flex items-start gap-2 rounded-lg border border-warning/40 bg-warning/5 px-3 py-2 text-[12px]"
                      >
                        <AlertTriangle className="mt-0.5 size-3.5 shrink-0 text-warning" />
                        {w}
                      </li>
                    ))}
                  </ul>
                )}
                {result.errors.length > 0 && (
                  <ul className="space-y-1.5">
                    {result.errors.map((err, i) => (
                      <li
                        key={i}
                        className="flex items-start gap-2 rounded-lg border border-danger/40 bg-danger/5 px-3 py-2 text-[12px]"
                      >
                        <AlertTriangle className="mt-0.5 size-3.5 shrink-0 text-danger" />
                        {err}
                      </li>
                    ))}
                  </ul>
                )}
                {!result.errors.length && result.employees.length > 0 && (
                  <p className="flex items-center gap-2 text-[12px] text-success">
                    <CheckCircle2 className="size-4" />
                    Ready — {result.employees.length} roles will be added to the chart.
                  </p>
                )}
              </div>
            )}
          </div>

          <DialogFooter className="gap-2 sm:justify-between">
            <div className="mr-auto flex flex-col gap-1">
              <p className="text-[11px] text-muted-foreground">
                Replace rebuilds this scenario; Refresh keeps layout &amp; edits.
              </p>
              <button
                type="button"
                onClick={() => {
                  downloadBlob(employeesToCsv([]), "orgeasy-org-template.csv", "text/csv");
                  toast.success("CSV template downloaded", {
                    description: "Fill it in from any spreadsheet, then drop it back here.",
                  });
                }}
                className="inline-flex items-center gap-1 self-start text-[11px] font-medium text-brand hover:underline"
              >
                <FileSpreadsheet className="size-3" /> Download the CSV template
              </button>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                disabled={!result || result.employees.length === 0 || result.errors.length > 0}
                onClick={() => commit("merge")}
              >
                <Upload className="mr-1.5 size-4 rotate-180" /> Refresh &amp; merge
              </Button>
              <Button
                disabled={!result || result.employees.length === 0 || result.errors.length > 0}
                onClick={() => commit("replace")}
              >
                <Upload className="mr-1.5 size-4" /> Replace scenario
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
