import { useCallback, useMemo, useState } from "react";
import { Camera, History, RotateCcw, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useOrgEasy } from "@/lib/orgeasy/store";
import {
  SNAPSHOT_LIMITS,
  SNAPSHOT_REASONS,
  deleteScenarioSnapshot,
  loadAllScenarioSnapshots,
  type ScenarioSnapshot,
} from "@/lib/orgeasy/scenario-snapshots";
import { toast } from "sonner";

const REASON_HEX: Record<ScenarioSnapshot["reason"], string> = {
  manual: "2563EB",
  "pre-import": "7C3AED",
  "pre-reset": "B45309",
  "pre-restore": "0F9D8F",
};

function money(value: number, currency: string) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    maximumFractionDigits: 0,
  }).format(value);
}

function when(iso: string) {
  const d = new Date(iso);
  return Number.isFinite(d.getTime()) ? d.toLocaleString() : "unknown";
}

/**
 * Snapshot history for a single scenario. Complements workspace restore points:
 * an import or bulk edit can be rolled back for one scenario without reverting
 * the rest of the workspace.
 */
export function ScenarioSnapshots() {
  const { workspace, scenario, snapshotScenario, restoreScenarioSnapshot } = useOrgEasy();
  const [all, setAll] = useState<ScenarioSnapshot[]>(() => loadAllScenarioSnapshots());
  const [label, setLabel] = useState("");
  const [scope, setScope] = useState<"active" | "all">("active");
  const refresh = useCallback(() => setAll(loadAllScenarioSnapshots()), []);

  const visible = useMemo(
    () => (scope === "active" && scenario ? all.filter((s) => s.scenarioId === scenario.id) : all),
    [all, scope, scenario],
  );

  const onSave = () => {
    const saved = snapshotScenario({ reason: "manual", ...(label.trim() ? { label: label.trim() } : {}) });
    setLabel("");
    refresh();
    if (saved) toast.success(`Snapshot saved for “${saved.scenarioName}”`);
    else toast.info("Nothing new to snapshot — this scenario is unchanged since the last one.");
  };

  const onRestore = (snapshot: ScenarioSnapshot) => {
    const ok = restoreScenarioSnapshot(snapshot.id);
    refresh();
    if (ok) {
      toast.success(`Restored “${snapshot.label}”`, {
        description: "Only this scenario changed. Your previous state was kept as “Before a restore”.",
      });
    } else {
      toast.error("That snapshot is no longer available.");
    }
  };

  return (
    <section className="overflow-hidden rounded-xl border bg-card">
      <header className="flex flex-wrap items-center justify-between gap-3 border-b px-5 py-3">
        <div className="flex items-center gap-2">
          <History className="size-4 text-muted-foreground" />
          <h2 className="text-[13.5px] font-semibold">Scenario snapshots</h2>
        </div>
        <div className="flex items-center gap-1 rounded-lg border p-0.5">
          <Button
            size="sm"
            variant={scope === "active" ? "secondary" : "ghost"}
            className="h-7 px-2.5 text-[12px]"
            onClick={() => setScope("active")}
          >
            This scenario
          </Button>
          <Button
            size="sm"
            variant={scope === "all" ? "secondary" : "ghost"}
            className="h-7 px-2.5 text-[12px]"
            onClick={() => setScope("all")}
          >
            All scenarios
          </Button>
        </div>
      </header>

      <div className="flex flex-wrap items-end gap-3 border-b px-5 py-4">
        <div className="min-w-[240px] flex-1">
          <label className="text-[11.5px] font-semibold uppercase tracking-wide text-muted-foreground">
            Snapshot {scenario ? `“${scenario.name}”` : "the active scenario"}
          </label>
          <Input
            className="mt-1.5"
            value={label}
            placeholder="Optional name, e.g. “Before Workday import”"
            onChange={(e) => setLabel(e.target.value)}
          />
        </div>
        <Button className="gap-2" onClick={onSave} disabled={!scenario}>
          <Camera className="size-4" /> Save snapshot
        </Button>
      </div>

      {visible.length === 0 ? (
        <p className="px-5 py-8 text-center text-[13px] text-muted-foreground">
          No snapshots yet. One is captured automatically before every import or reset, and you can
          save your own at any time. The newest {SNAPSHOT_LIMITS.maxPerScenario} per scenario are kept
          in this browser only.
        </p>
      ) : (
        <ul className="divide-y">
          {visible.map((s) => {
            const stale = !workspace.scenarios.some((sc) => sc.id === s.scenarioId);
            return (
              <li key={s.id} className="flex flex-wrap items-start justify-between gap-3 px-5 py-4">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className="rounded-full px-2 py-0.5 text-[10.5px] font-semibold uppercase tracking-wide"
                      style={{
                        backgroundColor: `#${REASON_HEX[s.reason]}1F`,
                        color: `#${REASON_HEX[s.reason]}`,
                      }}
                    >
                      {SNAPSHOT_REASONS[s.reason]}
                    </span>
                    <p className="truncate text-[13.5px] font-semibold">{s.label}</p>
                    {stale ? (
                      <span className="rounded-full bg-muted px-2 py-0.5 text-[10.5px] font-semibold uppercase tracking-wide text-muted-foreground">
                        Scenario deleted
                      </span>
                    ) : null}
                  </div>
                  <p className="mt-1.5 text-[12.5px] text-muted-foreground">
                    {s.scenarioName} · {when(s.createdAt)} · {s.roleCount.toLocaleString()} roles ·{" "}
                    {s.plannedPositions.toLocaleString()} positions · {money(s.annualCost, s.currency)}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Button size="sm" className="gap-2" onClick={() => onRestore(s)}>
                    <RotateCcw className="size-3.5" /> {stale ? "Recover" : "Revert"}
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      deleteScenarioSnapshot(s.id);
                      refresh();
                      toast.success("Snapshot deleted");
                    }}
                  >
                    <Trash2 className="size-3.5" />
                  </Button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
