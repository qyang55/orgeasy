import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  AlertTriangle,
  CheckCircle2,
  Download,
  Loader2,
  ShieldCheck,
  Trash2,
  XCircle,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { downloadBlob } from "@/lib/orgeasy/csv";
import { loadPresets } from "@/lib/orgeasy/filter-presets";
import { recordErasure } from "@/lib/orgeasy/erasure-log";
import {
  DELETION_SCOPES,
  buildBackup,
  listPresentKeys,
  receiptToText,
  runDeletion,
  type DeletionReceipt,
  type DeletionScopeId,
} from "@/lib/orgeasy/deletion";

const CONFIRM_WORD = "DELETE";

export function DeleteMyDataDialog() {
  const { workspace, resetDemoData } = useOrgEasy();
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState<DeletionScopeId[]>(
    DELETION_SCOPES.filter((s) => s.defaultSelected).map((s) => s.id),
  );
  const [phrase, setPhrase] = useState("");
  const [busy, setBusy] = useState(false);
  const [receipt, setReceipt] = useState<DeletionReceipt | null>(null);
  const [present, setPresent] = useState<string[]>([]);

  useEffect(() => {
    if (open) setPresent(listPresentKeys());
  }, [open]);

  const counts = useMemo(() => {
    const scenarios = workspace.scenarios ?? [];
    const roles = scenarios.flatMap((s) => s.employees ?? []);
    return {
      scenarios: scenarios.length,
      roles: roles.length,
      namedPeople: roles.filter((r) => (r.name ?? "").trim().length > 0).length,
      photos: roles.filter((r) => Boolean(r.photoUrl)).length,
      adkarGroups: scenarios.reduce((n, s) => n + (s.adkarGroups?.length ?? 0), 0),
      savedViews: loadPresets().length,
    };
  }, [workspace]);

  const toggle = (id: DeletionScopeId) =>
    setSelected((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));

  const reset = () => {
    setPhrase("");
    setReceipt(null);
    setBusy(false);
    setSelected(DELETION_SCOPES.filter((s) => s.defaultSelected).map((s) => s.id));
  };

  const runNow = async () => {
    setBusy(true);
    // Clear in-memory state first so the store cannot re-persist while we delete.
    if (selected.includes("workspace")) resetDemoData();
    await new Promise((r) => setTimeout(r, 80));
    const result = runDeletion(selected, counts);
    if (selected.includes("workspace")) {
      recordErasure({
        reason: `Delete my data flow (receipt ${result.id})`,
        removed: counts,
        keysCleared: result.keys.filter((k) => k.verifiedGone).map((k) => k.key),
        keysRemaining: result.keysRetained,
      });
    }
    setReceipt(result);
    setBusy(false);
    if (result.allVerified) toast.success("Deletion complete and verified");
    else toast.error("Some storage keys could not be removed — see the receipt");
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (!next) reset();
      }}
    >
      <DialogTrigger asChild>
        <Button variant="destructive">
          <Trash2 className="mr-1.5 size-4" /> Delete my data
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
        {receipt ? (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                {receipt.allVerified ? (
                  <CheckCircle2 className="size-5 text-success" />
                ) : (
                  <AlertTriangle className="size-5 text-destructive" />
                )}
                {receipt.allVerified ? "Deletion complete" : "Deletion partially complete"}
              </DialogTitle>
              <DialogDescription>
                Receipt {receipt.id} · {new Date(receipt.at).toLocaleString()}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 text-[12.5px]">
              <div className="grid grid-cols-3 gap-2">
                {[
                  ["Scenarios", receipt.removed.scenarios],
                  ["Role records", receipt.removed.roles],
                  ["Named individuals", receipt.removed.namedPeople],
                  ["Photos", receipt.removed.photos],
                  ["ADKAR groups", receipt.removed.adkarGroups],
                  ["Saved views", receipt.removed.savedViews],
                ].map(([label, value]) => (
                  <div key={label as string} className="rounded border border-border bg-muted/30 px-3 py-2">
                    <p className="text-[16px] font-semibold tabular-nums">{value as number}</p>
                    <p className="text-[11px] text-muted-foreground">{label as string}</p>
                  </div>
                ))}
              </div>

              <div className="overflow-hidden rounded-md border border-border">
                <table className="w-full text-[12px]">
                  <thead className="bg-muted/60 text-left text-muted-foreground">
                    <tr>
                      <th className="px-3 py-2 font-semibold">Storage key</th>
                      <th className="px-3 py-2 font-semibold">Before</th>
                      <th className="px-3 py-2 font-semibold">Verified</th>
                    </tr>
                  </thead>
                  <tbody>
                    {receipt.keys.map((k) => (
                      <tr key={k.key} className="border-t border-border">
                        <td className="px-3 py-2 font-mono text-[11.5px]">{k.key}</td>
                        <td className="px-3 py-2 text-muted-foreground">
                          {k.existedBefore ? `${k.bytesBefore.toLocaleString()} bytes` : "not present"}
                        </td>
                        <td className="px-3 py-2">
                          {k.verifiedGone ? (
                            <span className="inline-flex items-center gap-1 text-success">
                              <CheckCircle2 className="size-3.5" /> gone
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-destructive">
                              <XCircle className="size-3.5" /> still present
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="rounded-md border border-info/40 bg-info/10 p-3">
                <p className="flex items-center gap-1.5 font-semibold">
                  <ShieldCheck className="size-4 text-info" /> Account & server-side data
                </p>
                <p className="mt-1 leading-relaxed text-muted-foreground">{receipt.serverCopies}</p>
              </div>

              {receipt.keysRetained.length ? (
                <p className="text-muted-foreground">
                  <span className="font-semibold text-foreground">Retained by your choice: </span>
                  {receipt.keysRetained.join(" · ")}
                </p>
              ) : null}

              <p className="text-muted-foreground">
                Files you already exported (PPTX, PDF, PNG, CSV) and any copy held in your HRIS are
                outside this app and must be deleted separately.
              </p>
            </div>

            <DialogFooter>
              <Button
                variant="outline"
                onClick={() =>
                  downloadBlob(
                    receiptToText(receipt),
                    `orgeasy-deletion-receipt-${receipt.id}.txt`,
                    "text/plain",
                  )
                }
              >
                <Download className="mr-1.5 size-4" /> Download receipt
              </Button>
              <Button onClick={() => setOpen(false)}>Done</Button>
            </DialogFooter>
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Trash2 className="size-5 text-destructive" /> Delete my data
              </DialogTitle>
              <DialogDescription>
                Organisation Strategy Studio has no account or server-side profile — your records live only in this
                browser. Choose what to remove; deletion is immediate, permanent and verified.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div className="space-y-2">
                {DELETION_SCOPES.map((scope) => {
                  const hasData = scope.keys.some((k) => present.includes(k));
                  return (
                    <label
                      key={scope.id}
                      className="flex cursor-pointer gap-3 rounded-md border border-border bg-card p-3"
                    >
                      <Checkbox
                        checked={selected.includes(scope.id)}
                        onCheckedChange={() => toggle(scope.id)}
                        className="mt-0.5"
                      />
                      <span>
                        <span className="flex items-center gap-2 text-[13px] font-semibold">
                          {scope.label}
                          {!hasData ? (
                            <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
                              nothing stored
                            </span>
                          ) : null}
                        </span>
                        <span className="mt-1 block text-[12px] leading-relaxed text-muted-foreground">
                          {scope.description}
                        </span>
                      </span>
                    </label>
                  );
                })}
              </div>

              <div className="flex flex-wrap items-center gap-3 rounded-md border border-border bg-muted/30 px-3 py-2.5">
                <p className="text-[12px] text-muted-foreground">
                  Need a copy before deleting? Download a JSON backup of everything stored locally.
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() =>
                    downloadBlob(buildBackup(), "orgeasy-local-data-backup.json", "application/json")
                  }
                >
                  <Download className="mr-1.5 size-3.5" /> Download backup
                </Button>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="confirm-delete" className="text-[12.5px]">
                  Type <span className="font-mono font-semibold">{CONFIRM_WORD}</span> to confirm
                </Label>
                <Input
                  id="confirm-delete"
                  value={phrase}
                  onChange={(e) => setPhrase(e.target.value)}
                  placeholder={CONFIRM_WORD}
                  autoComplete="off"
                />
              </div>
            </div>

            <DialogFooter>
              <Button variant="ghost" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button
                variant="destructive"
                disabled={busy || phrase.trim().toUpperCase() !== CONFIRM_WORD || !selected.length}
                onClick={runNow}
              >
                {busy ? (
                  <>
                    <Loader2 className="mr-1.5 size-4 animate-spin" /> Deleting…
                  </>
                ) : (
                  <>Delete permanently</>
                )}
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
