import { useNavigate, Link } from "@tanstack/react-router";
import { ArrowRight, Bot, Car, Layers, TrendingDown, Upload, Compass, PlayCircle, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { computeImpact, formatMoney } from "@/lib/orgeasy/impact";
import { requestTourReplay } from "@/lib/orgeasy/first-run";
import { ensureAutomotiveDemo } from "@/lib/orgeasy/guided-demo";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const EXAMPLES = [
  {
    scenarioId: "future-p1",
    label: "Efficiency programme",
    icon: TrendingDown,
    blurb: "Release low-yield roles and reinvest the savings.",
  },
  {
    scenarioId: "future-capability",
    label: "Shared services",
    icon: Layers,
    blurb: "Move transactional work into a centre of excellence.",
  },
  {
    scenarioId: "future-p3",
    label: "AI-enabled delivery",
    icon: Bot,
    blurb: "Agents take routine work; people move to judgement roles.",
  },
];

export function GettingStarted({ onDismiss }: { onDismiss?: (() => void) | undefined }) {
  const { workspace, setActiveScenario, createScenarioWithEmployees } = useOrgEasy();
  const navigate = useNavigate();

  const openExample = (id: string, label: string) => {
    setActiveScenario(id);
    toast.success(`Opened the "${label}" example`);
    void navigate({ to: "/" });
  };

  const cards = EXAMPLES.map((ex) => ({
    ...ex,
    scenario: workspace.scenarios.find((s) => s.id === ex.scenarioId) ?? null,
  })).filter((c) => c.scenario);

  return (
    <section className="relative grid gap-6 lg:grid-cols-[1fr_320px]">
      {onDismiss ? (
        <button
          type="button"
          onClick={onDismiss}
          aria-label="Dismiss the getting started panel"
          className="absolute right-3 top-3 rounded-md p-1.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
        >
          <X className="size-4" />
        </button>
      ) : null}
      <div className="rounded-2xl border border-border bg-card p-6 shadow-panel">
        <h2 className="text-lg font-semibold tracking-tight">Start from a pre-built example</h2>
        <p className="mt-1 text-[13px] text-muted-foreground">
          Open one of these scenarios to see how cost, headcount and structure change together.
        </p>

        <div className="mt-5 grid gap-3 sm:grid-cols-3">
          {cards.map((card) => {
            const Icon = card.icon;
            const impact = computeImpact(card.scenario);
            return (
              <button
                key={card.scenarioId}
                type="button"
                onClick={() => openExample(card.scenarioId, card.label)}
                className={cn(
                  "group flex flex-col rounded-xl border border-border bg-background p-4 text-left transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-panel",
                )}
              >
                <span className="flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <Icon className="size-4.5" />
                </span>
                <span className="mt-3 text-[14px] font-semibold">{card.label}</span>
                <span className="mt-1 flex-1 text-[12px] leading-relaxed text-muted-foreground">
                  {card.blurb}
                </span>
                <span className="mt-3 text-[11px] text-muted-foreground">
                  {impact.headcountDelta === 0
                    ? "Positions flat"
                    : `${impact.headcountDelta > 0 ? "+" : ""}${impact.headcountDelta} positions`}
                  {" · "}
                  {impact.costDelta > 0 ? "+" : ""}
                  {formatMoney(impact.costDelta, card.scenario?.currency ?? "USD")} cost
                </span>
                <span className="mt-2 inline-flex items-center gap-1 text-[12px] font-medium text-primary transition-transform group-hover:translate-x-0.5">
                  Open example <ArrowRight className="size-3.5" />
                </span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="space-y-4">
        <div className="rounded-2xl border border-border bg-card p-5 shadow-panel">
          <h3 className="text-[14px] font-semibold">Bring your own data</h3>
          <p className="mt-1 text-[12px] text-muted-foreground">
            Upload a CSV or HRIS extract, or pick an industry pack.
          </p>
          <div className="mt-4 flex flex-col gap-2">
            <Button asChild size="sm">
              <Link to="/data-input">
                <Upload className="mr-1.5 size-4" /> Start with your data
              </Link>
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                const id = ensureAutomotiveDemo(workspace.scenarios, createScenarioWithEmployees);
                setActiveScenario(id);
                toast.success("Automotive operating model generated", {
                  description: "ASEAN mid-size, Human + AI Agent variant — now the active scenario.",
                });
                void navigate({ to: "/chart" });
              }}
            >
              <Car className="mr-1.5 size-4" /> Automotive model — one click
            </Button>
            <Button asChild variant="ghost" size="sm" className="justify-start text-muted-foreground">
              <Link to="/packs">
                <Compass className="mr-1.5 size-4" /> Customise industry packs
              </Link>
            </Button>
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-card p-5 shadow-panel">
          <h3 className="text-[14px] font-semibold">New to the studio?</h3>
          <p className="mt-1 text-[12px] text-muted-foreground">
            A three-step tour of the sidebar controls.
          </p>
          <Button
            variant="outline"
            size="sm"
            className="mt-4 w-full"
            onClick={() => requestTourReplay()}
          >
            <PlayCircle className="mr-1.5 size-4" /> Take the 3-step tour
          </Button>
        </div>
      </div>
    </section>
  );
}
