import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  ClipboardCheck,
  LayoutDashboard,
  Users,
  Upload,
  Network,
  BarChart3,
  Car,
  Bot,
  Globe2,
  GaugeCircle,
  UserPlus,
  MessageSquareText,
  FileDown,
  GitCompareArrows,
  Columns3,
  Plug,
  Sparkles,
  Plus,
  Layers,
  Layers3,
  UserCircle2,
  ShieldCheck,
  Lock,
  History as HistoryIcon,
  ChevronDown,
  PanelLeftClose,
  Pencil,
  Check,
  X,
  
  Copy,
  Stethoscope,
  PieChart,
  ArrowRightLeft,
  LifeBuoy,
  ScrollText,
} from "lucide-react";
import type { ReactNode } from "react";
import { useEffect, useMemo, useState } from "react";
import orgeasyLogo from "@/assets/orgeasy-logo.png";
import { useOrgEasy } from "@/lib/orgeasy/store";
import {
  currentStateScenario,
  listPhases,
  nextPhaseOrder,
  phaseTitle,
  scenarioLabel,
} from "@/lib/orgeasy/phases";
import { CURRENT_STATE_ID } from "@/lib/orgeasy/seed";
import {
  SCENARIO_TEMPLATES,
  fillPattern,
  getScenarioTemplate,
  templatePatch,
  type ScenarioTemplateId,
} from "@/lib/orgeasy/scenario-templates";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  ScenarioTour,
  resetScenarioTour,
  isScenarioTourCompleted,
  tourCompletedAt,
} from "@/components/orgeasy/ScenarioTour";
import { TOUR_REPLAY_EVENT } from "@/lib/orgeasy/first-run";
import { impactSnapshot } from "@/lib/orgeasy/impact-snapshot";
import { ROLE_META } from "@/lib/orgeasy/roles";
import { BoardPackButton } from "@/components/orgeasy/BoardPackButton";
import { QuickStart, QUICKSTART_REPLAY_EVENT } from "@/components/orgeasy/QuickStart";
import { SidebarPhaseOrder } from "@/components/orgeasy/SidebarPhaseOrder";
import { usePersistedFlag } from "@/lib/orgeasy/ui-prefs";
import { StudioChromeContext } from "@/lib/orgeasy/studio-chrome";
import { toast } from "sonner";

const TOP_NAV = [
  { to: "/welcome", label: "Welcome", icon: Sparkles },
  { to: "/dashboard", label: "Programme dashboard", icon: LayoutDashboard },
] as const;

const NAV_GROUPS = [
  {
    id: "design",
    label: "Baseline & design",
    to: "/chart",
    icon: Network,
    items: [
      { to: "/data-input", label: "Data input (start here)", icon: Upload },
      { to: "/data-health", label: "Data health check", icon: Stethoscope },
      { to: "/packs", label: "Industry packs", icon: Car },
      { to: "/chart", label: "Org chart designer", icon: Network },
      { to: "/operating-model", label: "Operating model blueprint", icon: Sparkles },
      { to: "/people", label: "Positions & headcount", icon: Users },
      { to: "/integrations", label: "HRIS data sources", icon: Plug },
    ],
  },
  {
    id: "analyse",
    label: "Transformation levers",
    to: "/impact",
    icon: BarChart3,
    items: [
      { to: "/impact", label: "Headcount & cost impact", icon: BarChart3 },
      { to: "/span", label: "Span, layers & duplicates", icon: Layers3 },
      { to: "/distribution", label: "Distributions & flow", icon: PieChart },
      { to: "/automation", label: "AI & work redesign", icon: Bot },
      { to: "/automation-bulk", label: "AI & work redesign - Bulk JD", icon: Layers },
      { to: "/compare", label: "Current vs future states", icon: GitCompareArrows },
      { to: "/scenario-compare", label: "Compare scenarios side by side", icon: Columns3 },
      { to: "/separation", label: "Country Guidance", icon: Globe2 },
    ],
  },
  {
    id: "change",
    label: "Phased delivery",
    to: "/change-plan",
    icon: MessageSquareText,
    items: [
      { to: "/decision", label: "Decision summary", icon: ClipboardCheck },
      { to: "/change-plan", label: "Change plan (ADKAR)", icon: GaugeCircle },
      { to: "/redeployment", label: "Redeployment matching", icon: ArrowRightLeft },
      { to: "/hiring", label: "Hiring pipeline", icon: UserPlus },
      { to: "/adkar", label: "ADKAR readiness", icon: GaugeCircle },
      { to: "/communications", label: "Comms copilot", icon: MessageSquareText },
      { to: "/exports", label: "Programme exports", icon: FileDown },
    ],
  },
  {
    id: "governance",
    label: "Governance & compliance",
    to: "/compliance",
    icon: ShieldCheck,
    items: [
      { to: "/activity", label: "Activity & audit", icon: ScrollText },
      { to: "/versions", label: "Version history", icon: HistoryIcon },
      { to: "/privacy", label: "Privacy & data", icon: Lock },
      { to: "/compliance", label: "Compliance centre", icon: ShieldCheck },
    ],
  },
] as const;

/** Module name shown in the studio top bar for each route. */
const PAGE_TITLES: Record<string, string> = (() => {
  const map: Record<string, string> = {};
  for (const item of TOP_NAV) map[item.to] = item.label;
  for (const group of NAV_GROUPS) {
    map[group.to] = group.label;
    for (const item of group.items) map[item.to] = item.label;
  }
  return map;
})();

function relativeTime(iso: string) {
  const then = new Date(iso).getTime();
  if (!Number.isFinite(then)) return "recently";
  const mins = Math.round((Date.now() - then) / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.round(hrs / 24);
  if (days < 30) return `${days}d ago`;
  return new Date(then).toLocaleDateString();
}

export function AppShell({ children }: { children: ReactNode }) {
  const {
    workspace,
    scenario,
    setActiveScenario,
    createScenario,
    addNextPhase,
    renameScenario,
    updateScenario,
    role,
    can,
  } = useOrgEasy();
  const account = workspace.account;
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("Future State — Phase 3");
  const [cloneFrom, setCloneFrom] = useState<string>("none");
  const [kind, setKind] = useState<"current" | "future">("future");
  const [phaseLabel, setPhaseLabel] = useState("");
  const [baselineId, setBaselineId] = useState<string>("auto");
  const [templateId, setTemplateId] = useState<ScenarioTemplateId>("blank");
  const [spotlight, setSpotlight] = useState(true);
  const [renaming, setRenaming] = useState(false);
  const [renameValue, setRenameValue] = useState("");
  const [tourDone, setTourDone] = useState(false);
  const [replayTour, setReplayTour] = useState(0);
  const [tourAt, setTourAt] = useState<string | null>(null);
  const [sidebarCollapsed, setSidebarCollapsed] = usePersistedFlag("shell.sidebarCollapsed", false);
  // Portal targets in the top bar: pages (Baseline & design) render their
  // view-specific actions and metrics strip into these nodes while the shell
  // owns the chrome layout.
  const [chromeActionsEl, setChromeActionsEl] = useState<HTMLElement | null>(null);
  const [chromeMetricsEl, setChromeMetricsEl] = useState<HTMLElement | null>(null);
  const chromeValue = useMemo(
    () => ({ actionsEl: chromeActionsEl, metricsEl: chromeMetricsEl }),
    [chromeActionsEl, chromeMetricsEl],
  );
  useEffect(() => {
    setTourDone(isScenarioTourCompleted());
    setTourAt(tourCompletedAt());
  }, []);
  // The getting-started panel is the clean entry point into the tour.
  useEffect(() => {
    const replay = () => setReplayTour((n) => n + 1);
    window.addEventListener(TOUR_REPLAY_EVENT, replay);
    return () => window.removeEventListener(TOUR_REPLAY_EVENT, replay);
  }, []);
  const commitRename = () => {
    const next = renameValue.trim();
    if (!scenario || !next) {
      setRenaming(false);
      return;
    }
    renameScenario(scenario.id, next, scenario.description);
    setRenaming(false);
    toast.success(`Renamed to "${next}"`);
  };
  useEffect(() => {
    const t = window.setTimeout(() => setSpotlight(false), 4000);
    return () => window.clearTimeout(t);
  }, []);
  const activeGroup = NAV_GROUPS.find((g) => g.items.some((i) => i.to === pathname))?.id ?? null;
  const [openGroups, setOpenGroups] = useState<string[]>(activeGroup ? [activeGroup] : []);
  const isGroupOpen = (id: string) => openGroups.includes(id) || activeGroup === id;
  const toggleGroup = (id: string) =>
    setOpenGroups((prev) =>
      prev.includes(id) || activeGroup === id ? prev.filter((g) => g !== id) : [...prev, id],
    );

  const current = currentStateScenario(workspace.scenarios);
  const phases = listPhases(workspace.scenarios);
  const nextOrder = nextPhaseOrder(workspace.scenarios);

  const pickTemplate = (id: ScenarioTemplateId) => {
    setTemplateId(id);
    const template = getScenarioTemplate(id);
    setName(fillPattern(template.namePattern, nextOrder));
    setPhaseLabel(fillPattern(template.phaseLabelPattern, nextOrder));
    const latest = phases[phases.length - 1];
    setCloneFrom(
      template.startFrom === "current"
        ? (current?.id ?? "none")
        : template.startFrom === "latest"
          ? (latest?.id ?? current?.id ?? "none")
          : "none",
    );
  };

  // The landing page is public marketing surface, and the popped-out canvas is
  // a dedicated chrome-free window: render them full-bleed, without the shell.
  if (pathname === "/welcome" || pathname === "/canvas-popout") {
    return <>{children}</>;
  }

  const pageTitle = PAGE_TITLES[pathname] ?? "Studio";

  return (
    <StudioChromeContext.Provider value={chromeValue}>
    <div className="flex h-dvh w-full overflow-hidden bg-background text-foreground">
      <aside
        className={cn(
          "flex h-full shrink-0 flex-col overflow-y-auto border-r border-sidebar-border bg-sidebar text-sidebar-foreground transition-[width] duration-200",
          sidebarCollapsed ? "w-14" : "w-60",
        )}
      >
        <div
          className={cn(
            "sticky top-0 z-20 flex items-center border-b border-sidebar-border bg-sidebar",
            sidebarCollapsed ? "justify-center px-2 py-3" : "gap-2.5 px-4 py-3.5",
          )}
        >
          {sidebarCollapsed ? (
            <button
              type="button"
              onClick={() => setSidebarCollapsed(false)}
              aria-label="Expand sidebar"
              title="Expand sidebar"
              className="rounded-lg transition-opacity hover:opacity-80"
            >
              <img
                src={orgeasyLogo}
                alt="Organisation Strategy Studio logo"
                width={32}
                height={32}
                className="size-8 rounded-lg"
              />
            </button>
          ) : (
            <>
              <img
                src={orgeasyLogo}
                alt="Organisation Strategy Studio logo"
                width={36}
                height={36}
                className="size-9 shrink-0 rounded-lg"
              />
              <div className="min-w-0 flex-1">
                <p className="truncate font-display text-[13.5px] font-semibold leading-tight tracking-tight text-sidebar-accent-foreground">
                  Organisation Strategy Studio
                </p>
                <p className="mt-0.5 text-[9px] font-medium uppercase tracking-[0.18em] text-sidebar-foreground/60">
                  Design · Simulation · Transform
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSidebarCollapsed(true)}
                aria-label="Collapse sidebar"
                title="Collapse sidebar"
                className="flex size-7 shrink-0 items-center justify-center rounded-md text-sidebar-foreground/60 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              >
                <PanelLeftClose className="size-4" />
              </button>
            </>
          )}
        </div>

        {sidebarCollapsed ? (
          <>
            <nav className="mt-2 flex flex-1 flex-col items-center gap-1 px-2 pb-3">
              <button
                type="button"
                onClick={() => setSidebarCollapsed(false)}
                title={`Active scenario: ${scenario?.name ?? "none"} — expand to switch`}
                aria-label="Expand sidebar to switch scenario"
                className="mb-1 flex size-9 items-center justify-center rounded-lg border border-brand/30 bg-brand/10 font-display text-[10px] font-bold uppercase text-brand"
              >
                {scenario ? (scenario.kind === "future" ? "F" : "C") : "–"}
              </button>
              {TOP_NAV.map((item) => {
                const active = pathname === item.to;
                return (
                  <Link
                    key={item.to}
                    to={item.to}
                    title={item.label}
                    aria-label={item.label}
                    className={cn(
                      "flex size-9 items-center justify-center rounded-lg transition-colors",
                      active
                        ? "bg-sidebar-accent text-sidebar-accent-foreground"
                        : "text-sidebar-foreground/75 hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground",
                    )}
                  >
                    <item.icon className={cn("size-4", active ? "text-brand" : "")} />
                  </Link>
                );
              })}
              <div className="my-2 h-px w-6 bg-sidebar-border/70" />
              {NAV_GROUPS.map((group) => {
                const active = group.items.some((i) => i.to === pathname);
                return (
                  <Link
                    key={group.id}
                    to={group.to}
                    title={group.label}
                    aria-label={group.label}
                    className={cn(
                      "flex size-9 items-center justify-center rounded-lg transition-colors",
                      active
                        ? "bg-sidebar-accent text-sidebar-accent-foreground"
                        : "text-sidebar-foreground/75 hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground",
                    )}
                  >
                    <group.icon className={cn("size-4", active ? "text-brand" : "")} />
                  </Link>
                );
              })}
            </nav>
            <a
              href="mailto:enterprise@orgeasy.app?subject=Pilot%20support%20—%20Organisation%20Strategy%20Studio"
              title="Talk to us about your data"
              aria-label="Talk to us about your data"
              className="mx-2 mb-1 flex items-center justify-center rounded-md border border-sidebar-border p-2 text-sidebar-foreground/70 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            >
              <LifeBuoy className="size-4" />
            </a>
            <Link
              to="/auth"
              title={account ? account.email : "Sign in to workspace"}
              aria-label={account ? account.email : "Sign in to workspace"}
              className="m-2 mt-0 flex items-center justify-center rounded-md border border-sidebar-border bg-sidebar-accent/40 p-2.5 text-sidebar-accent-foreground transition-colors hover:bg-sidebar-accent"
            >
              <UserCircle2 className="size-4" />
            </Link>
          </>
        ) : (
          <>
        <div className="sticky top-[65px] z-20 shrink-0 border-b border-sidebar-border bg-sidebar px-4 pb-4 pt-3">
          <ScenarioTour replayKey={replayTour} />
          <div
            className={cn(
              "rounded-lg border border-sidebar-border bg-sidebar-accent/40 p-3 transition-shadow",
              spotlight && "ring-2 ring-brand/60 animate-pulse",
            )}
          >
            <div className="mb-2 flex items-center justify-between gap-2">
              <p className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-sidebar-accent-foreground">
                <Layers className="size-3.5 text-brand" />
                Active scenario
              </p>
              <div className="flex items-center gap-0.5">
                <button
                  type="button"
                  disabled={!scenario || renaming || !can("manageScenarios")}
                  onClick={() => {
                    setRenameValue(scenario?.name ?? "");
                    setRenaming(true);
                  }}
                  aria-label="Rename scenario"
                  title="Rename scenario"
                  className="flex size-6 items-center justify-center rounded-md text-sidebar-foreground/60 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground disabled:opacity-40"
                >
                  <Pencil className="size-3" />
                </button>
              <button
                type="button"
                disabled={!scenario || renaming || !can("manageScenarios")}
                onClick={() => {
                    if (!scenario) return;
                    const order = nextPhaseOrder(workspace.scenarios);
                    const copyName = `${scenario.name} (copy)`;
                    createScenario(copyName, scenario.id, {
                      kind: "future",
                      phaseLabel: `Phase ${order}`,
                      description: scenario.description
                        ? scenario.description
                        : `Duplicated from “${scenario.name}”.`,
                    });
                    toast.success(`Duplicated as "${copyName}"`, {
                      description:
                        current && current.id !== scenario.id
                          ? `Impact vs ${current.name}: ${impactSnapshot(current.employees, scenario.employees, scenario.currency)}`
                          : "All roles, budgets and ADKAR data were copied.",
                    });
                  }}
                  aria-label="Duplicate scenario"
                  title="Duplicate scenario"
                  className="flex size-6 items-center justify-center rounded-md text-sidebar-foreground/60 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground disabled:opacity-40"
                >
                  <Copy className="size-3" />
                </button>
                <span className="ml-1 flex items-center gap-1.5 rounded-full border border-brand/30 bg-brand/10 px-2 py-0.5 text-[9px] font-semibold uppercase tracking-wide text-brand">
                  <span className="size-1.5 rounded-full bg-brand" />
                  {scenario?.kind === "future" ? "Future" : "Current"}
                </span>
              </div>
            </div>
            {renaming ? (
              <div className="flex items-center gap-1.5">
                <Input
                  autoFocus
                  value={renameValue}
                  onChange={(e) => setRenameValue(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") commitRename();
                    if (e.key === "Escape") setRenaming(false);
                  }}
                  aria-label="Scenario name"
                  className="h-10 border-sidebar-border bg-sidebar text-[13px] font-medium text-sidebar-accent-foreground"
                />
                <Button
                  size="icon"
                  onClick={commitRename}
                  aria-label="Save scenario name"
                  className="size-9 shrink-0"
                >
                  <Check className="size-4" />
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => setRenaming(false)}
                  aria-label="Cancel rename"
                  className="size-9 shrink-0 text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                >
                  <X className="size-4" />
                </Button>
              </div>
            ) : (
            <div className="flex items-center gap-1.5">
            <Select value={scenario?.id ?? ""} onValueChange={setActiveScenario}>
              <SelectTrigger className="h-auto min-h-[52px] w-full min-w-0 items-center gap-2.5 rounded-lg border-sidebar-border/70 bg-sidebar px-2.5 py-2 text-left transition-colors hover:bg-sidebar-accent/50">
                <span className="flex size-8 shrink-0 items-center justify-center rounded-md border border-brand/25 bg-brand/10 font-display text-[10px] font-bold uppercase tracking-wide text-brand">
                  {scenario ? (scenario.kind === "future" ? "F" : "C") : "–"}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[13px] font-medium leading-tight text-sidebar-accent-foreground">
                    {scenario ? scenario.name : "Select scenario"}
                  </span>
                  <span className="mt-0.5 block truncate text-[10px] leading-tight text-sidebar-foreground/60">
                    {scenario
                      ? `${phaseTitle(scenario)} · ${scenario.employees.length} roles`
                      : "Choose a scenario"}
                  </span>
                </span>
              </SelectTrigger>
              <SelectContent className="max-h-72 w-[var(--radix-select-trigger-width)] min-w-[15rem]">
                {(current ? [current, ...phases] : phases).map((s) => (
                  <SelectItem key={s.id} value={s.id} className="items-start py-2">
                    <span className="flex w-full min-w-0 flex-col gap-1 pr-6">
                      <span className="flex min-w-0 items-center gap-2">
                        <span className="min-w-0 flex-1 truncate text-[13px] font-medium leading-tight">
                          {s.name}
                        </span>
                        <span
                          className={cn(
                            "shrink-0 whitespace-nowrap rounded-full px-1.5 py-0.5 text-[9px] font-semibold uppercase leading-none tracking-wide",
                            s.kind === "future"
                              ? "bg-brand/15 text-brand"
                              : "bg-muted text-muted-foreground",
                          )}
                        >
                          {phaseTitle(s)}
                        </span>
                      </span>
                      <span className="truncate text-[10.5px] leading-tight text-muted-foreground">
                        {s.employees.length} role{s.employees.length === 1 ? "" : "s"} · updated{" "}
                        {relativeTime(s.updatedAt ?? s.createdAt)}
                      </span>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            </div>
            )}
            {scenario?.id === CURRENT_STATE_ID ? (
              <p className="mt-1.5 flex items-center gap-1.5 text-[10.5px] leading-tight text-sidebar-foreground/80">
                <Lock className="size-3 text-brand" />
                Fixed demo data – numbers do not change on refresh
              </p>
            ) : null}
            <Button
              onClick={() => {
                setKind("future");
                pickTemplate("blank");
                setOpen(true);
              }}
              disabled={!can("manageScenarios")}
              title={
                can("manageScenarios")
                  ? "Create a new scenario"
                  : `${ROLE_META[role].label}s can't create scenarios`
              }
              className={cn(
                "mt-2 h-9 w-full gap-1.5 text-[12.5px] font-semibold",
                phases.length === 0 && "animate-pulse",
              )}
            >
              <Plus className="size-4" /> Create scenario
            </Button>
            {phases.length > 0 ? (
              <Button
                asChild
                variant="outline"
                className="mt-1.5 h-8 w-full gap-1.5 border-sidebar-border bg-transparent text-[12px] font-medium text-sidebar-accent-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              >
                <Link to="/scenario-compare">
                  <Columns3 className="size-3.5" /> Compare side by side
                </Link>
              </Button>
            ) : null}
            {phases.length === 0 ? (
              <p className="mt-1.5 text-[10.5px] text-sidebar-foreground/70">
                Start here — add your first future state to compare against today.
              </p>
            ) : null}
            <p className="mt-2 text-[11px] text-sidebar-foreground/75">
              Everything on every page reflects this scenario ·{" "}
              {phases.length} future phase{phases.length === 1 ? "" : "s"} planned
            </p>
            <SidebarPhaseOrder />
          </div>
          <div className="mt-2 space-y-0.5">
            <button
              onClick={() => {
                const source = phases[phases.length - 1] ?? current;
                addNextPhase();
                toast.success(`Phase ${nextPhaseOrder(workspace.scenarios)} added`, {
                  description: source
                    ? `Impact vs ${current?.name ?? "today"}: ${impactSnapshot(current?.employees, source.employees, source.currency)}`
                    : undefined,
                });
              }}
              disabled={!can("manageScenarios")}
              title={
                can("manageScenarios")
                  ? "Add the next phase after the current one"
                  : `${ROLE_META[role].label}s can't add phases`
              }
              className="flex w-full items-center gap-1.5 rounded-md px-2 py-1.5 text-[12px] text-sidebar-foreground/80 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground disabled:cursor-not-allowed disabled:opacity-50"
            >
              <Layers className="size-3.5" /> Add next phase
            </button>
          </div>
        </div>

        <nav className="mt-3 flex-1 px-3 pb-3">
          <div className="space-y-1">
            {TOP_NAV.map((item) => {
              const active = pathname === item.to;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "group flex items-center gap-2.5 rounded-lg px-3 py-2 text-[13px] font-medium transition-colors",
                    active
                      ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-[inset_2px_0_0_0_var(--color-brand)]"
                      : "text-sidebar-foreground/85 hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground",
                  )}
                >
                  <item.icon
                    className={cn(
                      "size-4 transition-colors",
                      active
                        ? "text-brand"
                        : "text-sidebar-foreground/55 group-hover:text-sidebar-foreground",
                    )}
                  />
                  {item.label}
                </Link>
              );
            })}
          </div>

          <div className="mx-2 my-3.5 h-px bg-sidebar-border/70" />

          <div className="space-y-1.5">
            {NAV_GROUPS.map((group) => {
              const expanded = isGroupOpen(group.id);
              const containsActive = activeGroup === group.id;
              return (
                <div key={group.id}>
                  <div
                    className={cn(
                      "group flex w-full items-center rounded-lg text-[12.5px] font-semibold transition-colors",
                      containsActive
                        ? "bg-sidebar-accent/50 text-sidebar-accent-foreground"
                        : "text-sidebar-foreground/75 hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground",
                    )}
                  >
                    <Link
                      to={group.to}
                      className="flex min-w-0 flex-1 items-center gap-2.5 rounded-l-lg px-3 py-2"
                    >
                      <group.icon
                        className={cn(
                          "size-4 shrink-0 transition-colors",
                          containsActive
                            ? "text-brand"
                            : "text-sidebar-foreground/50 group-hover:text-sidebar-foreground",
                        )}
                      />
                      <span className="min-w-0 flex-1 text-left">{group.label}</span>
                    </Link>
                    <button
                      type="button"
                      aria-label={`${expanded ? "Collapse" : "Expand"} ${group.label}`}
                      aria-expanded={expanded}
                      onClick={() => toggleGroup(group.id)}
                      className="flex size-8 shrink-0 items-center justify-center rounded-r-lg text-sidebar-foreground/70 hover:text-sidebar-accent-foreground"
                    >
                      <ChevronDown
                        className={cn(
                          "size-3.5 opacity-60 transition-transform duration-200",
                          expanded ? "rotate-0" : "-rotate-90",
                        )}
                      />
                    </button>
                  </div>
                  {expanded ? (
                    <div className="ml-5 mt-1 space-y-0.5 border-l border-sidebar-border/60 pl-2.5">
                      {group.items.map((item) => {
                        const active = pathname === item.to;
                        return (
                          <Link
                            key={item.to}
                            to={item.to}
                            className={cn(
                              "group flex items-center gap-2 rounded-md px-2.5 py-1.5 text-[12px] font-medium transition-colors",
                              active
                                ? "bg-brand/10 text-sidebar-accent-foreground shadow-[inset_2px_0_0_0_var(--color-brand)]"
                                : "text-sidebar-foreground/65 hover:bg-sidebar-accent/40 hover:text-sidebar-accent-foreground",
                            )}
                          >
                            <item.icon
                              className={cn(
                                "size-3.5 transition-colors",
                                active
                                  ? "text-brand"
                                  : "text-sidebar-foreground/45 group-hover:text-sidebar-foreground/80",
                              )}
                            />
                            {item.label}
                          </Link>
                        );
                      })}
                    </div>
                  ) : null}
                </div>
              );
            })}
          </div>
        </nav>

        <div className="mx-3 mt-1 flex items-center justify-between gap-2 text-[11px] text-sidebar-foreground/65">
          <span className="truncate">
            {tourDone
              ? `Tour completed${tourAt ? ` · ${relativeTime(tourAt)}` : ""}`
              : "Tour not completed"}
          </span>
          <button
            type="button"
            onClick={() => {
              resetScenarioTour();
              setTourDone(false);
              setTourAt(null);
              setReplayTour((n) => n + 1);
              toast.success("Tour restarted");
            }}
            className="shrink-0 rounded px-1.5 py-0.5 font-medium text-sidebar-foreground/85 underline-offset-2 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:underline"
          >
            Reset tour
          </button>
        </div>

        <div className="mx-3 mb-1 flex items-center justify-between gap-2 text-[11px] text-sidebar-foreground/65">
          <button
            type="button"
            onClick={() => window.dispatchEvent(new Event(QUICKSTART_REPLAY_EVENT))}
            className="rounded px-1.5 py-0.5 font-medium text-sidebar-foreground/85 underline-offset-2 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:underline"
          >
            Quick start
          </button>
          <a
            href="mailto:enterprise@orgeasy.app?subject=Pilot%20support%20—%20Organisation%20Strategy%20Studio"
            className="flex items-center gap-1 truncate rounded px-1.5 py-0.5 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
          >
            <LifeBuoy className="size-3 shrink-0" />
            Talk to us about your data
          </a>
        </div>

        <Link
          to="/auth"
          className="m-3 mt-1 flex items-center gap-2.5 rounded-md border border-sidebar-border bg-sidebar-accent/40 px-3 py-2.5 text-[12px] text-sidebar-accent-foreground transition-colors hover:bg-sidebar-accent"
        >
          <UserCircle2 className="size-4 shrink-0 text-sidebar-foreground" />
          <span className="truncate">{account ? account.email : "Sign in to workspace"}</span>
          <span
            className={cn(
              "ml-auto shrink-0 rounded-full border px-1.5 py-px text-[9px] font-semibold uppercase tracking-wide",
              ROLE_META[role].badgeClass,
            )}
          >
            {ROLE_META[role].label}
          </span>
        </Link>
          </>
        )}
      </aside>

      <div className="flex h-full min-w-0 flex-1 flex-col">
        <header className="shrink-0 border-b border-border bg-background">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-2 px-4 py-2">
            <div className="min-w-0">
              <p className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">
                Organisation Strategy Studio
              </p>
              <p className="truncate font-display text-[15px] font-semibold leading-tight tracking-tight">
                {pageTitle}
              </p>
            </div>
            <div className="hidden h-7 w-px bg-border sm:block" />
            <Select value={scenario?.id ?? ""} onValueChange={setActiveScenario}>
              <SelectTrigger className="h-8 w-52 max-w-[38vw] text-[12.5px]">
                <SelectValue placeholder="Select scenario" />
              </SelectTrigger>
              <SelectContent>
                {workspace.scenarios.map((s) => (
                  <SelectItem key={s.id} value={s.id}>
                    {scenarioLabel(s)} · {s.employees.length} roles
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {/* Page-level actions (search, add role, export…) portal in here. */}
            <div className="ml-auto flex items-center gap-1.5">
              <BoardPackButton />
              <div
                ref={setChromeActionsEl}
                className="flex flex-wrap items-center justify-end gap-1.5 empty:hidden"
              />
            </div>
          </div>
          {/* Live metrics strip portals in here on design views. */}
          <div
            ref={setChromeMetricsEl}
            className="border-border/60 px-4 empty:hidden [&:not(:empty)]:border-t [&:not(:empty)]:py-1.5"
          />
        </header>
        <main className="min-h-0 flex-1 overflow-y-auto">{children}</main>
        <QuickStart />
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create scenario</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <button
              type="button"
              onClick={() => {
                setOpen(false);
                navigate({ to: "/packs" });
              }}
              className="flex w-full items-start gap-2 rounded-lg border border-brand/50 bg-brand/10 p-3 text-left transition hover:bg-brand/15"
            >
              <Car className="mt-0.5 size-4 text-brand" />
              <span>
                <span className="block text-[13px] font-semibold">Start from an industry pack</span>
                <span className="block text-[11px] leading-snug text-muted-foreground">
                  Generate a realistic automotive operating model (400–600 positions), human or Human + AI Agent.
                </span>
              </span>
            </button>
            <div className="space-y-1.5">
              <Label>Start from a template</Label>
              <div className="grid grid-cols-2 gap-2">
                {SCENARIO_TEMPLATES.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => pickTemplate(t.id)}
                    aria-pressed={templateId === t.id}
                    className={cn(
                      "rounded-lg border p-2.5 text-left transition-colors",
                      templateId === t.id
                        ? "border-brand bg-brand/5 ring-1 ring-brand/40"
                        : "border-border hover:bg-muted/60",
                    )}
                  >
                    <span className="flex items-center justify-between gap-2">
                      <span className="text-[13px] font-semibold">{t.label}</span>
                      {templateId === t.id ? <Check className="size-3.5 text-brand" /> : null}
                    </span>
                    <span className="mt-0.5 block text-[11px] leading-snug text-muted-foreground">
                      {t.tagline}
                    </span>
                  </button>
                ))}
              </div>
              <ul className="mt-1 space-y-0.5 rounded-md bg-muted/50 px-2.5 py-2 text-[11px] text-muted-foreground">
                {getScenarioTemplate(templateId).prefills.map((p) => (
                  <li key={p} className="flex gap-1.5">
                    <span className="text-brand">•</span>
                    <span>{p}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="scenario-name">Scenario name</Label>
              <Input id="scenario-name" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Scenario type</Label>
                <Select value={kind} onValueChange={(v) => setKind(v as "current" | "future")}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="future">Future state (phase)</SelectItem>
                    <SelectItem value="current">Current state (baseline)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="phase-label">Phase label</Label>
                <Input
                  id="phase-label"
                  placeholder="Phase 2 — Q1 2027"
                  disabled={kind === "current"}
                  value={phaseLabel}
                  onChange={(e) => setPhaseLabel(e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Start from</Label>
              <Select value={cloneFrom} onValueChange={setCloneFrom}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Empty scenario</SelectItem>
                  {workspace.scenarios.map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      Copy of {s.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {kind === "future" ? (
              <div className="space-y-1.5">
                <Label>Compare against</Label>
                <Select value={baselineId} onValueChange={setBaselineId}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="auto">Automatic (previous phase)</SelectItem>
                    {workspace.scenarios.map((s) => (
                      <SelectItem key={s.id} value={s.id}>
                        {s.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ) : null}
            <Button
              className="w-full"
              onClick={() => {
                if (!name.trim()) return;
                const template = getScenarioTemplate(templateId);
                const source = workspace.scenarios.find((s) => s.id === cloneFrom);
                createScenario(name.trim(), cloneFrom === "none" ? undefined : cloneFrom, {
                  kind,
                  ...(template.id === "blank" ? {} : { description: template.description }),
                  ...(kind === "current"
                    ? { phaseOrder: 0, phaseLabel: "", baselineId: null }
                    : {
                        phaseLabel: phaseLabel.trim(),
                        baselineId:
                          baselineId === "auto"
                            ? cloneFrom === "none"
                              ? null
                              : cloneFrom
                            : baselineId,
                      }),
                });
                const patch = templatePatch(template, {
                  employees: source?.employees ?? [],
                  adkarGroups: source?.adkarGroups ?? [],
                });
                if (Object.keys(patch).length) updateScenario(patch);
                setOpen(false);
                const targetEmployees = patch.employees ?? source?.employees ?? [];
                const baseline =
                  kind === "future"
                    ? baselineId !== "auto"
                      ? (workspace.scenarios.find((s) => s.id === baselineId) ?? null)
                      : cloneFrom === "none"
                        ? current
                        : (source ?? null)
                    : null;
                toast.success(`Scenario "${name.trim()}" created`, {
                  description:
                    [
                      template.id !== "blank" ? `${template.label} template applied.` : null,
                      targetEmployees.length
                        ? baseline
                          ? `Impact vs ${baseline.name}: ${impactSnapshot(baseline.employees, targetEmployees, source?.currency ?? "USD")}`
                          : impactSnapshot(null, targetEmployees, source?.currency ?? "USD")
                        : null,
                    ]
                      .filter(Boolean)
                      .join(" ") || undefined,
                });
              }}
            >
              Create scenario
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
    </StudioChromeContext.Provider>
  );
}

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  const { scenario } = useOrgEasy();
  return (
    <header className="border-b border-border bg-background px-8 py-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="font-display text-[10px] font-semibold uppercase tracking-[0.2em] text-brand">
            {scenario?.name ?? "No scenario"}
          </p>
          <h1 className="mt-2 font-display text-[26px] font-medium tracking-tight">{title}</h1>
          {description ? (
            <p className="mt-2 max-w-3xl text-[13px] leading-relaxed text-muted-foreground">
              {description}
            </p>
          ) : null}
        </div>
        {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
      </div>
    </header>
  );
}
