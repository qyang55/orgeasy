import { Link } from "@tanstack/react-router";
import {
  Network,
  BarChart3,
  MessageSquareText,
  ShieldCheck,
  ArrowRight,
  Sparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";

const SECTIONS = [
  {
    id: "design",
    label: "Baseline & design",
    short: "Start from an industry pack or build your org chart, positions and operating model.",
    icon: Network,
    to: "/packs",
    color: "brand",
  },
  {
    id: "analyse",
    label: "Transformation levers",
    short: "Model headcount, span, duplicates, AI automation and compare current vs future states.",
    icon: BarChart3,
    to: "/impact",
    color: "info",
  },
  {
    id: "change",
    label: "Phased delivery",
    short: "Build the ADKAR change plan, run the comms copilot and export the leadership pack.",
    icon: MessageSquareText,
    to: "/change-plan",
    color: "warning",
  },
  {
    id: "governance",
    label: "Governance & compliance",
    short: "Review Country Guidance, privacy controls, audit logs and data deletion.",
    icon: ShieldCheck,
    to: "/compliance",
    color: "success",
  },
] as const;

const colorStyles: Record<
  (typeof SECTIONS)[number]["color"],
  { bg: string; text: string; ring: string }
> = {
  brand: { bg: "bg-brand/10", text: "text-brand", ring: "ring-brand/30" },
  info: { bg: "bg-info/10", text: "text-info", ring: "ring-info/30" },
  warning: { bg: "bg-warning/10", text: "text-warning", ring: "ring-warning/30" },
  success: { bg: "bg-success/10", text: "text-success", ring: "ring-success/30" },
};

export function WelcomePanel() {
  return (
    <section className="relative overflow-hidden rounded-2xl border border-border bg-card p-6 shadow-panel sm:p-8 animate-fade-in">
      <div className="pointer-events-none absolute -right-12 -top-12 size-64 rounded-full bg-brand/5 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-16 -left-16 size-56 rounded-full bg-info/5 blur-3xl" />

      <div className="relative">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 text-brand">
              <Sparkles className="size-4" />
              <span className="text-[11px] font-semibold uppercase tracking-widest">
                Organisation Strategy Studio
              </span>
            </div>
            <h1 className="mt-2 text-2xl font-semibold tracking-tight sm:text-3xl">
              Welcome to your transformation workspace
            </h1>
            <p className="mt-2 max-w-xl text-[13px] leading-relaxed text-muted-foreground">
              Design current and future org structures, simulate headcount and cost impact, review
              Country Guidance and export a leadership-ready PowerPoint — all in one place.
            </p>
          </div>
          <Link
            to="/chart"
            className="inline-flex items-center gap-1.5 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Open org chart <ArrowRight className="size-4" />
          </Link>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {SECTIONS.map((section, i) => {
            const Icon = section.icon;
            const styles = colorStyles[section.color];
            return (
              <Link
                key={section.id}
                to={section.to}
                className="group relative flex flex-col rounded-xl border border-border bg-background p-4 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-brand/40 hover:shadow-panel"
              >
                <span
                  className={cn(
                    "flex size-10 items-center justify-center rounded-lg",
                    styles.bg,
                    styles.text,
                  )}
                >
                  <Icon className="size-5" />
                </span>
                <h2 className="mt-3 text-[14px] font-semibold">{section.label}</h2>
                <p className="mt-1 flex-1 text-[12px] leading-relaxed text-muted-foreground">
                  {section.short}
                </p>
                <span className="mt-4 inline-flex items-center gap-1 text-[12px] font-medium text-brand transition-transform group-hover:translate-x-0.5">
                  Explore <ArrowRight className="size-3.5" />
                </span>
                <span
                  className={cn(
                    "pointer-events-none absolute inset-0 rounded-xl ring-1 ring-inset transition-opacity duration-300 opacity-0 group-hover:opacity-100",
                    styles.ring,
                  )}
                />
              </Link>
            );
          })}
        </div>

        <div className="mt-6 flex flex-wrap gap-3 text-[12px] text-muted-foreground">
          <span className="rounded-full border border-border bg-secondary px-3 py-1">
            Tip: pick an industry pack to load a starter scenario
          </span>
          <span className="rounded-full border border-border bg-secondary px-3 py-1">
            Tip: switch scenarios from the sidebar to compare states
          </span>
        </div>
      </div>
    </section>
  );
}
