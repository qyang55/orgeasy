import { AlertTriangle } from "lucide-react";
import { DISCLAIMER } from "@/lib/orgeasy/types";
import { cn } from "@/lib/utils";

export function Disclaimer({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "flex gap-3 rounded-md border border-warning/40 bg-warning/10 px-4 py-3",
        className,
      )}
    >
      <AlertTriangle className="mt-0.5 size-4 shrink-0 text-warning-foreground" />
      <p className="text-[12.5px] leading-relaxed text-warning-foreground">
        <span className="font-semibold">Important disclaimer. </span>
        {DISCLAIMER}
      </p>
    </div>
  );
}