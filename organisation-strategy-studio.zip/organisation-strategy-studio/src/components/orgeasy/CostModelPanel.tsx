/**
 * Full cost model panel: workspace assumptions plus the fixed / variable /
 * total split of a scenario's people and agent cost.
 */
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { formatMoney } from "@/lib/orgeasy/impact";
import {
  REGION_EMPLOYER_RATES,
  setCostAssumptions,
  useCostAssumptions,
  type CostModelSummary,
  type CostTotals,
} from "@/lib/orgeasy/cost-model";
import { cn } from "@/lib/utils";
import { Coins, Layers3, Receipt } from "lucide-react";

function Delta({ value, currency }: { value: number; currency: string }) {
  if (!value) return <span className="text-muted-foreground">no change</span>;
  return (
    <span className={value < 0 ? "text-success" : "text-destructive"}>
      {value < 0 ? "−" : "+"}
      {formatMoney(Math.abs(value), currency)}
    </span>
  );
}

function Block({
  label,
  icon: Icon,
  current,
  planned,
  currency,
  share,
  note,
  tone,
}: {
  label: string;
  icon: typeof Coins;
  current: number;
  planned: number;
  currency: string;
  share?: number;
  note?: string;
  tone: "fixed" | "variable" | "total";
}) {
  return (
    <div className="rounded-lg border border-border bg-card px-5 py-4 shadow-panel">
      <p className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
        <Icon className="size-3.5" /> {label}
      </p>
      <p
        className={cn(
          "mt-2 text-xl font-semibold tabular-nums",
          tone === "total" ? "text-brand" : "text-foreground",
        )}
      >
        {formatMoney(planned, currency)}
      </p>
      <p className="mt-1 text-[11.5px] text-muted-foreground tabular-nums">
        from {formatMoney(current, currency)} ·{" "}
        <Delta value={planned - current} currency={currency} />
      </p>
      {share != null ? (
        <div className="mt-3">
          <div className="h-1.5 rounded-full bg-secondary">
            <div
              className={cn(
                "h-1.5 rounded-full",
                tone === "fixed" ? "bg-brand" : "bg-warning",
              )}
              style={{ width: `${Math.min(100, Math.round(share * 100))}%` }}
            />
          </div>
          <p className="mt-1 text-[11px] text-muted-foreground">
            {Math.round(share * 100)}% of total cost
          </p>
        </div>
      ) : null}
      {note ? <p className="mt-2 text-[11px] text-muted-foreground">{note}</p> : null}
    </div>
  );
}

const lineItems: { label: string; key: keyof CostTotals; kind: "fixed" | "variable" }[] = [
  { label: "Base salary", key: "baseSalary", kind: "fixed" },
  { label: "Employer contributions", key: "employerContributions", kind: "fixed" },
  { label: "Benefits", key: "benefits", kind: "fixed" },
  { label: "Bonus & incentives", key: "variablePay", kind: "variable" },
  { label: "Agent running cost", key: "agentCost", kind: "variable" },
];

export function CostModelPanel({
  model,
  currency,
}: {
  model: CostModelSummary;
  currency: string;
}) {
  const a = useCostAssumptions();
  const regions = Object.entries(REGION_EMPLOYER_RATES)
    .map(([r, v]) => `${r} ${v}%`)
    .join(" · ");

  return (
    <section className="space-y-4">
      <div className="rounded-lg border border-border bg-card px-5 py-4 shadow-panel">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 className="text-sm font-semibold">Cost model assumptions</h2>
            <p className="mt-0.5 max-w-2xl text-[11.5px] text-muted-foreground">
              Each role is priced from its base salary and loaded with employer contributions,
              benefits, bonus and — where the role is agentic — agent running cost. Any role can
              override the benefits and bonus rates in the chart designer.
            </p>
          </div>
          <div className="flex flex-wrap items-end gap-3">
            <label className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
              Employer contributions %
              <Input
                className="mt-1 h-9 w-28"
                type="number"
                min={0}
                max={100}
                value={a.employerContributionPct}
                onChange={(e) =>
                  setCostAssumptions({ employerContributionPct: Number(e.target.value) })
                }
              />
            </label>
            <label className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
              Benefits %
              <Input
                className="mt-1 h-9 w-24"
                type="number"
                min={0}
                max={100}
                value={a.benefitsPct}
                onChange={(e) => setCostAssumptions({ benefitsPct: Number(e.target.value) })}
              />
            </label>
            <label className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
              Bonus / incentive %
              <Input
                className="mt-1 h-9 w-24"
                type="number"
                min={0}
                max={100}
                value={a.variablePayPct}
                onChange={(e) => setCostAssumptions({ variablePayPct: Number(e.target.value) })}
              />
            </label>
          </div>
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-3 border-t border-border pt-3">
          <Switch
            id="regional-rates"
            checked={a.useRegionalRates}
            onCheckedChange={(v) => setCostAssumptions({ useRegionalRates: v })}
          />
          <Label htmlFor="regional-rates" className="text-[12px] font-medium">
            Use regional employer contribution rates
          </Label>
          <span className="text-[11px] text-muted-foreground">{regions}</span>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Block
          label="Fixed cost"
          icon={Layers3}
          current={model.current.fixed}
          planned={model.planned.fixed}
          currency={currency}
          share={model.plannedFixedShare}
          note="Salary, employer contributions and benefits — committed each year."
          tone="fixed"
        />
        <Block
          label="Variable cost"
          icon={Coins}
          current={model.current.variable}
          planned={model.planned.variable}
          currency={currency}
          share={1 - model.plannedFixedShare}
          note="Bonus at target plus AI agent running cost."
          tone="variable"
        />
        <Block
          label="Total cost"
          icon={Receipt}
          current={model.current.total}
          planned={model.planned.total}
          currency={currency}
          note={`${formatMoney(model.plannedCostPerPosition, currency)} fully loaded per position · ${model.plannedLoadingFactor.toFixed(2)}× base salary`}
          tone="total"
        />
      </div>

      <div className="rounded-lg border border-border bg-card shadow-panel">
        <div className="border-b border-border px-5 py-3.5">
          <h2 className="text-sm font-semibold">Cost build-up</h2>
        </div>
        <table className="w-full text-left text-[13px]">
          <thead className="bg-secondary text-[11px] uppercase tracking-wide text-muted-foreground">
            <tr>
              {["Cost element", "Type", "Current", "Planned", "Change"].map((h) => (
                <th key={h} className="px-5 py-2.5 font-semibold">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {lineItems.map((row) => (
              <tr key={row.key} className="border-t border-border">
                <td className="px-5 py-2.5 font-medium">{row.label}</td>
                <td className="px-5 py-2.5">
                  <span
                    className={cn(
                      "rounded-full px-2 py-0.5 text-[10.5px] font-semibold uppercase tracking-wide",
                      row.kind === "fixed"
                        ? "bg-brand/10 text-brand"
                        : "bg-warning/20 text-warning-foreground",
                    )}
                  >
                    {row.kind}
                  </span>
                </td>
                <td className="px-5 py-2.5 tabular-nums text-muted-foreground">
                  {formatMoney(model.current[row.key], currency)}
                </td>
                <td className="px-5 py-2.5 tabular-nums">
                  {formatMoney(model.planned[row.key], currency)}
                </td>
                <td className="px-5 py-2.5 tabular-nums">
                  <Delta value={model.delta[row.key]} currency={currency} />
                </td>
              </tr>
            ))}
            <tr className="border-t border-border bg-secondary/50 font-semibold">
              <td className="px-5 py-2.5">Total cost of workforce</td>
              <td className="px-5 py-2.5 text-[11px] uppercase tracking-wide text-muted-foreground">
                Fixed + variable
              </td>
              <td className="px-5 py-2.5 tabular-nums">
                {formatMoney(model.current.total, currency)}
              </td>
              <td className="px-5 py-2.5 tabular-nums">
                {formatMoney(model.planned.total, currency)}
              </td>
              <td className="px-5 py-2.5 tabular-nums">
                <Delta value={model.delta.total} currency={currency} />
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="rounded-lg border border-border bg-card shadow-panel">
        <div className="border-b border-border px-5 py-3.5">
          <h2 className="text-sm font-semibold">Fixed vs variable by department</h2>
        </div>
        <table className="w-full text-left text-[13px]">
          <thead className="bg-secondary text-[11px] uppercase tracking-wide text-muted-foreground">
            <tr>
              {["Department", "Positions", "Fixed", "Variable", "Total", "Fixed share", "Change"].map(
                (h) => (
                  <th key={h} className="px-5 py-2.5 font-semibold">
                    {h}
                  </th>
                ),
              )}
            </tr>
          </thead>
          <tbody>
            {model.byDepartment.map((d) => {
              const fixedShare = d.planned.total ? d.planned.fixed / d.planned.total : 0;
              return (
                <tr key={d.department} className="border-t border-border">
                  <td className="px-5 py-2.5 font-medium">{d.department}</td>
                  <td className="px-5 py-2.5 tabular-nums">
                    {d.current.positions.toLocaleString()} → {d.planned.positions.toLocaleString()}
                  </td>
                  <td className="px-5 py-2.5 tabular-nums">
                    {formatMoney(d.planned.fixed, currency)}
                  </td>
                  <td className="px-5 py-2.5 tabular-nums">
                    {formatMoney(d.planned.variable, currency)}
                  </td>
                  <td className="px-5 py-2.5 tabular-nums font-medium">
                    {formatMoney(d.planned.total, currency)}
                  </td>
                  <td className="px-5 py-2.5 tabular-nums text-muted-foreground">
                    {Math.round(fixedShare * 100)}%
                  </td>
                  <td className="px-5 py-2.5 tabular-nums">
                    <Delta value={d.planned.total - d.current.total} currency={currency} />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}
