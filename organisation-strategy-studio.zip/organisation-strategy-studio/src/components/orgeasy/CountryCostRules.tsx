import { useMemo, useState } from "react";
import { AlertTriangle, RotateCcw, Search, SlidersHorizontal } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { formatMoney } from "@/lib/orgeasy/impact";
import {
  COUNTRY_COST_RULES,
  OVERRIDE_FIELDS,
  RISK_LEVELS,
  RISK_META,
  effectiveRules,
  isOverridden,
  type ConsultationRisk,
} from "@/lib/orgeasy/country-costs";
import type { CountryCostOverride } from "@/lib/orgeasy/types";

export function RiskBadge({ risk, className }: { risk: ConsultationRisk; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide",
        RISK_META[risk].className,
        className,
      )}
    >
      {risk === "High" ? <AlertTriangle className="size-3" /> : null}
      {RISK_META[risk].label} risk
    </span>
  );
}

/**
 * Editable Country Cost Rules module. Edits are stored as per-scenario
 * overrides so each scenario can hold its own separation-cost assumptions.
 */
export function CountryCostRules({ currency = "USD" }: { currency?: string }) {
  const { scenario, updateScenario } = useOrgEasy();
  const [query, setQuery] = useState("");
  const rules = useMemo(() => effectiveRules(scenario), [scenario]);

  const overrides = scenario?.countryCostOverrides ?? {};

  function patch(country: string, next: CountryCostOverride) {
    const merged = { ...(overrides[country] ?? {}), ...next };
    for (const key of Object.keys(merged) as (keyof CountryCostOverride)[]) {
      if (merged[key] === undefined || Number.isNaN(merged[key] as number)) delete merged[key];
    }
    const all = { ...overrides, [country]: merged };
    if (!Object.keys(merged).length) delete all[country];
    updateScenario({ countryCostOverrides: all });
  }

  function resetCountry(country: string) {
    const all = { ...overrides };
    delete all[country];
    updateScenario({ countryCostOverrides: all });
  }

  const filtered = rules.filter((r) =>
    `${r.country} ${r.region}`.toLowerCase().includes(query.trim().toLowerCase()),
  );
  const overrideCount = Object.keys(overrides).length;

  return (
    <section className="rounded-lg border border-border bg-card shadow-panel">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-5 py-3.5">
        <div>
          <h2 className="flex items-center gap-2 text-sm font-semibold">
            <SlidersHorizontal className="size-4 text-brand" /> Country cost rules
          </h2>
          <p className="mt-0.5 text-[11.5px] text-muted-foreground">
            {COUNTRY_COST_RULES.length} markets. Edit any value to override the assumption for this
            scenario only — illustrative heuristics, not legal advice.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {overrideCount ? (
            <Button
              variant="outline"
              size="sm"
              className="gap-1.5"
              onClick={() => updateScenario({ countryCostOverrides: {} })}
            >
              <RotateCcw className="size-3.5" /> Reset {overrideCount} override
              {overrideCount === 1 ? "" : "s"}
            </Button>
          ) : null}
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 size-3.5 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Find a market…"
              className="h-9 w-52 pl-8"
            />
          </div>
        </div>
      </div>

      <div className="max-h-[520px] overflow-auto">
        <table className="w-full text-left text-[12.5px]">
          <thead className="sticky top-0 bg-secondary text-[10.5px] uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-4 py-2.5 font-semibold">Market</th>
              {OVERRIDE_FIELDS.map((f) => (
                <th key={f.key} className="px-3 py-2.5 font-semibold">
                  {f.label}
                </th>
              ))}
              <th className="px-3 py-2.5 font-semibold">Consultation risk</th>
              <th className="px-3 py-2.5 font-semibold">Non-payroll cost / exit</th>
              <th className="px-3 py-2.5" />
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filtered.map((r) => {
              const dirty = isOverridden(scenario, r.country);
              return (
                <tr key={r.country} className={cn(dirty && "bg-brand/5")}>
                  <td className="px-4 py-2.5">
                    <p className="font-medium">{r.country}</p>
                    <p className="text-[11px] text-muted-foreground">{r.region}</p>
                  </td>
                  {OVERRIDE_FIELDS.map((f) => (
                    <td key={f.key} className="px-3 py-2">
                      <Input
                        type="number"
                        step={f.step}
                        min={0}
                        className="h-8 w-24 tabular-nums"
                        value={r[f.key]}
                        onChange={(e) =>
                          patch(r.country, { [f.key]: Number(e.target.value) } as CountryCostOverride)
                        }
                      />
                    </td>
                  ))}
                  <td className="px-3 py-2">
                    <div className="flex gap-1">
                      {RISK_LEVELS.map((level) => (
                        <button
                          key={level}
                          type="button"
                          onClick={() => patch(r.country, { risk: level })}
                          aria-pressed={r.risk === level}
                          className={cn(
                            "rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase",
                            r.risk === level
                              ? RISK_META[level].className
                              : "bg-secondary text-muted-foreground",
                          )}
                        >
                          {level}
                        </button>
                      ))}
                    </div>
                    <p className="mt-1 max-w-[260px] text-[11px] leading-snug text-muted-foreground">
                      {r.riskNote}
                    </p>
                  </td>
                  <td className="px-3 py-2 tabular-nums">
                    {formatMoney(
                      r.legalFeePerExit + r.outplacementPerExit + r.adminPerExit,
                      currency,
                    )}
                    <p className="text-[11px] text-muted-foreground">
                      + tribunal exposure ≈{" "}
                      {formatMoney(
                        Math.round((r.claimRatePct / 100) * r.defenceCostPerClaim),
                        currency,
                      )}{" "}
                      per exit plus {r.avgClaimMonths} months&rsquo; pay per claim
                    </p>
                    <p className="mt-1 max-w-[260px] text-[11px] leading-snug text-muted-foreground">
                      {r.legalNote}
                    </p>
                    <p className="mt-1 max-w-[240px] text-[11px] leading-snug text-muted-foreground">
                      {r.formulaNote}
                    </p>
                  </td>
                  <td className="px-3 py-2">
                    {dirty ? (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="gap-1 text-[11px]"
                        onClick={() => resetCountry(r.country)}
                      >
                        <RotateCcw className="size-3" /> Reset
                      </Button>
                    ) : null}
                  </td>
                </tr>
              );
            })}
            {!filtered.length ? (
              <tr>
                <td colSpan={10} className="px-4 py-8 text-center text-xs text-muted-foreground">
                  No market matches “{query}”.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </section>
  );
}