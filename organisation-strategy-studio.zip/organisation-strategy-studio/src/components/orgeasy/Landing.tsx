import { Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BookOpen,
  Calculator,
  Check,
  Compass,
  Factory,
  FileBarChart2,
  Layers,
  Presentation,
  ShieldCheck,
  Users,
  Workflow,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import orgeasyLogo from "@/assets/orgeasy-logo.png";

const NAV_LINKS = [
  { label: "Product", href: "#product" },
  { label: "Enterprise", href: "#enterprise" },
  { label: "Pilot & plans", href: "#pilot" },
  { label: "Use Cases", href: "#use-cases" },
  { label: "Resources", href: "#resources" },
];

const FEATURES = [
  {
    icon: Workflow,
    title: "Intelligent org modelling & simulation",
    body: "Design current and future structures on a live canvas — drag, re-parent and resize roles, model dotted-line reporting, COE/GBS structures and human + AI agent hybrid roles.",
  },
  {
    icon: Calculator,
    title: "Cost, headcount & risk impact",
    body: "Country-specific cost models across 22 markets — salary, benefits, severance, legal fees and tribunal risk — split into fixed, variable and one-off programme costs.",
  },
  {
    icon: Layers,
    title: "Phased transformation planning",
    body: "Sequence options into phases, reorder them as plans evolve, compare scenarios side by side, and track change readiness with built-in ADKAR action plans.",
  },
  {
    icon: Presentation,
    title: "Board-ready PowerPoint export",
    body: "One click turns any scenario into an editable leadership deck or a one-page decision summary — the numbers boards actually ask for, without the spreadsheet gymnastics.",
  },
];

const CAPABILITIES = [
  "Span-of-control analysis",
  "Duplicate role detection",
  "Automation opportunity analyzer",
  "Excel / CSV import with mapping wizard",
  "Extracts from Workday · SAP SuccessFactors · Oracle HCM",
  "API & bi-directional integrations on Enterprise plans",
  "Version history & snapshots",
  "Country guidance library",
];

const AUDIENCES: {
  icon: typeof Users;
  title: string;
  body: string;
  to?: "/packs";
  search?: { generate: "automotive" };
  linkLabel?: string;
}[] = [
  {
    icon: Users,
    title: "HR & people leaders",
    body: "Answer “what if” before it becomes “what now” — headcount, cost and consultation risk quantified for every option you put on the table.",
  },
  {
    icon: Compass,
    title: "Transformation & PMO teams",
    body: "Run restructuring programmes with phased roadmaps, lever-level impact and a hiring pipeline for the roles the future state creates.",
  },
  {
    icon: Workflow,
    title: "Organisation designers",
    body: "Model spans, layers and operating blueprints at enterprise scale — from 200 to 1,000,000 positions — with data health checks built in.",
  },
  {
    icon: Factory,
    title: "Automotive & enterprise operating models",
    body: "Start from industry packs with size-aware benchmarks, including JV-heavy markets across China, ASEAN, India and MEA.",
    to: "/packs",
    search: { generate: "automotive" as const },
    linkLabel: "Generate an automotive model — one click",
  },
];

type TrustStatus = "Available" | "Enterprise plan" | "On roadmap";

const TRUST_STATUS_STYLES: Record<TrustStatus, string> = {
  Available: "border-success/30 bg-success/10 text-success",
  "Enterprise plan": "border-brand/25 bg-brand-subtle text-brand",
  "On roadmap": "border-border bg-surface-3 text-muted-foreground",
};

const TRUST: { title: string; body: string; status: TrustStatus }[] = [
  {
    title: "Role-based access control",
    body: "Admin, editor and viewer roles, scoped per workspace.",
    status: "Enterprise plan",
  },
  {
    title: "Single sign-on (SSO)",
    body: "SAML / OIDC — Okta, Microsoft Entra ID and Google Workspace.",
    status: "Enterprise plan",
  },
  {
    title: "Audit logs",
    body: "Who changed what, and when — across scenarios, structures and exports.",
    status: "On roadmap",
  },
  {
    title: "Encryption in transit & at rest",
    body: "All workspace data encrypted in transit and at rest.",
    status: "Available",
  },
  {
    title: "GDPR-ready data handling",
    body: "Built-in consent controls, with full customer data deletion on request.",
    status: "Available",
  },
  {
    title: "SOC 2 Type II",
    body: "Compliance programme in progress — report shared on completion.",
    status: "On roadmap",
  },
  {
    title: "Isolated workspaces",
    body: "Multi-tenancy for business units, regions or client engagements.",
    status: "Enterprise plan",
  },
  {
    title: "Data residency options",
    body: "Regional hosting for enterprise workspaces, agreed during onboarding.",
    status: "Enterprise plan",
  },
  {
    title: "Security reviews & NDAs",
    body: "Security questionnaires supported; NDA available before any pilot data is shared.",
    status: "Available",
  },
];

const PILOT_STEPS = [
  "Data load & validation — Excel / CSV or an HRIS extract",
  "Model 2–3 future-state options with cost, risk and health impact",
  "Working session with your OD / transformation team",
  "Board-ready pack delivered",
];

const ENTERPRISE_MAILTO = "mailto:enterprise@orgeasy.app?subject=Pilot%20request";

const PLANS: {
  name: string;
  price: string;
  tagline: string;
  points: string[];
  cta: string;
  to?: "/dashboard";
  search?: { demo: "guided" };
  href?: string;
  highlight?: boolean;
}[] = [
  {
    name: "Demo",
    price: "Free",
    tagline: "The fastest way to see the studio.",
    points: [
      "Pre-loaded sample organisation",
      "Three pre-built scenarios",
      "Every export type included",
    ],
    cta: "Open the studio",
    to: "/dashboard",
    search: { demo: "guided" },
  },
  {
    name: "Pilot",
    price: "4 weeks",
    tagline: "Prove value on your own data.",
    points: [
      "Data load & validation included",
      "2–3 costed future-state options",
      "Working session with your OD team",
      "Named support throughout",
    ],
    cta: "Request a pilot",
    href: ENTERPRISE_MAILTO,
    highlight: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    tagline: "Roll out with full governance.",
    points: [
      "SSO (SAML / OIDC) & role-based access",
      "Isolated workspaces per unit or client",
      "API & bi-directional HRIS integrations",
      "Dedicated onboarding & support",
    ],
    cta: "Contact for enterprise pricing",
    href: ENTERPRISE_MAILTO,
  },
];

const RESOURCES = [
  {
    icon: BookOpen,
    title: "Country guidance library",
    body: "Consultation thresholds, notice, severance and tribunal risk across 22 markets.",
    to: "/compliance",
  },
  {
    icon: Compass,
    title: "ADKAR change toolkit",
    body: "Turn any scenario into an actionable change plan with readiness tracking.",
    to: "/change-plan",
  },
  {
    icon: FileBarChart2,
    title: "Leadership deck gallery",
    body: "See the executive narrative and full appendix exports the studio generates.",
    to: "/exports",
  },
];

function SectionHeading({
  eyebrow,
  title,
  body,
}: {
  eyebrow: string;
  title: string;
  body?: string;
}) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      <p className="font-display text-[11px] font-bold uppercase tracking-[0.2em] text-brand">
        {eyebrow}
      </p>
      <h2 className="mt-3 font-display text-[30px] font-semibold leading-[1.15] tracking-tight text-foreground sm:text-[36px]">
        {title}
      </h2>
      {body ? <p className="mt-4 text-[15px] leading-relaxed text-muted-foreground">{body}</p> : null}
    </div>
  );
}

export function Landing() {
  return (
    <div className="landing min-h-screen scroll-smooth bg-background font-sans text-foreground antialiased">
      {/* ── 1. Top navigation ─────────────────────────────────────────── */}
      <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
          <Link to="/welcome" className="flex items-center gap-2.5">
            <img
              src={orgeasyLogo}
              alt="Organisation Strategy Studio logo"
              width={34}
              height={34}
              className="size-[34px] rounded-lg"
            />
            <span className="font-display text-[15px] font-semibold tracking-tight">
              Organisation Strategy Studio
            </span>
          </Link>
          <nav className="hidden items-center gap-7 lg:flex">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-[13.5px] font-medium text-muted-foreground transition-colors hover:text-foreground"
              >
                {link.label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild>
              <Link to="/auth">Log in</Link>
            </Button>
            <Button size="sm" asChild>
              <Link to="/dashboard" search={{ demo: "guided" }}>
                Open the studio
                <ArrowRight />
              </Link>
            </Button>
          </div>
        </div>
      </header>

      {/* ── 2. Hero ───────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              "radial-gradient(52rem 30rem at 78% -8%, oklch(0.58 0.10 55 / 10%), transparent 65%), radial-gradient(40rem 26rem at 8% 12%, oklch(0.72 0.10 85 / 8%), transparent 60%)",
          }}
        />
        <div className="relative mx-auto grid max-w-6xl items-center gap-14 px-6 pb-20 pt-16 lg:grid-cols-[1.02fr_1fr] lg:pt-24">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full border border-brand/25 bg-brand-subtle px-3 py-1.5 font-display text-[10.5px] font-bold uppercase tracking-[0.18em] text-brand">
              <span className="size-1.5 rounded-full bg-brand" />
              Organisation design · Simulation · Transformation
            </p>
            <h1 className="mt-6 font-display text-[40px] font-semibold leading-[1.06] tracking-tight text-foreground sm:text-[52px]">
              Model, simulate and transform your organisation with confidence
            </h1>
            <p className="mt-5 max-w-xl text-[16px] leading-relaxed text-muted-foreground">
              Organisation Strategy Studio turns your HRIS data into living org models. Simulate
              restructuring, headcount, cost and risk scenarios in minutes — and walk into every
              leadership meeting with board-ready answers.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Button size="lg" className="px-6" asChild>
                <Link to="/dashboard" search={{ demo: "guided" }}>
                  Start free
                  <ArrowRight />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="px-5" asChild>
                <Link to="/auth">Continue with Google</Link>
              </Button>
              <Button size="lg" variant="outline" className="px-5" asChild>
                <Link to="/auth">Continue with Microsoft</Link>
              </Button>
            </div>
            <p className="mt-4 text-[12.5px] text-muted-foreground">
              Free demo workspace · No credit card ·{" "}
              <Link
                to="/packs"
                search={{ generate: "automotive" }}
                className="font-medium text-brand hover:underline"
              >
                see an automotive operating model →
              </Link>{" "}
              ·{" "}
              <a href="#pilot" className="font-medium text-brand hover:underline">
                or request a 4-week pilot →
              </a>
            </p>
            <p className="mt-8 border-t border-border pt-5 text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground/70">
              Designed for transformation teams at global organisations · Automotive OEMs · Global
              HR functions · OD consultancies
            </p>
          </div>
        </div>
      </section>

      {/* ── 3. Key features ───────────────────────────────────────────── */}
      <section id="product" className="mx-auto max-w-6xl scroll-mt-20 px-6 py-24">
        <SectionHeading
          eyebrow="Product"
          title="Everything between “we should restructure” and “approved”"
          body="One workspace that takes you from raw HRIS extract to a defensible, costed, phased organisation option."
        />
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((f) => (
            <div
              key={f.title}
              className="group rounded-xl border border-border bg-card p-6 shadow-raised transition-shadow hover:shadow-panel"
            >
              <div className="flex size-11 items-center justify-center rounded-lg border border-brand/25 bg-brand-subtle text-brand">
                <f.icon className="size-5" />
              </div>
              <h3 className="mt-5 font-display text-[16px] font-semibold leading-snug tracking-tight text-foreground">
                {f.title}
              </h3>
              <p className="mt-2.5 text-[13.5px] leading-relaxed text-muted-foreground">{f.body}</p>
            </div>
          ))}
        </div>
        <div className="mt-10 flex flex-wrap items-center justify-center gap-2">
          {CAPABILITIES.map((c) => (
            <span
              key={c}
              className="inline-flex items-center gap-1.5 rounded-full border border-border bg-surface-2 px-3 py-1.5 text-[12px] font-medium text-muted-foreground"
            >
              <Check className="size-3.5 text-success" />
              {c}
            </span>
          ))}
        </div>
      </section>

      {/* ── 4. Enterprise trust ───────────────────────────────────────── */}
      <section id="enterprise" className="scroll-mt-20 border-y border-border bg-surface-2">
        <div className="mx-auto max-w-6xl px-6 py-24">
          <SectionHeading
            eyebrow="Enterprise trust & security"
            title="Built for enterprise governance"
            body="Security, governance and data protection your procurement and infosec teams can review — with an honest status on every item."
          />
          <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {TRUST.map((t) => (
              <div
                key={t.title}
                className="rounded-xl border border-border bg-card p-6 shadow-raised"
              >
                <div className="flex items-start justify-between gap-3">
                  <h3 className="font-display text-[15px] font-semibold leading-snug tracking-tight text-foreground">
                    {t.title}
                  </h3>
                  <span
                    className={cn(
                      "shrink-0 rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.08em]",
                      TRUST_STATUS_STYLES[t.status],
                    )}
                  >
                    {t.status}
                  </span>
                </div>
                <p className="mt-2.5 text-[13px] leading-relaxed text-muted-foreground">{t.body}</p>
              </div>
            ))}
          </div>
          <p className="mx-auto mt-8 flex max-w-2xl items-center justify-center gap-2 text-center text-[12.5px] text-muted-foreground">
            <ShieldCheck className="size-4 shrink-0 text-success" />
            Statuses reflect the current product — “Enterprise plan” and “On roadmap” items are
            scoped contractually during pilot discussions, so there are no surprises in your
            security review.
          </p>
        </div>
      </section>

      {/* ── 5. Pilot path & plans ─────────────────────────────────────── */}
      <section id="pilot" className="scroll-mt-20">
        <div className="mx-auto max-w-6xl px-6 py-24">
          <div className="grid items-center gap-12 lg:grid-cols-[1.05fr_1fr]">
            <div>
              <p className="font-display text-[11px] font-bold uppercase tracking-[0.2em] text-brand">
                The pilot path
              </p>
              <h2 className="mt-3 font-display text-[30px] font-semibold leading-[1.15] tracking-tight text-foreground sm:text-[36px]">
                From demo to your own data in four weeks
              </h2>
              <p className="mt-4 max-w-xl text-[15px] leading-relaxed text-muted-foreground">
                Keep exploring the free sample workspace for as long as you like. When you are
                ready, a guided pilot proves the value on your own organisation — with security and
                procurement needs handled up front.
              </p>
              <ul className="mt-7 space-y-3">
                {PILOT_STEPS.map((step) => (
                  <li key={step} className="flex items-start gap-3 text-[14px] text-foreground">
                    <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full border border-success/30 bg-success/10">
                      <Check className="size-3 text-success" />
                    </span>
                    {step}
                  </li>
                ))}
              </ul>
              <p className="mt-6 text-[12.5px] font-medium text-muted-foreground">
                NDA available · Security questionnaire supported
              </p>
            </div>
            <div className="rounded-2xl border border-brand/25 bg-card p-8 shadow-panel">
              <h3 className="font-display text-[20px] font-semibold tracking-tight text-foreground">
                Request a 4-week pilot
              </h3>
              <p className="mt-3 text-[13.5px] leading-relaxed text-muted-foreground">
                Dedicated onboarding for enterprise pilots — a named contact from first data load
                to the board-ready pack.
              </p>
              <div className="mt-6 flex flex-col gap-2.5">
                <Button size="lg" className="w-full" asChild>
                  <a href={ENTERPRISE_MAILTO}>
                    Request a pilot on your data
                    <ArrowRight />
                  </a>
                </Button>
                <Button size="lg" variant="outline" className="w-full" asChild>
                  <Link to="/dashboard" search={{ demo: "guided" }}>
                    Keep exploring the free demo
                  </Link>
                </Button>
              </div>
              <p className="mt-4 text-center text-[12px] text-muted-foreground">
                No credit card · No procurement step needed for the demo workspace
              </p>
            </div>
          </div>

          <div id="plans" className="mt-24 scroll-mt-24">
            <SectionHeading
              eyebrow="Plans"
              title="Simple plans that scale with the programme"
              body="Start free, prove value in a pilot, then roll out with enterprise controls."
            />
            <div className="mt-14 grid gap-5 lg:grid-cols-3">
              {PLANS.map((p) => (
                <div
                  key={p.name}
                  className={cn(
                    "flex flex-col rounded-xl border bg-card p-7 shadow-raised",
                    p.highlight ? "border-brand/40 shadow-panel" : "border-border",
                  )}
                >
                  <div className="flex items-baseline justify-between gap-3">
                    <h3 className="font-display text-[16px] font-semibold tracking-tight text-foreground">
                      {p.name}
                    </h3>
                    <span className="font-display text-[13px] font-semibold text-brand">
                      {p.price}
                    </span>
                  </div>
                  <p className="mt-1.5 text-[13px] text-muted-foreground">{p.tagline}</p>
                  <ul className="mt-5 flex-1 space-y-2.5">
                    {p.points.map((pt) => (
                      <li key={pt} className="flex items-start gap-2.5 text-[13px] text-foreground">
                        <Check className="mt-0.5 size-3.5 shrink-0 text-success" />
                        {pt}
                      </li>
                    ))}
                  </ul>
                  <Button
                    className="mt-6 w-full"
                    variant={p.highlight ? "default" : "outline"}
                    size="sm"
                    asChild
                  >
                    {p.href ? (
                      <a href={p.href}>{p.cta}</a>
                    ) : (
                      <Link to={p.to ?? "/dashboard"} search={p.search ?? {}}>
                        {p.cta}
                      </Link>
                    )}
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── 6. Use cases / built for ──────────────────────────────────── */}
      <section id="use-cases" className="scroll-mt-20 border-y border-border bg-surface-2">
        <div className="mx-auto max-w-6xl px-6 py-24">
          <SectionHeading
            eyebrow="Use cases"
            title="Built for the people who reshape organisations"
            body="From enterprise HR to operating-model consultancies — the studio speaks the language of real transformation work."
          />
          <div className="mt-14 grid gap-5 sm:grid-cols-2">
            {AUDIENCES.map((a) => (
              <div
                key={a.title}
                className="flex gap-5 rounded-xl border border-border bg-card p-7 shadow-raised"
              >
                <div className="flex size-11 shrink-0 items-center justify-center rounded-lg border border-border bg-surface-3 text-brand">
                  <a.icon className="size-5" />
                </div>
                <div>
                  <h3 className="font-display text-[16px] font-semibold tracking-tight text-foreground">
                    {a.title}
                  </h3>
                  <p className="mt-2 text-[13.5px] leading-relaxed text-muted-foreground">{a.body}</p>
                  {a.to ? (
                    <Link
                      to={a.to}
                      search={a.search ?? {}}
                      className="mt-3 inline-flex items-center gap-1.5 text-[13px] font-medium text-brand hover:underline"
                    >
                      {a.linkLabel ?? "Open"}
                      <ArrowRight className="size-4" />
                    </Link>
                  ) : null}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>


      {/* ── Resources ─────────────────────────────────────────────────── */}
      <section id="resources" className="scroll-mt-20 border-t border-border bg-surface-2">
        <div className="mx-auto max-w-6xl px-6 py-24">
          <SectionHeading
            eyebrow="Resources"
            title="Explore the toolkit"
            body="Three ways to see what the studio can do before you bring your own data."
          />
          <div className="mt-14 grid gap-5 sm:grid-cols-3">
            {RESOURCES.map((r) => (
              <Link
                key={r.title}
                to={r.to}
                className="group rounded-xl border border-border bg-card p-7 shadow-raised transition-shadow hover:shadow-panel"
              >
                <div className="flex size-11 items-center justify-center rounded-lg border border-brand/25 bg-brand-subtle text-brand">
                  <r.icon className="size-5" />
                </div>
                <h3 className="mt-5 font-display text-[16px] font-semibold tracking-tight text-foreground">
                  {r.title}
                </h3>
                <p className="mt-2 text-[13.5px] leading-relaxed text-muted-foreground">{r.body}</p>
                <span className="mt-4 inline-flex items-center gap-1.5 text-[13px] font-medium text-brand">
                  Open
                  <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── 6. Final CTA ──────────────────────────────────────────────── */}
      <section id="get-started" className="mx-auto max-w-6xl scroll-mt-20 px-6 py-24">
        <div
          className="relative overflow-hidden rounded-2xl px-8 py-16 text-center shadow-overlay sm:px-16"
          style={{
            background:
              "linear-gradient(135deg, oklch(0.48 0.10 55) 0%, oklch(0.55 0.11 60) 55%, oklch(0.58 0.10 75) 100%)",
          }}
        >
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0"
            style={{
              background:
                "radial-gradient(36rem 18rem at 85% 0%, oklch(0.98 0.008 60 / 18%), transparent 60%)",
            }}
          />
          <div className="relative">
            <h2 className="mx-auto max-w-2xl font-display text-[30px] font-semibold leading-[1.12] tracking-tight text-primary-foreground sm:text-[38px]">
              Bring your next transformation into focus
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-[15px] leading-relaxed text-primary-foreground/80">
              Open the demo workspace, explore three pre-built scenarios, and see your first
              leadership-ready export in under five minutes.
            </p>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
              <Button size="lg" className="bg-primary-foreground px-6 text-primary hover:bg-primary-foreground/90" asChild>
                <Link to="/dashboard" search={{ demo: "guided" }}>
                  Open the studio
                  <ArrowRight />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-primary-foreground/30 bg-transparent px-6 text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground"
                asChild
              >
                <Link to="/decision">See a decision summary</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* ── Footer ────────────────────────────────────────────────────── */}
      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-6 py-8">
          <div className="flex items-center gap-2.5">
            <img
              src={orgeasyLogo}
              alt=""
              width={26}
              height={26}
              className="size-[26px] rounded-md"
            />
            <span className="text-[13px] font-medium text-muted-foreground">
              © 2026 Organisation Strategy Studio
            </span>
          </div>
          <div className="flex items-center gap-6 text-[13px] text-muted-foreground">
            <Link to="/privacy" className="transition-colors hover:text-foreground">
              Privacy & data
            </Link>
            <Link to="/compliance" className="transition-colors hover:text-foreground">
              Country guidance
            </Link>
            <Link to="/dashboard" className="transition-colors hover:text-foreground">
              Programme dashboard
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
