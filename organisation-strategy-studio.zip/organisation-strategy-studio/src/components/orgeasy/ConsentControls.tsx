import { useCallback, useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Cookie, ShieldCheck, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import {
  CONSENT_CATEGORIES,
  allConsent,
  readConsent,
  subscribeConsent,
  writeConsent,
  type ConsentCategoryId,
  type ConsentState,
} from "@/lib/orgeasy/consent";
import { CONSENT_VERSION } from "@/lib/orgeasy/consent";

/** Live consent state, synced across banner and Privacy page. */
export function useConsent() {
  const [state, setState] = useState<ConsentState | null>(null);

  useEffect(() => {
    setState(readConsent());
    return subscribeConsent(setState);
  }, []);

  const save = useCallback((categories: Record<ConsentCategoryId, boolean>) => {
    writeConsent({
      version: CONSENT_VERSION,
      decidedAt: new Date().toISOString(),
      categories: { ...categories, essential: true },
    });
  }, []);

  const acceptAll = useCallback(() => writeConsent(allConsent(true)), []);
  const rejectAll = useCallback(() => writeConsent(allConsent(false)), []);

  return { state, save, acceptAll, rejectAll };
}

function CategoryRows({
  value,
  onChange,
}: {
  value: Record<ConsentCategoryId, boolean>;
  onChange: (id: ConsentCategoryId, next: boolean) => void;
}) {
  return (
    <div className="divide-y divide-border overflow-hidden rounded-md border border-border">
      {CONSENT_CATEGORIES.map((c) => (
        <div key={c.id} className="flex items-start gap-4 bg-card px-4 py-3">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <p className="text-[13px] font-semibold tracking-tight">{c.label}</p>
              {c.required ? (
                <span className="rounded-full bg-muted px-2 py-0.5 text-[9.5px] font-semibold uppercase tracking-wide text-muted-foreground">
                  Always on
                </span>
              ) : null}
            </div>
            <p className="mt-1 text-[12.5px] leading-relaxed text-muted-foreground">{c.purpose}</p>
            <p className="mt-1 text-[11px] text-muted-foreground/80">{c.storage}</p>
          </div>
          <Switch
            className="mt-1"
            checked={c.required ? true : value[c.id]}
            disabled={c.required}
            aria-label={c.label}
            onCheckedChange={(next) => onChange(c.id, next)}
          />
        </div>
      ))}
    </div>
  );
}

/** Full preference panel used on the Privacy & Data page. */
export function ConsentPreferences() {
  const { state, save, acceptAll, rejectAll } = useConsent();
  const [draft, setDraft] = useState<Record<ConsentCategoryId, boolean> | null>(null);

  useEffect(() => {
    if (state) setDraft(state.categories);
  }, [state]);

  if (!state || !draft) return null;

  const dirty = CONSENT_CATEGORIES.some((c) => draft[c.id] !== state.categories[c.id]);

  return (
    <section className="rounded-lg border border-border bg-card p-6 shadow-panel">
      <h2 className="flex items-center gap-2 text-[15px] font-semibold tracking-tight">
        <ShieldCheck className="size-4 text-brand" /> Cookies & local storage choices
      </h2>
      <p className="mt-2 max-w-3xl text-[13px] leading-relaxed text-muted-foreground">
        Organisation Strategy Studio uses browser storage rather than a server database. Only strictly necessary storage
        is used before you consent — workspace persistence, preferences and analytics stay off until
        you opt in, and switching one off clears the storage it covers on next load. You can change
        this at any time from this page.
      </p>

      <div className="mt-4">
        <CategoryRows
          value={draft}
          onChange={(id, next) => setDraft((prev) => ({ ...(prev as typeof draft), [id]: next }))}
        />
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-3">
        <Button onClick={() => save(draft)} disabled={!dirty}>
          Save choices
        </Button>
        <Button variant="outline" onClick={acceptAll}>
          Accept all
        </Button>
        <Button variant="ghost" onClick={rejectAll}>
          Reject non-essential
        </Button>
        <p className="text-[11.5px] text-muted-foreground">
          {state.decidedAt
            ? `Last updated ${new Date(state.decidedAt).toLocaleString()}`
            : "No choice recorded yet — only strictly necessary storage is active."}
        </p>
      </div>
    </section>
  );
}

/** Compact bottom banner shown inside the studio until a choice is recorded. */
export function CookieConsentBanner() {
  const { state, save, acceptAll, rejectAll } = useConsent();
  const [customising, setCustomising] = useState(false);
  const [draft, setDraft] = useState<Record<ConsentCategoryId, boolean> | null>(null);
  // Session-only dismissal ("remind me later") — stores nothing, essential-only stays active.
  const [dismissed, setDismissed] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    if (state && !draft) setDraft(state.categories);
  }, [state, draft]);

  // Never cover the public landing page; the banner belongs inside the product.
  if (pathname === "/welcome") return null;
  if (!state || state.decidedAt || !draft || dismissed) return null;

  return (
    <div
      role="dialog"
      aria-modal="false"
      aria-label="Cookie and storage consent"
      className="pointer-events-none fixed inset-x-0 bottom-0 z-50 flex justify-center px-3 pb-3 sm:px-4 sm:pb-4"
    >
      <div className="pointer-events-auto relative w-full max-w-3xl rounded-xl border border-border bg-card p-4 shadow-panel sm:p-5">
        <button
          type="button"
          onClick={() => setDismissed(true)}
          aria-label="Dismiss for now"
          title="Dismiss for now — strictly necessary storage only"
          className="absolute right-3 top-3 flex size-6 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
        >
          <X className="size-3.5" />
        </button>
        <div className="flex items-start gap-3">
          <Cookie className="mt-0.5 size-4 shrink-0 text-brand" />
          <div className="min-w-0 flex-1 pr-6">
            <h2 className="text-[13.5px] font-semibold tracking-tight">
              Your cookie & storage choices
            </h2>
            <p className="mt-1 text-[12px] leading-relaxed text-muted-foreground">
              Your restructuring data stays in this browser. Strictly necessary storage is always
              on; workspace persistence, preferences and analytics only switch on with your
              consent.{" "}
              <Link to="/privacy" className="font-medium text-brand underline-offset-2 hover:underline">
                Privacy & data
              </Link>
            </p>

            {customising ? (
              <div className="mt-3">
                <CategoryRows
                  value={draft}
                  onChange={(id, next) =>
                    setDraft((prev) => ({ ...(prev as typeof draft), [id]: next }))
                  }
                />
              </div>
            ) : null}

            <div className="mt-3 flex flex-wrap items-center gap-2">
              <Button size="sm" onClick={acceptAll}>
                Accept all
              </Button>
              <Button size="sm" variant="outline" onClick={rejectAll}>
                Reject non-essential
              </Button>
              {customising ? (
                <Button size="sm" variant="secondary" onClick={() => save(draft)}>
                  Save selected
                </Button>
              ) : (
                <Button size="sm" variant="ghost" onClick={() => setCustomising(true)}>
                  Customise
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
