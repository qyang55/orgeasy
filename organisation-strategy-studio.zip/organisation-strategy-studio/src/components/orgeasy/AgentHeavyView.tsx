import { Bot, User, Sparkles, TrendingDown } from "lucide-react";
import type { Scenario } from "@/lib/orgeasy/types";
import { ROLE_TYPE_META } from "@/lib/orgeasy/types";
import { compareAgentModel, roleTypeOf, useAgentMonthlyCost } from "@/lib/orgeasy/agents";
import { formatMoney } from "@/lib/orgeasy/impact";
import { StatCard } from "@/components/orgeasy/StatCard";
import { cn } from "@/lib/utils";

/** Side-by-side human-only baseline vs the agent-enabled target structure. */
export function AgentHeavyView({
  base,
  target,
}: {
  base: Scenario | null;
  target: Scenario | null;
}) {
  const agentMonthly = useAgentMonthlyCost();
  const cmp = compareAgentModel(base, target, agentMonthly);
  if (!cmp || !base || !target) return null;
  const cur = cmp.currency;

  const columns = [
    {
      title: `Traditional — ${base.name}`,
      subtitle: "Human-only structure as it stands today",
      icon: <User className="size-4" />,
      model: cmp.traditional,
    },
    {
      title: `Agent-heavy — ${target.name}`,
      subtitle: "Agents absorbing eligible work, people on judgement work",
      icon: <Bot className="size-4" />,
      model: cmp.agentHeavy,
    },
  ];

  return (
    <div className="space-y-6 px-8 py-6">
      <div className="grid gap-4 md:grid-cols-3">
        <StatCard
          label="Net human headcount reduction"
          value={`${cmp.humanReduction >= 0 ? "−" : "+"}${Math.abs(cmp.humanReduction)}`}
          sub={`${cmp.traditional.humanHeadcount} → ${cmp.agentHeavy.humanHeadcount} people`}
          tone={cmp.humanReduction > 0 ? "negative" : "brand"}
          icon={<TrendingDown className="size-4" />}
        />
        <StatCard
          label="Agents added"
          value={cmp.agentsAdded.toLocaleString()}
          sub={`${cmp.agentHeavy.agentHeadcount} full agent · ${cmp.agentHeavy.hybridHeadcount} hybrid roles`}
          tone="brand"
          icon={<Bot className="size-4" />}
        />
        <StatCard
          label={cmp.costSaving >= 0 ? "Annual cost saving" : "Annual cost increase"}
          value={formatMoney(Math.abs(cmp.costSaving), cur)}
          sub={`Includes ${formatMoney(cmp.agentHeavy.agentCost, cur)} of agent running cost`}
          tone={cmp.costSaving >= 0 ? "positive" : "negative"}
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {columns.map((col) => (
          <section key={col.title} className="rounded-lg border border-border bg-card shadow-panel">
            <div className="flex items-start gap-2.5 border-b border-border px-5 py-3.5">
              <span className="mt-0.5 text-brand">{col.icon}</span>
              <div>
                <h2 className="text-sm font-semibold">{col.title}</h2>
                <p className="text-[11.5px] text-muted-foreground">{col.subtitle}</p>
              </div>
            </div>
            <dl className="divide-y divide-border text-[13px]">
              {(
                [
                  ["People", col.model.humanHeadcount.toLocaleString()],
                  ["AI agents", col.model.agentHeadcount.toLocaleString()],
                  ["Hybrid roles", col.model.hybridHeadcount.toLocaleString()],
                  ["Total positions", col.model.totalHeadcount.toLocaleString()],
                  ["Human people cost", formatMoney(col.model.humanCost, cur)],
                  ["Agent running cost", formatMoney(col.model.agentCost, cur)],
                ] as const
              ).map(([label, value]) => (
                <div key={label} className="flex items-center justify-between px-5 py-2.5">
                  <dt className="text-muted-foreground">{label}</dt>
                  <dd className="font-medium tabular-nums">{value}</dd>
                </div>
              ))}
              <div className="flex items-center justify-between bg-secondary px-5 py-3">
                <dt className="font-semibold">Total annual cost</dt>
                <dd className="font-semibold tabular-nums">
                  {formatMoney(col.model.totalCost, cur)}
                </dd>
              </div>
            </dl>
          </section>
        ))}
      </div>

      <section className="rounded-lg border border-border bg-card shadow-panel">
        <h2 className="border-b border-border px-5 py-3.5 text-sm font-semibold">
          Roles delivered with agents in {target.name}
        </h2>
        {cmp.convertedRoles.length ? (
          <table className="w-full text-left text-[13px]">
            <thead className="bg-secondary text-[11px] uppercase tracking-wide text-muted-foreground">
              <tr>
                {["Role", "Function", "Delivery model", "Positions", "Agent cost / yr"].map((h) => (
                  <th key={h} className="px-5 py-2.5 font-semibold">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {cmp.convertedRoles.map(({ employee }) => {
                const type = roleTypeOf(employee);
                const meta = ROLE_TYPE_META[type];
                return (
                  <tr key={employee.id}>
                    <td className="px-5 py-3 font-medium">{employee.title || employee.name}</td>
                    <td className="px-5 py-3 text-muted-foreground">{employee.department}</td>
                    <td className="px-5 py-3">
                      <span
                        className={cn(
                          "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-semibold",
                        )}
                        style={{
                          color: `#${meta.hex}`,
                          borderColor: `#${meta.hex}66`,
                          background: `#${meta.hex}14`,
                        }}
                      >
                        {type === "agent" ? (
                          <Bot className="size-3" />
                        ) : (
                          <Sparkles className="size-3" />
                        )}
                        {meta.label}
                      </span>
                    </td>
                    <td className="px-5 py-3 tabular-nums">{employee.plannedHeadcount}</td>
                    <td className="px-5 py-3 tabular-nums">
                      {formatMoney((employee.agentMonthlyCost ?? agentMonthly) * 12, cur)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        ) : (
          <p className="px-5 py-8 text-center text-xs text-muted-foreground">
            No roles are set to agent or hybrid delivery yet. Convert roles from the AI &amp;
            automation analysis or the chart designer to model an agent-heavy structure.
          </p>
        )}
      </section>
    </div>
  );
}