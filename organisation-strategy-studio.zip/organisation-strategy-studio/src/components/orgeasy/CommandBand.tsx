import { useEffect, useState, type ReactNode } from "react";
import { TrendingDown, TrendingUp, X } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * "Ocean Teal" command surface: a quiet page header (eyebrow,
 * title, status pill, actions) above a bento grid of metric tiles where
 * the numeral dominates and supporting copy recedes.
 */
export function CommandBand({
  eyebrow,
  title,
  titleAccent,
  description,
  status,
  actions,
  children,
}: {
  eyebrow: string;
  title: string;
  titleAccent?: string;
  description?: string;
  status?: string;
  actions?: ReactNode;
  children?: ReactNode;
}) {
  const [statusHidden, setStatusHidden] = useState(false);

  useEffect(() => {
    try {
      setStatusHidden(localStorage.getItem("orgeasy.commandBand.statusHidden") === "true");
    } catch {
      /* storage unavailable */
    }
  }, []);

  const hideStatus = () => {
    setStatusHidden(true);
    try {
      localStorage.setItem("orgeasy.commandBand.statusHidden", "true");
    } catch {
      /* storage unavailable */
    }
  };

  return (
    <section className="border-b border-border bg-background px-8 pb-8 pt-7">
      <header className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <div className="max-w-3xl">
          <div className="flex items-center gap-2.5">
            <span className="h-px w-6 bg-brand" />
            <span className="font-display text-[10px] font-semibold uppercase tracking-[0.22em] text-brand">
              {eyebrow}
            </span>
          </div>
          <h1 className="mt-3 font-display text-3xl font-medium tracking-tight text-foreground lg:text-[34px]">
            {title}
            {titleAccent ? (
              <span className="text-muted-foreground"> {titleAccent}</span>
            ) : null}
          </h1>
          {description ? (
            <p className="mt-3 max-w-2xl text-[13px] leading-relaxed text-muted-foreground">
              {description}
            </p>
          ) : null}
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {status && !statusHidden ? (
            <span className="group flex items-center gap-2.5 rounded-full border border-border bg-card px-3.5 py-1.5">
              <span className="size-1.5 rounded-full bg-success" />
              <span className="font-display text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
                {status}
              </span>
              <button
                type="button"
                onClick={hideStatus}
                className="ml-0.5 rounded p-0.5 text-muted-foreground/50 opacity-0 transition hover:bg-accent hover:text-foreground group-hover:opacity-100"
                aria-label="Hide status"
                title="Hide status"
              >
                <X className="size-3" />
              </button>
            </span>
          ) : null}
          {actions}
        </div>
      </header>

      {children ? (
        <div className="mt-8 grid grid-cols-1 gap-3 md:grid-cols-6 lg:grid-cols-10">
          {children}
        </div>
      ) : null}
    </section>
  );
}

const TONE = {
  neutral: {
    text: "text-foreground",
    bar: "bg-foreground/40",
    ring: "hover:border-input",
  },
  violet: {
    text: "text-brand",
    bar: "bg-brand",
    ring: "hover:border-brand/40",
  },
  mint: {
    text: "text-success",
    bar: "bg-success",
    ring: "hover:border-success/40",
  },
  alert: {
    text: "text-destructive",
    bar: "bg-destructive",
    ring: "hover:border-destructive/40",
  },
} as const;

export type CommandTone = keyof typeof TONE;

/** Low/mid/high scale shown on wide tiles (e.g. a cost estimate range). */
export interface CommandRange {
  low: number;
  mid: number;
  high: number;
  lowLabel: string;
  highLabel: string;
  midLabel?: string;
}

function TrendMark({ trend, className }: { trend: "up" | "down"; className?: string }) {
  const Icon = trend === "up" ? TrendingUp : TrendingDown;
  return (
    <span
      className={cn(
        "flex size-6 items-center justify-center rounded-md border border-border bg-background/60",
        className,
      )}
    >
      <Icon className="size-3.5" />
    </span>
  );
}

/** A bento metric tile. `span` sets the lg column width (out of 10). */
export function CommandTile({
  label,
  value,
  unit,
  sub,
  tone = "neutral",
  progress,
  trend,
  range,
  span = 2,
  wide = false,
  className,
}: {
  label: string;
  value: string;
  unit?: string;
  sub?: string;
  tone?: CommandTone;
  /** 0–100 thin bar under the numeral. */
  progress?: number;
  /** Small directional marker beside the label, tinted by tone. */
  trend?: "up" | "down";
  /** Wide tiles only: renders a low–high scale with the mid-point marked. */
  range?: CommandRange;
  span?: 2 | 3 | 4 | 10;
  wide?: boolean;
  className?: string;
}) {
  const t = TONE[tone];
  const spanClass = {
    2: "md:col-span-3 lg:col-span-2",
    3: "md:col-span-3 lg:col-span-3",
    4: "md:col-span-6 lg:col-span-4",
    10: "md:col-span-6 lg:col-span-10",
  }[span];

  if (wide) {
    const spread = range ? Math.max(range.high - range.low, 1) : 1;
    const midPct = range ? ((range.mid - range.low) / spread) * 100 : 0;
    return (
      <div
        className={cn(
          "rounded-xl border border-border bg-card px-6 pb-5 pt-5 transition-colors",
          spanClass,
          t.ring,
          className,
        )}
      >
        <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
          <div className="max-w-xl">
            <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
              {label}
            </p>
            {sub ? (
              <p className="mt-2 text-[12px] leading-relaxed text-muted-foreground/80">{sub}</p>
            ) : null}
          </div>
          <div className="shrink-0 md:text-right">
            <p
              className={cn(
                "font-display text-[34px] font-semibold leading-none tracking-tight tabular-nums lg:text-[42px]",
                t.text,
              )}
            >
              {value}
            </p>
            {range?.midLabel ? (
              <p className="mt-1.5 text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground/70">
                {range.midLabel}
              </p>
            ) : null}
          </div>
        </div>

        {range ? (
          <div className="mt-5">
            <div className="relative h-1 w-full rounded-full bg-muted">
              <div
                className={cn("absolute inset-y-0 left-0 rounded-full opacity-70", t.bar)}
                style={{ width: `${Math.max(1.5, Math.min(100, midPct))}%` }}
              />
              <span
                className="absolute top-1/2 size-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-card bg-foreground"
                style={{ left: `${Math.max(1.5, Math.min(98.5, midPct))}%` }}
              />
            </div>
            <div className="mt-2 flex items-baseline justify-between text-[10.5px] font-medium tabular-nums text-muted-foreground/80">
              <span>{range.lowLabel}</span>
              <span>{range.highLabel}</span>
            </div>
          </div>
        ) : null}
      </div>
    );
  }

  return (
    <div
      className={cn(
        "group flex flex-col rounded-xl border border-border bg-card p-5 transition-colors",
        spanClass,
        t.ring,
        className,
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
          {label}
        </p>
        {trend ? <TrendMark trend={trend} className={t.text} /> : null}
      </div>
      <div className="mt-3 flex items-baseline gap-2">
        <span
          className={cn(
            "font-display text-[32px] font-semibold leading-none tracking-tight tabular-nums lg:text-[34px]",
            t.text,
          )}
        >
          {value}
        </span>
        {unit ? (
          <span className="text-[10px] font-medium uppercase tracking-[0.12em] text-muted-foreground/70">
            {unit}
          </span>
        ) : null}
      </div>
      {typeof progress === "number" ? (
        <div className="mt-3.5 h-[3px] w-full overflow-hidden rounded-full bg-muted">
          <div
            className={cn("h-full rounded-full", t.bar)}
            style={{ width: `${Math.max(2, Math.min(100, progress))}%` }}
          />
        </div>
      ) : null}
      {sub ? (
        <p className="mt-auto pt-3 text-[11.5px] leading-relaxed text-muted-foreground/80">
          {sub}
        </p>
      ) : null}
    </div>
  );
}
