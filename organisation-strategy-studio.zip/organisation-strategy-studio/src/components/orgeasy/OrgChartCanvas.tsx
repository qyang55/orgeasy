import "@xyflow/react/dist/style.css";
import {
  Background,
  BackgroundVariant,
  Controls,
  Handle,
  MiniMap,
  NodeResizer,
  Panel,
  Position,
  ReactFlow,
  ReactFlowProvider,
  applyNodeChanges,
  useReactFlow,
  useViewport,
  type Edge,
  type Node,
  type NodeProps,
  type NodeChange,
} from "@xyflow/react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Activity,
  Bot,
  ChevronDown,
  ChevronRight,
  CircleDollarSign,
  GitFork,
  Layers3,
  MapPin,
  Maximize2,
  Minus,
  Network,
  Plus,
  Rows2,
  Rows3,
  Search,
  StretchVertical,
  Sparkles,
  Trash2,
  Type,
  User,
  UserPlus,
  Users,
  X,
} from "lucide-react";
import type { Employee, Scenario } from "@/lib/orgeasy/types";
import { ROLE_TYPE_META, SCOPE_META, STATUS_META, UNIT_META } from "@/lib/orgeasy/types";
import { HYBRID_AGENT_SHARE, roleTypeOf } from "@/lib/orgeasy/agents";
import { analyseSpans, SPAN_BENCHMARK } from "@/lib/orgeasy/span";
import { computeCostModel } from "@/lib/orgeasy/cost-model";
import { collapseBelowDepth, computeLayout, nodeSize, type LayoutKind } from "@/lib/orgeasy/layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { DIFF_CLASS_META, type DiffClass } from "@/lib/orgeasy/diff";
import {
  accentFor,
  buildEncodeContext,
  getTheme,
  levelMap,
  type ChartTheme,
  type ColorBy,
} from "@/lib/orgeasy/themes";
import { cn } from "@/lib/utils";

/** Which optional attributes each card shows. */
export type CardFields = {
  photo: boolean;
  department: boolean;
  location: boolean;
  span: boolean;
  reports: boolean;
  headcount: boolean;
  costCenter: boolean;
};

export const DEFAULT_CARD_FIELDS: CardFields = {
  photo: true,
  department: true,
  location: false,
  span: true,
  reports: true,
  headcount: true,
  costCenter: false,
};

export const CARD_FIELD_LABELS: [keyof CardFields, string][] = [
  ["photo", "Photo / initials"],
  ["department", "Department"],
  ["location", "Location"],
  ["span", "Span of control"],
  ["reports", "Total headcount under"],
  ["headcount", "Role headcount"],
  ["costCenter", "Cost centre"],
];

/** Card density presets — how much information each node shows. */
export type CardDensity = "compact" | "standard" | "detailed";

export const CARD_DENSITY_PRESETS: Record<
  CardDensity,
  { label: string; hint: string; fields: CardFields }
> = {
  compact: {
    label: "Compact",
    hint: "Minimal cards — best for very large charts",
    fields: {
      photo: false,
      department: false,
      location: false,
      span: true,
      reports: false,
      headcount: true,
      costCenter: false,
    },
  },
  standard: {
    label: "Standard",
    hint: "Balanced detail for design sessions",
    fields: { ...DEFAULT_CARD_FIELDS },
  },
  detailed: {
    label: "Detailed",
    hint: "Every available attribute on the card",
    fields: {
      photo: true,
      department: true,
      location: true,
      span: true,
      reports: true,
      headcount: true,
      costCenter: true,
    },
  },
};

type OrgNodeData = {
  employee: Employee;
  childCount: number;
  collapsed: boolean;
  size: { w: number; h: number };
  horizontal: boolean;
  onToggle: (id: string) => void;
  onSelect: (id: string) => void;
  onResize: (id: string, size: { w: number; h: number }) => void;
  selected: boolean;
  accent: string;
  theme: ChartTheme;
  dim?: boolean;
  /** Another card is being dragged over this one: ring it as a drop target. */
  dropTarget?: "valid" | "invalid" | undefined;
  /** Direct reports (span of control). */
  span: number;
  /** Total planned headcount in the whole subtree, including this role. */
  reportsTotal: number;
  fields: CardFields;
  /** Adds a new open role reporting into this one. */
  onAddChild?: ((managerId: string) => void) | undefined;
  /** Deletes this role from the scenario. */
  onDeleteRole?: ((id: string) => void) | undefined;
  /** Saves inline edits typed straight onto the card. */
  onRename?: ((id: string, patch: { title?: string; name?: string }) => void) | undefined;
};

function initials(e: Employee) {
  if (e.isOpenRole || !e.name) return "+";
  return e.name
    .split(/\s+/)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? "")
    .join("");
}

const ROLE_TYPE_ICON = { human: User, agent: Bot, hybrid: Sparkles } as const;

/** Small delivery-model badge: person, robot or hybrid spark. */
function RoleTypeBadge({ employee }: { employee: Employee }) {
  const type = roleTypeOf(employee);
  const meta = ROLE_TYPE_META[type];
  const Icon = ROLE_TYPE_ICON[type];
  return (
    <span
      title={`${meta.label} — ${meta.description}`}
      className="inline-flex items-center gap-1 rounded-full border px-1.5 py-[1px] text-[8.5px] font-bold uppercase tracking-wide"
      style={{
        color: `#${meta.hex}`,
        borderColor: `#${meta.hex}66`,
        background: `#${meta.hex}1A`,
      }}
    >
      <Icon className="size-2.5" />
      {meta.short}
    </span>
  );
}

function OrgNode({ data }: NodeProps) {
  const d = data as unknown as OrgNodeData;
  const [hovered, setHovered] = useState(false);
  /** Which text field on the card is being typed into, if any. */
  const [editing, setEditing] = useState<null | "title" | "name">(null);
  const [draft, setDraft] = useState("");
  const { employee: e, size, horizontal, accent, theme } = d;
  const meta = STATUS_META[e.status];
  const compact = size.h < 118;
  const fields = d.fields ?? DEFAULT_CARD_FIELDS;
  // Vacant / open roles read as dashed outlines, the Lucidchart convention.
  const vacant = e.isOpenRole || !e.name;
  const wideSpan = d.span >= 9;
  // AI-agent roles get a tinted surface and type-coloured border so human
  // vs agent capacity is readable at a glance; hybrids keep the human look.
  const roleType = roleTypeOf(e);
  const typeHex = `#${ROLE_TYPE_META[roleType].hex}`;
  const isAgent = roleType === "agent";
  const dropRing =
    d.dropTarget === "valid"
      ? `0 0 0 2.5px ${accent}, 0 0 0 9px color-mix(in srgb, ${accent} 25%, transparent)`
      : d.dropTarget === "invalid"
        ? `0 0 0 2.5px #${STATUS_META["to-be-removed"].hex}, 0 0 0 9px color-mix(in srgb, #${STATUS_META["to-be-removed"].hex} 22%, transparent)`
        : undefined;

  // Quiet elevation: a soft resting contact shadow, a gentle lift on hover
  // and a restrained brand ring when selected. No gloss or gradient chrome.
  const depth = (lift: boolean) =>
    lift
      ? `0 12px 26px -12px color-mix(in srgb, ${theme.text} 32%, transparent)`
      : `0 2px 8px -4px color-mix(in srgb, ${theme.text} 22%, transparent)`;

  const showChips = Boolean(
    (fields.department && e.department) ||
      (fields.location && e.country) ||
      (fields.costCenter && e.costCenter),
  );
  const showMetrics = Boolean(
    (fields.span && d.span > 0) ||
      (fields.reports && d.reportsTotal > (e.plannedHeadcount || 0)) ||
      fields.headcount,
  );
  const showAbout = size.h >= 190 && Boolean(e.responsibilities);
  const onlyHeader = compact || (!showChips && !showMetrics && !showAbout);

  return (
    <div
      onClick={() => d.onSelect(e.id)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        width: "100%",
        height: "100%",
        opacity: d.dim ? 0.45 : 1,
        filter: d.dim ? "saturate(0.3)" : undefined,
        background: isAgent
          ? `color-mix(in srgb, ${theme.surface} 86%, ${typeHex})`
          : theme.surface,
        borderColor: d.selected
          ? accent
          : vacant
            ? `#${STATUS_META.planned.hex}`
            : isAgent
              ? `color-mix(in srgb, ${typeHex} 55%, ${theme.border})`
              : theme.border,
        borderStyle: vacant ? "dashed" : "solid",
        borderWidth: vacant ? 1.5 : 1,
        color: theme.text,
        boxShadow:
          dropRing ??
          (d.selected
            ? `0 0 0 1.5px ${accent}, 0 0 0 6px color-mix(in srgb, ${accent} 15%, transparent), ${depth(true)}`
            : depth(hovered)),
        transform: hovered && !d.selected ? "translateY(-1px)" : "translateY(0)",
      }}
      className={cn(
        "group relative flex flex-col rounded-xl border px-4 py-3 transition-[transform,box-shadow,border-color,opacity] duration-200 ease-out",
        onlyHeader && "justify-center",
        !d.selected && "hover:border-foreground/20",
      )}
    >
      <NodeResizer
        minWidth={130}
        minHeight={54}
        maxWidth={620}
        maxHeight={460}
        isVisible={d.selected || hovered}
        lineClassName="!border-transparent"
        handleStyle={{
          width: 8,
          height: 8,
          borderRadius: 2.5,
          background: theme.surface,
          border: `1.5px solid ${accent}`,
        }}
        onResizeEnd={(_evt, params) =>
          d.onResize(e.id, { w: Math.round(params.width), h: Math.round(params.height) })
        }
      />
      <Handle
        type="target"
        position={horizontal ? Position.Left : Position.Top}
        title="Drop a line here to report into this role"
        className={cn(
          "!border-2 transition-all",
          hovered || d.selected
            ? "!size-3 !border-white/90"
            : "!size-2 !border-transparent",
        )}
        style={{ background: accent }}
      />
      {/* Slim accent rail on the leading edge — the colour-coding anchor. */}
      <span
        className="pointer-events-none absolute bottom-3 left-0 top-3 w-[3px] rounded-full transition-shadow duration-200"
        style={{
          background: accent,
          boxShadow:
            hovered || d.selected
              ? `0 0 12px color-mix(in srgb, ${accent} 60%, transparent)`
              : undefined,
        }}
      />
      {(d.onAddChild || d.onDeleteRole) && (hovered || d.selected) ? (
        <div className="nodrag nopan absolute -top-[11px] right-2.5 z-30 flex items-center gap-1">
          {d.onAddChild ? (
            <button
              type="button"
              title="Add a new role reporting into this one"
              aria-label={`Add a role reporting to ${e.title}`}
              onClick={(event) => {
                event.stopPropagation();
                d.onAddChild?.(e.id);
              }}
              className="grid size-[20px] place-items-center rounded-full border shadow-sm transition-transform hover:scale-110"
              style={{ background: theme.surface, borderColor: accent, color: accent }}
            >
              <UserPlus className="size-3" />
            </button>
          ) : null}
          {d.onDeleteRole ? (
            <button
              type="button"
              title="Remove this role from the chart"
              aria-label={`Remove ${e.title}`}
              onClick={(event) => {
                event.stopPropagation();
                d.onDeleteRole?.(e.id);
              }}
              className="grid size-[20px] place-items-center rounded-full border shadow-sm transition-transform hover:scale-110"
              style={{
                background: theme.surface,
                borderColor: `#${STATUS_META["to-be-removed"].hex}`,
                color: `#${STATUS_META["to-be-removed"].hex}`,
              }}
            >
              <Trash2 className="size-3" />
            </button>
          ) : null}
        </div>
      ) : null}
      <div className="absolute right-2.5 top-2 z-10 flex items-center gap-1">
          <RoleTypeBadge employee={e} />
          {e.unitKind && e.unitKind !== "line" ? (
            <span
              title={UNIT_META[e.unitKind].label}
              className="rounded px-1.5 py-[1px] text-[8.5px] font-bold uppercase tracking-wide text-black"
              style={{ background: `#${UNIT_META[e.unitKind].hex}` }}
            >
              {UNIT_META[e.unitKind].short}
            </span>
          ) : null}
          {e.roleScope && e.roleScope !== "unset" ? (
            <span
              title={SCOPE_META[e.roleScope].label}
              className="rounded border px-1.5 py-[1px] text-[8.5px] font-bold uppercase tracking-wide"
              style={{
                color: `#${SCOPE_META[e.roleScope].hex}`,
                borderColor: `#${SCOPE_META[e.roleScope].hex}66`,
                background: `#${SCOPE_META[e.roleScope].hex}14`,
              }}
            >
              {SCOPE_META[e.roleScope].short}
            </span>
          ) : null}
      </div>
      <div className="relative flex items-center gap-2.5">
        {!fields.photo ? null : e.photoUrl ? (
          <img
            src={e.photoUrl}
            alt={e.name ? `${e.name}, ${e.title}` : e.title}
            className={cn(
              "shrink-0 rounded-full object-cover",
              compact ? "size-8" : "size-10",
            )}
            style={{
              boxShadow: `0 0 0 1.5px color-mix(in srgb, ${accent} 75%, transparent)`,
            }}
          />
        ) : (
        <span
          className={cn(
            "grid shrink-0 select-none place-items-center rounded-full font-display font-semibold tracking-tight text-black",
            compact ? "size-8 text-[11px]" : "size-10 text-[13px]",
          )}
          style={{
            background: `linear-gradient(150deg, color-mix(in srgb, ${accent} 82%, #FFFFFF) 0%, ${accent} 100%)`,
          }}
        >
          {isAgent ? <Bot className={compact ? "size-4" : "size-5"} /> : initials(e)}
        </span>
        )}
        <div className="min-w-0 flex-1">
          {/* Role title leads the card — it is the thing people read. */}
          <div className="flex items-start gap-1.5">
            {editing === "title" ? (
              <input
                autoFocus
                value={draft}
                aria-label="Role title"
                onChange={(ev) => setDraft(ev.target.value)}
                onBlur={() => {
                  const value = draft.trim();
                  if (value && value !== e.title) d.onRename?.(e.id, { title: value });
                  setEditing(null);
                }}
                onKeyDown={(ev) => {
                  if (ev.key === "Enter") (ev.target as HTMLInputElement).blur();
                  if (ev.key === "Escape") {
                    setDraft(e.title);
                    setEditing(null);
                  }
                  ev.stopPropagation();
                }}
                onClick={(ev) => ev.stopPropagation()}
                onDoubleClick={(ev) => ev.stopPropagation()}
                className={cn(
                  "nodrag nopan w-full rounded-md border bg-transparent px-1 py-0.5 font-display font-semibold leading-[1.2] tracking-[-0.01em] outline-none",
                  compact ? "text-[14px]" : "text-[16px]",
                )}
                style={{ borderColor: accent, color: theme.text }}
              />
            ) : (
              <p
                title={d.onRename ? "Double-click to rename" : undefined}
                onDoubleClick={(ev) => {
                  if (!d.onRename) return;
                  ev.stopPropagation();
                  setDraft(e.title);
                  setEditing("title");
                }}
                className={cn(
                  "font-display font-semibold leading-[1.2] tracking-[-0.01em]",
                  compact ? "truncate text-[14px]" : "line-clamp-2 text-[16px]",
                  d.onRename && "cursor-text",
                )}
              >
                {e.title}
              </p>
            )}
            <span
              title={meta.label}
              className="mt-[5px] size-1.5 shrink-0 rounded-full"
              style={{ backgroundColor: `#${meta.hex}`, boxShadow: `0 0 0 3px #${meta.hex}22` }}
            />
          </div>
          {editing === "name" ? (
            <input
              autoFocus
              value={draft}
              aria-label="Person name"
              placeholder="Person name (leave blank for open role)"
              onChange={(ev) => setDraft(ev.target.value)}
              onBlur={() => {
                const value = draft.trim();
                if (value !== (e.name ?? "")) d.onRename?.(e.id, { name: value });
                setEditing(null);
              }}
              onKeyDown={(ev) => {
                if (ev.key === "Enter") (ev.target as HTMLInputElement).blur();
                if (ev.key === "Escape") setEditing(null);
                ev.stopPropagation();
              }}
              onClick={(ev) => ev.stopPropagation()}
              onDoubleClick={(ev) => ev.stopPropagation()}
              className="nodrag nopan mt-0.5 w-full rounded-md border bg-transparent px-1 py-0.5 text-[12px] font-medium outline-none"
              style={{ borderColor: accent, color: theme.text }}
            />
          ) : (
            <p
              title={d.onRename ? "Double-click to edit the person" : undefined}
              onDoubleClick={(ev) => {
                if (!d.onRename) return;
                ev.stopPropagation();
                setDraft(e.name ?? "");
                setEditing("name");
              }}
              className={cn(
                "mt-[1px] truncate text-[12px] font-medium",
                d.onRename && "cursor-text",
              )}
              style={{ color: theme.muted }}
            >
              {e.isOpenRole || !e.name ? "Open role" : e.name}
            </p>
          )}
        </div>
      </div>
      {showAbout ? (
        <p className="relative mt-2 line-clamp-2 text-[11px] leading-snug" style={{ color: theme.muted }}>
          {e.responsibilities}
        </p>
      ) : null}
      {!compact && (showChips || showMetrics) ? (
        // Only the essentials stay on the card: everything else lives in the
        // “Selected role” panel on the right.
        <div className="mt-auto flex flex-col gap-1.5 pt-2.5">
          {showChips ? (
            <div className="flex flex-wrap items-center gap-1.5">
              {fields.department && e.department ? (
                <span
                  className="max-w-[58%] truncate rounded-md px-1.5 py-0.5 text-[10.5px] font-medium"
                  style={{ background: theme.chip, color: theme.muted }}
                >
                  {e.department}
                </span>
              ) : null}
              {fields.location && e.country ? (
                <span
                  className="inline-flex max-w-[46%] items-center gap-1 truncate rounded-md px-1.5 py-0.5 text-[10.5px] font-medium"
                  style={{ background: theme.chip, color: theme.muted }}
                >
                  <MapPin className="size-3 shrink-0" />
                  {e.country}
                </span>
              ) : null}
              {fields.costCenter && e.costCenter ? (
                <span
                  className="truncate rounded-md px-1.5 py-0.5 text-[10.5px] font-medium tabular-nums"
                  style={{ background: theme.chip, color: theme.muted }}
                >
                  {e.costCenter}
                </span>
              ) : null}
            </div>
          ) : null}
          {showMetrics ? (
            <div
              className="flex items-center gap-4 border-t pt-2"
              style={{ borderColor: `color-mix(in srgb, ${theme.border} 70%, transparent)` }}
            >
              {fields.span && d.span > 0 ? (
                <span
                  title={`Span of control: ${d.span} direct report${d.span === 1 ? "" : "s"}`}
                  className="inline-flex items-center gap-1.5 text-[11.5px] font-semibold tabular-nums"
                  style={{ color: wideSpan ? "var(--color-warning)" : theme.muted }}
                >
                  <GitFork className="size-3" style={{ color: wideSpan ? "var(--color-warning)" : accent }} />
                  {d.span}
                  <span className="text-[9px] font-medium uppercase tracking-[0.08em] opacity-75">
                    span
                  </span>
                </span>
              ) : null}
              {fields.reports && d.reportsTotal > (e.plannedHeadcount || 0) ? (
                <span
                  title={`Total headcount in this branch: ${d.reportsTotal}`}
                  className="inline-flex items-center gap-1.5 text-[11.5px] font-semibold tabular-nums"
                  style={{ color: theme.muted }}
                >
                  <Users className="size-3" style={{ color: accent }} />
                  {d.reportsTotal}
                  <span className="text-[9px] font-medium uppercase tracking-[0.08em] opacity-75">
                    total
                  </span>
                </span>
              ) : fields.headcount ? (
                <span
                  title="Planned headcount for this role"
                  className="inline-flex items-center gap-1.5 text-[11.5px] font-semibold tabular-nums"
                  style={{ color: theme.muted }}
                >
                  <Users className="size-3" style={{ color: accent }} />
                  {e.plannedHeadcount}
                  <span className="text-[9px] font-medium uppercase tracking-[0.08em] opacity-75">
                    FTE
                  </span>
                </span>
              ) : null}
            </div>
          ) : null}
        </div>
      ) : null}
      {d.childCount > 0 && (
        <button
          onClick={(event) => {
            event.stopPropagation();
            d.onToggle(e.id);
          }}
          title={d.collapsed ? "Expand branch" : "Collapse branch"}
          className="nodrag nopan absolute -bottom-[10px] left-1/2 z-20 flex -translate-x-1/2 items-center gap-1 rounded-full border px-2 py-[2px] text-[10px] font-semibold leading-none transition-transform hover:scale-110"
          style={{
            background: theme.surface,
            borderColor: `color-mix(in srgb, ${accent} 55%, transparent)`,
            color: accent,
            boxShadow: `0 2px 6px -2px color-mix(in srgb, ${theme.text} 30%, transparent)`,
          }}
        >
          {d.collapsed ? (
            <ChevronRight className="size-3" />
          ) : (
            <ChevronDown className="size-3" />
          )}
          {d.childCount}
        </button>
      )}
      <Handle
        type="source"
        position={horizontal ? Position.Right : Position.Bottom}
        title="Drag from here to link a reporting line"
        className={cn(
          "!border-2 transition-all",
          hovered || d.selected
            ? "!size-3 !border-white/90"
            : "!size-2 !border-transparent",
        )}
        style={{ background: accent }}
      />
    </div>
  );
}

const nodeTypes = { org: OrgNode };

function Canvas({
  scenario,
  layout,
  selectedId,
  onSelect,
  onReparent,
  onMove,
  onResizeNode,
  onDottedLink,
  onLineChange,
  themeId = "clay",
  colorBy = "status",
  diffMode = false,
  diffClasses,
  showViewTools = true,
  hideMetrics = false,
  searchValue,
  onSearchValueChange,
  cardFields = DEFAULT_CARD_FIELDS,
  density,
  onDensityChange,
  onAddChild,
  onAddRoot,
  onDeleteRole,
  onRename,
}: {
  scenario: Scenario;
  layout: LayoutKind;
  selectedId: string | null;
  onSelect: (id: string) => void;
  onReparent?: (childId: string, managerId: string | null) => void;
  onMove?: (id: string, pos: { x: number; y: number }) => void;
  onResizeNode?: (id: string, size: { w: number; h: number }) => void;
  onDottedLink?: (childId: string, managerId: string) => void;
  /** Restyles or removes an existing reporting line (click a connector). */
  onLineChange?: (childId: string, managerId: string, action: "solid" | "dotted" | "remove") => void;
  themeId?: string;
  colorBy?: ColorBy;
  /** Colour every card by its change status instead of the palette. */
  diffMode?: boolean;
  diffClasses?: Map<string, DiffClass>;
  /** Show the search / zoom toolbar (hidden in the read-only compare pane). */
  showViewTools?: boolean;
  /** Hide the on-canvas live metrics strip (the studio top bar shows it). */
  hideMetrics?: boolean;
  /** Controlled search query from the studio top bar; hides the on-canvas box. */
  searchValue?: string | undefined;
  onSearchValueChange?: ((value: string) => void) | undefined;
  /** Which optional attributes appear on each card. */
  cardFields?: CardFields;
  /** Active card density preset, or "custom" when fields were hand-tuned. */
  density?: CardDensity | "custom";
  /** Applies a card density preset from the canvas toolbar. */
  onDensityChange?: (level: CardDensity) => void;
  /** Adds a new open role under the given manager (enables on-card + buttons). */
  onAddChild?: (managerId: string) => void;
  /** Adds a new top-level role (enables the toolbar “Add role” button). */
  onAddRoot?: () => void;
  /** Deletes a role (enables on-card delete buttons). */
  onDeleteRole?: (id: string) => void;
  /** Saves inline card edits (double-click a title or name to type). */
  onRename?: (id: string, patch: { title?: string; name?: string }) => void;
}) {
  const READABLE_ZOOM = 0.95;
  const [collapsed, setCollapsed] = useState<Set<string>>(() =>
    collapseBelowDepth(scenario.employees, 2),
  );
  const [sizes, setSizes] = useState<Record<string, { w: number; h: number }>>(
    () => scenario.nodeSizes ?? {},
  );
  const { getIntersectingNodes, setCenter, fitView, fitBounds, zoomIn, zoomOut, getZoom } =
    useReactFlow();
  const { zoom: viewportZoom } = useViewport();
  const [internalQuery, setInternalQuery] = useState("");
  const searchControlled = searchValue !== undefined;
  const query = searchControlled ? searchValue : internalQuery;
  const setQuery = useCallback(
    (value: string) => {
      if (searchControlled) onSearchValueChange?.(value);
      else setInternalQuery(value);
    },
    [searchControlled, onSearchValueChange],
  );
  const overridesRef = useRef<Record<string, { x: number; y: number }>>({});
  const [nodes, setNodes] = useState<Node[]>([]);
  const theme = useMemo(() => getTheme(themeId), [themeId]);
  /** The connector the user last clicked — drives the line restyle bar. */
  const [selectedEdgeId, setSelectedEdgeId] = useState<string | null>(null);
  /** One-time “how to draw reporting lines” hint, dismissible forever. */
  const [linkHintDismissed, setLinkHintDismissed] = useState(() => {
    try {
      return window.localStorage.getItem("orgeasy.chart.linkHintDismissed") === "1";
    } catch {
      return false;
    }
  });
  const dismissLinkHint = () => {
    setLinkHintDismissed(true);
    try {
      window.localStorage.setItem("orgeasy.chart.linkHintDismissed", "1");
    } catch {
      /* storage unavailable */
    }
  };

  useEffect(() => {
    overridesRef.current = { ...(scenario.positions ?? {}) };
  }, [layout, scenario.id, scenario.positions]);

  useEffect(() => {
    setSelectedEdgeId(null);
  }, [layout, scenario.id]);

  // Switching scenario re-applies the "top three layers expanded" default.
  useEffect(() => {
    setCollapsed(collapseBelowDepth(scenario.employees, 2));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scenario.id]);

  // Card sizes persist with the scenario, so pick up saved sizes on switch.
  useEffect(() => {
    setSizes(scenario.nodeSizes ?? {});
  }, [scenario.id, scenario.nodeSizes]);

  const toggle = useCallback((id: string) => {
    setCollapsed((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const handleResize = useCallback(
    (id: string, size: { w: number; h: number }) => {
      setSizes((prev) => ({ ...prev, [id]: size }));
      onResizeNode?.(id, size);
    },
    [onResizeNode],
  );

  /** Change status for the visual diff palette, defaulting to unchanged. */
  const diffClassOf = useCallback(
    (e: Employee): DiffClass =>
      diffClasses?.get(e.id) ?? (e.status === "to-be-removed" ? "removed" : "unchanged"),
    [diffClasses],
  );

  const { nodes: computedNodes, edges } = useMemo(() => {
    const size = nodeSize(layout);
    const { positions, visible } = computeLayout(scenario.employees, layout, collapsed);
    const posById = new Map(positions.map((p) => [p.id, p]));
    const levels = levelMap(scenario.employees);
    const encode = buildEncodeContext(scenario.employees);
    const childCounts = new Map<string, number>();
    const kidsOf = new Map<string, string[]>();
    for (const e of scenario.employees) {
      if (!e.managerId) continue;
      childCounts.set(e.managerId, (childCounts.get(e.managerId) ?? 0) + 1);
      kidsOf.set(e.managerId, [...(kidsOf.get(e.managerId) ?? []), e.id]);
    }

    // Total planned headcount in each branch, computed once per render.
    const byIdAll = new Map(scenario.employees.map((e) => [e.id, e]));
    const subtree = new Map<string, number>();
    const totalUnder = (id: string, guard = new Set<string>()): number => {
      if (subtree.has(id)) return subtree.get(id)!;
      if (guard.has(id)) return 0;
      guard.add(id);
      const self = byIdAll.get(id)?.plannedHeadcount ?? 0;
      const total =
        self + (kidsOf.get(id) ?? []).reduce((sum, kid) => sum + totalUnder(kid, guard), 0);
      subtree.set(id, total);
      return total;
    };
    scenario.employees.forEach((e) => totalUnder(e.id));


    const flowNodes: Node[] = scenario.employees
      .filter((e) => visible.has(e.id))
      .map((e) => {
        const base = posById.get(e.id) ?? { x: 0, y: 0 };
        const saved = scenario.positions?.[e.id];
        const pos = overridesRef.current[e.id] ?? saved ?? { x: base.x, y: base.y };
        const cls = diffClassOf(e);
        return {
          id: e.id,
          type: "org",
          position: pos,
          style: {
            width: sizes[e.id]?.w ?? size.w,
            height: sizes[e.id]?.h ?? size.h,
          },
          data: {
            employee: e,
            childCount: childCounts.get(e.id) ?? 0,
            collapsed: collapsed.has(e.id),
            size: { ...size, ...(sizes[e.id] ?? {}) },
            horizontal: layout === "horizontal",
            onToggle: toggle,
            onSelect,
            onResize: handleResize,
            selected: selectedId === e.id,
            accent: diffMode
              ? `#${DIFF_CLASS_META[cls].hex}`
              : accentFor(e, colorBy, theme, levels, encode),
            theme,
            dim: diffMode && cls === "unchanged",
            span: childCounts.get(e.id) ?? 0,
            reportsTotal: subtree.get(e.id) ?? e.plannedHeadcount,
            fields: cardFields,
            onAddChild,
            onDeleteRole,
            onRename,
          } satisfies OrgNodeData as unknown as Record<string, unknown>,
        };
      });

    const flowEdges: Edge[] =
      layout === "department"
        ? []
        : scenario.employees
            .filter((e) => e.managerId && visible.has(e.id) && visible.has(e.managerId))
            .map((e) => ({
              id: `${e.managerId}-${e.id}`,
              source: e.managerId!,
              target: e.id,
              type: layout === "radial" || layout === "mindmap" ? "straight" : "smoothstep",
              pathOptions:
                layout === "radial" || layout === "mindmap"
                  ? undefined
                  : { borderRadius: 20, offset: 16 },
              animated: e.status === "planned" || e.status === "moved",
              // A generous invisible hit area makes connectors easy to click.
              interactionWidth: 18,
              style: {
                stroke: diffMode
                  ? `#${DIFF_CLASS_META[diffClassOf(e)].hex}${diffClassOf(e) === "unchanged" ? "55" : "cc"}`
                  : colorBy === "status"
                    ? e.status === "to-be-removed"
                      ? `#${STATUS_META["to-be-removed"].hex}`
                      : e.status === "planned"
                        ? `#${STATUS_META.planned.hex}`
                        : theme.edge
                    : `${accentFor(e, colorBy, theme, levels, encode)}b0`,
                strokeWidth: 1.75,
                strokeDasharray: e.status === "planned" ? "6 5" : undefined,
                strokeLinecap: "round",
              },
            }));

    const dottedEdges: Edge[] =
      layout === "department"
        ? []
        : scenario.employees.flatMap((e) =>
            (e.dottedManagerIds ?? [])
              .filter((mid) => mid !== e.managerId && visible.has(e.id) && visible.has(mid))
              .map((mid) => ({
                id: `dotted-${mid}-${e.id}`,
                source: mid,
                target: e.id,
                type: "smoothstep",
                pathOptions: { borderRadius: 20, offset: 16 },
                interactionWidth: 18,
                style: {
                  stroke: theme.muted,
                  strokeWidth: 1.5,
                  strokeDasharray: "2 6",
                  strokeLinecap: "round" as const,
                },
              })),
          );

    return { nodes: flowNodes, edges: [...flowEdges, ...dottedEdges] };
  }, [
    scenario.employees,
    scenario.positions,
    layout,
    collapsed,
    sizes,
    selectedId,
    toggle,
    onSelect,
    handleResize,
    theme,
    colorBy,
    cardFields,
    diffMode,
    diffClassOf,
    onAddChild,
    onDeleteRole,
    onRename,
  ]);

  // Highlight the connector the user clicked so the restyle bar has context.
  const displayEdges = useMemo(
    () =>
      selectedEdgeId
        ? edges.map((edge) =>
            edge.id === selectedEdgeId
              ? { ...edge, selected: true, style: { ...edge.style, strokeWidth: 3 } }
              : edge,
          )
        : edges,
    [edges, selectedEdgeId],
  );

  /** Manager → role details for the clicked connector, if it still exists. */
  const selectedEdgeInfo = useMemo(() => {
    if (!selectedEdgeId) return null;
    const edge = edges.find((e) => e.id === selectedEdgeId);
    if (!edge) return null;
    const byId = new Map(scenario.employees.map((e) => [e.id, e]));
    const child = byId.get(String(edge.target));
    const manager = byId.get(String(edge.source));
    if (!child || !manager) return null;
    return { child, manager, dotted: selectedEdgeId.startsWith("dotted-") };
  }, [selectedEdgeId, edges, scenario.employees]);

  // Merge freshly computed nodes into React Flow's own node state, keeping the
  // internal measurements (and live drag positions) that React Flow attaches.
  useEffect(() => {
    setNodes((prev) => {
      const prevById = new Map(prev.map((n) => [n.id, n]));
      return computedNodes.map((n) => {
        const old = prevById.get(n.id);
        if (!old) return n;
        return { ...old, ...n, position: overridesRef.current[n.id] ?? n.position };
      });
    });
  }, [computedNodes]);

  const handleNodesChange = useCallback(
    (changes: NodeChange[]) => {
      setNodes((prev) => applyNodeChanges(changes, prev));
      for (const change of changes) {
        if (change.type === "position" && change.position) {
          overridesRef.current[change.id] = change.position;
          if (change.dragging === false) onMove?.(change.id, change.position);
        }
      }
    },
    [onMove],
  );

  // Tracks Shift so a drawn line can become a dotted secondary reporting line.
  const shiftRef = useRef(false);
  useEffect(() => {
    const track = (ev: KeyboardEvent) => {
      shiftRef.current = ev.shiftKey;
    };
    window.addEventListener("keydown", track);
    window.addEventListener("keyup", track);
    return () => {
      window.removeEventListener("keydown", track);
      window.removeEventListener("keyup", track);
    };
  }, []);

  /** True when making `childId` report to `managerId` would create a loop. */
  const wouldCycle = useCallback(
    (childId: string, managerId: string) => {
      if (childId === managerId) return true;
      const byId = new Map(scenario.employees.map((emp) => [emp.id, emp]));
      let cursor: string | null | undefined = managerId;
      const guard = new Set<string>();
      while (cursor && !guard.has(cursor)) {
        if (cursor === childId) return true;
        guard.add(cursor);
        cursor = byId.get(cursor)?.managerId ?? null;
      }
      return false;
    },
    [scenario.employees],
  );

  // Drop-target highlight: while a card is dragged over another card, ring the
  // target with the accent colour (safe re-parent) or red (would loop).
  const [dropTarget, setDropTarget] = useState<{ id: string; valid: boolean } | null>(null);
  const dropTargetRef = useRef<{ id: string; valid: boolean } | null>(null);
  const displayNodes = useMemo(
    () =>
      dropTarget
        ? nodes.map((n) =>
            n.id === dropTarget.id
              ? {
                  ...n,
                  data: { ...n.data, dropTarget: dropTarget.valid ? "valid" : "invalid" },
                }
              : n,
          )
        : nodes,
    [nodes, dropTarget],
  );

  // Live model metrics: recomputed on every structural change so span, layers,
  // cost and the AI-agent ratio update instantly while the user edits.
  const live = useMemo(() => {
    if (!showViewTools) return null;
    const active = scenario.employees.filter((e) => e.status !== "to-be-removed");
    if (!active.length) return null;
    const spans = analyseSpans(scenario);
    const cost = computeCostModel(scenario.employees);
    let fte = 0;
    let agentFte = 0;
    let dotted = 0;
    for (const e of active) {
      const f = Math.max(e.plannedHeadcount || e.currentHeadcount || 0, 0);
      fte += f;
      const t = roleTypeOf(e);
      agentFte += t === "agent" ? f : t === "hybrid" ? f * HYBRID_AGENT_SHARE : 0;
      dotted += (e.dottedManagerIds ?? []).length;
    }
    return {
      roles: active.length,
      fte,
      layers: spans.maxLayer,
      avgSpan: spans.avgSpan,
      wide: spans.wide.length,
      cost: cost.planned.total,
      agentShare: fte ? agentFte / fte : 0,
      dotted,
    };
  }, [scenario, showViewTools]);

  const cardSize = nodeSize(layout);

  /** Centres the viewport on a card at a comfortable reading zoom. */
  const centerOn = useCallback(
    (id: string, zoom?: number) => {
      const node = computedNodes.find((n) => n.id === id);
      if (!node) return;
      const w = Number(node.style?.width ?? cardSize.w);
      const h = Number(node.style?.height ?? cardSize.h);
      const pos = overridesRef.current[id] ?? node.position;
      setCenter(pos.x + w / 2, pos.y + h / 2, {
        zoom: zoom ?? Math.max(getZoom(), READABLE_ZOOM),
        duration: 500,
      });
    },
    [computedNodes, cardSize.w, cardSize.h, setCenter, getZoom],
  );

  /**
   * Brings a card into view together with its line manager, so a freshly added
   * or searched role never lands on an apparently empty canvas.
   */
  const focusWithContext = useCallback(
    (id: string) => {
      const node = computedNodes.find((n) => n.id === id);
      if (!node) return;
      const managerId = scenario.employees.find((e) => e.id === id)?.managerId ?? null;
      const manager = managerId ? computedNodes.find((n) => n.id === managerId) : undefined;
      // No line manager (a new top-level role) — pull in the nearest card so the
      // user can see where on the canvas the role landed.
      const neighbour =
        manager ??
        [...computedNodes]
          .filter((n) => n.id !== id)
          .sort(
            (a, b) =>
              Math.hypot(a.position.x - node.position.x, a.position.y - node.position.y) -
              Math.hypot(b.position.x - node.position.x, b.position.y - node.position.y),
          )[0];
      if (!neighbour) {
        centerOn(id);
        return;
      }
      const boxes = [node, neighbour].map((n) => {
        const pos = overridesRef.current[n.id] ?? n.position;
        return {
          x: pos.x,
          y: pos.y,
          w: Number(n.style?.width ?? cardSize.w),
          h: Number(n.style?.height ?? cardSize.h),
        };
      });

      const minX = Math.min(...boxes.map((b) => b.x));
      const minY = Math.min(...boxes.map((b) => b.y));
      const maxX = Math.max(...boxes.map((b) => b.x + b.w));
      const maxY = Math.max(...boxes.map((b) => b.y + b.h));
      // If the pair is far apart, fitting both would zoom out past the minimum
      // and show neither card — centre on the role itself instead.
      if (maxX - minX > cardSize.w * 6 || maxY - minY > cardSize.h * 6) {
        centerOn(id);
        return;
      }
      fitBounds(
        { x: minX, y: minY, width: maxX - minX, height: maxY - minY },
        { duration: 500, padding: 0.3 },
      );

    },
    [computedNodes, scenario.employees, cardSize.w, cardSize.h, centerOn, fitBounds],
  );

  /** “Readable size”: 1:1-ish zoom anchored on the top of the house. */
  const readableSize = useCallback(() => {
    const top = [...computedNodes].sort(
      (a, b) => a.position.y - b.position.y || a.position.x - b.position.x,
    )[0];
    if (!top) return;
    const w = Number(top.style?.width ?? cardSize.w);
    setCenter(top.position.x + w / 2, top.position.y + cardSize.h * 1.35, {
      zoom: READABLE_ZOOM,
      duration: 400,
    });
  }, [computedNodes, cardSize.w, cardSize.h, setCenter]);

  // Readable size is the default view for each scenario / layout — unless a
  // specific role is waiting to be brought into view (e.g. one just added),
  // which would otherwise be overridden by this default.
  const viewKey = `${scenario.id}:${layout}`;
  const appliedViewRef = useRef<string>("");
  const readyRef = useRef(false);
  const pendingFocus = useRef<string | null>(null);
  useEffect(() => {
    if (!readyRef.current || !computedNodes.length || appliedViewRef.current === viewKey) return;
    appliedViewRef.current = viewKey;
    if (pendingFocus.current || selectedId) return;
    const t = window.setTimeout(() => {
      if (!pendingFocus.current && !selectedId) readableSize();
    }, 60);
    return () => window.clearTimeout(t);
  }, [viewKey, computedNodes.length, readableSize, selectedId]);


  // A selected role must be visible: expand every collapsed ancestor, otherwise
  // a role added under a collapsed manager would never appear on the canvas.
  useEffect(() => {
    if (!selectedId) return;
    setCollapsed((prev) => {
      const byId = new Map(scenario.employees.map((e) => [e.id, e]));
      const next = new Set(prev);
      const guard = new Set<string>();
      let cursor = byId.get(selectedId)?.managerId ?? null;
      let changed = false;
      while (cursor && !guard.has(cursor)) {
        guard.add(cursor);
        if (next.delete(cursor)) changed = true;
        cursor = byId.get(cursor)?.managerId ?? null;
      }
      return changed ? next : prev;
    });
  }, [selectedId, scenario.employees]);

  // Selecting or searching a role brings it into view once the layout contains
  // it (a brand-new card only appears on the next layout pass).
  useEffect(() => {
    if (selectedId) pendingFocus.current = selectedId;
  }, [selectedId]);

  useEffect(() => {
    const id = pendingFocus.current;
    if (!id || !computedNodes.some((n) => n.id === id)) return;
    pendingFocus.current = null;
    // Called straight away: a cleanup-cancelled timer would be wiped out by the
    // very next layout pass, leaving the role off-screen.
    focusWithContext(id);
  }, [computedNodes, focusWithContext]);



  const matches = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (q.length < 2) return [];
    return scenario.employees
      .filter(
        (e) =>
          e.title.toLowerCase().includes(q) ||
          (e.name ?? "").toLowerCase().includes(q) ||
          (e.department ?? "").toLowerCase().includes(q),
      )
      .slice(0, 8);
  }, [query, scenario.employees]);

  /** Expands every ancestor of a role so a searched card is actually visible. */
  const revealAndSelect = useCallback(
    (id: string) => {
      const byId = new Map(scenario.employees.map((e) => [e.id, e]));
      const ancestors: string[] = [];
      let cur = byId.get(id)?.managerId ?? null;
      const guard = new Set<string>();
      while (cur && !guard.has(cur)) {
        guard.add(cur);
        ancestors.push(cur);
        cur = byId.get(cur)?.managerId ?? null;
      }
      setCollapsed((prev) => {
        const next = new Set(prev);
        ancestors.forEach((a) => next.delete(a));
        return next;
      });
      onSelect(id);
      setQuery("");
      window.setTimeout(() => centerOn(id, Math.max(READABLE_ZOOM, 1)), 120);
    },
    [scenario.employees, onSelect, centerOn, setQuery],
  );

  /** Search hit list, shared by the on-canvas box and the top-bar dropdown. */
  const matchButtons = matches.map((m) => (
    <button
      key={m.id}
      onClick={() => revealAndSelect(m.id)}
      className="block w-full px-3 py-2 text-left text-[12.5px] hover:bg-accent"
    >
      <span className="font-semibold">{m.title}</span>
      <span className="block truncate text-[11.5px] text-muted-foreground">
        {(m.name || "Open role") + (m.department ? ` · ${m.department}` : "")}
      </span>
    </button>
  ));

  return (
    <ReactFlow
      nodes={displayNodes}
      edges={displayEdges}
      nodeTypes={nodeTypes}
      onNodesChange={handleNodesChange}
      onInit={() => {
        // The flow only knows its own size once initialised, so anchor the
        // default "readable size" view here rather than on first render.
        readyRef.current = true;
        appliedViewRef.current = viewKey;
        window.requestAnimationFrame(() => {
          if (!pendingFocus.current && !selectedId) readableSize();
        });
      }}
      onConnect={(connection) => {
        // Dragging from a manager's handle onto another card sets the reporting
        // line. Holding Shift draws a dotted (secondary) line instead.
        const manager = connection.source;
        const child = connection.target;
        if (!manager || !child || manager === child) return;
        if (shiftRef.current) onDottedLink?.(child, manager);
        else onReparent?.(child, manager);
      }}
      isValidConnection={(connection) => {
        const manager = connection.source;
        const child = connection.target;
        if (!manager || !child || manager === child) return false;
        // Block loops: the child must not be an ancestor of the manager.
        return !wouldCycle(child, manager);
      }}
      connectionLineStyle={{ stroke: theme.edge, strokeWidth: 2.5 }}
      // A generous snap radius so a drawn line connects even when the drop
      // lands a little off the target card.
      connectionRadius={48}
      onPaneClick={() => setSelectedEdgeId(null)}
      onNodeDrag={(_event, node) => {
        // Ring the card under the dragged one so re-parenting has visual
        // feedback before the drop lands.
        const hit = getIntersectingNodes(node).find((n) => n.id !== node.id);
        const next = hit ? { id: hit.id, valid: !wouldCycle(node.id, hit.id) } : null;
        const prev = dropTargetRef.current;
        if (next?.id !== prev?.id || next?.valid !== prev?.valid) {
          dropTargetRef.current = next;
          setDropTarget(next);
        }
      }}
      onNodeDragStop={(event, node) => {
        dropTargetRef.current = null;
        setDropTarget(null);
        // Only relink when the card was actually dropped on top of another card.
        const hit = getIntersectingNodes(node).find((n) => n.id !== node.id);
        if (!hit) return;
        const shift = "shiftKey" in event ? Boolean((event as MouseEvent).shiftKey) : false;
        if (shift) onDottedLink?.(node.id, hit.id);
        else onReparent?.(node.id, hit.id);
      }}
      minZoom={0.08}
      maxZoom={2.5}
      defaultViewport={{ x: 0, y: 0, zoom: READABLE_ZOOM }}
      zoomOnScroll
      zoomOnPinch
      zoomOnDoubleClick
      panOnDrag
      panOnScroll={false}
      selectionOnDrag={false}
      // Clicking a connector opens the line actions (solid / dotted / remove)
      // and selects the role it points at.
      onEdgeClick={(_event, edge) => {
        setSelectedEdgeId(edge.id);
        if (edge.target) onSelect(edge.target);
      }}
      // Enterprise-scale charts render only what the viewport can show.
      onlyRenderVisibleElements
      proOptions={{ hideAttribution: true }}
      style={{ background: theme.canvas }}
      defaultEdgeOptions={{ type: "smoothstep" }}
    >
      <Background variant={BackgroundVariant.Dots} gap={26} size={1.4} color={theme.dot} />
      {showViewTools ? (
      <Panel position="bottom-center" className="!m-3">
        <div className="flex items-center gap-2 rounded-xl border border-border bg-card/95 p-1.5 shadow-panel backdrop-blur">
          {!searchControlled ? (
            <>
              <div className="relative">
                <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={query}
                  onChange={(ev) => setQuery(ev.target.value)}
                  placeholder="Find a role or person"
                  aria-label="Find a role or person on the chart"
                  className="nodrag nopan h-8 w-56 pl-8 text-[12.5px]"
                />
                {matches.length ? (
                  <div className="absolute bottom-9 left-0 z-20 w-72 overflow-hidden rounded-lg border border-border bg-popover shadow-panel">
                    {matchButtons}
                  </div>
                ) : null}
              </div>
              <div className="h-6 w-px bg-border" />
            </>
          ) : null}
          <Button size="sm" variant="secondary" className="h-8" onClick={readableSize}>
            <Type className="mr-1.5 size-3.5" /> Readable size
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="h-8"
            onClick={() => fitView({ duration: 400, padding: 0.15, maxZoom: 1.1 })}
          >
            <Maximize2 className="mr-1.5 size-3.5" /> Fit to screen
          </Button>
          {onAddRoot ? (
            <Button
              size="sm"
              variant="default"
              className="h-8"
              title="Add a new top-level role to this chart"
              onClick={onAddRoot}
            >
              <UserPlus className="mr-1.5 size-3.5" /> Add role
            </Button>
          ) : null}
          {onDensityChange ? (
            <>
              <div className="h-6 w-px bg-border" />
              <div
                role="group"
                aria-label="Card density"
                className="flex items-center gap-0.5 rounded-lg border border-border/70 bg-muted/30 p-0.5"
              >
                {(Object.keys(CARD_DENSITY_PRESETS) as CardDensity[]).map((level) => {
                  const preset = CARD_DENSITY_PRESETS[level];
                  const DensityIcon =
                    level === "compact" ? Rows3 : level === "detailed" ? StretchVertical : Rows2;
                  const active = density === level;
                  return (
                    <button
                      key={level}
                      type="button"
                      title={`${preset.label} — ${preset.hint}`}
                      aria-pressed={active}
                      onClick={() => onDensityChange(level)}
                      className={cn(
                        "grid size-7 place-items-center rounded-md transition-colors",
                        active
                          ? "bg-card text-foreground shadow-sm"
                          : "text-muted-foreground hover:text-foreground",
                      )}
                    >
                      <DensityIcon className="size-3.5" />
                    </button>
                  );
                })}
              </div>
            </>
          ) : null}
          <div className="h-6 w-px bg-border" />
          <div className="flex items-center gap-0.5">
            <Button
              size="icon"
              variant="ghost"
              className="size-8"
              aria-label="Zoom out"
              onClick={() => zoomOut({ duration: 220 })}
            >
              <Minus className="size-4" />
            </Button>
            <button
              type="button"
              onClick={readableSize}
              title="Reset to readable size"
              aria-label={`Current zoom ${Math.round(viewportZoom * 100)} percent — reset to readable size`}
              className="h-8 min-w-11 rounded-md px-1 text-[11.5px] font-semibold tabular-nums text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
            >
              {Math.round(viewportZoom * 100)}%
            </button>
            <Button
              size="icon"
              variant="ghost"
              className="size-8"
              aria-label="Zoom in"
              onClick={() => zoomIn({ duration: 220 })}
            >
              <Plus className="size-4" />
            </Button>
          </div>
        </div>
      </Panel>
      ) : null}
      {showViewTools && searchControlled && matches.length ? (
        <Panel position="top-left" className="!m-3">
          <div className="nodrag nopan w-72 overflow-hidden rounded-lg border border-border bg-popover shadow-panel">
            {matchButtons}
          </div>
        </Panel>
      ) : null}
      {live && !hideMetrics ? (
        <Panel position="top-center" className="!m-3">
          <div className="nodrag nopan flex items-center divide-x divide-border rounded-xl border border-border bg-card/95 px-4 py-2 shadow-panel backdrop-blur">
            <span className="flex items-center gap-1.5 pr-3.5 text-[9.5px] font-bold uppercase tracking-[0.14em] text-brand">
              <span className="relative flex size-1.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand opacity-60" />
                <span className="relative inline-flex size-1.5 rounded-full bg-brand" />
              </span>
              Live model
            </span>
            <span className="flex items-center gap-1.5 px-3.5" title="Active roles on the canvas">
              <Users className="size-3.5 text-muted-foreground" />
              <span className="text-[12.5px] font-semibold tabular-nums">
                {live.roles.toLocaleString()}
              </span>
              <span className="text-[9px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
                Roles
              </span>
            </span>
            <span className="flex items-center gap-1.5 px-3.5" title="Planned full-time equivalents">
              <Activity className="size-3.5 text-muted-foreground" />
              <span className="text-[12.5px] font-semibold tabular-nums">
                {live.fte.toLocaleString()}
              </span>
              <span className="text-[9px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
                FTE
              </span>
            </span>
            <span
              className="flex items-center gap-1.5 px-3.5"
              title={`Organisation depth — benchmark up to ${SPAN_BENCHMARK.maxLayers} layers`}
            >
              <Layers3
                className={cn(
                  "size-3.5",
                  live.layers > SPAN_BENCHMARK.maxLayers ? "text-warning" : "text-muted-foreground",
                )}
              />
              <span className="text-[12.5px] font-semibold tabular-nums">{live.layers}</span>
              <span className="text-[9px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
                Layers
              </span>
            </span>
            <span
              className="flex items-center gap-1.5 px-3.5"
              title={
                live.wide
                  ? `${live.wide} manager${live.wide === 1 ? "" : "s"} over ${SPAN_BENCHMARK.wideSpan} direct reports`
                  : "Average direct reports per manager"
              }
            >
              <GitFork
                className={cn("size-3.5", live.wide ? "text-warning" : "text-muted-foreground")}
              />
              <span className="text-[12.5px] font-semibold tabular-nums">
                {live.avgSpan.toFixed(1)}
              </span>
              <span className="text-[9px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
                Avg span{live.wide ? ` · ${live.wide} wide` : ""}
              </span>
            </span>
            <span className="flex items-center gap-1.5 px-3.5" title="Total planned annual cost">
              <CircleDollarSign className="size-3.5 text-muted-foreground" />
              <span className="text-[12.5px] font-semibold tabular-nums">
                {live.cost >= 1e9
                  ? `$${(live.cost / 1e9).toFixed(2)}B`
                  : live.cost >= 1e6
                    ? `$${(live.cost / 1e6).toFixed(1)}M`
                    : `$${Math.round(live.cost / 1e3)}K`}
              </span>
              <span className="text-[9px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
                / yr
              </span>
            </span>
            <span
              className="flex items-center gap-1.5 px-3.5"
              title="Share of planned capacity delivered by AI agents"
            >
              <Bot className="size-3.5 text-muted-foreground" />
              <span className="text-[12.5px] font-semibold tabular-nums">
                {Math.round(live.agentShare * 100)}%
              </span>
              <span className="text-[9px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
                AI agent
              </span>
            </span>
            <span
              className="flex items-center gap-1.5 pl-3.5"
              title="Dotted secondary reporting lines (matrix)"
            >
              <Network className="size-3.5 text-muted-foreground" />
              <span className="text-[12.5px] font-semibold tabular-nums">{live.dotted}</span>
              <span className="text-[9px] font-medium uppercase tracking-[0.08em] text-muted-foreground">
                Matrix
              </span>
            </span>
          </div>
        </Panel>
      ) : null}
      {selectedEdgeInfo && onLineChange ? (
        <Panel position="top-center" className={cn("!mx-3", live && !hideMetrics ? "!mt-16" : "!mt-3")}>
          <div className="nodrag nopan flex items-center gap-2 rounded-xl border border-border bg-card/95 py-1.5 pl-3 pr-1.5 shadow-panel backdrop-blur">
            <div className="min-w-0">
              <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                {selectedEdgeInfo.dotted ? "Dotted reporting line" : "Reporting line"}
              </p>
              <p className="max-w-64 truncate text-[12.5px] font-medium leading-tight">
                {selectedEdgeInfo.manager.title} → {selectedEdgeInfo.child.title}
              </p>
            </div>
            <div className="h-6 w-px bg-border" />
            {selectedEdgeInfo.dotted ? (
              <Button
                size="sm"
                variant="secondary"
                className="h-8"
                onClick={() => {
                  onLineChange(selectedEdgeInfo.child.id, selectedEdgeInfo.manager.id, "solid");
                  setSelectedEdgeId(null);
                }}
              >
                Make solid
              </Button>
            ) : (
              <Button
                size="sm"
                variant="secondary"
                className="h-8"
                onClick={() => {
                  onLineChange(selectedEdgeInfo.child.id, selectedEdgeInfo.manager.id, "dotted");
                  setSelectedEdgeId(null);
                }}
              >
                Make dotted
              </Button>
            )}
            <Button
              size="sm"
              variant="ghost"
              className="h-8 text-destructive hover:text-destructive"
              onClick={() => {
                onLineChange(selectedEdgeInfo.child.id, selectedEdgeInfo.manager.id, "remove");
                setSelectedEdgeId(null);
              }}
            >
              <Trash2 className="mr-1 size-3.5" /> Remove line
            </Button>
            <Button
              size="icon"
              variant="ghost"
              className="size-7"
              aria-label="Close line actions"
              onClick={() => setSelectedEdgeId(null)}
            >
              <X className="size-4" />
            </Button>
          </div>
        </Panel>
      ) : null}
      {showViewTools && !linkHintDismissed && !selectedEdgeInfo ? (
        <Panel position="top-left" className="!m-3">
          <div className="nodrag nopan flex max-w-xs items-start gap-2 rounded-xl border border-border bg-card/95 px-3 py-2.5 shadow-panel backdrop-blur">
            <GitFork className="mt-0.5 size-4 shrink-0 text-brand" />
            <div className="min-w-0 flex-1">
              <p className="text-[12px] font-semibold leading-tight">Editing the structure</p>
              <p className="mt-1 text-[11.5px] leading-snug text-muted-foreground">
                Drag a card onto another card to re-parent it, or drag from the dot under a card to
                draw a line — hold{" "}
                <kbd className="rounded border border-border bg-muted px-1 text-[10px]">Shift</kbd>{" "}
                for a dotted matrix line. Click any line to restyle or remove it.
              </p>
            </div>
            <Button
              size="icon"
              variant="ghost"
              className="size-6 shrink-0"
              aria-label="Dismiss editing hint"
              onClick={dismissLinkHint}
            >
              <X className="size-3.5" />
            </Button>
          </div>
        </Panel>
      ) : null}
      <MiniMap
        pannable
        zoomable
        maskColor="oklch(0.21 0.06 258 / 0.10)"
        nodeColor={(n) => String((n.data as unknown as OrgNodeData)?.accent ?? theme.edge)}
        className="!rounded-xl !border !shadow-panel"
        style={{ background: theme.surface, borderColor: theme.border }}
      />
      <Controls
        showInteractive={false}
        className="!rounded-xl !border !shadow-panel [&_button]:!border-border/60 [&_button]:!bg-transparent [&_button:hover]:!bg-accent"
        style={{ background: theme.surface, borderColor: theme.border }}
      />
    </ReactFlow>
  );
}

export function OrgChartCanvas(props: Parameters<typeof Canvas>[0]) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) {
    return (
      <div className="grid h-full place-items-center text-sm text-muted-foreground">
        Preparing canvas…
      </div>
    );
  }
  return (
    <ReactFlowProvider>
      <Canvas {...props} />
    </ReactFlowProvider>
  );
}