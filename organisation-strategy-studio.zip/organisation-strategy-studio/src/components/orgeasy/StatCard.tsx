import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function StatCard({
  label,
  value,
  sub,
  tone = "default",
  icon,
}: {
  label: string;
  value: string;
  sub?: string;
  tone?: "default" | "brand" | "positive" | "negative";
  icon?: ReactNode;
}) {
  const toneClass = {
    default: "text-foreground",
    brand: "text-brand",
    positive: "text-success",
    negative: "text-destructive",
  }[tone];

  return (
    <div className="rounded-xl border border-border bg-card p-5 transition-colors hover:border-input">
      <div className="flex items-center justify-between gap-2">
        <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
          {label}
        </p>
        {icon ? <span className="text-muted-foreground/60 [&_svg]:size-3.5">{icon}</span> : null}
      </div>
      <p
        className={cn(
          "mt-3 font-display text-[28px] font-medium leading-none tracking-tight tabular-nums",
          toneClass,
        )}
      >
        {value}
      </p>
      {sub ? (
        <p className="mt-2 text-[11.5px] leading-relaxed text-muted-foreground/80">{sub}</p>
      ) : null}
    </div>
  );
}
