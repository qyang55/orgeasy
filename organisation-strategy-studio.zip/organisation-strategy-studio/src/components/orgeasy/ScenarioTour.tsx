import { useEffect, useState } from "react";
import { Layers, Plus, Repeat2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const KEY = "orgeasy.tour.scenario.v1";
const AT_KEY = "orgeasy.tour.scenario.v1.completedAt";

const STEPS = [
  {
    icon: Layers,
    title: "Start with the scenario",
    body: "This card is the control room. Everything you see on every page — charts, impact, legal, exports — reflects the scenario selected here.",
  },
  {
    icon: Repeat2,
    title: "Switch in one click",
    body: "Open the dropdown to jump between your current state and each future phase. Each entry previews its type, role count and when it was last updated.",
  },
  {
    icon: Plus,
    title: "Create or phase up",
    body: "“Add next phase” clones your latest future state into the next phase. “New scenario…” lets you name it, pick current vs future and choose a baseline to compare against.",
  },
];

function readSeen() {
  if (typeof window === "undefined") return true;
  try {
    return (
      window.localStorage.getItem(KEY) === "1" || window.sessionStorage.getItem(KEY) === "1"
    );
  } catch {
    return false;
  }
}

function markSeen() {
  try {
    window.localStorage.setItem(KEY, "1");
    window.localStorage.setItem(AT_KEY, new Date().toISOString());
  } catch {
    try {
      window.sessionStorage.setItem(KEY, "1");
      window.sessionStorage.setItem(AT_KEY, new Date().toISOString());
    } catch {
      /* storage unavailable */
    }
  }
}

export function tourCompletedAt(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.localStorage.getItem(AT_KEY) ?? window.sessionStorage.getItem(AT_KEY);
  } catch {
    return null;
  }
}

export function isScenarioTourCompleted() {
  return readSeen();
}

/** Clears the "completed" flag so the tour shows again on next load. */
export function resetScenarioTour() {
  try {
    window.localStorage.removeItem(KEY);
    window.localStorage.removeItem(AT_KEY);
  } catch {
    /* ignore */
  }
  try {
    window.sessionStorage.removeItem(KEY);
    window.sessionStorage.removeItem(AT_KEY);
  } catch {
    /* ignore */
  }
}

export function ScenarioTour({ replayKey = 0 }: { replayKey?: number }) {
  const [visible, setVisible] = useState(false);
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (replayKey > 0) {
      setStep(0);
      setVisible(true);
    }
  }, [replayKey]);

  if (!visible) return null;

  const s = STEPS[step] ?? STEPS[0]!;
  const last = step === STEPS.length - 1;
  const close = () => {
    markSeen();
    setVisible(false);
  };

  return (
    <div className="absolute left-full top-0 z-50 ml-3 w-72 animate-in fade-in slide-in-from-left-2 duration-200">
      <div className="relative rounded-xl border border-border bg-popover p-4 text-popover-foreground shadow-xl">
        <span className="absolute -left-1.5 top-6 size-3 rotate-45 border-b border-l border-border bg-popover" />
        <button
          type="button"
          aria-label="Dismiss tour"
          onClick={close}
          className="absolute right-2.5 top-2.5 rounded-md p-1 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
        >
          <X className="size-3.5" />
        </button>
        <div className="flex items-center gap-2 pr-6">
          <span className="flex size-7 items-center justify-center rounded-lg bg-brand/15 text-brand">
            <s.icon className="size-4" />
          </span>
          <p className="text-[13px] font-semibold leading-tight">{s.title}</p>
        </div>
        <p className="mt-2 text-[12px] leading-relaxed text-muted-foreground">{s.body}</p>
        <div className="mt-3 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            {STEPS.map((_, i) => (
              <span
                key={i}
                className={cn(
                  "h-1.5 rounded-full transition-all",
                  i === step ? "w-4 bg-brand" : "w-1.5 bg-border",
                )}
              />
            ))}
          </div>
          <div className="flex items-center gap-1.5">
            {step > 0 && (
              <Button variant="ghost" size="sm" className="h-7 px-2 text-[12px]" onClick={() => setStep(step - 1)}>
                Back
              </Button>
            )}
            <Button
              size="sm"
              className="h-7 px-3 text-[12px]"
              onClick={() => (last ? close() : setStep(step + 1))}
            >
              {last ? "Got it" : "Next"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
