import { Link } from "@tanstack/react-router";
import { ArrowRight, PlayCircle } from "lucide-react";
import { requestTourReplay } from "@/lib/orgeasy/first-run";

/** Clean, focused welcome hero. No bento grid, no capability rail — just the value prop and a way in. */
export function AuroraHero() {
  return (
    <section className="relative overflow-hidden rounded-3xl border border-aurora-ink/10 bg-aurora-deep px-6 py-12 text-aurora-ink sm:px-10 sm:py-16 lg:py-20">
      <div className="pointer-events-none absolute -left-28 -top-32 size-[26rem] rounded-full bg-aurora-mint/12 blur-[130px] aurora-drift" />
      <div className="pointer-events-none absolute -bottom-32 -right-24 size-[26rem] rounded-full bg-aurora-violet/15 blur-[130px] aurora-drift [animation-delay:-6s]" />
      <div className="pointer-events-none absolute inset-0 opacity-[0.05] [background-image:linear-gradient(to_right,oklch(0.27_0.022_62)_1px,transparent_1px),linear-gradient(to_bottom,oklch(0.27_0.022_62)_1px,transparent_1px)] [background-size:56px_56px]" />

      <div className="relative mx-auto max-w-3xl text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-aurora-ink/10 bg-aurora-ink/[0.04] px-3 py-1.5">
          <span className="size-2 rounded-full bg-aurora-mint" />
          <span className="font-display text-[10px] font-bold uppercase tracking-[0.2em] text-aurora-ink/70">
            Organisation design, simulated
          </span>
        </div>

        <h1 className="mt-6 font-display text-[32px] font-bold leading-[1.08] tracking-tight text-aurora-ink sm:text-[44px] lg:text-[52px]">
          Design the organisation{" "}
          <span className="bg-gradient-to-r from-aurora-violet to-aurora-mint bg-clip-text text-transparent">
            before you commit
          </span>
        </h1>

        <p className="mx-auto mt-5 max-w-xl text-[14px] leading-relaxed text-aurora-ink/55 sm:text-[15px]">
          Build current and future structures, simulate cost and capability, review Country Guidance,
          then export a leadership-ready pack.
        </p>

        <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Link
            to="/dashboard"
            className="group relative inline-flex items-center overflow-hidden rounded-lg bg-aurora-violet px-6 py-3 font-display text-sm font-semibold text-aurora-deep"
          >
            <span className="pointer-events-none absolute inset-y-0 w-1/3 -skew-x-12 bg-aurora-ink/40 aurora-sheen" />
            <span className="relative flex items-center">
              Enter the studio <ArrowRight className="ml-1.5 size-4" />
            </span>
          </Link>
          <Link
            to="/chart"
            className="inline-flex items-center rounded-lg border border-aurora-ink/15 bg-aurora-ink/5 px-6 py-3 text-sm font-medium text-aurora-ink/85 transition-colors hover:bg-aurora-ink/10"
          >
            Open org chart
          </Link>
          <button
            type="button"
            onClick={() => requestTourReplay()}
            className="inline-flex items-center gap-1.5 text-[13px] font-medium text-aurora-ink/55 transition-colors hover:text-aurora-ink"
          >
            <PlayCircle className="size-4" /> Take the tour
          </button>
        </div>
      </div>
    </section>
  );
}
