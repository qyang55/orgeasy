import { useState } from "react";
import { Loader2, Presentation } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useOrgEasy } from "@/lib/orgeasy/store";
import { downloadBoardPack } from "@/lib/orgeasy/board-pack";
import { toast } from "sonner";

/**
 * Persistent top-bar shortcut: a board-ready leadership deck for the active
 * scenario in one click, from anywhere in the studio.
 */
export function BoardPackButton() {
  const { workspace, scenario, can, recordActivity } = useOrgEasy();
  const [busy, setBusy] = useState(false);
  if (!scenario) return null;
  const allowed = can("exportPacks");
  return (
    <Button
      variant="outline"
      size="sm"
      disabled={busy || !allowed}
      title={
        allowed
          ? "Download the 5–7 slide leadership board pack for the active scenario"
          : "Your workspace role can't export packs"
      }
      onClick={async () => {
        setBusy(true);
        try {
          await downloadBoardPack(workspace, scenario, workspace.account?.email ?? null);
          recordActivity("export", `Exported the leadership board pack`, scenario.name);
          toast.success("Board pack downloaded", {
            description: "5–7 slides with cover, trade-offs, risks and editable charts.",
          });
        } catch (error) {
          console.error(error);
          toast.error("Could not build the board pack", {
            description: "Try again from Programme exports, with charts turned off.",
          });
        } finally {
          setBusy(false);
        }
      }}
    >
      {busy ? (
        <Loader2 className="mr-1.5 size-4 animate-spin" />
      ) : (
        <Presentation className="mr-1.5 size-4" />
      )}
      Board pack
    </Button>
  );
}
