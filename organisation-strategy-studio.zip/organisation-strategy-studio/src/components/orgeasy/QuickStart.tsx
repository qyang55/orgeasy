import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  CheckCircle2,
  Circle,
  FileDown,
  GitCompareArrows,
  Globe2,
  Network,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { readGuidedDemo, subscribeGuidedDemo } from "@/lib/orgeasy/guided-demo";

/**
 * First-visit quick-start checklist: a small, dismissible card that points new
 * users at the four moments that matter — current state, an impact
 * simulation, cost/risk/health, and the board pack export. It auto-shows
 * once, never nags again after dismissal, and can be replayed from the
 * sidebar footer via QUICKSTART_REPLAY_EVENT.
 */

const DISMISS_KEY = "orgeasy.quickstart.v1.dismissed";
const DONE_KEY = "orgeasy.quickstart.v1.done";

export const QUICKSTART_REPLAY_EVENT = "orgeasy:replay-quickstart";

const ITEMS = [
  {
    id: "current",
    to: "/chart",
    icon: Network,
    title: "See the current state",
    body: "Your baseline organisation on a live canvas — drag roles to explore the structure.",
  },
  {
    id: "impact",
    to: "/impact",
    icon: GitCompareArrows,
    title: "Run an impact simulation",
    body: "Create a future phase and see the impact on cost and risk in seconds.",
  },
  {
    id: "risk",
    to: "/separation",
    icon: Globe2,
    title: "Review cost, risk & health",
    body: "Country guidance, transition cost ranges and the data health check behind the numbers.",
  },
  {
    id: "export",
    to: "/exports",
    icon: FileDown,
    title: "Export a board pack",
    body: "A presentation-ready leadership deck — cover, trade-offs, risks and next steps.",
  },
] as const;

function readDone(): string[] {
  try {
    const raw = window.localStorage.getItem(DONE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.filter((x) => typeof x === "string") : [];
  } catch {
    return [];
  }
}

function wasDismissed() {
  try {
    return window.localStorage.getItem(DISMISS_KEY) === "1";
  } catch {
    return false;
  }
}

/** True while the cookie/storage consent banner is still up (undecided). */
function consentPending() {
  try {
    return !window.localStorage.getItem("orgeasy.consent.v1");
  } catch {
    return false;
  }
}

export function QuickStart() {
  const [visible, setVisible] = useState(false);
  const [done, setDone] = useState<string[]>([]);
  const [demoActive, setDemoActive] = useState(false);
  const [bannerUp, setBannerUp] = useState(false);

  useEffect(() => {
    setDone(readDone());
    setVisible(!wasDismissed());
    setDemoActive(Boolean(readGuidedDemo()));
    setBannerUp(consentPending());
    const onConsent = () => setBannerUp(consentPending());
    window.addEventListener("orgeasy:consent-change", onConsent);
    const unsub = subscribeGuidedDemo(() => setDemoActive(Boolean(readGuidedDemo())));
    return () => {
      window.removeEventListener("orgeasy:consent-change", onConsent);
      unsub();
    };
  }, []);

  useEffect(() => {
    const replay = () => setVisible(true);
    window.addEventListener(QUICKSTART_REPLAY_EVENT, replay);
    return () => window.removeEventListener(QUICKSTART_REPLAY_EVENT, replay);
  }, []);

  if (!visible || demoActive) return null;

  const dismiss = () => {
    try {
      window.localStorage.setItem(DISMISS_KEY, "1");
    } catch {
      /* storage unavailable */
    }
    setVisible(false);
  };

  const markDone = (id: string) => {
    setDone((prev) => {
      if (prev.includes(id)) return prev;
      const next = [...prev, id];
      try {
        window.localStorage.setItem(DONE_KEY, JSON.stringify(next));
      } catch {
        /* storage unavailable */
      }
      return next;
    });
  };

  const doneCount = ITEMS.filter((i) => done.includes(i.id)).length;

  return (
    <aside
      aria-label="Quick start checklist"
      className={cn(
        "fixed left-6 z-40 w-[330px] max-w-[calc(100vw-3rem)] animate-in fade-in slide-in-from-bottom-3 rounded-2xl border border-border bg-card/95 shadow-overlay backdrop-blur duration-300",
        bannerUp ? "bottom-48" : "bottom-6",
      )}
    >
      <div className="flex items-start justify-between gap-3 px-5 pt-4">
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-brand">
            Quick start
          </p>
          <p className="mt-1 text-[14px] font-semibold leading-snug">
            From login to a board pack in about 15 minutes
          </p>
        </div>
        <button
          type="button"
          onClick={dismiss}
          aria-label="Dismiss quick start"
          className="rounded-md p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
        >
          <X className="size-4" />
        </button>
      </div>
      <ul className="space-y-1 px-3 py-3">
        {ITEMS.map((item) => {
          const isDone = done.includes(item.id);
          return (
            <li key={item.id}>
              <Link
                to={item.to}
                onClick={() => markDone(item.id)}
                className="group flex items-start gap-2.5 rounded-lg px-2 py-2 transition-colors hover:bg-secondary/70"
              >
                {isDone ? (
                  <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-success" />
                ) : (
                  <Circle className="mt-0.5 size-4 shrink-0 text-muted-foreground/50 transition-colors group-hover:text-brand" />
                )}
                <span className="min-w-0">
                  <span
                    className={cn(
                      "flex items-center gap-1.5 text-[12.5px] font-semibold",
                      isDone && "text-muted-foreground line-through decoration-muted-foreground/40",
                    )}
                  >
                    <item.icon className="size-3.5 text-brand" />
                    {item.title}
                  </span>
                  <span className="mt-0.5 block text-[11.5px] leading-snug text-muted-foreground">
                    {item.body}
                  </span>
                </span>
              </Link>
            </li>
          );
        })}
      </ul>
      <div className="flex items-center justify-between border-t border-border px-5 py-3">
        <span className="text-[11px] text-muted-foreground">
          {doneCount} of {ITEMS.length} explored
        </span>
        <button
          type="button"
          onClick={dismiss}
          className="text-[11.5px] font-medium text-muted-foreground underline-offset-2 transition-colors hover:text-foreground hover:underline"
        >
          Got it — don&apos;t show again
        </button>
      </div>
    </aside>
  );
}
